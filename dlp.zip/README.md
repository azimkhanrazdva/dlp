# AI DLP Diploma Project

This is a sanitized public version of a diploma project for an AI-assisted
Data Loss Prevention prototype. It keeps the application source code, endpoint
agent, browser extension, training/evaluation scripts, synthetic tests, and
presentation assets needed to understand the work.

The package intentionally excludes virtual environments, trained model
checkpoints, raw/processed datasets, logs, uploads, local configs, personal
files, and private credentials.

## Main Components

- `app/` - Flask web application, DLP engine, behavioral risk engine, storage,
  templates, and static UI assets.
- `agent/` - endpoint agent prototypes for Windows/POSIX plus local simulator.
- `browser_extension/` - browser-side DLP inspection extension.
- `scripts/` - dataset preparation, training, evaluation, regression, and chart
  generation utilities.
- `tests/` - unit and integration tests for scanner logic, storage, auth,
  behavioral scoring, API, and performance.
- `analysis/` and `presentation_package_max/` - sanitized figures and
  presentation materials.

## What Is Not Included

- `.venv/`
- `data/`
- `models/`
- `logs/`
- `agent_data/`
- `app/uploads/`
- local `config.json` and `local_settings.json`
- private documents, checkpoints, and generated reports

## Quick Start

```bash
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements_web.txt
python run_app.py
```

Open `http://127.0.0.1:5000`.

## Run Tests

```bash
pip install -r requirements_web.txt
pytest
```

## Notes

All examples are synthetic placeholders. Replace `.env.example` values before
using the project in a real environment, and never commit runtime secrets,
uploads, logs, datasets, or model checkpoints.
