$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$pythonExe = & (Join-Path $root "ensure_project_python.ps1")
& $pythonExe (Join-Path $root "run_agent.py")
