(function () {
  const inspectedForms = new WeakSet();

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  async function filePreview(file) {
    const safeText = ["text/plain", "text/csv", "application/json", "application/xml"];
    const meta = `filename=${file.name} size=${file.size} type=${file.type || "unknown"}`;
    if (!safeText.includes(file.type) || file.size > 1024 * 1024) {
      return meta;
    }
    try {
      const text = await file.text();
      return `${meta} preview=${text.slice(0, 4000)}`;
    } catch (_) {
      return meta;
    }
  }

  async function buildFormText(form) {
    const fields = [];
    const formData = new FormData(form);
    for (const [key, value] of formData.entries()) {
      if (value instanceof File) {
        if (value.name) {
          fields.push(await filePreview(value));
        }
      } else if (String(value || "").trim()) {
        fields.push(`${key}=${normalizeText(value).slice(0, 2000)}`);
      }
    }
    return fields.join("\n").slice(0, 24000);
  }

  async function inspectAndMaybeBlock(payload, onAllow) {
    const response = await chrome.runtime.sendMessage({
      type: "securemail-inspect",
      channel: payload.channel,
      platform: payload.platform,
      destination: payload.destination,
      text: payload.text
    });
    if (!response?.ok) {
      return onAllow();
    }
    const verdict = response.payload || {};
    if (verdict.allowed) {
      return onAllow();
    }
    const severity = verdict.result?.severity || "HIGH";
    alert(`SecureMail Browser Guard blocked this action. Severity: ${severity}`);
  }

  document.addEventListener("submit", async (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || inspectedForms.has(form)) {
      return;
    }
    event.preventDefault();
    const text = await buildFormText(form);
    await inspectAndMaybeBlock(
      {
        channel: "web",
        platform: "Browser Form",
        destination: window.location.href,
        text: `url=${window.location.href}\n${text}`
      },
      () => {
        inspectedForms.add(form);
        form.requestSubmit();
        setTimeout(() => inspectedForms.delete(form), 1000);
      }
    );
  }, true);

  document.addEventListener("paste", async (event) => {
    const pastedText = event.clipboardData?.getData("text/plain") || "";
    if (normalizeText(pastedText).length < 32) {
      return;
    }
    const active = document.activeElement;
    const destination = active && "name" in active ? active.name || active.id || "clipboard-target" : "clipboard-target";
    await inspectAndMaybeBlock(
      {
        channel: "clipboard",
        platform: "Browser Paste",
        destination,
        text: `url=${window.location.href}\npaste=${pastedText.slice(0, 24000)}`
      },
      () => {}
    );
  }, true);
})();
