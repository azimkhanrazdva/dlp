async function hmacSignature(method, path, timestamp, body, key) {
  const encoder = new TextEncoder();
  const digest = await crypto.subtle.digest("SHA-256", body);
  const digestHex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  const payload = encoder.encode(`${method.toUpperCase()}\n${path}\n${timestamp}\n${digestHex}`);
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    encoder.encode(key),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", cryptoKey, payload);
  return Array.from(new Uint8Array(signature)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function loadSettings() {
  const defaults = {
    serverUrl: "http://127.0.0.1:5000",
    agentId: "",
    agentKey: "",
    actorEmail: "",
    platformLabel: "Browser Guard"
  };
  const stored = await chrome.storage.sync.get(defaults);
  return { ...defaults, ...stored };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "securemail-inspect") {
    return false;
  }
  (async () => {
    const settings = await loadSettings();
    if (!settings.agentId || !settings.agentKey || !settings.actorEmail) {
      sendResponse({ ok: false, error: "Browser Guard is not configured yet." });
      return;
    }
    const path = "/api/agent/inspect";
    const bodyObj = {
      agent_id: settings.agentId,
      actor_email: settings.actorEmail,
      channel: message.channel || "web",
      platform: message.platform || settings.platformLabel || "Browser Guard",
      destination: message.destination || (sender.tab?.url || "browser"),
      text: message.text || ""
    };
    const raw = new TextEncoder().encode(JSON.stringify(bodyObj));
    const timestamp = String(Math.floor(Date.now() / 1000));
    const signature = await hmacSignature("POST", path, timestamp, raw, settings.agentKey);
    const response = await fetch(`${settings.serverUrl.replace(/\/$/, "")}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Agent-Id": settings.agentId,
        "X-Agent-Key": settings.agentKey,
        "X-Agent-Timestamp": timestamp,
        "X-Agent-Signature": signature
      },
      body: JSON.stringify(bodyObj)
    });
    const payload = await response.json();
    sendResponse({ ok: response.ok, payload });
  })().catch((error) => {
    sendResponse({ ok: false, error: error?.message || String(error) });
  });
  return true;
});
