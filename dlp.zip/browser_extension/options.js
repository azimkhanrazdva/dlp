const fields = ["serverUrl", "actorEmail", "agentId", "agentKey", "platformLabel"];

async function restore() {
  const stored = await chrome.storage.sync.get({
    serverUrl: "http://127.0.0.1:5000",
    actorEmail: "",
    agentId: "",
    agentKey: "",
    platformLabel: "Browser Guard"
  });
  for (const name of fields) {
    const input = document.getElementById(name);
    if (input) input.value = stored[name] || "";
  }
}

document.getElementById("save").addEventListener("click", async () => {
  const payload = {};
  for (const name of fields) {
    payload[name] = document.getElementById(name).value.trim();
  }
  await chrome.storage.sync.set(payload);
  document.getElementById("status").textContent = "Configuration saved.";
});

restore();
