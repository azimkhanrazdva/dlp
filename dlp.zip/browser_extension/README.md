# SecureMail Browser Guard

This browser extension is a companion control plane for web forms, cloud uploads and browser paste events.

What it does:

- intercepts HTML form submissions
- inspects pasted text in the browser
- extracts text previews from small text-based files
- sends signed DLP inspection requests to SecureMail `/api/agent/inspect`
- blocks submission when the SecureMail verdict is `HIGH` or `CRITICAL`

Setup:

1. Open your browser extension developer mode.
2. Load the `browser_extension` folder as an unpacked extension.
3. Open the extension options page.
4. Enter:
   - SecureMail server URL
   - actor email
   - per-agent `agent_id`
   - per-agent `agent_key`
5. Save settings.

Recommended use:

- pair the extension with the SecureMail endpoint agent
- use the same per-endpoint agent identity for browser and desktop controls
- keep the SecureMail backend on HTTPS in hosted deployments
