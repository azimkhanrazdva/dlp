import sys
from pathlib import Path

try:
    import servicemanager
    import win32event
    import win32service
    import win32serviceutil
except Exception:  # pragma: no cover
    servicemanager = None
    win32event = None
    win32service = None
    win32serviceutil = None

from agent.windows_agent import AgentConfig, EndpointAgent

AGENT_DIR = Path(__file__).resolve().parent


class SecureMailAgentService(win32serviceutil.ServiceFramework if win32serviceutil else object):
    _svc_name_ = "SecureMailEndpointAgent"
    _svc_display_name_ = "SecureMail Endpoint Agent"
    _svc_description_ = "Monitors clipboard, files and USB activity and sends DLP inspections to SecureMail."

    def __init__(self, args):
        if not win32serviceutil:
            raise RuntimeError("pywin32 is required to run the Windows service wrapper.")
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.running = True

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self.running = False
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        config_path = AGENT_DIR / "config.json"
        config = AgentConfig.load(config_path)
        agent = EndpointAgent(config, config_path=config_path)
        agent.enroll_if_needed()
        servicemanager.LogInfoMsg("SecureMail Endpoint Agent service started")
        while self.running:
            try:
                agent.heartbeat()
                agent.poll_clipboard()
                agent.poll_usb()
                agent.poll_directories()
            except Exception as exc:
                servicemanager.LogErrorMsg(f"SecureMail Endpoint Agent loop error: {exc}")
            rc = win32event.WaitForSingleObject(self.stop_event, int(config.poll_interval_sec * 1000))
            if rc == win32event.WAIT_OBJECT_0:
                break
        servicemanager.LogInfoMsg("SecureMail Endpoint Agent service stopped")


def main():
    if not win32serviceutil:
        print("pywin32 is not installed. Install it with: python -m pip install -r requirements_agent.txt")
        return 1
    win32serviceutil.HandleCommandLine(SecureMailAgentService)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
