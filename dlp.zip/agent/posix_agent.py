"""
SecureMail DLP Agent — Linux / macOS (POSIX) version.

Monitors clipboard, watched directories, and running processes.
Communicates with the SecureMail server via authenticated HTTPS.

Usage:
    python posix_agent.py --server http://localhost:5000 \\
                          --agent-id hostname:user \\
                          --api-key <key> \\
                          --watch /home/user/Downloads /tmp

Environment variables (alternative to flags):
    SECUREMAIL_SERVER_URL
    SECUREMAIL_AGENT_ID
    SECUREMAIL_API_KEY
    SECUREMAIL_WATCH_DIRS   (colon-separated paths)
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set

try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
except ImportError:
    print("ERROR: 'requests' package is required. Install with: pip install requests", file=sys.stderr)
    sys.exit(1)

AGENT_VERSION = "2.0.0"
PLATFORM = platform.system()  # "Linux" or "Darwin"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("dlp_posix_agent")

# ── Source code extensions that need special scrutiny ─────────────────────────
SOURCE_CODE_SUFFIXES = {
    ".py", ".js", ".ts", ".go", ".java", ".cs", ".cpp", ".c",
    ".rb", ".php", ".sh", ".bash", ".env", ".yaml", ".yml", ".toml",
}

# ── Files/dirs to never scan ──────────────────────────────────────────────────
SKIP_DIRS = {".git", "__pycache__", ".venv", "node_modules", ".tox"}

# ── Max file size to scan (bytes) ─────────────────────────────────────────────
MAX_FILE_BYTES = 4 * 1024 * 1024  # 4 MB


# ── HTTP client with retry ────────────────────────────────────────────────────
def _build_session(server_url: str) -> requests.Session:
    sess = requests.Session()
    retry = Retry(total=3, backoff_factor=0.5, status_forcelist=[502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    sess.mount("http://", adapter)
    sess.mount("https://", adapter)
    sess.headers.update({"User-Agent": f"SecureMail-POSIX-Agent/{AGENT_VERSION}"})
    return sess


# ── HMAC signing ──────────────────────────────────────────────────────────────
def _sign_request(body: bytes, api_key: str) -> Dict[str, str]:
    ts = str(int(time.time()))
    body_hash = hashlib.sha256(body).hexdigest()
    sig_data = f"{ts}.{body_hash}".encode()
    sig = hmac.new(api_key.encode(), sig_data, hashlib.sha256).hexdigest()
    return {"X-Agent-Timestamp": ts, "X-Agent-Signature": sig}


# ── Clipboard reading (POSIX) ─────────────────────────────────────────────────
def _read_clipboard() -> Optional[str]:
    if PLATFORM == "Darwin":
        try:
            return subprocess.check_output(["pbpaste"], text=True, timeout=2)
        except Exception:
            return None
    # Linux: try xclip, then xsel, then wl-paste (Wayland)
    for cmd in [["xclip", "-selection", "clipboard", "-o"],
                ["xsel", "--clipboard", "--output"],
                ["wl-paste"]]:
        if shutil.which(cmd[0]):
            try:
                return subprocess.check_output(cmd, text=True, timeout=2)
            except Exception:
                continue
    return None


# ── File text extraction ───────────────────────────────────────────────────────
def _extract_text(path: Path) -> str:
    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            try:
                import PyPDF2
                with open(path, "rb") as f:
                    reader = PyPDF2.PdfReader(f)
                    return " ".join(page.extract_text() or "" for page in reader.pages[:20])
            except Exception:
                return ""
        if suffix == ".zip":
            texts: List[str] = []
            budget = [20 * 1024 * 1024]  # 20MB total
            with zipfile.ZipFile(path) as zf:
                for entry in zf.infolist()[:50]:
                    if entry.file_size > 5 * 1024 * 1024 or entry.file_size > budget[0]:
                        continue
                    budget[0] -= entry.file_size
                    try:
                        data = zf.read(entry.filename)
                        texts.append(data.decode("utf-8", errors="ignore"))
                    except Exception:
                        continue
            return "\n".join(texts)
        # Plain text / source code
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(MAX_FILE_BYTES)
    except Exception:
        return ""


# ── Main Agent Class ──────────────────────────────────────────────────────────
class PosixDLPAgent:
    def __init__(
        self,
        server_url: str,
        agent_id: str,
        api_key: str,
        watch_dirs: List[Path],
        actor_email: str = "",
        heartbeat_interval: int = 60,
        clipboard_interval: int = 5,
        file_scan_interval: int = 120,
    ) -> None:
        self.server_url = server_url.rstrip("/")
        self.agent_id = agent_id
        self.api_key = api_key
        self.watch_dirs = [Path(d) for d in watch_dirs]
        self.actor_email = actor_email or f"{agent_id}@endpoint.local"
        self.heartbeat_interval = heartbeat_interval
        self.clipboard_interval = clipboard_interval
        self.file_scan_interval = file_scan_interval
        self.session = _build_session(server_url)
        self._last_clipboard: str = ""
        self._scanned_files: Dict[str, float] = {}  # path → mtime
        self._stop = threading.Event()

    def _post(self, endpoint: str, payload: dict) -> Optional[dict]:
        url = f"{self.server_url}{endpoint}"
        body = json.dumps(payload, ensure_ascii=False).encode()
        headers = _sign_request(body, self.api_key)
        headers["Content-Type"] = "application/json"
        try:
            resp = self.session.post(url, data=body, headers=headers, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:
            log.warning("POST %s failed: %s", endpoint, exc)
            return None

    def _send_heartbeat(self) -> None:
        payload = {
            "agent_id": self.agent_id,
            "api_key": self.api_key,
            "actor_email": self.actor_email,
            "hostname": platform.node(),
            "username": os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
            "platform": PLATFORM.lower(),
            "version": AGENT_VERSION,
            "active_channels": ["clipboard", "file"],
            "monitors": self.watch_dirs and [str(d) for d in self.watch_dirs] or [],
            "status": "online",
        }
        result = self._post("/api/agent/heartbeat", payload)
        if result:
            log.debug("Heartbeat OK")

    def _inspect_text(self, text: str, channel: str, platform_name: str = "", source: str = "") -> Optional[dict]:
        if not text or len(text.strip()) < 20:
            return None
        payload = {
            "agent_id": self.agent_id,
            "api_key": self.api_key,
            "actor_email": self.actor_email,
            "text": text[:8000],
            "channel": channel,
            "platform": platform_name or channel,
            "destination": "",
            "source_ref": source,
        }
        return self._post("/api/agent/inspect", payload)

    def _handle_result(self, result: dict, source: str = "") -> None:
        if not result:
            return
        inner = result.get("result") or {}
        severity = (inner.get("severity") or "SAFE").upper()
        summary = inner.get("summary") or ""
        if severity == "SAFE":
            return

        log.warning("[%s] %s — %s", severity, source or "clipboard", summary)

        # Show desktop notification (macOS: osascript, Linux: notify-send)
        msg = f"[{severity}] DLP Alert: {summary[:120]}"
        if PLATFORM == "Darwin":
            try:
                subprocess.run(
                    ["osascript", "-e", f'display notification "{msg}" with title "SecureMail DLP"'],
                    timeout=5, check=False,
                )
            except Exception:
                pass
        elif shutil.which("notify-send"):
            try:
                subprocess.run(["notify-send", "-u", "critical", "SecureMail DLP", msg], timeout=5, check=False)
            except Exception:
                pass

        if severity == "CRITICAL" and source:
            self._quarantine_file(Path(source))

    def _quarantine_file(self, path: Path) -> None:
        q_dir = Path.home() / ".securemail_quarantine"
        q_dir.mkdir(parents=True, exist_ok=True)
        try:
            dest = q_dir / f"{path.name}.{int(time.time())}.quarantined"
            path.rename(dest)
            log.info("Quarantined: %s → %s", path, dest)
        except Exception as exc:
            log.error("Failed to quarantine %s: %s", path, exc)

    def _poll_clipboard(self) -> None:
        while not self._stop.is_set():
            try:
                text = _read_clipboard()
                if text and text != self._last_clipboard:
                    self._last_clipboard = text
                    result = self._inspect_text(text, "clipboard")
                    if result:
                        self._handle_result(result, source="clipboard")
            except Exception as exc:
                log.debug("Clipboard poll error: %s", exc)
            self._stop.wait(self.clipboard_interval)

    def _scan_watched_dirs(self) -> None:
        while not self._stop.is_set():
            for watch_dir in self.watch_dirs:
                if not watch_dir.exists():
                    continue
                try:
                    self._scan_directory(watch_dir)
                except Exception as exc:
                    log.debug("Directory scan error %s: %s", watch_dir, exc)
            self._stop.wait(self.file_scan_interval)

    def _scan_directory(self, directory: Path) -> None:
        for item in directory.rglob("*"):
            if self._stop.is_set():
                return
            if item.is_dir():
                if item.name in SKIP_DIRS:
                    continue
                continue
            if not item.is_file():
                continue
            if item.stat().st_size > MAX_FILE_BYTES:
                continue
            mtime = item.stat().st_mtime
            key = str(item)
            if self._scanned_files.get(key) == mtime:
                continue
            self._scanned_files[key] = mtime
            text = _extract_text(item)
            if not text:
                continue
            channel = "file"
            if item.suffix.lower() in SOURCE_CODE_SUFFIXES:
                channel = "clipboard"  # source code treated with higher scrutiny
            result = self._inspect_text(text, channel, platform_name="filesystem", source=key)
            if result:
                self._handle_result(result, source=key)

    def _heartbeat_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._send_heartbeat()
            except Exception as exc:
                log.debug("Heartbeat error: %s", exc)
            self._stop.wait(self.heartbeat_interval)

    def run(self) -> None:
        log.info("SecureMail DLP POSIX Agent v%s starting", AGENT_VERSION)
        log.info("Agent ID: %s | Server: %s", self.agent_id, self.server_url)
        log.info("Watch dirs: %s", [str(d) for d in self.watch_dirs])

        threads = [
            threading.Thread(target=self._heartbeat_loop, daemon=True, name="heartbeat"),
            threading.Thread(target=self._poll_clipboard, daemon=True, name="clipboard"),
            threading.Thread(target=self._scan_watched_dirs, daemon=True, name="file_scan"),
        ]
        for t in threads:
            t.start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            log.info("Shutting down agent...")
            self._stop.set()


# ── CLI ───────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="SecureMail DLP POSIX Agent")
    parser.add_argument("--server", default=os.environ.get("SECUREMAIL_SERVER_URL", "http://localhost:5000"))
    parser.add_argument("--agent-id", default=os.environ.get("SECUREMAIL_AGENT_ID", f"{platform.node()}:{os.getlogin()}"))
    parser.add_argument("--api-key", default=os.environ.get("SECUREMAIL_API_KEY", ""))
    parser.add_argument("--actor-email", default=os.environ.get("SECUREMAIL_ACTOR_EMAIL", ""))
    parser.add_argument(
        "--watch",
        nargs="*",
        default=[p for p in os.environ.get("SECUREMAIL_WATCH_DIRS", "").split(":") if p],
    )
    parser.add_argument("--heartbeat-interval", type=int, default=60)
    parser.add_argument("--clipboard-interval", type=int, default=5)
    parser.add_argument("--file-scan-interval", type=int, default=120)
    parser.add_argument("--enroll", action="store_true", help="Enroll this agent with the server and get an API key")
    parser.add_argument("--enrollment-key", default=os.environ.get("SECUREMAIL_AGENT_ENROLLMENT_KEY", "example-enrollment-key"))
    args = parser.parse_args()

    if args.enroll:
        sess = _build_session(args.server)
        resp = sess.post(
            f"{args.server.rstrip('/')}/api/agent/enroll",
            json={
                "agent_id": args.agent_id,
                "hostname": platform.node(),
                "username": os.environ.get("USER", "agent"),
                "actor_email": args.actor_email or f"{os.environ.get('USER', 'agent')}@endpoint.local",
                "platform": PLATFORM.lower(),
                "version": AGENT_VERSION,
                "monitors": args.watch or [],
            },
            headers={"X-Agent-Enrollment-Key": args.enrollment_key},
            timeout=15,
        )
        if resp.ok:
            data = resp.json()
            print(f"Enrolled! Agent ID: {data['agent_id']}")
            print(f"API Key: {data['agent_key']}")
            print(f"\nAdd these to your config or pass as --api-key and --agent-id")
        else:
            print(f"Enrollment failed: {resp.status_code} {resp.text}")
        sys.exit(0 if resp.ok else 1)

    if not args.api_key:
        print("ERROR: --api-key is required. Run with --enroll first.", file=sys.stderr)
        sys.exit(1)

    agent = PosixDLPAgent(
        server_url=args.server,
        agent_id=args.agent_id,
        api_key=args.api_key,
        watch_dirs=args.watch or [],
        actor_email=args.actor_email,
        heartbeat_interval=args.heartbeat_interval,
        clipboard_interval=args.clipboard_interval,
        file_scan_interval=args.file_scan_interval,
    )
    agent.run()


if __name__ == "__main__":
    main()
