import json
import subprocess
import threading
from pathlib import Path
from tkinter import filedialog, messagebox
import tkinter as tk

import customtkinter as ctk

from agent.windows_agent import AgentConfig, EndpointAgent

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "agent" / "config.json"
LOG_PATH = ROOT / "agent_data" / "agent.log"
SERVICE_NAME = "SecureMailEndpointAgent"

BG = "#0b1220"
PANEL = "#121b2d"
PANEL2 = "#17233a"
PANEL_ALT = "#1d2a44"
BORDER = "#2d456c"
TEXT_COLOR = "#edf4ff"
MUTED = "#9fb2d1"
ACCENT = "#69b7ff"
SUCCESS = "#3ecf8e"
DANGER = "#ff6b88"
WARNING = "#ffc107"

SEVERITY_COLORS = {
    "SAFE": SUCCESS,
    "LOW": "#8bc34a",
    "MEDIUM": WARNING,
    "HIGH": "#ff9800",
    "CRITICAL": "#ff4d6b",
}


def powershell_command(script: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["powershell", "-NoProfile", "-Command", script],
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )


def _ctk_text_insert(widget: ctk.CTkTextbox, text: str) -> None:
    widget.configure(state="normal")
    widget.delete("0.0", "end")
    widget.insert("0.0", text)
    widget.configure(state="disabled")


class DesktopApp:
    def __init__(self) -> None:
        self.root = ctk.CTk()
        self.root.title("SecureMail — Endpoint Agent")
        self.root.geometry("1400x900")
        self.root.minsize(1200, 800)
        self.root.configure(fg_color=BG)

        self.config = AgentConfig.load(CONFIG_PATH)
        self.agent_process = None
        self._live_refresh_job = None

        self.server_var = ctk.StringVar(value=self.config.server_url)
        self.email_var = ctk.StringVar(value=self.config.actor_email)
        self.agent_id_var = ctk.StringVar(value=self.config.agent_id)
        self.agent_key_var = ctk.StringVar(value=self.config.agent_key)
        self.display_name_var = ctk.StringVar(value=self.config.display_name)
        self.enrollment_key_var = ctk.StringVar(value=self.config.enrollment_key)
        self.status_var = ctk.StringVar(value="Ready")
        self.service_status_var = ctk.StringVar(value="Unknown")
        self.header_service_var = ctk.StringVar(value="Unknown")
        self.header_server_var = ctk.StringVar(value=self.config.server_url or "Not configured")
        self.header_actor_var = ctk.StringVar(value=self.config.actor_email or "Not configured")

        self._build_ui()
        self.refresh_status()

    def _labeled_entry(self, parent, label: str, variable: ctk.StringVar, row: int) -> None:
        ctk.CTkLabel(
            parent,
            text=label,
            font=ctk.CTkFont("Segoe UI", 11),
            text_color=MUTED,
            anchor="w",
        ).grid(row=row, column=0, sticky="w", pady=8, padx=(0, 16))
        ctk.CTkEntry(
            parent,
            textvariable=variable,
            width=420,
            height=36,
            fg_color=PANEL_ALT,
            border_color=BORDER,
            text_color=TEXT_COLOR,
            font=ctk.CTkFont("Segoe UI", 11),
        ).grid(row=row, column=1, sticky="ew", pady=8)

    def _section_label(self, parent, text: str) -> ctk.CTkLabel:
        label = ctk.CTkLabel(
            parent,
            text=text,
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        )
        return label

    def _card_frame(self, parent, **kwargs) -> ctk.CTkFrame:
        return ctk.CTkFrame(parent, fg_color=PANEL, corner_radius=12, **kwargs)

    def _make_textbox(self, parent, height: int = 20, font_size: int = 10) -> ctk.CTkTextbox:
        box = ctk.CTkTextbox(
            parent,
            fg_color="#0d1828",
            text_color=TEXT_COLOR,
            font=ctk.CTkFont("Cascadia Code", font_size),
            corner_radius=8,
            border_color=BORDER,
            border_width=1,
            height=height * 18,
            wrap="word",
        )
        return box

    def _pill_button(self, parent, text: str, command, color=ACCENT, text_color="#000c1a", hover=None, width=140, height=34) -> ctk.CTkButton:
        return ctk.CTkButton(
            parent,
            text=text,
            command=command,
            fg_color=color,
            text_color=text_color,
            hover_color=hover or ACCENT,
            font=ctk.CTkFont("Segoe UI", 11, "bold"),
            corner_radius=8,
            width=width,
            height=height,
        )

    def _build_ui(self) -> None:
        shell = ctk.CTkFrame(self.root, fg_color=BG)
        shell.pack(fill="both", expand=True, padx=20, pady=20)

        self._build_header(shell)

        self.notebook = ctk.CTkTabview(
            shell,
            fg_color=PANEL,
            segmented_button_fg_color=PANEL2,
            segmented_button_selected_color=ACCENT,
            segmented_button_selected_hover_color="#93cbff",
            segmented_button_unselected_color=PANEL2,
            segmented_button_unselected_hover_color=PANEL_ALT,
            text_color=TEXT_COLOR,
            corner_radius=12,
        )
        self.notebook.pack(fill="both", expand=True, pady=(18, 0))

        self.notebook.add("Configuration")
        self.notebook.add("Service & Runtime")
        self.notebook.add("Manual Inspection")
        self.notebook.add("Live Monitor")
        self.notebook.add("Logs & Activity")

        self._build_config_tab(self.notebook.tab("Configuration"))
        self._build_control_tab(self.notebook.tab("Service & Runtime"))
        self._build_manual_tab(self.notebook.tab("Manual Inspection"))
        self._build_live_monitor_tab(self.notebook.tab("Live Monitor"))
        self._build_logs_tab(self.notebook.tab("Logs & Activity"))

        footer = ctk.CTkFrame(shell, fg_color=PANEL, corner_radius=10, height=50)
        footer.pack(fill="x", pady=(12, 0))
        footer.pack_propagate(False)

        ctk.CTkLabel(
            footer,
            textvariable=self.status_var,
            font=ctk.CTkFont("Segoe UI", 11),
            text_color=MUTED,
            anchor="w",
        ).pack(side="left", padx=16)

        self._pill_button(footer, "Refresh", self.refresh_status, color=PANEL_ALT, text_color=TEXT_COLOR, hover=PANEL2, width=110, height=30).pack(side="right", padx=12, pady=10)

    def _build_header(self, parent) -> None:
        header = ctk.CTkFrame(parent, fg_color=BG)
        header.pack(fill="x", pady=(0, 4))

        left = ctk.CTkFrame(header, fg_color=BG)
        left.pack(side="left", fill="x", expand=True)

        ctk.CTkLabel(
            left,
            text="SecureMail",
            font=ctk.CTkFont("Segoe UI", 28, "bold"),
            text_color=TEXT_COLOR,
        ).pack(anchor="w")

        ctk.CTkLabel(
            left,
            text="Endpoint DLP — Kazakhstan Data Protection",
            font=ctk.CTkFont("Segoe UI", 12),
            text_color=MUTED,
        ).pack(anchor="w", pady=(2, 0))

        right = ctk.CTkFrame(header, fg_color=PANEL, corner_radius=12)
        right.pack(side="right")

        metrics = [
            ("SERVER", self.header_server_var),
            ("ACTOR", self.header_actor_var),
            ("SERVICE", self.header_service_var),
        ]
        for label, var in metrics:
            pill = ctk.CTkFrame(right, fg_color=PANEL2, corner_radius=8)
            pill.pack(side="left", padx=10, pady=12, ipadx=10, ipady=6)
            ctk.CTkLabel(pill, text=label, font=ctk.CTkFont("Segoe UI", 9, "bold"), text_color=MUTED).pack()
            ctk.CTkLabel(pill, textvariable=var, font=ctk.CTkFont("Segoe UI", 11, "bold"), text_color=TEXT_COLOR).pack()

    def _build_config_tab(self, parent) -> None:
        layout = ctk.CTkFrame(parent, fg_color="transparent")
        layout.pack(fill="both", expand=True)
        layout.columnconfigure(0, weight=3)
        layout.columnconfigure(1, weight=2)

        form_card = self._card_frame(layout)
        form_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        ctk.CTkLabel(
            form_card,
            text="Connection & Identity",
            font=ctk.CTkFont("Segoe UI", 16, "bold"),
            text_color=TEXT_COLOR,
            anchor="w",
        ).pack(anchor="w", padx=20, pady=(20, 4))

        ctk.CTkLabel(
            form_card,
            text="Connect the workstation to SecureMail and define how this endpoint appears in the registry.",
            font=ctk.CTkFont("Segoe UI", 11),
            text_color=MUTED,
            wraplength=540,
            justify="left",
            anchor="w",
        ).pack(anchor="w", padx=20, pady=(0, 16))

        fields_frame = ctk.CTkFrame(form_card, fg_color="transparent")
        fields_frame.pack(fill="x", padx=20)
        fields_frame.columnconfigure(1, weight=1)

        data = [
            ("SecureMail server URL", self.server_var),
            ("Actor email", self.email_var),
            ("Agent ID", self.agent_id_var),
            ("Agent key", self.agent_key_var),
            ("Display name", self.display_name_var),
            ("Enrollment key", self.enrollment_key_var),
        ]
        for idx, (label, variable) in enumerate(data):
            self._labeled_entry(fields_frame, label, variable, idx)

        actions_frame = ctk.CTkFrame(form_card, fg_color="transparent")
        actions_frame.pack(fill="x", padx=20, pady=(20, 8))

        self._pill_button(actions_frame, "Save", self.save_config).pack(side="left")
        self._pill_button(actions_frame, "Enroll / Rotate", self.enroll_agent, color=SUCCESS, text_color="#07140d", hover="#60f0b4").pack(side="left", padx=10)
        self._pill_button(actions_frame, "Open folder", self.open_config_folder, color=PANEL_ALT, text_color=TEXT_COLOR, hover=PANEL2).pack(side="left")

        ctk.CTkLabel(
            form_card,
            text=f"Config: {CONFIG_PATH}",
            font=ctk.CTkFont("Segoe UI", 9),
            text_color=MUTED,
        ).pack(anchor="w", padx=20, pady=(4, 20))

        side = ctk.CTkFrame(layout, fg_color="transparent")
        side.grid(row=0, column=1, sticky="nsew")

        overview = self._card_frame(side)
        overview.pack(fill="x")
        ctk.CTkLabel(overview, text="Coverage overview", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 6))
        for line in ["Clipboard inspection", "File and archive inspection", "USB event monitoring", "Messenger and browser context tagging", "Simulator-driven QA scenarios"]:
            ctk.CTkLabel(overview, text=f"  {line}", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w").pack(anchor="w", padx=16, pady=3)
        ctk.CTkFrame(overview, fg_color="transparent", height=12).pack()

        flow = self._card_frame(side)
        flow.pack(fill="x", pady=(10, 0))
        ctk.CTkLabel(flow, text="Recommended flow", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 6))
        for idx, line in enumerate(["Save configuration", "Enroll endpoint", "Run service or foreground mode", "Monitor live events in Live Monitor tab"], start=1):
            ctk.CTkLabel(flow, text=f"  {idx}.  {line}", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w").pack(anchor="w", padx=16, pady=3)
        ctk.CTkFrame(flow, fg_color="transparent", height=12).pack()

    def _build_control_tab(self, parent) -> None:
        top = ctk.CTkFrame(parent, fg_color="transparent")
        top.pack(fill="x")
        top.columnconfigure((0, 1), weight=1)

        service = self._card_frame(top)
        service.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        ctk.CTkLabel(service, text="Windows Service", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 4))
        ctk.CTkLabel(service, text="Background service for persistent endpoint monitoring.", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w").pack(anchor="w", padx=16)

        svc_info = ctk.CTkFrame(service, fg_color=PANEL2, corner_radius=8)
        svc_info.pack(fill="x", padx=16, pady=12)
        ctk.CTkLabel(svc_info, text="STATUS", font=ctk.CTkFont("Segoe UI", 9, "bold"), text_color=MUTED).pack(anchor="w", padx=12, pady=(10, 2))
        ctk.CTkLabel(svc_info, textvariable=self.service_status_var, font=ctk.CTkFont("Segoe UI", 13, "bold"), text_color=TEXT_COLOR).pack(anchor="w", padx=12, pady=(0, 10))

        svc_btns = ctk.CTkFrame(service, fg_color="transparent")
        svc_btns.pack(fill="x", padx=16, pady=(0, 16))
        self._pill_button(svc_btns, "Install", self.install_service, width=110).pack(side="left")
        self._pill_button(svc_btns, "Start", self.start_service, color=SUCCESS, text_color="#07140d", hover="#60f0b4", width=90).pack(side="left", padx=6)
        self._pill_button(svc_btns, "Stop", self.stop_service, color=PANEL_ALT, text_color=TEXT_COLOR, hover=PANEL2, width=90).pack(side="left")
        self._pill_button(svc_btns, "Uninstall", self.uninstall_service, color=DANGER, text_color="#18070c", hover="#ff9bb0", width=110).pack(side="left", padx=6)

        runtime = self._card_frame(top)
        runtime.grid(row=0, column=1, sticky="nsew", padx=(8, 0))

        ctk.CTkLabel(runtime, text="Foreground Runtime", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 4))
        ctk.CTkLabel(runtime, text="Best for demos, live validation, and local troubleshooting.", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w").pack(anchor="w", padx=16)

        rt_btns = ctk.CTkFrame(runtime, fg_color="transparent")
        rt_btns.pack(fill="x", padx=16, pady=16)
        self._pill_button(rt_btns, "Run agent once", self.start_agent_process).pack(side="left")
        self._pill_button(rt_btns, "Stop foreground", self.stop_agent_process, color=PANEL_ALT, text_color=TEXT_COLOR, hover=PANEL2).pack(side="left", padx=10)

        coverage = self._card_frame(parent)
        coverage.pack(fill="both", expand=True, pady=(12, 0))

        ctk.CTkLabel(coverage, text="Operational Coverage", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 4))
        ctk.CTkLabel(coverage, text="What the endpoint agent currently observes and validates.", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w").pack(anchor="w", padx=16, pady=(0, 12))

        grid = ctk.CTkFrame(coverage, fg_color="transparent")
        grid.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        grid.columnconfigure((0, 1), weight=1)

        features_left = ["Clipboard monitoring with DLP inspection", "Signed API communication", "Desktop / Documents / Downloads monitoring"]
        features_right = ["USB event tracking", "Manual scan support", "Live Monitor with color-coded feed"]

        for col_idx, items in enumerate([features_left, features_right]):
            block = ctk.CTkFrame(grid, fg_color=PANEL2, corner_radius=10)
            block.grid(row=0, column=col_idx, sticky="nsew", padx=(0 if col_idx == 0 else 6, 6 if col_idx == 0 else 0))
            for item in items:
                ctk.CTkLabel(block, text=f"  {item}", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w", wraplength=500, justify="left").pack(anchor="w", padx=14, pady=8)

    def _build_manual_tab(self, parent) -> None:
        layout = ctk.CTkFrame(parent, fg_color="transparent")
        layout.pack(fill="both", expand=True)
        layout.columnconfigure((0, 1), weight=1)

        left = self._card_frame(layout)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        ctk.CTkLabel(left, text="Manual Inspection Input", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 4))
        ctk.CTkLabel(left, text="Paste text or choose a file to validate classification behavior.", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w").pack(anchor="w", padx=16, pady=(0, 10))

        ctk.CTkLabel(left, text="TEXT PAYLOAD", font=ctk.CTkFont("Segoe UI", 10, "bold"), text_color=MUTED).pack(anchor="w", padx=16)

        self.manual_text = ctk.CTkTextbox(
            left,
            fg_color="#0d1828",
            text_color=TEXT_COLOR,
            font=ctk.CTkFont("Cascadia Code", 10),
            corner_radius=8,
            border_color=BORDER,
            border_width=1,
            wrap="word",
        )
        self.manual_text.pack(fill="both", expand=True, padx=16, pady=(6, 10))

        manual_btns = ctk.CTkFrame(left, fg_color="transparent")
        manual_btns.pack(fill="x", padx=16, pady=(0, 16))
        self._pill_button(manual_btns, "Inspect text", self.inspect_text).pack(side="left")
        self._pill_button(manual_btns, "Inspect file", self.inspect_file, color=PANEL_ALT, text_color=TEXT_COLOR, hover=PANEL2).pack(side="left", padx=10)

        right = self._card_frame(layout)
        right.grid(row=0, column=1, sticky="nsew", padx=(8, 0))

        ctk.CTkLabel(right, text="Inspection Output", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 4))
        ctk.CTkLabel(right, text="Severity, indicators, actions, and raw server response are shown here.", font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w").pack(anchor="w", padx=16, pady=(0, 10))

        self.result_box = self._make_textbox(right)
        self.result_box.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.result_box.configure(state="disabled")

    def _build_live_monitor_tab(self, parent) -> None:
        top = ctk.CTkFrame(parent, fg_color="transparent")
        top.pack(fill="x", pady=(0, 10))
        top.columnconfigure(0, weight=1)
        top.columnconfigure(1, weight=1)
        top.columnconfigure(2, weight=1)

        # Status cards
        self._live_agent_status = self._status_card(top, "Агент", "Остановлен", DANGER)
        self._live_agent_status.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self._live_clip_status  = self._status_card(top, "Clipboard", "Мониторинг", SUCCESS)
        self._live_clip_status.grid(row=0, column=1, sticky="ew", padx=6)
        self._live_event_count  = self._status_card(top, "Событий сегодня", "0", ACCENT)
        self._live_event_count.grid(row=0, column=2, sticky="ew", padx=(6, 0))

        # Watched paths
        paths_card = self._card_frame(parent)
        paths_card.pack(fill="x", pady=(0, 10))
        inner = ctk.CTkFrame(paths_card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)
        ctk.CTkLabel(inner, text="Что мониторится прямо сейчас", font=ctk.CTkFont("Segoe UI", 13, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w")

        self._watch_paths_frame = ctk.CTkFrame(inner, fg_color=PANEL2, corner_radius=8)
        self._watch_paths_frame.pack(fill="x", pady=(8, 0))
        self._refresh_watch_paths()

        # Controls
        ctrl = ctk.CTkFrame(paths_card, fg_color="transparent")
        ctrl.pack(fill="x", padx=16, pady=(0, 12))
        self._pill_button(ctrl, "Запустить агент", self.start_agent_process, color=SUCCESS, text_color="#07140d", hover="#60f0b4").pack(side="left")
        self._pill_button(ctrl, "Остановить агент", self.stop_agent_process, color=DANGER, text_color="#fff", hover="#ff8fa3").pack(side="left", padx=8)
        self._pill_button(ctrl, "Открыть SOC-консоль", self._open_soc, color=ACCENT, text_color="#000c1a", hover="#93cbff").pack(side="left")

        # Live event feed
        feed_card = self._card_frame(parent)
        feed_card.pack(fill="both", expand=True)

        feed_header = ctk.CTkFrame(feed_card, fg_color="transparent")
        feed_header.pack(fill="x", padx=16, pady=(14, 6))
        ctk.CTkLabel(feed_header, text="Live feed (авто-обновление каждые 3 сек)", font=ctk.CTkFont("Segoe UI", 13, "bold"), text_color=TEXT_COLOR, anchor="w").pack(side="left")
        self._live_auto_var = ctk.StringVar(value="ON")
        ctk.CTkButton(
            feed_header, textvariable=self._live_auto_var, width=60, height=28,
            fg_color=PANEL_ALT, hover_color=PANEL2, text_color=TEXT_COLOR,
            font=ctk.CTkFont("Segoe UI", 10), corner_radius=6,
            command=self._toggle_live_refresh,
        ).pack(side="right")

        self.live_feed = tk.Text(
            feed_card,
            height=22, wrap="word",
            bg="#080f1c", fg=TEXT_COLOR,
            insertbackground=TEXT_COLOR,
            relief="flat", borderwidth=0,
            padx=14, pady=10,
            font=("Cascadia Code", 10),
            selectbackground="#31507c",
        )
        self.live_feed.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.live_feed.configure(state="disabled")

        # Colour tags
        self.live_feed.tag_configure("CRITICAL", foreground="#ff4d6b")
        self.live_feed.tag_configure("HIGH",     foreground="#ff9800")
        self.live_feed.tag_configure("MEDIUM",   foreground="#ffc107")
        self.live_feed.tag_configure("LOW",       foreground="#8bc34a")
        self.live_feed.tag_configure("SAFE",      foreground="#3ecf8e")
        self.live_feed.tag_configure("INFO",      foreground=MUTED)
        self.live_feed.tag_configure("TS",        foreground="#4a5a7a")

        self._live_last_lines = 0
        self._live_paused = False
        self._start_live_refresh()

    def _status_card(self, parent, label: str, value: str, color: str) -> ctk.CTkFrame:
        card = ctk.CTkFrame(parent, fg_color=PANEL, corner_radius=10)
        ctk.CTkLabel(card, text=label.upper(), font=ctk.CTkFont("Segoe UI", 9, "bold"), text_color=MUTED).pack(anchor="w", padx=14, pady=(12, 2))
        lbl = ctk.CTkLabel(card, text=value, font=ctk.CTkFont("Segoe UI", 16, "bold"), text_color=color)
        lbl.pack(anchor="w", padx=14, pady=(0, 12))
        card._value_label = lbl
        return card

    def _refresh_watch_paths(self) -> None:
        for w in self._watch_paths_frame.winfo_children():
            w.destroy()
        config = AgentConfig.load(CONFIG_PATH)
        monitors = [
            ("Clipboard",  "✓" if config.clipboard_enabled else "✗",  SUCCESS if config.clipboard_enabled else DANGER),
            ("USB-устройства", "✓" if config.usb_enabled else "✗",   SUCCESS if config.usb_enabled else DANGER),
            ("Файловая система", "✓" if config.directory_enabled else "✗", SUCCESS if config.directory_enabled else DANGER),
        ]
        for label, state, color in monitors:
            row = ctk.CTkFrame(self._watch_paths_frame, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=3)
            ctk.CTkLabel(row, text=state, font=ctk.CTkFont("Segoe UI", 12, "bold"), text_color=color, width=20).pack(side="left")
            ctk.CTkLabel(row, text=label, font=ctk.CTkFont("Segoe UI", 11), text_color=TEXT_COLOR).pack(side="left", padx=(6, 0))

        dirs = config.watch_directories or []
        if dirs:
            ctk.CTkLabel(self._watch_paths_frame, text="Папки:", font=ctk.CTkFont("Segoe UI", 10, "bold"), text_color=MUTED).pack(anchor="w", padx=12, pady=(8, 2))
            for d in dirs[:10]:
                ctk.CTkLabel(self._watch_paths_frame, text=f"  {d}", font=ctk.CTkFont("Cascadia Code", 9), text_color=MUTED, anchor="w").pack(anchor="w", padx=12)
        ctk.CTkFrame(self._watch_paths_frame, fg_color="transparent", height=8).pack()

    def _open_soc(self) -> None:
        base = self.server_var.get().rstrip("/") or "http://127.0.0.1:5000"
        url = f"{base}/admin"
        safe_url = url.replace("'", "")  # prevent PS string injection
        subprocess.run(["powershell", "-NoProfile", "-Command", f"Start-Process '{safe_url}'"], check=False)

    def _toggle_live_refresh(self) -> None:
        self._live_paused = not self._live_paused
        self._live_auto_var.set("ПАУЗА" if self._live_paused else "ON")

    def _start_live_refresh(self) -> None:
        self._do_live_refresh()

    def _do_live_refresh(self) -> None:
        if not self._live_paused:
            self._refresh_live_feed()
        self._live_refresh_job = self.root.after(3000, self._do_live_refresh)

    def _refresh_live_feed(self) -> None:
        if not LOG_PATH.exists():
            return
        try:
            lines = LOG_PATH.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            return

        if len(lines) == self._live_last_lines:
            return

        new_lines = lines[self._live_last_lines:]
        self._live_last_lines = len(lines)

        self.live_feed.configure(state="normal")
        for raw in new_lines:
            # Parse timestamp and message
            tag = "INFO"
            for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "SAFE"):
                if sev in raw.upper():
                    tag = sev
                    break
            # Timestamp part [YYYY-MM-DD HH:MM:SS]
            if raw.startswith("[") and "]" in raw:
                ts_end = raw.index("]") + 1
                self.live_feed.insert("end", raw[:ts_end] + " ", "TS")
                self.live_feed.insert("end", raw[ts_end:].strip() + "\n", tag)
            else:
                self.live_feed.insert("end", raw + "\n", tag)

        self.live_feed.see("end")
        self.live_feed.configure(state="disabled")

        # Count only real detections: lines with verdict= that are not SAFE
        total = sum(1 for l in lines if "verdict=" in l and "verdict=SAFE" not in l)
        self._live_event_count._value_label.configure(text=str(total))

        # Update agent status
        is_running = self.agent_process is not None and self.agent_process.poll() is None
        self._live_agent_status._value_label.configure(
            text="Запущен" if is_running else "Остановлен",
            text_color=SUCCESS if is_running else DANGER,
        )

    def _build_logs_tab(self, parent) -> None:
        header_card = self._card_frame(parent)
        header_card.pack(fill="x")

        ctk.CTkLabel(header_card, text="Agent Logs", font=ctk.CTkFont("Segoe UI", 14, "bold"), text_color=TEXT_COLOR, anchor="w").pack(anchor="w", padx=16, pady=(16, 4))
        ctk.CTkLabel(
            header_card,
            text="Review enrollment, runtime activity, and real inspections from the endpoint agent.",
            font=ctk.CTkFont("Segoe UI", 11),
            text_color=MUTED,
            anchor="w",
        ).pack(anchor="w", padx=16, pady=(0, 10))

        log_btns = ctk.CTkFrame(header_card, fg_color="transparent")
        log_btns.pack(fill="x", padx=16, pady=(0, 16))
        self._pill_button(log_btns, "Refresh logs", self.load_logs).pack(side="left")
        self._pill_button(log_btns, "Open agent_data", self.open_logs_folder, color=PANEL_ALT, text_color=TEXT_COLOR, hover=PANEL2).pack(side="left", padx=10)

        self.log_box = self._make_textbox(parent, height=30)
        self.log_box.pack(fill="both", expand=True, pady=(12, 0))
        self.log_box.configure(state="disabled")
        self.load_logs()

    def build_agent(self) -> EndpointAgent:
        self.sync_vars_to_config()
        return EndpointAgent(self.config, config_path=CONFIG_PATH)

    def sync_vars_to_config(self) -> None:
        self.config.server_url = self.server_var.get().strip()
        self.config.actor_email = self.email_var.get().strip()
        self.config.agent_id = self.agent_id_var.get().strip()
        self.config.agent_key = self.agent_key_var.get().strip()
        self.config.display_name = self.display_name_var.get().strip()
        self.config.enrollment_key = self.enrollment_key_var.get().strip()

    def sync_config_to_vars(self) -> None:
        self.server_var.set(self.config.server_url)
        self.email_var.set(self.config.actor_email)
        self.agent_id_var.set(self.config.agent_id)
        self.agent_key_var.set(self.config.agent_key)
        self.display_name_var.set(self.config.display_name)
        self.enrollment_key_var.set(self.config.enrollment_key)
        self.header_server_var.set(self.config.server_url or "Not configured")
        self.header_actor_var.set(self.config.actor_email or "Not configured")

    def set_status(self, text: str) -> None:
        self.status_var.set(text)

    def save_config(self) -> None:
        self.sync_vars_to_config()
        self.config.save(CONFIG_PATH)
        self.sync_config_to_vars()
        self.set_status("Configuration saved successfully.")

    def enroll_agent(self) -> None:
        self.set_status("Enrolling agent, please wait...")

        def worker():
            try:
                agent = self.build_agent()
                if agent.enroll_if_needed(force=True):
                    self.config = AgentConfig.load(CONFIG_PATH)
                    self.root.after(0, self.sync_config_to_vars)
                    self.root.after(0, lambda: self.set_status("Endpoint enrolled and agent key refreshed."))
                    self.root.after(0, lambda: messagebox.showinfo("SecureMail", "Agent enrollment completed successfully."))
                else:
                    self.root.after(0, lambda: messagebox.showerror("SecureMail", "Agent enrollment failed."))
                    self.root.after(0, lambda: self.set_status("Enrollment failed."))
            except Exception as exc:
                self.root.after(0, lambda e=exc: messagebox.showerror("SecureMail", str(e)))
                self.root.after(0, lambda: self.set_status("Enrollment error."))

        threading.Thread(target=worker, daemon=True).start()

    def inspect_text(self) -> None:
        text = self.manual_text.get("0.0", "end").strip()
        if not text:
            messagebox.showwarning("SecureMail", "Enter text to inspect.")
            return
        self.set_status("Running text inspection...")

        def worker():
            try:
                result = self.build_agent().inspect_text(text, "clipboard", "Windows Desktop App", "manual_scan")
                self.root.after(0, lambda: self.show_result(result))
                self.root.after(0, lambda: self.set_status("Manual text inspection completed."))
            except Exception as exc:
                self.root.after(0, lambda e=exc: messagebox.showerror("SecureMail", str(e)))
                self.root.after(0, lambda: self.set_status("Inspection failed."))

        threading.Thread(target=worker, daemon=True).start()

    def inspect_file(self) -> None:
        path = filedialog.askopenfilename()
        if not path:
            return
        self.set_status(f"Inspecting file: {Path(path).name}...")

        def worker():
            try:
                result = self.build_agent().inspect_file(Path(path), "file", "Windows Desktop App", str(Path(path).parent))
                self.root.after(0, lambda: self.show_result(result))
                self.root.after(0, lambda: self.set_status(f"File inspection completed: {Path(path).name}"))
            except Exception as exc:
                self.root.after(0, lambda e=exc: messagebox.showerror("SecureMail", str(e)))
                self.root.after(0, lambda: self.set_status("File inspection failed."))

        threading.Thread(target=worker, daemon=True).start()

    def _render_manual_result(self, result) -> str:
        if not result:
            return "No response returned from the inspection API."
        text_result = result.get("text_result") or {}
        indicators = text_result.get("indicators") or []
        actions = text_result.get("actions") or []
        lines = [
            f"Severity: {result.get('severity', 'UNKNOWN')}",
            f"Score: {result.get('score', 'n/a')}",
            f"Summary: {result.get('summary', 'No summary')}",
            f"Channel: {text_result.get('channel', 'n/a')}",
            "",
            "Recommended actions:",
        ]
        lines.extend([f"- {item}" for item in actions] if actions else ["- No explicit action suggestions returned."])
        lines.extend(["", "Matched indicators:"])
        if indicators:
            for item in indicators:
                lines.append(f"- {item.get('kind', 'indicator')} | {item.get('severity', 'n/a')} | {item.get('reason', 'No reason')} | value={item.get('value', '')}")
        else:
            lines.append("- No indicators were matched.")
        lines.extend(["", "Raw response:", json.dumps(result, indent=2, ensure_ascii=False)])
        return "\n".join(lines)

    def show_result(self, result) -> None:
        _ctk_text_insert(self.result_box, self._render_manual_result(result))

    def query_service_status(self) -> str:
        completed = powershell_command(f"sc.exe query {SERVICE_NAME}")
        raw = (completed.stdout or "") + (completed.stderr or "")
        upper = raw.upper()
        if "RUNNING" in upper:
            return "Running"
        if "STOPPED" in upper:
            return "Stopped"
        if "FAILED 1060" in upper or "DOES NOT EXIST" in upper:
            return "Not installed"
        return "Unknown"

    def run_script(self, script_name: str) -> None:
        subprocess.run(
            ["powershell", "-ExecutionPolicy", "Bypass", "-File", str(ROOT / "agent" / script_name)],
            check=False,
            cwd=str(ROOT),
        )

    def install_service(self) -> None:
        self.save_config()
        self.run_script("install_service.ps1")
        self.refresh_status()
        self.set_status("Service install command completed.")

    def uninstall_service(self) -> None:
        self.run_script("uninstall_service.ps1")
        self.refresh_status()
        self.set_status("Service uninstall command completed.")

    def start_service(self) -> None:
        subprocess.run(["powershell", "-NoProfile", "-Command", f"Start-Service -Name {SERVICE_NAME}"], check=False)
        self.refresh_status()
        self.set_status("Service start command completed.")

    def stop_service(self) -> None:
        subprocess.run(["powershell", "-NoProfile", "-Command", f"Stop-Service -Name {SERVICE_NAME} -Force"], check=False)
        self.refresh_status()
        self.set_status("Service stop command completed.")

    def start_agent_process(self) -> None:
        if self.agent_process and self.agent_process.poll() is None:
            self.set_status("Foreground agent is already running.")
            return
        self.save_config()
        self.agent_process = subprocess.Popen(
            [str(ROOT / ".venv" / "Scripts" / "python.exe"), str(ROOT / "run_agent.py")],
            cwd=str(ROOT),
        )
        self.set_status("Foreground agent started.")

    def stop_agent_process(self) -> None:
        if self.agent_process and self.agent_process.poll() is None:
            self.agent_process.terminate()
            self.set_status("Foreground agent stop requested.")
        else:
            self.set_status("No foreground agent process is running.")

    def load_logs(self) -> None:
        if not LOG_PATH.exists():
            _ctk_text_insert(self.log_box, "No logs yet.")
            return
        # Keep chronological order (oldest first, newest at bottom) — same as Live Monitor
        lines = LOG_PATH.read_text(encoding="utf-8", errors="ignore").splitlines()[-300:]
        _ctk_text_insert(self.log_box, "\n".join(lines))

    def open_config_folder(self) -> None:
        subprocess.run(["powershell", "-NoProfile", "-Command", f"ii '{CONFIG_PATH.parent}'"], check=False)

    def open_logs_folder(self) -> None:
        target = LOG_PATH.parent if LOG_PATH.parent.exists() else ROOT
        subprocess.run(["powershell", "-NoProfile", "-Command", f"ii '{target}'"], check=False)

    def refresh_status(self) -> None:
        self.sync_config_to_vars()
        service_status = self.query_service_status()
        self.service_status_var.set(service_status)
        self.header_service_var.set(service_status)
        self.load_logs()

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    app = DesktopApp()
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
