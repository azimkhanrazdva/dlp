import argparse
import ctypes
import ctypes.wintypes
import re
import datetime
import getpass
import hashlib
import hmac
import json
import mimetypes
import os
import shutil
import socket
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple
from urllib import error, parse, request


VERSION = "2.0.0"

# AI tool destinations — any browser tab navigating here with clipboard/file data = exfiltration risk
AI_TOOL_DOMAINS = {
    "chat.openai.com", "chatgpt.com", "claude.ai", "gemini.google.com",
    "copilot.microsoft.com", "bard.google.com", "perplexity.ai",
    "poe.com", "mistral.ai", "groq.com", "huggingface.co",
    "character.ai", "phind.com", "you.com",
}

FORENSIC_DIR = Path(__file__).resolve().parent.parent / "agent_data" / "forensics"
DEFAULT_PROCESS_MAP = {
    # Messengers
    "telegram": {"channel": "messenger", "platform": "Telegram"},
    "whatsapp": {"channel": "messenger", "platform": "WhatsApp"},
    "discord": {"channel": "messenger", "platform": "Discord"},
    "slack": {"channel": "messenger", "platform": "Slack"},
    "signal": {"channel": "messenger", "platform": "Signal"},
    "viber": {"channel": "messenger", "platform": "Viber"},
    "teams": {"channel": "messenger", "platform": "Microsoft Teams"},
    "skype": {"channel": "messenger", "platform": "Skype"},
    "wechat": {"channel": "messenger", "platform": "WeChat"},
    "line": {"channel": "messenger", "platform": "Line"},
    "icq": {"channel": "messenger", "platform": "ICQ"},
    # Browsers
    "chrome": {"channel": "web", "platform": "Chrome"},
    "msedge": {"channel": "web", "platform": "Edge"},
    "firefox": {"channel": "web", "platform": "Firefox"},
    "opera": {"channel": "web", "platform": "Opera"},
    "brave": {"channel": "web", "platform": "Brave"},
    # File managers / upload tools
    "filezilla": {"channel": "ftp", "platform": "FileZilla"},
    "winscp": {"channel": "ftp", "platform": "WinSCP"},
    "dropbox": {"channel": "cloud", "platform": "Dropbox"},
    "onedrive": {"channel": "cloud", "platform": "OneDrive"},
    "googledrivefs": {"channel": "cloud", "platform": "Google Drive"},
}

# Known messenger download/cache paths for Windows (appended to watch_directories)
MESSENGER_WATCH_PATHS: List[Dict[str, str]] = [
    {"env": "APPDATA",      "sub": "Telegram Desktop/Downloads",        "platform": "Telegram"},
    {"env": "APPDATA",      "sub": "Telegram Desktop/tdata",            "platform": "Telegram"},
    {"env": "LOCALAPPDATA", "sub": "WhatsApp/Attachment",               "platform": "WhatsApp"},
    {"env": "LOCALAPPDATA", "sub": "WhatsApp",                          "platform": "WhatsApp"},
    {"env": "APPDATA",      "sub": "discord/Cache",                     "platform": "Discord"},
    {"env": "APPDATA",      "sub": "Slack/Cache",                       "platform": "Slack"},
    {"env": "APPDATA",      "sub": "Signal/attachments.noindex",        "platform": "Signal"},
    {"env": "APPDATA",      "sub": "Microsoft/Teams/downloads",         "platform": "Teams"},
    {"env": "LOCALAPPDATA", "sub": "Viber/Downloads",                   "platform": "Viber"},
]


def powershell_json(command: str):
    completed = subprocess.run(
        ["powershell", "-NoProfile", "-Command", command],
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    raw = (completed.stdout or "").strip()
    if not raw:
        return []
    payload = json.loads(raw)
    return payload if isinstance(payload, list) else [payload]


def sha1_text(value: str) -> str:
    return hashlib.sha1(value.encode("utf-8", errors="ignore")).hexdigest()


def request_signature(method: str, path: str, timestamp: str, body: bytes, key: str) -> str:
    digest = hashlib.sha256(body).hexdigest()
    payload = f"{method.upper()}\n{path}\n{timestamp}\n{digest}".encode("utf-8")
    return hmac.new(key.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def read_text_preview(path: Path, limit: int = 16000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")[:limit]
    except Exception:
        return ""


def build_multipart(fields: Dict[str, str], files: Sequence[Path]) -> Tuple[bytes, str]:
    boundary = f"----SecureMailAgent{uuid.uuid4().hex}"
    parts: List[bytes] = []
    for key, value in fields.items():
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode())
        parts.append(str(value).encode("utf-8"))
        parts.append(b"\r\n")
    for path in files:
        mime_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(
            f'Content-Disposition: form-data; name="attachments"; filename="{path.name}"\r\n'.encode()
        )
        parts.append(f"Content-Type: {mime_type}\r\n\r\n".encode())
        parts.append(path.read_bytes())
        parts.append(b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


@dataclass
class AgentConfig:
    server_url: str
    agent_key: str
    actor_email: str
    agent_id: str = ""
    display_name: str = ""
    enrollment_key: str = ""
    heartbeat_interval_sec: int = 30
    poll_interval_sec: int = 6
    clipboard_enabled: bool = True
    usb_enabled: bool = True
    directory_enabled: bool = True
    kill_process_on_critical: bool = True
    clear_clipboard_on_high: bool = True
    quarantine_dir: str = "agent_data/quarantine"
    log_file: str = "agent_data/agent.log"
    max_upload_mb: int = 20
    max_files_per_cycle: int = 40
    recent_file_window_sec: int = 900
    allow_insecure_localhost: bool = True
    watch_directories: List[str] = field(default_factory=list)
    suspicious_extensions: List[str] = field(
        default_factory=lambda: [".txt", ".csv", ".log", ".json", ".env", ".ini", ".conf", ".cfg", ".sql", ".zip", ".rar", ".7z", ".png", ".jpg", ".jpeg", ".svg", ".pdf", ".docx", ".xlsx"]
    )
    process_map: Dict[str, Dict[str, str]] = field(default_factory=lambda: dict(DEFAULT_PROCESS_MAP))

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "AgentConfig":
        payload = {}
        if path and path.exists():
            payload = json.loads(path.read_text(encoding="utf-8"))
        else:
            payload = {
                "server_url": os.environ.get("SECUREMAIL_SERVER_URL", "http://127.0.0.1:5000"),
                "agent_key": os.environ.get("SECUREMAIL_AGENT_KEY", ""),
                "agent_id": os.environ.get("SECUREMAIL_AGENT_ID", ""),
                "display_name": os.environ.get("SECUREMAIL_AGENT_DISPLAY_NAME", ""),
                "enrollment_key": os.environ.get("SECUREMAIL_AGENT_ENROLLMENT_KEY", "example-enrollment-key"),
                "actor_email": os.environ.get("SECUREMAIL_AGENT_EMAIL", "analyst@example.test"),
            }
        if not payload.get("watch_directories"):
            home = Path.home()
            defaults = [home / "Desktop", home / "Documents", home / "Downloads"]
            dirs = [str(item) for item in defaults if item.exists()]
            # Auto-discover messenger download/attachment folders
            for entry in MESSENGER_WATCH_PATHS:
                base = os.environ.get(entry["env"], "")
                if base:
                    candidate = Path(base) / entry["sub"]
                    if candidate.exists():
                        dirs.append(str(candidate))
            payload["watch_directories"] = dirs
        return cls(**payload)

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "server_url": self.server_url,
            "agent_key": self.agent_key,
            "agent_id": self.agent_id,
            "display_name": self.display_name,
            "enrollment_key": self.enrollment_key,
            "actor_email": self.actor_email,
            "heartbeat_interval_sec": self.heartbeat_interval_sec,
            "poll_interval_sec": self.poll_interval_sec,
            "clipboard_enabled": self.clipboard_enabled,
            "usb_enabled": self.usb_enabled,
            "directory_enabled": self.directory_enabled,
            "kill_process_on_critical": self.kill_process_on_critical,
            "clear_clipboard_on_high": self.clear_clipboard_on_high,
            "quarantine_dir": self.quarantine_dir,
            "log_file": self.log_file,
            "max_upload_mb": self.max_upload_mb,
            "max_files_per_cycle": self.max_files_per_cycle,
            "recent_file_window_sec": self.recent_file_window_sec,
            "allow_insecure_localhost": self.allow_insecure_localhost,
            "watch_directories": self.watch_directories,
            "suspicious_extensions": self.suspicious_extensions,
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


class AgentApiClient:
    def __init__(self, config: AgentConfig) -> None:
        self.config = config

    def _headers(self, content_type: str = "application/json") -> Dict[str, str]:
        headers = {"Content-Type": content_type}
        if self.config.agent_key:
            headers["X-Agent-Key"] = self.config.agent_key
        if self.config.agent_id:
            headers["X-Agent-Id"] = self.config.agent_id
        return headers

    def _signed_headers(self, path: str, body: bytes, content_type: str = "application/json") -> Dict[str, str]:
        headers = self._headers(content_type)
        if self.config.agent_key:
            timestamp = str(int(time.time()))
            headers["X-Agent-Timestamp"] = timestamp
            headers["X-Agent-Signature"] = request_signature("POST", path, timestamp, body, self.config.agent_key)
        return headers

    def post_json(self, path: str, payload: Dict[str, object]) -> Dict[str, object]:
        data = json.dumps(payload).encode("utf-8")
        req = request.Request(
            self.config.server_url.rstrip("/") + path,
            data=data,
            headers=self._signed_headers(path, data),
            method="POST",
        )
        with request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))

    def post_multipart(self, path: str, fields: Dict[str, str], files: Sequence[Path]) -> Dict[str, object]:
        body, content_type = build_multipart(fields, files)
        req = request.Request(
            self.config.server_url.rstrip("/") + path,
            data=body,
            headers=self._signed_headers(path, body, content_type),
            method="POST",
        )
        with request.urlopen(req, timeout=60) as response:
            return json.loads(response.read().decode("utf-8"))


class EndpointAgent:
    def __init__(self, config: AgentConfig, config_path: Optional[Path] = None) -> None:
        self.config = config
        self.api = AgentApiClient(config)
        self.hostname = socket.gethostname()
        self.username = getpass.getuser()
        self.config_path = config_path
        self.root = Path.cwd()
        self.quarantine_dir = (self.root / config.quarantine_dir).resolve()
        self.log_path = (self.root / config.log_file).resolve()
        self.quarantine_dir.mkdir(parents=True, exist_ok=True)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        if self.config.server_url.startswith("http://") and not (
            self.config.allow_insecure_localhost
            and any(host in self.config.server_url for host in ["127.0.0.1", "localhost"])
        ):
            raise RuntimeError("Insecure server_url is blocked for remote deployments. Use HTTPS or localhost.")
        if not self.config.agent_id:
            self.config.agent_id = f"{self.hostname}:{self.username}"
        if not self.config.display_name:
            self.config.display_name = f"{self.hostname} endpoint"
        self.last_clipboard_hash = ""
        self.last_heartbeat = 0.0
        self.known_devices: Dict[str, Dict[str, object]] = {}
        self.known_files: Dict[str, float] = {}
        self.suspicious_extensions = {ext.lower() for ext in self.config.suspicious_extensions}

    def should_ignore_path(self, path: Path) -> bool:
        try:
            resolved = path.resolve()
        except OSError:
            return True
        ignored_roots = {
            self.root.resolve(),
            self.quarantine_dir.resolve(),
            self.log_path.parent.resolve(),
        }
        if resolved == self.log_path:
            return True
        if self.config_path:
            try:
                if resolved == self.config_path.resolve():
                    return True
            except OSError:
                return True
        return any(root == resolved or root in resolved.parents for root in ignored_roots)

    def log(self, message: str) -> None:
        line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
        print(line)
        self.log_path.open("a", encoding="utf-8").write(line + "\n")

    def persist_config(self) -> None:
        if self.config_path:
            self.config.save(self.config_path)

    def enrollment_payload(self) -> Dict[str, object]:
        return {
            "agent_id": self.config.agent_id,
            "display_name": self.config.display_name,
            "actor_email": self.config.actor_email,
            "hostname": self.hostname,
            "username": self.username,
            "platform": "windows",
            "version": VERSION,
            "active_channels": ["clipboard", "device", "file", "messenger", "social", "web", "public_upload"],
            "monitors": ["clipboard", "usb", "filesystem", "process_context"],
            "enrollment_key": self.config.enrollment_key,
        }

    def enroll_if_needed(self, force: bool = False) -> bool:
        if not force and self.config.agent_key:
            return True
        try:
            req = request.Request(
                self.config.server_url.rstrip("/") + "/api/agent/enroll",
                data=json.dumps(self.enrollment_payload()).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with request.urlopen(req, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
            self.config.agent_id = str(payload.get("agent_id") or self.config.agent_id)
            self.config.agent_key = str(payload.get("agent_key") or self.config.agent_key)
            self.config.display_name = str(payload.get("display_name") or self.config.display_name)
            self.persist_config()
            self.log(f"agent enrolled: {self.config.agent_id}")
            return True
        except Exception as exc:
            self.log(f"agent enrollment failed: {exc}")
            return False

    def guarded_post_json(self, path: str, payload: Dict[str, object]) -> Dict[str, object]:
        try:
            return self.api.post_json(path, payload)
        except error.HTTPError as exc:
            if exc.code == 401 and self.enroll_if_needed(force=True):
                return self.api.post_json(path, payload)
            raise

    def guarded_post_multipart(self, path: str, fields: Dict[str, str], files: Sequence[Path]) -> Dict[str, object]:
        try:
            return self.api.post_multipart(path, fields, files)
        except error.HTTPError as exc:
            if exc.code == 401 and self.enroll_if_needed(force=True):
                return self.api.post_multipart(path, fields, files)
            raise

    def active_processes(self) -> List[str]:
        try:
            rows = powershell_json("Get-Process | Select-Object ProcessName | ConvertTo-Json -Compress")
            return [str(item.get("ProcessName", "")).lower() for item in rows]
        except Exception:
            return []

    def infer_channel_context(self, processes: Optional[List[str]] = None) -> Dict[str, str]:
        processes = processes or self.active_processes()
        for proc_name, mapping in self.config.process_map.items():
            if proc_name.lower() in processes:
                return mapping
        return {"channel": "clipboard", "platform": "Clipboard"}

    def heartbeat(self) -> None:
        now = time.time()
        if now - self.last_heartbeat < self.config.heartbeat_interval_sec:
            return
        payload = {
            "agent_id": self.config.agent_id,
            "display_name": self.config.display_name,
            "hostname": self.hostname,
            "username": self.username,
            "actor_email": self.config.actor_email,
            "platform": "windows",
            "version": VERSION,
            "status": "online",
            "active_channels": ["clipboard", "device", "file", "messenger", "social", "web", "public_upload"],
            "monitors": ["clipboard", "usb", "filesystem", "process_context"],
        }
        try:
            self.guarded_post_json("/api/agent/heartbeat", payload)
            self.last_heartbeat = now
        except Exception as exc:
            self.log(f"heartbeat failed: {exc}")

    def get_clipboard_text(self) -> str:
        try:
            completed = subprocess.run(
                ["powershell", "-NoProfile", "-Command", "Get-Clipboard -Raw"],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            return (completed.stdout or "").strip()
        except Exception:
            return ""

    def clear_clipboard(self) -> None:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value ''"],
            capture_output=True,
            text=True,
            timeout=8,
            check=False,
        )

    @staticmethod
    def _sanitize_ps_string(value: str) -> str:
        """Remove characters that could escape a PowerShell double-quoted string."""
        return re.sub(r'["\r\n`$;|&]', "", value)

    def apply_usb_policy(self, device_key: str, policy: str) -> None:
        if policy != "blocked":
            return
        safe_key = self._sanitize_ps_string(device_key)
        if not safe_key:
            self.log(f"apply_usb_policy: device_key contained only unsafe chars, skipping")
            return
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             f'$id = "{safe_key}"; Disable-PnpDevice -InstanceId $id -Confirm:$false'],
            capture_output=True, text=True, timeout=12, check=False,
        )
        if result.returncode != 0:
            self.log(f"apply_usb_policy failed (rc={result.returncode}): {result.stderr.strip()[:200]}")

    def kill_sensitive_processes(self, processes: Sequence[str]) -> None:
        active = set(self.active_processes())
        for proc_name, mapping in self.config.process_map.items():
            if proc_name in active and mapping["platform"].lower() in {p.lower() for p in processes}:
                subprocess.run(
                    ["powershell", "-NoProfile", "-Command", f"Get-Process {proc_name} -ErrorAction SilentlyContinue | Stop-Process -Force"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                    check=False,
                )

    def inspect_text(self, text: str, channel: str, platform: str, destination: str) -> Optional[Dict[str, object]]:
        if not text.strip():
            return None
        try:
            return self.guarded_post_json(
                "/api/agent/inspect",
                {
                    "agent_id": self.config.agent_id,
                    "actor_email": self.config.actor_email,
                    "channel": channel,
                    "platform": platform,
                    "destination": destination,
                    "text": text,
                },
            )
        except error.HTTPError as exc:
            self.log(f"inspect_text http error: {exc.code}")
        except Exception as exc:
            self.log(f"inspect_text failed: {exc}")
        return None

    def inspect_file(self, path: Path, channel: str, platform: str, destination: str) -> Optional[Dict[str, object]]:
        fields = {
            "agent_id": self.config.agent_id,
            "actor_email": self.config.actor_email,
            "channel": channel,
            "platform": platform,
            "destination": destination,
            "text": read_text_preview(path),
        }
        try:
            if path.stat().st_size <= self.config.max_upload_mb * 1024 * 1024:
                return self.guarded_post_multipart("/api/agent/inspect", fields, [path])
            return self.guarded_post_json(
                "/api/agent/inspect",
                {
                    **fields,
                    "attachment_names": [path.name],
                    "text": f"{fields['text']} filename={path.name} size_bytes={path.stat().st_size}",
                },
            )
        except Exception as exc:
            self.log(f"inspect_file failed for {path.name}: {exc}")
            return None

    def quarantine_file(self, path: Path) -> Optional[Path]:
        try:
            target = self.quarantine_dir / f"{uuid.uuid4().hex}_{path.name}"
            shutil.move(str(path), str(target))
            return target
        except Exception as exc:
            self.log(f"quarantine failed for {path}: {exc}")
            return None

    # ── Graduated enforcement ──────────────────────────────────────────────

    def _show_toast(self, title: str, message: str) -> None:
        try:
            # Sanitize: PowerShell single-quoted strings only need ' escaped as ''
            safe_title   = title.replace("'", "''").replace("\r", "").replace("\n", " ")
            safe_message = message.replace("'", "''").replace("\r", "").replace("\n", " ")
            script = (
                "Add-Type -AssemblyName System.Windows.Forms; "
                "$n = New-Object System.Windows.Forms.NotifyIcon; "
                "$n.Icon = [System.Drawing.SystemIcons]::Warning; "
                "$n.Visible = $true; "
                f"$n.ShowBalloonTip(8000, '{safe_title}', '{safe_message}', [System.Windows.Forms.ToolTipIcon]::Warning); "
                "Start-Sleep 9; $n.Dispose()"
            )
            subprocess.Popen(
                ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as exc:
            self.log(f"toast notification failed: {exc}")

    def _lock_workstation(self) -> None:
        try:
            ctypes.windll.user32.LockWorkStation()
            self.log("WORKSTATION LOCKED by DLP policy (CRITICAL event)")
        except Exception as exc:
            self.log(f"workstation lock failed: {exc}")

    def _collect_forensic_evidence(self, source_ref: str, severity: str, result: Dict) -> None:
        try:
            FORENSIC_DIR.mkdir(parents=True, exist_ok=True)
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            evidence_dir = FORENSIC_DIR / f"{ts}_{severity}"
            evidence_dir.mkdir(exist_ok=True)

            # Process list
            procs = subprocess.run(
                ["powershell", "-NoProfile", "-Command", "Get-Process | Select-Object Name,Id,CPU,WorkingSet | ConvertTo-Json"],
                capture_output=True, text=True, timeout=15, check=False,
            )
            (evidence_dir / "process_list.json").write_text(procs.stdout or "[]", encoding="utf-8")

            # Incident metadata
            meta = {
                "timestamp": ts,
                "severity": severity,
                "source": source_ref,
                "actor": self.config.actor_email,
                "agent_id": self.config.agent_id,
                "result_summary": (result or {}).get("summary", ""),
                "threat_categories": (result or {}).get("threat_categories", []),
            }
            (evidence_dir / "incident_meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

            # Screenshot (best-effort)
            try:
                screenshot_script = (
                    f"Add-Type -AssemblyName System.Windows.Forms; "
                    f"$bmp = [System.Drawing.Bitmap]::new([System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width, "
                    f"[System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height); "
                    f"$g = [System.Drawing.Graphics]::FromImage($bmp); "
                    f"$g.CopyFromScreen(0,0,0,0,$bmp.Size); "
                    f"$bmp.Save('{evidence_dir / 'screenshot.png'}'); $g.Dispose(); $bmp.Dispose()"
                )
                subprocess.run(
                    ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", screenshot_script],
                    capture_output=True, timeout=10, check=False,
                )
            except Exception:
                pass

            self.log(f"forensic evidence saved -> {evidence_dir}")
        except Exception as exc:
            self.log(f"evidence collection failed: {exc}")

    def _detect_ai_tool_in_browser(self) -> Optional[str]:
        """Check if any open browser tab is navigating to an AI tool."""
        try:
            # Check Chrome/Edge current URL via accessibility or URL bar title patterns
            title_script = "Get-Process | Where-Object {$_.MainWindowTitle -ne ''} | Select-Object -ExpandProperty MainWindowTitle"
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", title_script],
                capture_output=True, text=True, timeout=8, check=False,
            )
            titles_raw = result.stdout.lower()
            for domain in AI_TOOL_DOMAINS:
                domain_key = domain.split(".")[0]  # e.g. "chatgpt", "claude"
                if domain_key in titles_raw or domain.replace(".", " ") in titles_raw:
                    return domain
        except Exception:
            pass
        return None

    def handle_result(self, result: Dict[str, object], source_type: str, source_ref: str, active_platforms: Optional[List[str]] = None) -> None:
        """Graduated enforcement: WARNING → MUTE → BLOCK → LOCKDOWN based on severity."""
        inner = (result or {}).get("result") or result or {}
        severity = str(inner.get("severity", "SAFE")).upper()
        threat_categories = list(inner.get("threat_categories") or [])
        summary = str(inner.get("summary", ""))

        if severity == "SAFE":
            return

        self.log(f"[{severity}] {source_type} verdict={severity} source={source_ref} categories={threat_categories}")

        # ── LOW: Warning toast only ────────────────────────────────────────
        if severity == "LOW":
            self._show_toast(
                "DLP предупреждение",
                f"Обнаружены данные с низким риском в {source_type}. Убедитесь, что передача авторизована.",
            )
            return

        # ── MEDIUM: Block + toast + sound ─────────────────────────────────
        if severity == "MEDIUM":
            self._show_toast(
                "DLP: Передача заблокирована",
                f"Обнаружены чувствительные данные в {source_type}. Действие заблокировано. Обратитесь к руководителю.",
            )
            try:
                subprocess.run(["powershell", "-NoProfile", "-Command", "[console]::beep(880,400)"], check=False, timeout=3)
            except Exception:
                pass
            return

        # ── HIGH: Block + quarantine + clear clipboard + kill exfil process ─
        if severity == "HIGH":
            self._show_toast(
                "DLP БЛОКИРОВКА",
                f"ВЫСОКИЙ РИСК: {source_type} заблокирован. Инцидент создан. ИТ-отдел уведомлён.",
            )
            if self.config.clear_clipboard_on_high:
                self.clear_clipboard()
                self.log("clipboard cleared (HIGH)")
            if source_type == "file":
                try:
                    quarantined = self.quarantine_file(Path(source_ref))
                    if quarantined:
                        self.log(f"file quarantined -> {quarantined}")
                except Exception as exc:
                    self.log(f"quarantine error: {exc}")
            # Kill only the active exfiltration app (not everything)
            if active_platforms:
                self.kill_sensitive_processes(active_platforms)
                self.log(f"exfil processes terminated: {active_platforms}")
            return

        # ── CRITICAL: Full lockdown ────────────────────────────────────────
        if severity == "CRITICAL":
            self._show_toast(
                "🚨 DLP КРИТИЧЕСКИЙ ИНЦИДЕНТ",
                "КРИТИЧЕСКИЙ УРОВЕНЬ РИСКА. Рабочая станция будет заблокирована. ИТ-отдел уведомлён немедленно.",
            )
            # 1. Clear clipboard
            self.clear_clipboard()
            self.log("clipboard cleared (CRITICAL)")

            # 2. Quarantine file
            if source_type == "file":
                try:
                    quarantined = self.quarantine_file(Path(source_ref))
                    if quarantined:
                        self.log(f"file quarantined -> {quarantined}")
                except Exception as exc:
                    self.log(f"quarantine error: {exc}")

            # 3. Kill ALL sensitive processes
            all_platforms = list({v["platform"] for v in self.config.process_map.values()})
            self.kill_sensitive_processes(all_platforms)
            self.log("all sensitive processes terminated (CRITICAL)")

            # 4. Collect forensic evidence BEFORE locking
            self._collect_forensic_evidence(source_ref, severity, inner)

            # 5. Lock workstation
            if self.config.kill_process_on_critical:
                self._lock_workstation()

    def poll_clipboard(self) -> None:
        if not self.config.clipboard_enabled:
            return
        text = self.get_clipboard_text()
        if not text or len(text) < 12:
            return
        current_hash = sha1_text(text[:4000])
        if current_hash == self.last_clipboard_hash:
            return
        self.last_clipboard_hash = current_hash
        process_snapshot = self.active_processes()
        ctx = self.infer_channel_context(process_snapshot)

        # Elevate to HIGH if clipboard is being pasted into an AI tool
        ai_tool = self._detect_ai_tool_in_browser()
        if ai_tool:
            self.log(f"clipboard pasted into AI tool detected: {ai_tool}")
            ctx = {"channel": "web", "platform": f"AI Tool ({ai_tool})"}

        result = self.inspect_text(text, ctx["channel"], ctx["platform"], ctx["platform"])
        if result:
            self.handle_result(result, "clipboard", ctx["platform"], [ctx["platform"]])

    def poll_usb(self) -> None:
        if not self.config.usb_enabled:
            return
        try:
            rows = powershell_json(
                "$items = Get-CimInstance Win32_DiskDrive | Where-Object { $_.InterfaceType -eq 'USB' } | "
                "Select-Object Model, SerialNumber, DeviceID, PNPDeviceID, Status, Size, MediaType; "
                "if ($items) { $items | ConvertTo-Json -Compress } else { '[]' }"
            )
        except Exception:
            rows = []
        current = {}
        sync_payload = []
        for item in rows:
            key = str(item.get("PNPDeviceID") or item.get("DeviceID") or item.get("Model") or uuid.uuid4().hex)
            current[key] = item
            sync_payload.append(
                {
                    "device_key": key,
                    "device_name": item.get("Model") or "USB Device",
                    "serial": str(item.get("SerialNumber") or "").strip(),
                    "status": item.get("Status") or "Unknown",
                    "media_type": item.get("MediaType") or "Removable",
                    "size_bytes": int(item.get("Size") or 0),
                    "size_gb": round((int(item.get("Size") or 0) / (1024 ** 3)), 2) if item.get("Size") else None,
                    "connection_state": "connected",
                    "owner": self.config.actor_email,
                }
            )
            if key not in self.known_devices:
                try:
                    self.guarded_post_json(
                        "/api/agent/device-event",
                        {
                            "agent_id": self.config.agent_id,
                            "actor_email": self.config.actor_email,
                            "device_name": item.get("Model") or "USB Device",
                            "device_key": key,
                            "event": "connected",
                            "notes": f"serial={item.get('SerialNumber','')} size={item.get('Size','')}",
                            "policy": "review",
                        },
                    )
                except Exception as exc:
                    self.log(f"device connect event failed: {exc}")
        for key, item in list(self.known_devices.items()):
            if key not in current:
                try:
                    self.guarded_post_json(
                        "/api/agent/device-event",
                        {
                            "agent_id": self.config.agent_id,
                            "actor_email": self.config.actor_email,
                            "device_name": item.get("Model") or "USB Device",
                            "device_key": key,
                            "event": "disconnected",
                            "notes": f"serial={item.get('SerialNumber','')}",
                            "policy": "review",
                        },
                    )
                except Exception as exc:
                    self.log(f"device disconnect event failed: {exc}")
        try:
            sync_result = self.guarded_post_json(
                "/api/agent/device-sync",
                {
                    "actor_email": self.config.actor_email,
                    "agent_id": self.config.agent_id,
                    "devices": sync_payload,
                },
            )
            for device_key, policy in (sync_result.get("device_policies") or {}).items():
                if policy == "blocked":
                    self.apply_usb_policy(device_key, policy)
        except Exception as exc:
            self.log(f"device sync failed: {exc}")
        self.known_devices = current

    def _infer_file_channel(self, path: Path, default_ctx: Dict[str, str]) -> Dict[str, str]:
        """Override channel context when file lives inside a known messenger folder."""
        path_str = str(path).lower()
        for entry in MESSENGER_WATCH_PATHS:
            sub = entry["sub"].lower().replace("\\", "/")
            if sub.split("/")[0] in path_str.replace("\\", "/"):
                return {"channel": "messenger", "platform": entry["platform"]}
        return default_ctx

    def _is_hidden_windows(self, path: Path) -> bool:
        try:
            # GetFileAttributesW returns INVALID_FILE_ATTRIBUTES (0xFFFFFFFF) on error.
            # ctypes may sign-extend this to -1; mask to 32-bit unsigned to be safe.
            attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
            attrs_u32 = attrs & 0xFFFFFFFF
            if attrs_u32 == 0xFFFFFFFF:  # INVALID_FILE_ATTRIBUTES
                return False
            return bool(attrs_u32 & 0x2)  # FILE_ATTRIBUTE_HIDDEN
        except Exception:
            return False

    def poll_directories(self) -> None:
        if not self.config.directory_enabled:
            return
        processes = self.active_processes()
        ctx = self.infer_channel_context(processes)
        now = time.time()
        candidates: List[Tuple[float, Path, str]] = []
        for root in [Path(item) for item in self.config.watch_directories]:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                if self.should_ignore_path(path):
                    continue
                if path.suffix.lower() not in self.suspicious_extensions:
                    continue
                try:
                    stat = path.stat()
                except OSError:
                    continue
                key = str(path.resolve())
                modified = stat.st_mtime
                if self.known_files.get(key) == modified:
                    continue
                if now - modified > self.config.recent_file_window_sec:
                    self.known_files[key] = modified
                    continue
                candidates.append((modified, path, key))
        for modified, path, key in sorted(candidates, key=lambda item: item[0], reverse=True)[: max(1, self.config.max_files_per_cycle)]:
            self.known_files[key] = modified
            file_ctx = self._infer_file_channel(path, ctx)
            hidden_note = " [HIDDEN]" if self._is_hidden_windows(path) else ""
            result = self.inspect_file(path, file_ctx["channel"], file_ctx["platform"], str(path.parent) + hidden_note)
            if result:
                self.handle_result(result, "file", key, [file_ctx["platform"]])

    def run(self) -> None:
        self.log("SecureMail endpoint agent started")
        while True:
            self.heartbeat()
            self.poll_clipboard()
            self.poll_usb()
            self.poll_directories()
            time.sleep(self.config.poll_interval_sec)


def main() -> int:
    parser = argparse.ArgumentParser(description="SecureMail Windows Endpoint Agent")
    parser.add_argument("--config", type=str, default="agent/config.json")
    args = parser.parse_args()
    config_path = Path(args.config)
    config = AgentConfig.load(config_path)
    agent = EndpointAgent(config, config_path=config_path)
    agent.enroll_if_needed()
    try:
        agent.run()
    except KeyboardInterrupt:
        agent.log("agent stopped by user")
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
