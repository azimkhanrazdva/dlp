import subprocess
import threading
import time
import tkinter as tk
from typing import Optional

import customtkinter as ctk

from agent.endpoint_simulator import EndpointScenarioSimulator, SimulationScenario
from agent.windows_agent import EndpointAgent

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

BG = "#0b1220"
PANEL = "#121b2d"
PANEL2 = "#17233a"
BORDER = "#2d456c"
TEXT_COLOR = "#edf4ff"
MUTED = "#9fb2d1"
ACCENT = "#69b7ff"

STEP_ACTIVE_BORDER = "#69b7ff"
STEP_DONE_BORDER = "#3ecf8e"
STEP_IDLE_BORDER = BORDER

SEVERITY_COLORS = {
    "SAFE": "#3ecf8e",
    "LOW": "#8bc34a",
    "MEDIUM": "#ffc107",
    "HIGH": "#ff9800",
    "CRITICAL": "#ff4d6b",
    "ERROR": "#9fb2d1",
    "UNKNOWN": "#9fb2d1",
}

CATEGORY_COLORS = {
    "clipboard": "#69b7ff",
    "filesystem": "#ff9800",
    "internet": "#ab7df8",
    "usb": "#3ecf8e",
}

HIGHLIGHT_TAGS = {
    "email": "#4CAF50",
    "phone": "#00BCD4",
    "iin": "#FF9800",
    "iban": "#FF9800",
    "card": "#F44336",
    "api_key": "#E91E63",
    "secret": "#E91E63",
    "db_uri": "#E91E63",
    "credential": "#FF5722",
}

ANALYSIS_STEPS = [
    ("Text normalization", "Removing obfuscation: hxxps, [at], [dot]..."),
    ("Regex pattern matching", "Scanning 25+ patterns: emails, KZ phones, IINs, IBANs, cards..."),
    ("Entropy analysis", "Shannon entropy to detect high-randomness tokens..."),
    ("Heuristic scoring", "Scoring by pattern combination, bulk-leak detection..."),
    ("ML — Stage 1", "bert-base-multilingual: binary SAFE vs RISK..."),
    ("ML — Stage 2", "bert-base-multilingual: LOW / MEDIUM / HIGH / CRITICAL..."),
    ("ML — Stage 3", "bert-base-multilingual: secret & credential detector..."),
    ("Final verdict", "Aggregating all signals: heuristic + ML consensus..."),
]

HIGHLIGHT_PATTERNS = [
    ("email", r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"),
    ("phone", r"\+7[0-9]{10}"),
    ("iban", r"KZ[0-9]{2}[A-Z0-9]{3}[0-9]{13}"),
    ("card", r"\b(?:4[0-9]{3}|5[1-5][0-9]{2}|3[47][0-9]{2})[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}\b"),
    ("api_key", r"\bsk-[A-Za-z0-9\-_]{16,}\b"),
    ("secret", r"(?:SECRET|secret|_SECRET)[=:]\s*[^\s,\n]{8,}"),
    ("db_uri", r"(?:postgresql|redis|mongodb|mysql|sqlite)://[^\s\"']+"),
    ("credential", r"(?:PASSWORD|password|passwd|PASSWD|TOKEN|token)[=:]\s*[^\s,\n]{4,}"),
]

import re as _re


def _apply_syntax_highlight(text_widget: tk.Text, content: str) -> None:
    text_widget.configure(state="normal")
    text_widget.delete("1.0", "end")
    text_widget.insert("1.0", content)
    for tag_name, color in HIGHLIGHT_TAGS.items():
        text_widget.tag_configure(tag_name, foreground=color, font=("Cascadia Code", 10, "bold"))
    for tag_name, pattern in HIGHLIGHT_PATTERNS:
        for match in _re.finditer(pattern, content):
            start_line = content[: match.start()].count("\n") + 1
            start_col = match.start() - content[: match.start()].rfind("\n") - 1
            end_line = content[: match.end()].count("\n") + 1
            end_col = match.end() - content[: match.end()].rfind("\n") - 1
            text_widget.tag_add(tag_name, f"{start_line}.{start_col}", f"{end_line}.{end_col}")
    text_widget.configure(state="disabled")


class StepCard(tk.Frame):
    def __init__(self, parent, number: int, title: str, description: str, **kwargs):
        super().__init__(parent, bg=PANEL2, **kwargs)
        self.number = number
        self.title_str = title
        self.description_str = description
        self._state = "idle"
        self._dot_count = 0
        self._dot_job = None

        self.configure(relief="flat", highlightthickness=1, highlightbackground=STEP_IDLE_BORDER)

        left = tk.Frame(self, bg=PANEL2)
        left.pack(side="left", padx=(12, 10), pady=10)

        self.circle = tk.Label(
            left,
            text=str(number),
            bg=BORDER,
            fg=MUTED,
            font=("Segoe UI Semibold", 9),
            width=2,
            height=1,
            relief="flat",
        )
        self.circle.pack()

        body = tk.Frame(self, bg=PANEL2)
        body.pack(side="left", fill="both", expand=True, pady=8)

        self.title_label = tk.Label(
            body,
            text=title,
            bg=PANEL2,
            fg=TEXT_COLOR,
            font=("Segoe UI Semibold", 10),
            anchor="w",
        )
        self.title_label.pack(anchor="w")

        self.desc_label = tk.Label(
            body,
            text=description,
            bg=PANEL2,
            fg=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
            wraplength=360,
            justify="left",
        )
        self.desc_label.pack(anchor="w", pady=(2, 0))

        self.status_label = tk.Label(body, text="", bg=PANEL2, fg=ACCENT, font=("Segoe UI", 9), anchor="w")
        self.status_label.pack(anchor="w")

    def set_idle(self):
        self._state = "idle"
        self._stop_dots()
        self.configure(highlightbackground=STEP_IDLE_BORDER)
        self.circle.configure(bg=BORDER, fg=MUTED)
        self.title_label.configure(fg=TEXT_COLOR)
        self.status_label.configure(text="", fg=ACCENT)

    def set_active(self):
        self._state = "active"
        self.configure(highlightbackground=STEP_ACTIVE_BORDER)
        self.circle.configure(bg=ACCENT, fg="#000c1a")
        self.title_label.configure(fg=ACCENT)
        self.status_label.configure(text="processing...", fg=ACCENT)
        self._start_dots()

    def set_done(self):
        self._state = "done"
        self._stop_dots()
        self.configure(highlightbackground=STEP_DONE_BORDER)
        self.circle.configure(bg="#3ecf8e", fg="#07140d")
        self.title_label.configure(fg="#3ecf8e")
        self.status_label.configure(text="done", fg="#3ecf8e")

    def _start_dots(self):
        self._dot_count = 0
        self._animate_dots()

    def _animate_dots(self):
        if self._state != "active":
            return
        dots = "." * ((self._dot_count % 3) + 1)
        self.status_label.configure(text=f"processing{dots}")
        self._dot_count += 1
        self._dot_job = self.after(350, self._animate_dots)

    def _stop_dots(self):
        if self._dot_job:
            try:
                self.after_cancel(self._dot_job)
            except Exception:
                pass
            self._dot_job = None


class SimulatorWindow(ctk.CTkToplevel):
    def __init__(self, parent, agent: EndpointAgent, simulator: EndpointScenarioSimulator):
        super().__init__(parent)
        self.agent = agent
        self.simulator = simulator
        self._running = False
        self._stop_flag = False
        self._scenarios = simulator.scenarios()
        self._selected_id: Optional[str] = None
        self._step_cards: list[StepCard] = []

        self.title("DLP Visual Analyzer — Endpoint Simulator")
        self.geometry("1120x780")
        self.minsize(960, 700)
        self.configure(fg_color=BG)

        self._build_ui()
        self._populate_scenarios()

        self.after(100, self._on_ready)

    def _on_ready(self):
        if self._scenarios:
            self._select_scenario(self._scenarios[0].scenario_id)

    def _build_ui(self):
        root_frame = ctk.CTkFrame(self, fg_color=BG)
        root_frame.pack(fill="both", expand=True, padx=0, pady=0)

        header = ctk.CTkFrame(root_frame, fg_color=PANEL, height=56)
        header.pack(fill="x", padx=0, pady=0)
        header.pack_propagate(False)

        title_label = ctk.CTkLabel(
            header,
            text="DLP Visual Analyzer",
            font=ctk.CTkFont("Segoe UI", 20, "bold"),
            text_color=TEXT_COLOR,
        )
        title_label.pack(side="left", padx=20, pady=14)

        subtitle = ctk.CTkLabel(
            header,
            text="Step-by-step detection pipeline visualization",
            font=ctk.CTkFont("Segoe UI", 11),
            text_color=MUTED,
        )
        subtitle.pack(side="left", padx=(0, 20), pady=14)

        body = ctk.CTkFrame(root_frame, fg_color=BG)
        body.pack(fill="both", expand=True, padx=12, pady=12)

        self._build_left_panel(body)
        self._build_center_panel(body)
        self._build_right_panel(body)

    def _build_left_panel(self, parent):
        left = ctk.CTkFrame(parent, fg_color=PANEL, width=280, corner_radius=12)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        hdr = ctk.CTkFrame(left, fg_color=PANEL, height=40)
        hdr.pack(fill="x", padx=14, pady=(14, 0))
        hdr.pack_propagate(False)
        ctk.CTkLabel(
            hdr,
            text="SCENARIOS",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(side="left", anchor="w", pady=8)

        self._scenario_scroll = ctk.CTkScrollableFrame(left, fg_color=PANEL, scrollbar_button_color=BORDER)
        self._scenario_scroll.pack(fill="both", expand=True, padx=8, pady=(8, 0))

        btn_row = ctk.CTkFrame(left, fg_color=PANEL)
        btn_row.pack(fill="x", padx=12, pady=12)

        self._run_btn = ctk.CTkButton(
            btn_row,
            text="Run Scenario",
            command=self._run_selected,
            fg_color=ACCENT,
            text_color="#000c1a",
            hover_color="#93cbff",
            font=ctk.CTkFont("Segoe UI", 11, "bold"),
            height=36,
            corner_radius=8,
        )
        self._run_btn.pack(fill="x", pady=(0, 6))

        self._stop_btn = ctk.CTkButton(
            btn_row,
            text="Stop",
            command=self._stop_scenario,
            fg_color=PANEL2,
            text_color=MUTED,
            hover_color="#2d456c",
            font=ctk.CTkFont("Segoe UI", 11),
            height=32,
            corner_radius=8,
        )
        self._stop_btn.pack(fill="x")

    def _build_center_panel(self, parent):
        center = ctk.CTkFrame(parent, fg_color=PANEL, width=500, corner_radius=12)
        center.pack(side="left", fill="both", expand=True, padx=(0, 8))
        center.pack_propagate(False)

        payload_section = ctk.CTkFrame(center, fg_color=PANEL)
        payload_section.pack(fill="x", padx=14, pady=(14, 0))

        ctk.CTkLabel(
            payload_section,
            text="PAYLOAD",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(anchor="w")

        self._payload_frame = tk.Frame(center, bg=PANEL, relief="flat", highlightthickness=1, highlightbackground=BORDER)
        self._payload_frame.pack(fill="x", padx=14, pady=(6, 12))

        self._payload_text = tk.Text(
            self._payload_frame,
            height=7,
            bg="#0d1828",
            fg=TEXT_COLOR,
            insertbackground=TEXT_COLOR,
            relief="flat",
            borderwidth=0,
            padx=12,
            pady=10,
            font=("Cascadia Code", 10),
            selectbackground="#31507c",
            wrap="word",
            state="disabled",
        )
        self._payload_text.pack(fill="x")

        ctk.CTkLabel(
            center,
            text="ANALYSIS PIPELINE",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(anchor="w", padx=14, pady=(0, 6))

        steps_container = ctk.CTkScrollableFrame(center, fg_color=PANEL, scrollbar_button_color=BORDER)
        steps_container.pack(fill="both", expand=True, padx=14, pady=(0, 8))

        self._step_cards = []
        for idx, (title, description) in enumerate(ANALYSIS_STEPS, start=1):
            card = StepCard(steps_container, idx, title, description)
            card.pack(fill="x", pady=(0, 5))
            self._step_cards.append(card)

        progress_frame = ctk.CTkFrame(center, fg_color=PANEL)
        progress_frame.pack(fill="x", padx=14, pady=(0, 14))

        self._progress_bar = ctk.CTkProgressBar(
            progress_frame,
            height=6,
            corner_radius=3,
            fg_color=PANEL2,
            progress_color=ACCENT,
        )
        self._progress_bar.set(0)
        self._progress_bar.pack(fill="x")

    def _build_right_panel(self, parent):
        right = ctk.CTkFrame(parent, fg_color=PANEL, width=300, corner_radius=12)
        right.pack(side="left", fill="y")
        right.pack_propagate(False)

        ctk.CTkLabel(
            right,
            text="VERDICT",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(anchor="w", padx=14, pady=(14, 6))

        self._verdict_frame = ctk.CTkFrame(right, fg_color=PANEL2, corner_radius=10, height=90)
        self._verdict_frame.pack(fill="x", padx=14, pady=(0, 12))
        self._verdict_frame.pack_propagate(False)

        self._verdict_label = ctk.CTkLabel(
            self._verdict_frame,
            text="—",
            font=ctk.CTkFont("Segoe UI", 30, "bold"),
            text_color=MUTED,
        )
        self._verdict_label.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(
            right,
            text="INDICATORS",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(anchor="w", padx=14, pady=(0, 4))

        self._indicators_scroll = ctk.CTkScrollableFrame(right, fg_color=PANEL, height=200, scrollbar_button_color=BORDER)
        self._indicators_scroll.pack(fill="x", padx=14, pady=(0, 10))

        self._no_indicators_label = ctk.CTkLabel(
            self._indicators_scroll,
            text="No indicators yet",
            font=ctk.CTkFont("Segoe UI", 10),
            text_color=MUTED,
        )
        self._no_indicators_label.pack(pady=10)

        ctk.CTkLabel(
            right,
            text="ACTIONS",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(anchor="w", padx=14, pady=(0, 4))

        self._actions_scroll = ctk.CTkScrollableFrame(right, fg_color=PANEL, height=100, scrollbar_button_color=BORDER)
        self._actions_scroll.pack(fill="x", padx=14, pady=(0, 10))

        self._no_actions_label = ctk.CTkLabel(
            self._actions_scroll,
            text="No actions yet",
            font=ctk.CTkFont("Segoe UI", 10),
            text_color=MUTED,
        )
        self._no_actions_label.pack(pady=8)

        ctk.CTkLabel(
            right,
            text="METADATA",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(anchor="w", padx=14, pady=(0, 4))

        meta_frame = ctk.CTkFrame(right, fg_color=PANEL2, corner_radius=8)
        meta_frame.pack(fill="x", padx=14, pady=(0, 10))

        self._meta_channel = self._meta_row(meta_frame, "Channel", "—")
        self._meta_platform = self._meta_row(meta_frame, "Platform", "—")
        self._meta_duration = self._meta_row(meta_frame, "Duration", "—")

        # Incident section — shown only after result
        ctk.CTkLabel(
            right,
            text="INCIDENT",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=MUTED,
        ).pack(anchor="w", padx=14, pady=(0, 4))

        self._incident_frame = ctk.CTkFrame(right, fg_color=PANEL2, corner_radius=8)
        self._incident_frame.pack(fill="x", padx=14, pady=(0, 14))

        self._incident_label = ctk.CTkLabel(
            self._incident_frame,
            text="Нет инцидента",
            font=ctk.CTkFont("Segoe UI", 10),
            text_color=MUTED,
        )
        self._incident_label.pack(pady=8)

        self._incident_btn = ctk.CTkButton(
            self._incident_frame,
            text="Открыть в SOC-консоли",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            fg_color="#1a3a5c",
            hover_color="#243c62",
            text_color=ACCENT,
            height=32,
            corner_radius=8,
            command=self._open_incident_in_browser,
            state="disabled",
        )
        self._incident_btn.pack(fill="x", padx=10, pady=(0, 8))
        self._current_incident_id: Optional[int] = None

    def _meta_row(self, parent, label: str, value: str):
        row = ctk.CTkFrame(parent, fg_color=PANEL2)
        row.pack(fill="x", padx=10, pady=4)
        ctk.CTkLabel(row, text=label, font=ctk.CTkFont("Segoe UI", 9), text_color=MUTED, width=70, anchor="w").pack(side="left")
        val_label = ctk.CTkLabel(row, text=value, font=ctk.CTkFont("Segoe UI", 9, "bold"), text_color=TEXT_COLOR, anchor="w")
        val_label.pack(side="left", padx=(6, 0))
        return val_label

    def _populate_scenarios(self):
        for widget in self._scenario_scroll.winfo_children():
            widget.destroy()

        self._scenario_buttons = {}
        for scenario in self._scenarios:
            self._create_scenario_card(scenario)

    def _create_scenario_card(self, scenario: SimulationScenario):
        color = CATEGORY_COLORS.get(scenario.category, MUTED)
        severity_color = SEVERITY_COLORS.get(scenario.severity_hint.split("/")[0], MUTED)

        card = tk.Frame(
            self._scenario_scroll,
            bg=PANEL2,
            relief="flat",
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        card.pack(fill="x", pady=(0, 5))

        inner = tk.Frame(card, bg=PANEL2)
        inner.pack(fill="x", padx=10, pady=8)

        badge_row = tk.Frame(inner, bg=PANEL2)
        badge_row.pack(anchor="w", fill="x")

        cat_badge = tk.Label(
            badge_row,
            text=scenario.category.upper(),
            bg=color,
            fg="#000c1a",
            font=("Segoe UI", 7, "bold"),
            padx=5,
            pady=1,
        )
        cat_badge.pack(side="left")

        sev_badge = tk.Label(
            badge_row,
            text=scenario.severity_hint,
            bg=severity_color,
            fg="#000c1a",
            font=("Segoe UI", 7, "bold"),
            padx=5,
            pady=1,
        )
        sev_badge.pack(side="left", padx=(4, 0))

        title_label = tk.Label(
            inner,
            text=scenario.title,
            bg=PANEL2,
            fg=TEXT_COLOR,
            font=("Segoe UI", 10),
            anchor="w",
            wraplength=220,
            justify="left",
        )
        title_label.pack(anchor="w", pady=(4, 0))

        def on_click(s=scenario):
            self._select_scenario(s.scenario_id)

        for widget in [card, inner, badge_row, cat_badge, sev_badge, title_label]:
            widget.bind("<Button-1>", lambda e, fn=on_click: fn())
            widget.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=ACCENT))
            widget.bind("<Leave>", lambda e, c=card, sid=scenario.scenario_id: c.configure(
                highlightbackground=ACCENT if self._selected_id == sid else BORDER
            ))

        self._scenario_buttons[scenario.scenario_id] = card

    def _select_scenario(self, scenario_id: str):
        if self._running:
            return
        self._selected_id = scenario_id

        for sid, card in self._scenario_buttons.items():
            card.configure(highlightbackground=ACCENT if sid == scenario_id else BORDER)

        scenario = next((s for s in self._scenarios if s.scenario_id == scenario_id), None)
        if not scenario:
            return

        _apply_syntax_highlight(self._payload_text, scenario.payload)

        self._meta_channel.configure(text=scenario.channel)
        self._meta_platform.configure(text=scenario.platform)
        self._meta_duration.configure(text="—")

        self._reset_steps()
        self._reset_right_panel()

    def _reset_steps(self):
        for card in self._step_cards:
            card.set_idle()
        self._progress_bar.set(0)

    def _reset_right_panel(self):
        self._verdict_label.configure(text="—", text_color=MUTED)
        self._verdict_frame.configure(fg_color=PANEL2)

        for widget in self._indicators_scroll.winfo_children():
            widget.destroy()
        self._no_indicators_label = ctk.CTkLabel(
            self._indicators_scroll,
            text="No indicators yet",
            font=ctk.CTkFont("Segoe UI", 10),
            text_color=MUTED,
        )
        self._no_indicators_label.pack(pady=10)

        for widget in self._actions_scroll.winfo_children():
            widget.destroy()
        self._no_actions_label = ctk.CTkLabel(
            self._actions_scroll,
            text="No actions yet",
            font=ctk.CTkFont("Segoe UI", 10),
            text_color=MUTED,
        )
        self._no_actions_label.pack(pady=8)

        self._current_incident_id = None
        self._incident_label.configure(text="Нет инцидента", text_color=MUTED)
        self._incident_btn.configure(state="disabled")

    def _open_incident_in_browser(self):
        if self._current_incident_id is None:
            return
        server = getattr(self.agent.config, "server_url", "http://127.0.0.1:5000")
        url = f"{server.rstrip('/')}/incidents/{self._current_incident_id}"
        subprocess.run(["powershell", "-NoProfile", "-Command", f"Start-Process '{url}'"], check=False)

    def _run_selected(self):
        if self._running or not self._selected_id:
            return
        self._running = True
        self._stop_flag = False
        self._run_btn.configure(state="disabled", text="Running...")
        self._reset_steps()
        self._reset_right_panel()
        threading.Thread(target=self._run_worker, daemon=True).start()

    def _stop_scenario(self):
        self._stop_flag = True
        self._running = False
        self._run_btn.configure(state="normal", text="Run Scenario")
        for card in self._step_cards:
            if card._state == "active":
                card.set_idle()

    def _run_worker(self):
        scenario = next((s for s in self._scenarios if s.scenario_id == self._selected_id), None)
        if not scenario:
            self.after(0, self._finish_run)
            return

        start_time = time.monotonic()
        total_steps = len(self._step_cards)
        step_delay = 0.4

        for idx, card in enumerate(self._step_cards):
            if self._stop_flag:
                return

            self.after(0, card.set_active)
            time.sleep(step_delay)

            if self._stop_flag:
                return

            self.after(0, card.set_done)
            progress = (idx + 1) / total_steps
            self.after(0, lambda p=progress: self._progress_bar.set(p))

        if self._stop_flag:
            return

        try:
            result = self.simulator.run_scenario(scenario.scenario_id)
            duration = time.monotonic() - start_time

            self.after(0, lambda: self._show_result(result, duration))
        except Exception as exc:
            self.after(0, lambda e=exc: self._show_error(str(e)))
        finally:
            self.after(0, self._finish_run)

    def _finish_run(self):
        self._running = False
        self._stop_flag = False
        self._run_btn.configure(state="normal", text="Run Scenario")

    def _show_result(self, result, duration: float):
        severity = (result.severity or "UNKNOWN").upper().split("/")[0]
        color = SEVERITY_COLORS.get(severity, MUTED)

        self._verdict_label.configure(text=severity, text_color=color)
        self._verdict_frame.configure(fg_color=color + "22")

        self._meta_duration.configure(text=f"{duration:.1f}s")

        for widget in self._indicators_scroll.winfo_children():
            widget.destroy()

        raw = result.raw_result or {}
        result_node = raw.get("result") or raw.get("text_result") or {}
        indicators = result_node.get("indicators") or result.indicator_kinds or []

        if indicators:
            for item in indicators:
                if isinstance(item, dict):
                    kind = item.get("kind") or item.get("reason") or "indicator"
                    value = str(item.get("value") or "")
                    sev = str(item.get("severity") or "")
                else:
                    kind = str(item)
                    value = ""
                    sev = ""
                sev_color = SEVERITY_COLORS.get(sev.upper(), MUTED)
                self._add_indicator_card(kind, value, sev_color)
        else:
            ctk.CTkLabel(
                self._indicators_scroll,
                text="No indicators detected",
                font=ctk.CTkFont("Segoe UI", 10),
                text_color=MUTED,
            ).pack(pady=10)

        for widget in self._actions_scroll.winfo_children():
            widget.destroy()

        actions = result_node.get("actions") or result.actions or []
        if actions:
            for action in actions:
                ctk.CTkLabel(
                    self._actions_scroll,
                    text=f"- {action}",
                    font=ctk.CTkFont("Segoe UI", 9),
                    text_color=TEXT_COLOR,
                    wraplength=240,
                    justify="left",
                    anchor="w",
                ).pack(anchor="w", pady=2, padx=4)
        else:
            ctk.CTkLabel(
                self._actions_scroll,
                text="No specific actions recommended",
                font=ctk.CTkFont("Segoe UI", 10),
                text_color=MUTED,
            ).pack(pady=8)

        # Incident block
        incident_id = result.incident_id
        if incident_id:
            self._current_incident_id = incident_id
            sev_color = SEVERITY_COLORS.get(severity, MUTED)
            self._incident_label.configure(
                text=f"Инцидент #{incident_id} создан",
                text_color=sev_color,
            )
            self._incident_btn.configure(state="normal")
        else:
            self._incident_label.configure(text="Инцидент не создан (SAFE)", text_color=MUTED)
            self._incident_btn.configure(state="disabled")

    def _add_indicator_card(self, kind: str, value: str, sev_color: str):
        card = ctk.CTkFrame(self._indicators_scroll, fg_color=PANEL2, corner_radius=6)
        card.pack(fill="x", pady=(0, 4))

        top_row = ctk.CTkFrame(card, fg_color=PANEL2)
        top_row.pack(fill="x", padx=8, pady=(6, 0))

        kind_dot = tk.Label(top_row, text="●", bg=PANEL2, fg=sev_color, font=("Segoe UI", 8))
        kind_dot.pack(side="left")

        ctk.CTkLabel(
            top_row,
            text=kind,
            font=ctk.CTkFont("Segoe UI", 9, "bold"),
            text_color=TEXT_COLOR,
        ).pack(side="left", padx=(4, 0))

        if value:
            truncated = value[:38] + "..." if len(value) > 38 else value
            ctk.CTkLabel(
                card,
                text=truncated,
                font=ctk.CTkFont("Cascadia Code", 8),
                text_color=MUTED,
                anchor="w",
            ).pack(anchor="w", padx=8, pady=(2, 6))
        else:
            card.pack_configure(pady=(0, 4))
            ctk.CTkFrame(card, fg_color=PANEL2, height=2).pack()

    def _show_error(self, message: str):
        self._verdict_label.configure(text="ERROR", text_color=MUTED)
        self._verdict_frame.configure(fg_color=PANEL2)

        for widget in self._indicators_scroll.winfo_children():
            widget.destroy()

        ctk.CTkLabel(
            self._indicators_scroll,
            text=f"Error: {message[:120]}",
            font=ctk.CTkFont("Segoe UI", 9),
            text_color="#ff6b88",
            wraplength=240,
            justify="left",
        ).pack(pady=8, padx=4, anchor="w")

    def open_scenario(self, scenario_id: str):
        self._select_scenario(scenario_id)
        self._run_selected()
