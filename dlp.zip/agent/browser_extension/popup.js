// SecureMail DLP Guard — Popup Script
"use strict";

const DEFAULTS = {
  serverUrl: "http://localhost:5000",
  agentId: "",
  apiKey: "",
  enabled: true,
  scanClipboard: true,
  scanForms: true,
  blockHighRisk: true,
};

const ids = ["serverUrl", "agentId", "apiKey", "enabled", "scanClipboard", "scanForms", "blockHighRisk"];

function load() {
  chrome.storage.sync.get(DEFAULTS, (settings) => {
    for (const id of ids) {
      const el = document.getElementById(id);
      if (!el) continue;
      if (el.type === "checkbox") el.checked = Boolean(settings[id]);
      else el.value = settings[id] || "";
    }
    checkStatus(settings.serverUrl);
  });
}

async function checkStatus(serverUrl) {
  const dot = document.getElementById("statusDot");
  const text = document.getElementById("statusText");
  if (!serverUrl) {
    dot.className = "dot disabled";
    text.textContent = "Not configured";
    return;
  }
  try {
    const resp = await fetch(`${serverUrl}/health`, { signal: AbortSignal.timeout(3000) });
    if (resp.ok) {
      const data = await resp.json();
      dot.className = "dot";
      text.textContent = `Connected · ${data.status || "ok"}`;
    } else {
      dot.className = "dot offline";
      text.textContent = `Server error (${resp.status})`;
    }
  } catch {
    dot.className = "dot offline";
    text.textContent = "Cannot reach server";
  }
}

document.getElementById("saveBtn").addEventListener("click", () => {
  const settings = {};
  for (const id of ids) {
    const el = document.getElementById(id);
    if (!el) continue;
    settings[id] = el.type === "checkbox" ? el.checked : el.value;
  }
  chrome.storage.sync.set(settings, () => {
    const msg = document.getElementById("saveMsg");
    msg.style.display = "block";
    setTimeout(() => { msg.style.display = "none"; }, 2000);
    checkStatus(settings.serverUrl);
  });
});

load();
