// SecureMail DLP Guard — Content Script
// Monitors form submissions and clipboard paste events on all pages.
"use strict";

const DLP_VERSION = "1.0.0";

// ── Settings ──────────────────────────────────────────────────────────────────
let settings = {
  serverUrl: "http://localhost:5000",
  agentId: "",
  apiKey: "",
  enabled: true,
  scanClipboard: true,
  scanForms: true,
  blockHighRisk: true,
};

chrome.storage.sync.get(settings, (stored) => {
  Object.assign(settings, stored);
});

chrome.storage.onChanged.addListener((changes) => {
  for (const [key, { newValue }] of Object.entries(changes)) {
    settings[key] = newValue;
  }
});

// ── AI Tool Detection ─────────────────────────────────────────────────────────
const AI_DOMAINS = [
  "chatgpt.com", "chat.openai.com", "claude.ai", "gemini.google.com",
  "copilot.microsoft.com", "bard.google.com", "character.ai", "perplexity.ai",
  "poe.com", "you.com",
];

function isAiToolSite() {
  return AI_DOMAINS.some((d) => location.hostname.endsWith(d));
}

// ── DLP Scan ──────────────────────────────────────────────────────────────────
async function scanText(text, channel) {
  if (!settings.serverUrl || !settings.agentId || !settings.apiKey) return null;
  if (!text || text.trim().length < 20) return null;

  try {
    const resp = await fetch(`${settings.serverUrl}/api/agent/inspect`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        agent_id: settings.agentId,
        api_key: settings.apiKey,
        text: text.slice(0, 8000),
        channel: channel,
        platform: location.hostname,
        destination: location.hostname,
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!resp.ok) return null;
    return await resp.json();
  } catch {
    return null;
  }
}

// ── Warning Banner ────────────────────────────────────────────────────────────
function showWarningBanner(severity, summary) {
  const existing = document.getElementById("dlp-guard-banner");
  if (existing) existing.remove();

  const colors = { LOW: "#f59e0b", MEDIUM: "#f97316", HIGH: "#ef4444", CRITICAL: "#7f1d1d" };
  const bg = colors[severity] || "#6b7280";

  const banner = document.createElement("div");
  banner.id = "dlp-guard-banner";
  banner.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; z-index: 2147483647;
    background: ${bg}; color: white; padding: 12px 16px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 14px; display: flex; align-items: center; gap: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
  `;
  banner.innerHTML = `
    <strong>⚠ SecureMail DLP [${severity}]:</strong>
    <span style="flex:1">${summary || "Potential data leak detected"}</span>
    <button onclick="this.parentElement.remove()" style="background:transparent;border:1px solid rgba(255,255,255,0.5);color:white;padding:4px 10px;border-radius:4px;cursor:pointer">Dismiss</button>
  `;
  document.body.prepend(banner);
  setTimeout(() => banner.remove(), 12000);
}

// ── Clipboard Monitoring ──────────────────────────────────────────────────────
let _lastPastedText = "";

document.addEventListener("paste", async (e) => {
  if (!settings.enabled || !settings.scanClipboard) return;
  const text = e.clipboardData?.getData("text") || "";
  if (!text || text === _lastPastedText) return;
  _lastPastedText = text;

  const channel = isAiToolSite() ? "clipboard" : "clipboard";
  const result = await scanText(text, channel);
  if (!result) return;

  const severity = result?.result?.severity || "SAFE";
  if (severity === "SAFE" || severity === "LOW") return;

  showWarningBanner(severity, result?.result?.summary || "");

  if (settings.blockHighRisk && severity === "CRITICAL") {
    e.preventDefault();
    showWarningBanner("CRITICAL", "Paste blocked: critical data leak risk detected. Contact your IT security team.");
  }
}, true);

// ── Form Submit Monitoring ────────────────────────────────────────────────────
if (settings.scanForms && isAiToolSite()) {
  document.addEventListener("submit", async (e) => {
    if (!settings.enabled) return;
    const form = e.target;
    const textInputs = [...form.querySelectorAll("textarea, input[type=text]")];
    const text = textInputs.map((el) => el.value).join("\n").trim();
    if (!text || text.length < 30) return;

    const result = await scanText(text, "clipboard");
    if (!result) return;

    const severity = result?.result?.severity || "SAFE";
    if (severity === "SAFE" || severity === "LOW") return;

    showWarningBanner(severity, `[AI Tool Upload] ${result?.result?.summary || ""}`);

    if (settings.blockHighRisk && (severity === "HIGH" || severity === "CRITICAL")) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, true);
}

// ── Notify background of AI tool visit ───────────────────────────────────────
if (isAiToolSite()) {
  chrome.runtime.sendMessage({ type: "AI_TOOL_VISIT", hostname: location.hostname });
}
