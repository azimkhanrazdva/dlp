// SecureMail DLP Guard — Background Service Worker
"use strict";

// Track AI tool visits and notify
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === "AI_TOOL_VISIT") {
    chrome.storage.session.set({
      lastAiToolVisit: { hostname: msg.hostname, tab: sender.tab?.id, ts: Date.now() },
    });
    // Show badge to indicate AI tool monitoring is active
    chrome.action.setBadgeText({ text: "AI", tabId: sender.tab?.id });
    chrome.action.setBadgeBackgroundColor({ color: "#f97316", tabId: sender.tab?.id });
  }
});

// Clear badge when tab navigates away from AI tool
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete") {
    const AI_DOMAINS = [
      "chatgpt.com", "chat.openai.com", "claude.ai", "gemini.google.com",
      "copilot.microsoft.com",
    ];
    const isAi = AI_DOMAINS.some((d) => (tab.url || "").includes(d));
    if (!isAi) {
      chrome.action.setBadgeText({ text: "", tabId });
    }
  }
});
