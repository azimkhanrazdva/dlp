import json
import tempfile
import uuid
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from typing import Dict, List, Optional

from agent.windows_agent import EndpointAgent


@dataclass
class SimulationScenario:
    scenario_id: str
    title: str
    category: str
    channel: str
    platform: str
    destination: str
    mode: str
    severity_hint: str
    payload: str
    file_name: str = ""
    artifact_kind: str = "plain_text"
    notes: str = ""


@dataclass
class SimulationResult:
    scenario_id: str
    title: str
    category: str
    channel: str
    platform: str
    destination: str
    mode: str
    severity_hint: str
    started_at: str
    finished_at: str
    success: bool
    severity: str
    summary: str
    actions: List[str]
    indicator_count: int
    indicator_kinds: List[str]
    incident_id: Optional[int]
    message_id: Optional[int]
    allowed: Optional[bool]
    stored_content: Optional[bool]
    notes: str
    artifact_path: str = ""
    raw_result: Optional[Dict[str, object]] = None


class EndpointScenarioSimulator:
    def __init__(self, agent: EndpointAgent, root: Path) -> None:
        self.agent = agent
        self.root = root
        self.report_dir = self.root / "agent_data" / "simulator_reports"
        self.artifact_dir = self.report_dir / "artifacts"
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.artifact_dir.mkdir(parents=True, exist_ok=True)

    def scenarios(self) -> List[SimulationScenario]:
        return [
            SimulationScenario(
                scenario_id="telegram_banking_csv",
                title="Telegram — CSV с банковскими данными KZ",
                category="internet",
                channel="messenger",
                platform="Telegram",
                destination="Внешний чат Telegram",
                mode="file",
                severity_hint="CRITICAL",
                payload=(
                    "client_id,ИИН,ФИО,Телефон,IBAN,Баланс,Статус\n"
                    "1,870930400213,Сейткали Айгерим,+77012345678,KZ86125KZT5004100100,1250000,Активный\n"
                    "2,850720300147,Турегелді Диас,+77771234567,KZ24551KZT3409001200,890000,Активный\n"
                    "3,010412650089,Нурланова Асем,+77051234567,KZ19722KZT8800200345,3400000,VIP\n"
                    "4,960315450132,Бекова Жансая,+77752223344,KZ75125KZT2070001234,450000,Активный\n"
                    "5,771105300074,Ержан Бауыржан,+77073334455,KZ86125KZT5001234567,2100000,Активный\n"
                    "6,950820650031,Балтабек Айдос,+77614445566,KZ24551KZT3001234567,680000,Блокирован\n"
                ),
                file_name="kaspi_clients_export_2024.csv",
                notes=(
                    "Имитирует отправку CSV-файла с данными клиентов банка через Telegram. "
                    "Агент обнаруживает что Telegram.exe запущен, файл появляется в папке "
                    "Telegram Downloads — содержит ИИН, IBAN, телефоны KZ. "
                    "Ожидаемая реакция: CRITICAL, инцидент, блокировка."
                ),
            ),
            SimulationScenario(
                scenario_id="whatsapp_id_photo",
                title="WhatsApp — фото удостоверения личности KZ",
                category="internet",
                channel="messenger",
                platform="WhatsApp",
                destination="Внешний контакт WhatsApp",
                mode="text",
                severity_hint="HIGH",
                payload=(
                    "Удостоверение личности Республики Казахстан\n"
                    "Фамилия: НУРЛАНОВА\n"
                    "Имя: АСЕМ\n"
                    "ЖСН/ИИН: 010412650089\n"
                    "Дата рождения: 12.04.2001\n"
                    "Действителен до: 12.04.2031\n"
                    "Номер документа: N 7654321\n"
                    "Телефон владельца: +0 000 000 00 05\n"
                ),
                notes=(
                    "Имитирует пересылку фото удостоверения личности через WhatsApp. "
                    "OCR извлекает ИИН, номер документа и телефон. HIGH уровень угрозы."
                ),
            ),
            SimulationScenario(
                scenario_id="discord_hidden_folder_dump",
                title="Discord — дамп из скрытой папки",
                category="internet",
                channel="messenger",
                platform="Discord",
                destination="Discord сервер",
                mode="file",
                severity_hint="CRITICAL",
                payload=(
                    "# .secrets — HIDDEN FOLDER DUMP\n"
                    "OPENAI_API_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USE\n"
                    "DATABASE_URL=postgresql://admin:Pr0dS3cr3t@db.internal.kz:5432/production\n"
                    "TELEGRAM_BOT_TOKEN=EXAMPLE_TELEGRAM_BOT_TOKEN_DO_NOT_USE\n"
                    "AWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE\n"
                    "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n"
                    "KASPI_MERCHANT_KEY=sk-kaspi-7f3a9b2c1d4e5f6a8b9c0d1e2f3a4b5c\n"
                ),
                file_name=".env.production",
                notes=(
                    "Имитирует загрузку .env файла из скрытой папки через Discord. "
                    "Агент сканирует скрытые директории, обнаруживает критические секреты. "
                    "CRITICAL: содержит API ключи, БД URL, Telegram токен, AWS ключи."
                ),
            ),
            SimulationScenario(
                scenario_id="signal_medical_data",
                title="Signal — медицинские данные пациентов",
                category="internet",
                channel="messenger",
                platform="Signal",
                destination="Внешний Signal контакт",
                mode="text",
                severity_hint="HIGH",
                payload=(
                    "Пациент: Ахметов Нурлан Сейтович\n"
                    "ИИН: 820614350021\n"
                    "Дата рождения: 14.06.1982\n"
                    "Диагноз: F41.1 Генерализованное тревожное расстройство\n"
                    "Назначение: Сертралин 50мг\n"
                    "Телефон: +0 000 000 00 06\n"
                    "IBAN для возврата: KZ48125KZT9004567890\n"
                ),
                notes=(
                    "Имитирует передачу медицинских данных через Signal. "
                    "Содержит ИИН, диагноз, IBAN. HIGH/CRITICAL угроза — "
                    "нарушение медицинской тайны и закона о персональных данных РК."
                ),
            ),
            SimulationScenario(
                scenario_id="clipboard_safe_internal",
                title="Clipboard safe internal note",
                category="clipboard",
                channel="clipboard",
                platform="Clipboard",
                destination="Internal note",
                mode="text",
                severity_hint="SAFE",
                payload="Team sync at 16:00. Please confirm room booking and updated delivery checklist.",
                notes="Baseline clipboard scenario with benign business text.",
            ),
            SimulationScenario(
                scenario_id="clipboard_critical_db_url",
                title="Clipboard database URL leak",
                category="clipboard",
                channel="clipboard",
                platform="Clipboard",
                destination="Paste target",
                mode="text",
                severity_hint="CRITICAL",
                payload="DATABASE_URL=postgresql://admin:secretpass@prod-db.company.kz:5432/prod",
                notes="Tests critical detection through direct clipboard-style content.",
            ),
            SimulationScenario(
                scenario_id="telegram_secret_dump",
                title="Telegram secret dump",
                category="internet",
                channel="messenger",
                platform="Telegram Desktop",
                destination="External chat",
                mode="text",
                severity_hint="CRITICAL",
                payload="AWS_SECRET_ACCESS_KEY=EXAMPLE_AWS_SECRET_DO_NOT_USE\nclient_secret=EXAMPLE_CLIENT_SECRET_DO_NOT_USE",
                notes="Simulates secret exfiltration into messenger workflow.",
            ),
            SimulationScenario(
                scenario_id="discord_bot_token_leak",
                title="Discord bot token leak",
                category="internet",
                channel="messenger",
                platform="Discord",
                destination="External Discord server",
                mode="text",
                severity_hint="CRITICAL",
                payload="discord webhook https://discord.example.test/webhook/EXAMPLE_DO_NOT_USE",
                notes="Simulates sending a Discord webhook or bot credential through a desktop messenger workflow.",
            ),
            SimulationScenario(
                scenario_id="slack_webhook_leak",
                title="Slack webhook leak",
                category="internet",
                channel="messenger",
                platform="Slack",
                destination="Shared Slack workspace",
                mode="text",
                severity_hint="CRITICAL",
                payload="https://hooks.slack.com/services/T00000000/B00000000/abcdefghijklmnopqrstuvwxyz123456",
                notes="Simulates a Slack webhook leak from desktop communication.",
            ),
            SimulationScenario(
                scenario_id="whatsapp_finance_export",
                title="WhatsApp finance export leak",
                category="internet",
                channel="messenger",
                platform="WhatsApp",
                destination="Personal contact",
                mode="text",
                severity_hint="HIGH/CRITICAL",
                payload="Beneficiary,IBAN,Amount\nAlma K.,KZ86125KZT5004100100,250000\nDias T.,KZ24551KZT3409001200,185000",
                notes="Simulates sending structured financial transfer details over WhatsApp Desktop.",
            ),
            SimulationScenario(
                scenario_id="browser_public_form_db_uri",
                title="Browser public form credential leak",
                category="internet",
                channel="web",
                platform="Chrome",
                destination="Public web form",
                mode="text",
                severity_hint="CRITICAL",
                payload="redis://cache-admin:Pa55w0rd@corp-cache.company.kz:6379/0",
                notes="Simulates submitting infrastructure credentials to a browser form.",
            ),
            SimulationScenario(
                scenario_id="file_low_contacts_csv",
                title="Local file with bulk contacts",
                category="filesystem",
                channel="file",
                platform="Windows Explorer",
                destination="Desktop export",
                mode="file",
                severity_hint="LOW/MEDIUM",
                payload="name,email,phone\nAyan,ayan@example.com,+77011234567\nDana,dana@example.com,+77017654321\nMarat,marat@example.com,+77025551234\n",
                file_name="contacts_export.csv",
                notes="Simulates contact list leakage from local file system.",
            ),
            SimulationScenario(
                scenario_id="file_critical_env_dump",
                title="Local .env secret dump",
                category="filesystem",
                channel="file",
                platform="Windows Explorer",
                destination="Downloads folder",
                mode="file",
                severity_hint="CRITICAL",
                payload="OPENAI_API_KEY=sk-test-1234567890abcdefghijklmnop\nSESSION_SECRET=prod-session-secret\nDATABASE_URL=postgresql://admin:secretpass@prod-db.company.kz:5432/prod\n",
                file_name="prod.env",
                notes="Tests high-value secret detection inside a watched file artifact.",
            ),
            SimulationScenario(
                scenario_id="zip_secret_bundle",
                title="ZIP archive with secret bundle",
                category="filesystem",
                channel="file",
                platform="Windows Explorer",
                destination="Downloads folder",
                mode="file",
                severity_hint="CRITICAL",
                payload="DATABASE_URL=postgresql://admin:secretpass@prod-db.company.kz:5432/prod\nOPENAI_API_KEY=sk-test-1234567890abcdefghijklmnop\n",
                file_name="backup_secret_bundle.zip",
                artifact_kind="zip_text_entry",
                notes="Creates a real ZIP archive containing a text file with critical secrets.",
            ),
            SimulationScenario(
                scenario_id="rar_governed_review",
                title="RAR archive governed review",
                category="filesystem",
                channel="file",
                platform="Windows Explorer",
                destination="Downloads folder",
                mode="file",
                severity_hint="HIGH",
                payload="Protected archive placeholder with potential payroll export.",
                file_name="protected_payroll_backup.rar",
                artifact_kind="rar_placeholder",
                notes="Simulates a protected or unsupported RAR archive that should be escalated for review.",
            ),
            SimulationScenario(
                scenario_id="ocr_image_card_leak",
                title="OCR image payment card leak",
                category="filesystem",
                channel="file",
                platform="Windows Explorer",
                destination="Desktop screenshot",
                mode="file",
                severity_hint="HIGH",
                payload="Card 4111 1111 1111 1111\nExp 12/27\nCVV 123",
                file_name="card_screenshot.png",
                artifact_kind="ocr_png",
                notes="Creates an image with card data so the OCR path can be validated end-to-end.",
            ),
            SimulationScenario(
                scenario_id="usb_review_standard",
                title="USB insertion review event",
                category="usb",
                channel="device",
                platform="USB Device",
                destination="Endpoint device bus",
                mode="device",
                severity_hint="LOW/MEDIUM",
                payload="Routine removable media insertion detected during workstation activity.",
                notes="Simulates a normal USB insertion that should still be visible to admin.",
            ),
            SimulationScenario(
                scenario_id="usb_high_archive_export",
                title="USB archive export attempt",
                category="usb",
                channel="device",
                platform="USB Device",
                destination="Endpoint device bus",
                mode="device",
                severity_hint="HIGH",
                payload="Potential archive export to removable media. Contains backup dump and credential bundle.",
                notes="Simulates suspicious removable media usage with higher risk context.",
            ),
            SimulationScenario(
                scenario_id="kz_iin_bulk_leak",
                title="KZ IIN bulk export (Kaspi-style)",
                category="clipboard",
                channel="clipboard",
                platform="Clipboard",
                destination="External paste",
                mode="text",
                severity_hint="CRITICAL",
                payload=(
                    "Клиент,ИИН,Телефон,IBAN\n"
                    "Айгерим Сейткали,960315450132,+77012345678,KZ86125KZT5004100100\n"
                    "Диас Турегелді,850720300147,+77771234567,KZ24551KZT3409001200\n"
                    "Асем Нурланова,010412650089,+77051234567,KZ19722KZT8800200345\n"
                ),
                notes="Simulates bulk KZ personal data (IIN + phone + IBAN) copied to clipboard — common bank data leak pattern.",
            ),
            SimulationScenario(
                scenario_id="kz_passport_national_id",
                title="KZ national ID + passport data",
                category="filesystem",
                channel="file",
                platform="Windows Explorer",
                destination="Downloads folder",
                mode="file",
                severity_hint="HIGH",
                payload=(
                    "Удостоверение личности: N 5432167\n"
                    "ИИН: 870930400213\n"
                    "Дата рождения: 30.09.1987\n"
                    "Фамилия: Бекова\n"
                    "Имя: Жансая\n"
                    "Телефон: +7 702 555 1234\n"
                ),
                file_name="жансая_bekova_kyc.txt",
                notes="KZ national ID document data with IIN — high-risk personal data typical in KYC leaks.",
            ),
            SimulationScenario(
                scenario_id="kz_halyk_transfer_leak",
                title="Halyk Bank transfer details leak",
                category="internet",
                channel="messenger",
                platform="WhatsApp",
                destination="Personal contact",
                mode="text",
                severity_hint="HIGH",
                payload=(
                    "Банк: Halyk Bank Kazakhstan\n"
                    "Счёт получателя: KZ75125KZT2070001234\n"
                    "Сумма: 1 500 000 тенге\n"
                    "Назначение: Возврат займа\n"
                    "БИН организации: 991241000789\n"
                    "Контакт: +7 727 123 45 67\n"
                ),
                notes="Halyk Bank transfer details with IBAN and BIN — simulates payment data exfiltration via messenger.",
            ),
            SimulationScenario(
                scenario_id="kz_kaspi_credentials",
                title="Kaspi Bank API credentials leak",
                category="clipboard",
                channel="clipboard",
                platform="Clipboard",
                destination="External chat",
                mode="text",
                severity_hint="CRITICAL",
                payload=(
                    "KASPI_API_KEY=sk-kaspi-prod-7f3a9b2c1d4e5f6a8b9c0d1e\n"
                    "KASPI_SECRET=7b8c9d0e1f2a3b4c5d6e7f8a\n"
                    "DATABASE_URL=postgresql://kaspi_admin:Pr0d$ecret@db.kaspi.kz:5432/core\n"
                    "REDIS_URL=redis://:R3d1sPwd@cache.kaspi.kz:6379/0\n"
                ),
                notes="Simulates leak of Kaspi bank API credentials and database connection strings.",
            ),
            SimulationScenario(
                scenario_id="kz_employee_payroll_csv",
                title="Kazakhstan employee payroll CSV",
                category="filesystem",
                channel="file",
                platform="Windows Explorer",
                destination="USB or email",
                mode="file",
                severity_hint="CRITICAL",
                payload=(
                    "Сотрудник,ИИН,Зарплата,IBAN,Телефон\n"
                    "Нурлан Ахметов,820614350021,450000,KZ48125KZT9004567890,+77011112233\n"
                    "Гульмира Сейткали,910230400098,380000,KZ19722KZT8002345678,+77752223344\n"
                    "Бауыржан Ержан,771105300074,520000,KZ86125KZT5001234567,+77073334455\n"
                    "Айдос Балтабек,950820650031,290000,KZ24551KZT3001234567,+77614445566\n"
                ),
                file_name="жалақы_тізімі_2024.csv",
                notes="Full payroll sheet with KZ IINs, IBANs, salaries — CRITICAL bulk employee data leak.",
            ),
        ]

    def run_scenario(self, scenario_id: str) -> SimulationResult:
        scenario = next((item for item in self.scenarios() if item.scenario_id == scenario_id), None)
        if not scenario:
            raise ValueError(f"Unknown scenario: {scenario_id}")
        return self._execute_scenario(scenario)

    def run_all(self) -> Dict[str, object]:
        results = [self._execute_scenario(item) for item in self.scenarios()]
        report_paths = self._write_suite_report(results)
        return {
            "results": [asdict(item) for item in results],
            "report_json": str(report_paths["json"]),
            "report_html": str(report_paths["html"]),
            "summary": self._suite_summary(results),
        }

    def _execute_scenario(self, scenario: SimulationScenario) -> SimulationResult:
        started_at = datetime.now(timezone.utc).isoformat()
        raw_result: Dict[str, object] | None = None
        artifact_path = ""
        success = False
        error_summary = ""
        try:
            if scenario.mode == "text":
                raw_result = self.agent.inspect_text(
                    scenario.payload,
                    scenario.channel,
                    scenario.platform,
                    scenario.destination,
                )
            elif scenario.mode == "file":
                artifact = self._create_artifact_file(
                    scenario.file_name or f"{scenario.scenario_id}.txt",
                    scenario.payload,
                    artifact_kind=scenario.artifact_kind,
                )
                artifact_path = str(artifact)
                raw_result = self.agent.inspect_file(
                    artifact,
                    scenario.channel,
                    scenario.platform,
                    scenario.destination,
                )
            elif scenario.mode == "device":
                raw_result = self.agent.guarded_post_json(
                    "/api/agent/device-event",
                    {
                        "agent_id": self.agent.config.agent_id,
                        "actor_email": self.agent.config.actor_email,
                        "device_name": "Simulated USB Device",
                        "device_key": f"SIM-USB-{uuid.uuid4().hex[:8]}",
                        "event": "connected",
                        "notes": scenario.payload,
                        "policy": "review",
                    },
                )
            else:
                raise ValueError(f"Unsupported scenario mode: {scenario.mode}")
            success = raw_result is not None
        except Exception as exc:
            error_summary = str(exc)

        finished_at = datetime.now(timezone.utc).isoformat()
        parsed = self._parse_result(scenario, raw_result, success, error_summary)
        parsed.started_at = started_at
        parsed.finished_at = finished_at
        parsed.artifact_path = artifact_path
        parsed.raw_result = raw_result
        self._write_single_result(parsed)
        return parsed

    def _create_artifact_file(self, file_name: str, content: str, artifact_kind: str = "plain_text") -> Path:
        target = self.artifact_dir / f"{uuid.uuid4().hex}_{file_name}"
        if artifact_kind == "zip_text_entry":
            with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("secret_dump.txt", content)
            return target
        if artifact_kind == "rar_placeholder":
            target.write_bytes(content.encode("utf-8"))
            return target
        if artifact_kind == "ocr_png":
            self._create_ocr_png(target, content)
            return target
        target.write_text(content, encoding="utf-8")
        return target

    def _create_ocr_png(self, target: Path, content: str) -> None:
        try:
            from PIL import Image, ImageDraw, ImageFont
        except ImportError:
            target.write_text(content, encoding="utf-8")
            return
        lines = content.splitlines() or [content]
        width = 1100
        line_height = 54
        height = max(240, 80 + len(lines) * line_height)
        image = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(image)
        try:
            font = ImageFont.truetype("arial.ttf", 34)
        except Exception:
            font = ImageFont.load_default()
        y = 40
        for line in lines:
            draw.text((40, y), line, fill="black", font=font)
            y += line_height
        image.save(target)

    def _parse_result(
        self,
        scenario: SimulationScenario,
        raw_result: Optional[Dict[str, object]],
        success: bool,
        error_summary: str,
    ) -> SimulationResult:
        severity = "ERROR"
        summary = error_summary or "No result returned by endpoint agent."
        actions: List[str] = []
        indicator_kinds: List[str] = []
        indicator_count = 0
        incident_id = None
        message_id = None
        allowed = None
        stored_content = None

        if raw_result:
            result_node = raw_result.get("result") if isinstance(raw_result.get("result"), dict) else raw_result.get("event")
            if isinstance(result_node, dict):
                severity = str(result_node.get("severity") or raw_result.get("severity") or "UNKNOWN")
                summary = str(result_node.get("summary") or result_node.get("notes") or summary)
                actions = [str(item) for item in result_node.get("actions", [])] if isinstance(result_node.get("actions"), list) else []
                indicators = result_node.get("indicators", [])
                if isinstance(indicators, list):
                    indicator_kinds = [str(item.get("kind") or item.get("reason") or "indicator") for item in indicators[:12] if isinstance(item, dict)]
                    indicator_count = len(indicators)
            else:
                severity = str(raw_result.get("severity") or "UNKNOWN")
                summary = str(raw_result.get("message") or raw_result.get("error") or summary)

            incident_id = raw_result.get("incident_id")
            message_id = raw_result.get("message_id")
            allowed = raw_result.get("allowed") if "allowed" in raw_result else None
            stored_content = raw_result.get("stored_content") if "stored_content" in raw_result else None

        return SimulationResult(
            scenario_id=scenario.scenario_id,
            title=scenario.title,
            category=scenario.category,
            channel=scenario.channel,
            platform=scenario.platform,
            destination=scenario.destination,
            mode=scenario.mode,
            severity_hint=scenario.severity_hint,
            started_at="",
            finished_at="",
            success=success,
            severity=severity,
            summary=summary,
            actions=actions,
            indicator_count=indicator_count,
            indicator_kinds=indicator_kinds,
            incident_id=int(incident_id) if isinstance(incident_id, int) else None,
            message_id=int(message_id) if isinstance(message_id, int) else None,
            allowed=bool(allowed) if isinstance(allowed, bool) else None,
            stored_content=bool(stored_content) if isinstance(stored_content, bool) else None,
            notes=scenario.notes,
        )

    def _write_single_result(self, result: SimulationResult) -> None:
        file_path = self.report_dir / f"{result.scenario_id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
        payload = asdict(result)
        file_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def _suite_summary(self, results: List[SimulationResult]) -> Dict[str, object]:
        return {
            "total": len(results),
            "successful": sum(1 for item in results if item.success),
            "critical": sum(1 for item in results if item.severity.upper() == "CRITICAL"),
            "high": sum(1 for item in results if item.severity.upper() == "HIGH"),
            "medium": sum(1 for item in results if item.severity.upper() == "MEDIUM"),
            "low": sum(1 for item in results if item.severity.upper() == "LOW"),
            "safe": sum(1 for item in results if item.severity.upper() == "SAFE"),
            "incidents": sum(1 for item in results if item.incident_id is not None),
        }

    def _write_suite_report(self, results: List[SimulationResult]) -> Dict[str, Path]:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        summary = self._suite_summary(results)
        json_path = self.report_dir / f"endpoint_suite_{timestamp}.json"
        html_path = self.report_dir / f"endpoint_suite_{timestamp}.html"
        json_path.write_text(
            json.dumps(
                {
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "summary": summary,
                    "results": [asdict(item) for item in results],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        rows = []
        for item in results:
            rows.append(
                "<tr>"
                f"<td>{escape(item.title)}</td>"
                f"<td>{escape(item.category)}</td>"
                f"<td>{escape(item.severity_hint)}</td>"
                f"<td>{escape(item.severity)}</td>"
                f"<td>{'Yes' if item.success else 'No'}</td>"
                f"<td>{escape(item.summary)}</td>"
                f"<td>{escape(', '.join(item.indicator_kinds) or '-')}</td>"
                f"<td>{item.incident_id or '-'}</td>"
                f"<td>{item.message_id or '-'}</td>"
                "</tr>"
            )
        html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SecureMail Endpoint Simulation Report</title>
  <style>
    body {{ font-family: Segoe UI, Arial, sans-serif; background: #0b1220; color: #e9eef8; margin: 0; padding: 32px; }}
    h1, h2 {{ margin: 0 0 12px; }}
    .card {{ background: #131c2f; border: 1px solid #22314d; border-radius: 18px; padding: 20px; margin-bottom: 20px; }}
    table {{ width: 100%; border-collapse: collapse; }}
    th, td {{ text-align: left; padding: 12px; border-bottom: 1px solid #22314d; vertical-align: top; }}
    th {{ color: #8fa3c7; font-size: 12px; text-transform: uppercase; letter-spacing: 0.08em; }}
    .pill {{ display: inline-block; padding: 6px 10px; border-radius: 999px; background: #1d2d4d; margin-right: 8px; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>SecureMail Endpoint Simulation Report</h1>
    <p>Generated at {escape(datetime.now(timezone.utc).isoformat())}</p>
    <div>
      <span class="pill">Total: {summary['total']}</span>
      <span class="pill">Successful: {summary['successful']}</span>
      <span class="pill">Incidents: {summary['incidents']}</span>
      <span class="pill">Critical: {summary['critical']}</span>
    </div>
  </div>
  <div class="card">
    <h2>Scenario Results</h2>
    <table>
      <thead>
        <tr>
          <th>Scenario</th>
          <th>Category</th>
          <th>Expected</th>
          <th>Detected</th>
          <th>Success</th>
          <th>Summary</th>
          <th>Indicators</th>
          <th>Incident</th>
          <th>Message</th>
        </tr>
      </thead>
      <tbody>
        {''.join(rows)}
      </tbody>
    </table>
  </div>
</body>
</html>
"""
        html_path.write_text(html, encoding="utf-8")
        return {"json": json_path, "html": html_path}
