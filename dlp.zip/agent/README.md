# SecureMail Endpoint Agent

This agent is a Windows-side sensor and soft-enforcement component for SecureMail DLP.

What it does:

- polls clipboard content
- watches risky local directories for new or modified files
- monitors USB connect/disconnect events
- infers context from active processes like Telegram, WhatsApp, Chrome, Edge, Firefox, Discord and Slack
- sends outbound content to the SecureMail backend for AI DLP inspection
- stores no local evidence except logs and quarantined files
- clears clipboard or quarantines files on `HIGH/CRITICAL`
- can terminate monitored apps on `CRITICAL`
- auto-enrolls with the SecureMail backend and stores a per-endpoint key
- runs as a Windows Service with auto-start and restart recovery options
- refuses insecure remote `http` backends unless you explicitly use localhost for lab mode

Backend requirements:

- run the SecureMail web app
- set `SECUREMAIL_AGENT_ENROLLMENT_KEY`
- the agent sends to:
  - `/api/agent/enroll`
  - `/api/agent/heartbeat`
  - `/api/agent/device-event`
  - `/api/agent/inspect`
  - `/api/agent/device-sync`

Quick start:

1. Copy `agent/config.example.json` to `agent/config.json`
2. Set the correct `server_url`, `enrollment_key` and `actor_email`
3. Run:

```powershell
.\.venv\Scripts\python.exe .\run_agent.py
```

Windows Service:

```powershell
powershell -ExecutionPolicy Bypass -File .\agent\install_service.ps1
```

This installs the agent as an auto-start Windows service.

To remove it:

```powershell
powershell -ExecutionPolicy Bypass -File .\agent\uninstall_service.ps1
```
