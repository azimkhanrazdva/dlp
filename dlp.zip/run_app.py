import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "data" / "reports"
MODELS = ROOT / "models"

os.environ.setdefault("HOST", "127.0.0.1")
os.environ.setdefault("PORT", "5000")
os.environ.setdefault("FLASK_DEBUG", "1")
os.environ.setdefault("SECUREMAIL_SECRET_KEY", "securemail-local-dev-key")
os.environ.setdefault("SECUREMAIL_DB_PATH", str(REPORTS / "securemail_hosted.db"))
os.environ.setdefault("DLP_MODEL_PATH", str(MODELS / "dlp_bert_joint_v3"))
os.environ.setdefault("DLP_AUX_MODEL_PATH", str(MODELS / "dlp_bert_joint_v3_boost_v1"))
os.environ.setdefault("SECUREMAIL_AGENT_KEY", "securemail-agent-local")
os.environ.setdefault("SECUREMAIL_AGENT_ENROLLMENT_KEY", "example-enrollment-key")
os.environ.setdefault("SECUREMAIL_DEFAULT_AGENT_ID", "lab-win01:sen")

from app.main import app 


if __name__ == "__main__":
    app.run(
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "5000")),
        debug=os.environ.get("FLASK_DEBUG", "1") == "1",
    )
