from pathlib import Path

from agent.endpoint_simulator import EndpointScenarioSimulator
from agent.windows_agent import AgentConfig, EndpointAgent


def main() -> int:
    root = Path(__file__).resolve().parent
    config_path = root / "agent" / "config.json"
    config = AgentConfig.load(config_path)
    agent = EndpointAgent(config, config_path=config_path)
    agent.enroll_if_needed()
    simulator = EndpointScenarioSimulator(agent, root)
    result = simulator.run_all()
    print("Endpoint simulation suite completed.")
    print(f"JSON report: {result['report_json']}")
    print(f"HTML report: {result['report_html']}")
    print(f"Summary: {result['summary']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
