import hashlib
import json
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

try:
    import psycopg
    from psycopg.rows import dict_row
except Exception:  # pragma: no cover
    psycopg = None
    dict_row = None

from werkzeug.security import check_password_hash, generate_password_hash


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def row_to_dict(row: Any) -> Dict[str, Any]:
    if isinstance(row, dict):
        return dict(row)
    return {key: row[key] for key in row.keys()}


def safe_date(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).date().isoformat()
    except (ValueError, TypeError, AttributeError):
        return None


class SqliteStore:
    RETURNING_ID_TABLES = {
        "accounts",
        "messages",
        "attachments",
        "incidents",
        "devices",
        "device_events",
        "device_rules",
        "audit_chain",
        "endpoint_agents",
        "policies",
        "scan_jobs",
        "unlock_requests",
        "message_access_requests",
    }

    def __init__(self, root: Path, db_path: Optional[Any] = None) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path or (self.root / "securemail.db")
        self.db_url = str(self.db_path)
        self.engine = "postgres" if self.db_url.startswith(("postgresql://", "postgres://")) else "sqlite"
        if self.engine == "sqlite":
            self.db_path = Path(self.db_path)
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        elif not psycopg:
            raise RuntimeError("PostgreSQL support requires psycopg. Install requirements_web.txt.")
        self._init_db()

    def _connect(self):
        if self.engine == "sqlite":
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        conn = psycopg.connect(self.db_url, row_factory=dict_row)
        return conn

    def _convert_sql(self, sql: str) -> str:
        if self.engine != "postgres":
            return sql
        converted = sql.replace("?", "%s")
        converted = converted.replace(
            "INSERT OR REPLACE INTO sessions (token, email, role, created_at, expires_at) VALUES (%s, %s, %s, %s, %s)",
            "INSERT INTO sessions (token, email, role, created_at, expires_at) VALUES (%s, %s, %s, %s, %s) "
            "ON CONFLICT (token) DO UPDATE SET email=EXCLUDED.email, role=EXCLUDED.role, created_at=EXCLUDED.created_at, expires_at=EXCLUDED.expires_at",
        )
        return converted

    def _postgres_schema_statements(self) -> List[str]:
        return [
            """
            CREATE TABLE IF NOT EXISTS accounts (
                id BIGSERIAL PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                role TEXT NOT NULL,
                department TEXT,
                risk_profile TEXT,
                title TEXT,
                status TEXT NOT NULL DEFAULT 'active',
                can_send INTEGER NOT NULL DEFAULT 1,
                blocked_reason TEXT DEFAULT '',
                password_hash TEXT NOT NULL,
                totp_secret TEXT,
                last_login_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS messages (
                id BIGSERIAL PRIMARY KEY,
                sender TEXT NOT NULL,
                recipient TEXT NOT NULL,
                subject TEXT,
                body TEXT,
                folder TEXT NOT NULL DEFAULT 'inbox',
                status TEXT NOT NULL DEFAULT 'delivered',
                is_read INTEGER NOT NULL DEFAULT 0,
                dlp_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS attachments (
                id BIGSERIAL PRIMARY KEY,
                message_id BIGINT,
                filename TEXT NOT NULL,
                storage_path TEXT,
                extracted_text TEXT,
                result_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS incidents (
                id BIGSERIAL PRIMARY KEY,
                type TEXT NOT NULL,
                severity TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'open',
                summary TEXT NOT NULL,
                actions_json TEXT NOT NULL,
                owner TEXT,
                sender TEXT,
                recipient TEXT,
                subject TEXT,
                message_id BIGINT,
                created_at TEXT NOT NULL,
                updated_at TEXT,
                FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE SET NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS devices (
                id BIGSERIAL PRIMARY KEY,
                device_key TEXT NOT NULL UNIQUE,
                device_name TEXT NOT NULL,
                serial TEXT,
                status TEXT,
                media_type TEXT,
                size_bytes BIGINT,
                size_gb DOUBLE PRECISION,
                connection_state TEXT,
                policy TEXT,
                owner TEXT,
                enforcement_json TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS device_events (
                id BIGSERIAL PRIMARY KEY,
                device_name TEXT NOT NULL,
                device_key TEXT,
                event TEXT NOT NULL,
                notes TEXT,
                severity TEXT NOT NULL,
                policy TEXT,
                created_at TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS device_rules (
                id BIGSERIAL PRIMARY KEY,
                match_type TEXT NOT NULL,
                match_value TEXT NOT NULL,
                policy TEXT NOT NULL,
                owner TEXT,
                notes TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT,
                UNIQUE(match_type, match_value)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS audit_chain (
                id BIGSERIAL PRIMARY KEY,
                event_type TEXT NOT NULL,
                actor TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                previous_hash TEXT NOT NULL,
                entry_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                email TEXT NOT NULL,
                role TEXT NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS endpoint_agents (
                id BIGSERIAL PRIMARY KEY,
                agent_id TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL,
                actor_email TEXT,
                status TEXT NOT NULL DEFAULT 'active',
                hostname TEXT,
                platform TEXT,
                version TEXT,
                last_ip TEXT,
                last_seen_at TEXT,
                monitors_json TEXT,
                channels_json TEXT,
                api_key_hash TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS policies (
                id BIGSERIAL PRIMARY KEY,
                name TEXT NOT NULL,
                channel TEXT NOT NULL,
                block_threshold TEXT NOT NULL,
                quarantine_threshold TEXT NOT NULL,
                notes TEXT,
                created_at TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS scan_jobs (
                id BIGSERIAL PRIMARY KEY,
                job_type TEXT NOT NULL,
                channel TEXT NOT NULL,
                actor TEXT,
                status TEXT NOT NULL DEFAULT 'queued',
                target_name TEXT,
                severity TEXT,
                summary TEXT,
                result_json TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS unlock_requests (
                id BIGSERIAL PRIMARY KEY,
                email TEXT NOT NULL,
                requester_name TEXT NOT NULL,
                reason TEXT NOT NULL,
                attachment_name TEXT,
                attachment_path TEXT,
                status TEXT NOT NULL DEFAULT 'open',
                admin_comment TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS message_access_requests (
                id BIGSERIAL PRIMARY KEY,
                message_id BIGINT NOT NULL,
                requested_by_email TEXT NOT NULL,
                requested_by_name TEXT NOT NULL,
                sender_email TEXT NOT NULL,
                recipient_email TEXT NOT NULL,
                reason TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                sender_decision TEXT NOT NULL DEFAULT 'pending',
                recipient_decision TEXT NOT NULL DEFAULT 'pending',
                sender_comment TEXT DEFAULT '',
                recipient_comment TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE
            )
            """,
        ]

    def _init_db(self) -> None:
        if self.engine == "sqlite":
            with self._connect() as conn:
                conn.executescript(
                    """
                PRAGMA foreign_keys = ON;

                CREATE TABLE IF NOT EXISTS accounts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE,
                    role TEXT NOT NULL,
                    department TEXT,
                    risk_profile TEXT,
                    title TEXT,
                    status TEXT NOT NULL DEFAULT 'active',
                    can_send INTEGER NOT NULL DEFAULT 1,
                    blocked_reason TEXT DEFAULT '',
                    password_hash TEXT NOT NULL,
                    totp_secret TEXT,
                    last_login_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sender TEXT NOT NULL,
                    recipient TEXT NOT NULL,
                    subject TEXT,
                    body TEXT,
                    folder TEXT NOT NULL DEFAULT 'inbox',
                    status TEXT NOT NULL DEFAULT 'delivered',
                    is_read INTEGER NOT NULL DEFAULT 0,
                    dlp_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS attachments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id INTEGER,
                    filename TEXT NOT NULL,
                    storage_path TEXT,
                    extracted_text TEXT,
                    result_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS incidents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'open',
                    summary TEXT NOT NULL,
                    actions_json TEXT NOT NULL,
                    owner TEXT,
                    sender TEXT,
                    recipient TEXT,
                    subject TEXT,
                    message_id INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT,
                    FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE SET NULL
                );

                CREATE TABLE IF NOT EXISTS devices (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_key TEXT NOT NULL UNIQUE,
                    device_name TEXT NOT NULL,
                    serial TEXT,
                    status TEXT,
                    media_type TEXT,
                    size_bytes INTEGER,
                    size_gb REAL,
                    connection_state TEXT,
                    policy TEXT,
                    owner TEXT,
                    enforcement_json TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS device_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_name TEXT NOT NULL,
                    device_key TEXT,
                    event TEXT NOT NULL,
                    notes TEXT,
                    severity TEXT NOT NULL,
                    policy TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS device_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    match_type TEXT NOT NULL,
                    match_value TEXT NOT NULL,
                    policy TEXT NOT NULL,
                    owner TEXT,
                    notes TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT,
                    UNIQUE(match_type, match_value)
                );

                CREATE TABLE IF NOT EXISTS audit_chain (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    previous_hash TEXT NOT NULL,
                    entry_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS sessions (
                    token TEXT PRIMARY KEY,
                    email TEXT NOT NULL,
                    role TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS endpoint_agents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id TEXT NOT NULL UNIQUE,
                    display_name TEXT NOT NULL,
                    actor_email TEXT,
                    status TEXT NOT NULL DEFAULT 'active',
                    hostname TEXT,
                    platform TEXT,
                    version TEXT,
                    last_ip TEXT,
                    last_seen_at TEXT,
                    monitors_json TEXT,
                    channels_json TEXT,
                    api_key_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS policies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    block_threshold TEXT NOT NULL,
                    quarantine_threshold TEXT NOT NULL,
                    notes TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS scan_jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_type TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    actor TEXT,
                    status TEXT NOT NULL DEFAULT 'queued',
                    target_name TEXT,
                    severity TEXT,
                    summary TEXT,
                    result_json TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS unlock_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT NOT NULL,
                    requester_name TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    attachment_name TEXT,
                    attachment_path TEXT,
                    status TEXT NOT NULL DEFAULT 'open',
                    admin_comment TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS message_access_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id INTEGER NOT NULL,
                    requested_by_email TEXT NOT NULL,
                    requested_by_name TEXT NOT NULL,
                    sender_email TEXT NOT NULL,
                    recipient_email TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    sender_decision TEXT NOT NULL DEFAULT 'pending',
                    recipient_decision TEXT NOT NULL DEFAULT 'pending',
                    sender_comment TEXT DEFAULT '',
                    recipient_comment TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE
                );
                """
                )
            # Migrate existing DBs: add totp_secret if missing
            try:
                conn.execute("ALTER TABLE accounts ADD COLUMN totp_secret TEXT")
                conn.commit()
            except Exception:
                pass
            return
        with self._connect() as conn:
            with conn.cursor() as cur:
                for statement in self._postgres_schema_statements():
                    cur.execute(statement)
                try:
                    cur.execute("ALTER TABLE accounts ADD COLUMN IF NOT EXISTS totp_secret TEXT")
                except Exception:
                    pass
            conn.commit()

    def _query_all(self, sql: str, params: Iterable[Any] = ()) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            if self.engine == "sqlite":
                rows = conn.execute(sql, tuple(params)).fetchall()
            else:
                with conn.cursor() as cur:
                    cur.execute(self._convert_sql(sql), tuple(params))
                    rows = cur.fetchall()
        return [row_to_dict(row) for row in rows]

    def _query_one(self, sql: str, params: Iterable[Any] = ()) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            if self.engine == "sqlite":
                row = conn.execute(sql, tuple(params)).fetchone()
            else:
                with conn.cursor() as cur:
                    cur.execute(self._convert_sql(sql), tuple(params))
                    row = cur.fetchone()
        return row_to_dict(row) if row else None

    def _execute(self, sql: str, params: Iterable[Any] = ()) -> int:
        with self._connect() as conn:
            if self.engine == "sqlite":
                cursor = conn.execute(sql, tuple(params))
                conn.commit()
                return int(cursor.lastrowid)
            converted = self._convert_sql(sql)
            normalized = " ".join(sql.strip().split()).lower()
            with conn.cursor() as cur:
                if normalized.startswith("insert into "):
                    table = normalized.split()[2]
                    if table in self.RETURNING_ID_TABLES:
                        cur.execute(f"{converted} RETURNING id", tuple(params))
                        row = cur.fetchone()
                        conn.commit()
                        return int((row or {}).get("id", 0))
                cur.execute(converted, tuple(params))
            conn.commit()
            return 0

    def seed_accounts(self, accounts: List[Dict[str, Any]]) -> None:
        if self.list_accounts():
            return
        for account in accounts:
            self.create_account(account)

    def seed_endpoint_agents(self, agents: List[Dict[str, Any]]) -> None:
        for agent in agents:
            existing = self.get_endpoint_agent(agent["agent_id"])
            if existing:
                continue
            self.create_endpoint_agent(agent)

    def create_endpoint_agent(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        agent_id = str(payload["agent_id"]).strip()
        self._execute(
            """
            INSERT INTO endpoint_agents (
                agent_id, display_name, actor_email, status, hostname, platform, version, last_ip,
                last_seen_at, monitors_json, channels_json, api_key_hash, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                agent_id,
                payload.get("display_name", agent_id),
                payload.get("actor_email"),
                payload.get("status", "active"),
                payload.get("hostname"),
                payload.get("platform", "windows"),
                payload.get("version"),
                payload.get("last_ip"),
                payload.get("last_seen_at"),
                json.dumps(payload.get("monitors", []), ensure_ascii=False),
                json.dumps(payload.get("channels", []), ensure_ascii=False),
                generate_password_hash(payload.get("api_key", "change-me")),
                now_iso(),
                now_iso(),
            ),
        )
        return self.get_endpoint_agent(agent_id)

    def get_endpoint_agent(self, agent_id: str) -> Optional[Dict[str, Any]]:
        row = self._query_one("SELECT * FROM endpoint_agents WHERE agent_id=?", (agent_id,))
        if not row:
            return None
        row["monitors"] = json.loads(row.get("monitors_json") or "[]")
        row["channels"] = json.loads(row.get("channels_json") or "[]")
        row.pop("monitors_json", None)
        row.pop("channels_json", None)
        row["is_online"] = False
        if row.get("last_seen_at"):
            try:
                seen = datetime.fromisoformat(row["last_seen_at"].replace("Z", "+00:00"))
                row["is_online"] = (datetime.now(timezone.utc) - seen).total_seconds() <= 90
            except (ValueError, AttributeError):
                row["is_online"] = False
        return row

    def list_endpoint_agents(self) -> List[Dict[str, Any]]:
        rows = self._query_all("SELECT * FROM endpoint_agents ORDER BY created_at DESC")
        return [self.get_endpoint_agent(row["agent_id"]) for row in rows if row.get("agent_id")]

    def verify_endpoint_agent(self, agent_id: str, api_key: str) -> Optional[Dict[str, Any]]:
        row = self._query_one("SELECT * FROM endpoint_agents WHERE agent_id=?", (agent_id,))
        if not row or row.get("status") != "active":
            return None
        if not check_password_hash(row["api_key_hash"], api_key):
            return None
        return self.get_endpoint_agent(agent_id)

    def update_endpoint_agent(self, agent_id: str, **changes: Any) -> Optional[Dict[str, Any]]:
        current = self._query_one("SELECT * FROM endpoint_agents WHERE agent_id=?", (agent_id,))
        if not current:
            return None
        api_key_hash = current.get("api_key_hash")
        if "api_key" in changes and changes["api_key"]:
            api_key_hash = generate_password_hash(changes["api_key"])
        self._execute(
            """
            UPDATE endpoint_agents
            SET display_name=?, actor_email=?, status=?, hostname=?, platform=?, version=?, last_ip=?, last_seen_at=?,
                monitors_json=?, channels_json=?, api_key_hash=?, updated_at=?
            WHERE agent_id=?
            """,
            (
                changes.get("display_name", current.get("display_name")),
                changes.get("actor_email", current.get("actor_email")),
                changes.get("status", current.get("status")),
                changes.get("hostname", current.get("hostname")),
                changes.get("platform", current.get("platform")),
                changes.get("version", current.get("version")),
                changes.get("last_ip", current.get("last_ip")),
                changes.get("last_seen_at", current.get("last_seen_at")),
                json.dumps(changes.get("monitors", json.loads(current.get("monitors_json") or "[]")), ensure_ascii=False),
                json.dumps(changes.get("channels", json.loads(current.get("channels_json") or "[]")), ensure_ascii=False),
                api_key_hash,
                now_iso(),
                agent_id,
            ),
        )
        return self.get_endpoint_agent(agent_id)

    def create_account(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        email = str(payload["email"]).strip().lower()
        existing = self.get_account(email)
        if existing:
            raise ValueError("Account already exists")
        self._execute(
            """
            INSERT INTO accounts (
                name, email, role, department, risk_profile, title, status, can_send,
                blocked_reason, password_hash, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["name"],
                email,
                payload.get("role", "employee"),
                payload.get("department", "Operations"),
                payload.get("risk_profile", "standard"),
                payload.get("title", ""),
                payload.get("status", "active"),
                1 if payload.get("can_send", True) else 0,
                payload.get("blocked_reason", ""),
                generate_password_hash(payload.get("password", "Password123!")),
                now_iso(),
            ),
        )
        return self.get_account(email)

    def seed_demo_mailbox(self) -> None:
        if self.list_messages():
            return
        demo_messages = [
            {
                "sender": "soc@securemail.kz",
                "recipient": "analyst@example.test",
                "subject": "Security baseline for external sharing",
                "body": "Please use the secure portal when sending customer exports. High-risk attachments will be quarantined automatically.",
                "folder": "inbox",
                "status": "delivered",
                "is_read": 0,
                "dlp": {"severity": "SAFE", "summary": "No sensitive indicators detected.", "score": 0.98, "actions": ["Allow"], "channel": "email", "model_info": {}, "extracted_text": "", "indicators": []},
                "attachments": [],
            },
            {
                "sender": "madina@securemail.kz",
                "recipient": "dias@securemail.kz",
                "subject": "Customer callback sheet for review",
                "body": "Contains contact details and call routing notes for today's support shift.",
                "folder": "sent",
                "status": "delivered",
                "is_read": 1,
                "dlp": {"severity": "MEDIUM", "summary": "Multiple contact or suspicious fragments detected.", "score": 0.77, "actions": ["Warn sender", "Audit log", "Flag for review"], "channel": "email", "model_info": {}, "extracted_text": "", "indicators": [{"kind": "phone_kz", "value": "+0 000 000 00 07", "severity": "LOW", "reason": "Kazakhstan phone detected"}]},
                "attachments": [],
            },
            {
                "sender": "dias@securemail.kz",
                "recipient": "partner@external.com",
                "subject": "Production connection details",
                "body": "Blocked demo message containing database credentials.",
                "folder": "quarantine",
                "status": "blocked",
                "is_read": 0,
                "dlp": {"severity": "CRITICAL", "summary": "Critical secret or credential pattern detected.", "score": 0.9997, "actions": ["Block send", "Create priority incident"], "channel": "email", "model_info": {}, "extracted_text": "", "indicators": [{"kind": "db_uri", "value": "postgresql://...", "severity": "CRITICAL", "reason": "Database URI detected"}]},
                "attachments": [],
            },
        ]
        for message in demo_messages:
            self.add_message(message)

    def seed_demo_incidents(self) -> None:
        if self.list_incidents():
            return
        self.add_incident(
            {
                "type": "email_leak_attempt",
                "severity": "CRITICAL",
                "status": "open",
                "summary": "Outgoing message with production credential was quarantined before delivery.",
                "actions": ["Block send", "Alert SOC", "Open forensic review"],
                "owner": "SOC",
            }
        )
        self.add_incident(
            {
                "type": "usb_device_detected",
                "severity": "MEDIUM",
                "status": "open",
                "summary": "Unknown USB storage detected on finance workstation.",
                "actions": ["Review device", "Require authorization"],
                "owner": "Endpoint Control",
            }
        )

    def seed_default_policies(self) -> None:
        policies = [
            ("Corporate Outbound Mail", "email", "HIGH", "MEDIUM", "Primary outbound DLP policy."),
            ("Removable Media", "device", "HIGH", "MEDIUM", "Restrict suspicious USB copy operations."),
            ("Attachment Handling", "file", "HIGH", "MEDIUM", "Inspect uploaded files, OCR and archives."),
            ("Messenger Leakage Control", "messenger", "HIGH", "MEDIUM", "Inspect outbound content to chat and messaging platforms."),
            ("Social Media Disclosure Control", "social", "HIGH", "MEDIUM", "Restrict public and direct-message social media disclosure."),
            ("Web Form Submission Control", "web", "HIGH", "MEDIUM", "Inspect external web forms, tickets and uploads."),
            ("Public Upload Governance", "public_upload", "HIGH", "MEDIUM", "Inspect public file-sharing and cloud upload attempts."),
            ("Clipboard and Paste Guard", "clipboard", "HIGH", "MEDIUM", "Inspect copied sensitive text before external sharing."),
        ]
        for name, channel, block_threshold, quarantine_threshold, notes in policies:
            existing = self._query_one("SELECT id FROM policies WHERE name=? OR channel=? LIMIT 1", (name, channel))
            if existing:
                continue
            self._execute(
                "INSERT INTO policies (name, channel, block_threshold, quarantine_threshold, notes, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (name, channel, block_threshold, quarantine_threshold, notes, now_iso()),
            )

    def list_policies(self) -> List[Dict[str, Any]]:
        return self._query_all("SELECT * FROM policies ORDER BY id ASC")

    def add_scan_job(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        job_id = self._execute(
            """
            INSERT INTO scan_jobs (job_type, channel, actor, status, target_name, severity, summary, result_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload.get("job_type", "scan"),
                payload.get("channel", "email"),
                payload.get("actor"),
                payload.get("status", "queued"),
                payload.get("target_name"),
                payload.get("severity"),
                payload.get("summary"),
                json.dumps(payload.get("result", {}), ensure_ascii=False) if payload.get("result") is not None else None,
                now_iso(),
                now_iso(),
            ),
        )
        return self.get_scan_job(job_id)

    def get_scan_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        row = self._query_one("SELECT * FROM scan_jobs WHERE id=?", (job_id,))
        if not row:
            return None
        if row.get("result_json"):
            row["result"] = json.loads(row["result_json"])
        row.pop("result_json", None)
        return row

    def update_scan_job(self, job_id: int, **changes: Any) -> Optional[Dict[str, Any]]:
        current = self._query_one("SELECT * FROM scan_jobs WHERE id=?", (job_id,))
        if not current:
            return None
        result_json = current.get("result_json")
        if "result" in changes:
            result_json = json.dumps(changes["result"], ensure_ascii=False)
        self._execute(
            """
            UPDATE scan_jobs
            SET status=?, severity=?, summary=?, result_json=?, updated_at=?
            WHERE id=?
            """,
            (
                changes.get("status", current["status"]),
                changes.get("severity", current.get("severity")),
                changes.get("summary", current.get("summary")),
                result_json,
                now_iso(),
                job_id,
            ),
        )
        return self.get_scan_job(job_id)

    def list_scan_jobs(self, limit: int = 50) -> List[Dict[str, Any]]:
        rows = self._query_all("SELECT * FROM scan_jobs ORDER BY created_at DESC LIMIT ?", (limit,))
        out = []
        for row in rows:
            if row.get("result_json"):
                row["result"] = json.loads(row["result_json"])
            row.pop("result_json", None)
            out.append(row)
        return out

    def analytics_snapshot(self) -> Dict[str, Any]:
        messages = self.list_messages()
        incidents = self.list_incidents()
        devices = self.list_devices()
        jobs = self.list_scan_jobs(limit=200)
        severity_counts = {label: 0 for label in ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]}
        folder_counts: Dict[str, int] = {}
        today = datetime.now(timezone.utc).date()
        timeline_days = [(today - timedelta(days=offset)).isoformat() for offset in range(6, -1, -1)]
        message_timeline = {day: 0 for day in timeline_days}
        incident_timeline = {day: 0 for day in timeline_days}
        job_timeline = {day: 0 for day in timeline_days}
        for message in messages:
            sev = str((message.get("dlp") or {}).get("severity", "SAFE")).upper()
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
            folder = message.get("folder", "inbox")
            folder_counts[folder] = folder_counts.get(folder, 0) + 1
            created = safe_date(message.get("created_at"))
            if created in message_timeline:
                message_timeline[created] += 1
        job_status = {}
        channel_counts = {}
        job_types = {}
        for job in jobs:
            status = job.get("status", "queued")
            channel = job.get("channel", "email")
            job_type = job.get("job_type", "scan")
            job_status[status] = job_status.get(status, 0) + 1
            channel_counts[channel] = channel_counts.get(channel, 0) + 1
            job_types[job_type] = job_types.get(job_type, 0) + 1
            created = safe_date(job.get("created_at"))
            if created in job_timeline:
                job_timeline[created] += 1
        incident_counts = {}
        for incident in incidents:
            sev = incident.get("severity", "LOW")
            incident_counts[sev] = incident_counts.get(sev, 0) + 1
            created = safe_date(incident.get("created_at"))
            if created in incident_timeline:
                incident_timeline[created] += 1
        return {
            "message_severity": severity_counts,
            "folders": folder_counts,
            "incident_severity": incident_counts,
            "scan_jobs": job_status,
            "job_types": job_types,
            "channels": channel_counts,
            "devices": {
                "connected": sum(1 for item in devices if item.get("connection_state") == "connected"),
                "blocked": sum(1 for item in devices if item.get("policy") == "blocked"),
                "authorized": sum(1 for item in devices if item.get("policy") == "authorized"),
            },
            "timeline": {
                "days": timeline_days,
                "messages": [message_timeline[day] for day in timeline_days],
                "incidents": [incident_timeline[day] for day in timeline_days],
                "jobs": [job_timeline[day] for day in timeline_days],
            },
        }

    def list_accounts(self) -> List[Dict[str, Any]]:
        return self._query_all("SELECT id, name, email, role, department, risk_profile, title, status, can_send, blocked_reason, last_login_at, created_at, updated_at FROM accounts ORDER BY name ASC")

    def get_account(self, email: str) -> Optional[Dict[str, Any]]:
        return self._query_one(
            "SELECT id, name, email, role, department, risk_profile, title, status, can_send, blocked_reason, last_login_at, created_at, updated_at FROM accounts WHERE lower(email)=lower(?)",
            (email,),
        )

    def _get_account_with_secret(self, email: str) -> Optional[Dict[str, Any]]:
        return self._query_one("SELECT * FROM accounts WHERE lower(email)=lower(?)", (email,))

    def authenticate(self, email: str, password: str) -> Optional[Dict[str, Any]]:
        account = self._get_account_with_secret(email)
        if not account or not check_password_hash(account["password_hash"], password):
            return None
        self._execute("UPDATE accounts SET last_login_at=?, updated_at=? WHERE id=?", (now_iso(), now_iso(), account["id"]))
        token = secrets.token_hex(24)
        expires = (datetime.now(timezone.utc) + timedelta(hours=8)).isoformat()
        self._execute(
            "INSERT OR REPLACE INTO sessions (token, email, role, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
            (token, account["email"], account["role"], now_iso(), expires),
        )
        account_view = self.get_account(account["email"])
        if account_view:
            account_view["session_token"] = token
        return account_view

    def get_totp_secret(self, email: str) -> Optional[str]:
        row = self._query_one("SELECT totp_secret FROM accounts WHERE lower(email)=lower(?)", (email,))
        return row["totp_secret"] if row else None

    def set_totp_secret(self, email: str, secret: Optional[str]) -> None:
        self._execute(
            "UPDATE accounts SET totp_secret=?, updated_at=? WHERE lower(email)=lower(?)",
            (secret, now_iso(), email),
        )

    def get_session(self, token: str) -> Optional[Dict[str, Any]]:
        session = self._query_one("SELECT * FROM sessions WHERE token=?", (token,))
        if not session:
            return None
        expires_at = session.get("expires_at")
        if expires_at:
            try:
                exp = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                if datetime.now(timezone.utc) > exp:
                    self.clear_session(token)
                    return None
            except (ValueError, AttributeError):
                pass
        account = self.get_account(session["email"])
        if account:
            account["session_token"] = token
            return account
        return None

    def clear_session(self, token: str) -> None:
        self._execute("DELETE FROM sessions WHERE token=?", (token,))

    def update_account(self, email: str, **changes: Any) -> Optional[Dict[str, Any]]:
        account = self._get_account_with_secret(email)
        if not account:
            return None
        merged = dict(account)
        merged.update(changes)
        password_hash = account["password_hash"]
        if merged.get("password"):
            password_hash = generate_password_hash(str(merged["password"]))
        self._execute(
            """
            UPDATE accounts
            SET name=?, status=?, can_send=?, blocked_reason=?, role=?, department=?, risk_profile=?, title=?, password_hash=?, updated_at=?
            WHERE lower(email)=lower(?)
            """,
            (
                merged.get("name", account["name"]),
                merged.get("status", account["status"]),
                1 if merged.get("can_send", account["can_send"]) else 0,
                merged.get("blocked_reason", account.get("blocked_reason", "")),
                merged.get("role", account["role"]),
                merged.get("department", account.get("department")),
                merged.get("risk_profile", account.get("risk_profile")),
                merged.get("title", account.get("title")),
                password_hash,
                now_iso(),
                email,
            ),
        )
        return self.get_account(email)

    def delete_account(self, email: str) -> None:
        self._execute("DELETE FROM sessions WHERE lower(email)=lower(?)", (email,))
        self._execute("DELETE FROM accounts WHERE lower(email)=lower(?)", (email,))

    def add_unlock_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        request_id = self._execute(
            """
            INSERT INTO unlock_requests (
                email, requester_name, reason, attachment_name, attachment_path, status, admin_comment, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["email"],
                payload["requester_name"],
                payload["reason"],
                payload.get("attachment_name"),
                payload.get("attachment_path"),
                payload.get("status", "open"),
                payload.get("admin_comment", ""),
                now_iso(),
                now_iso(),
            ),
        )
        return self.get_unlock_request(request_id)

    def list_unlock_requests(self) -> List[Dict[str, Any]]:
        return self._query_all("SELECT * FROM unlock_requests ORDER BY created_at DESC")

    def get_unlock_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        return self._query_one("SELECT * FROM unlock_requests WHERE id=?", (request_id,))

    def update_unlock_request(self, request_id: int, **changes: Any) -> Optional[Dict[str, Any]]:
        current = self.get_unlock_request(request_id)
        if not current:
            return None
        merged = dict(current)
        merged.update(changes)
        self._execute(
            """
            UPDATE unlock_requests
            SET status=?, admin_comment=?, updated_at=?
            WHERE id=?
            """,
            (
                merged.get("status", current["status"]),
                merged.get("admin_comment", current.get("admin_comment", "")),
                now_iso(),
                request_id,
            ),
        )
        return self.get_unlock_request(request_id)

    def add_message_access_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        request_id = self._execute(
            """
            INSERT INTO message_access_requests (
                message_id, requested_by_email, requested_by_name, sender_email, recipient_email,
                reason, status, sender_decision, recipient_decision, sender_comment, recipient_comment, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["message_id"],
                payload["requested_by_email"],
                payload["requested_by_name"],
                payload["sender_email"],
                payload["recipient_email"],
                payload["reason"],
                payload.get("status", "pending"),
                payload.get("sender_decision", "pending"),
                payload.get("recipient_decision", "pending"),
                payload.get("sender_comment", ""),
                payload.get("recipient_comment", ""),
                now_iso(),
                now_iso(),
            ),
        )
        return self.get_message_access_request(request_id)

    def list_message_access_requests(self) -> List[Dict[str, Any]]:
        return self._query_all("SELECT * FROM message_access_requests ORDER BY created_at DESC")

    def get_message_access_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        return self._query_one("SELECT * FROM message_access_requests WHERE id=?", (request_id,))

    def get_open_message_access_request(self, message_id: int) -> Optional[Dict[str, Any]]:
        return self._query_one(
            "SELECT * FROM message_access_requests WHERE message_id=? AND status='pending' ORDER BY created_at DESC LIMIT 1",
            (message_id,),
        )

    def find_approved_message_access(self, message_id: int) -> Optional[Dict[str, Any]]:
        return self._query_one(
            """
            SELECT * FROM message_access_requests
            WHERE message_id=? AND status='approved' AND sender_decision='approved' AND recipient_decision='approved'
            ORDER BY updated_at DESC LIMIT 1
            """,
            (message_id,),
        )

    def update_message_access_request(self, request_id: int, **changes: Any) -> Optional[Dict[str, Any]]:
        current = self.get_message_access_request(request_id)
        if not current:
            return None
        merged = dict(current)
        merged.update(changes)
        status = merged.get("status", current["status"])
        sender_decision = merged.get("sender_decision", current["sender_decision"])
        recipient_decision = merged.get("recipient_decision", current["recipient_decision"])
        if sender_decision == "approved" and recipient_decision == "approved":
            status = "approved"
        elif sender_decision == "rejected" or recipient_decision == "rejected":
            status = "rejected"
        self._execute(
            """
            UPDATE message_access_requests
            SET status=?, sender_decision=?, recipient_decision=?, sender_comment=?, recipient_comment=?, updated_at=?
            WHERE id=?
            """,
            (
                status,
                sender_decision,
                recipient_decision,
                merged.get("sender_comment", current.get("sender_comment", "")),
                merged.get("recipient_comment", current.get("recipient_comment", "")),
                now_iso(),
                request_id,
            ),
        )
        return self.get_message_access_request(request_id)

    def add_message(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        created_at = now_iso()
        message_id = self._execute(
            """
            INSERT INTO messages (sender, recipient, subject, body, folder, status, is_read, dlp_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["sender"],
                payload["recipient"],
                payload.get("subject", ""),
                payload.get("body", ""),
                payload.get("folder", "inbox"),
                payload.get("status", "delivered"),
                1 if payload.get("is_read") else 0,
                json.dumps(payload.get("dlp", {}), ensure_ascii=False),
                created_at,
            ),
        )
        for attachment in payload.get("attachments", []):
            self._execute(
                """
                INSERT INTO attachments (message_id, filename, storage_path, extracted_text, result_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    message_id,
                    attachment.get("filename"),
                    attachment.get("storage_path"),
                    attachment.get("extracted_text"),
                    json.dumps(attachment.get("result", {}), ensure_ascii=False),
                    created_at,
                ),
            )
        return self.get_message(message_id)

    def list_messages(self) -> List[Dict[str, Any]]:
        rows = self._query_all("SELECT * FROM messages ORDER BY created_at DESC")
        return [self._message_with_attachments(row) for row in rows]

    def get_message(self, message_id: int) -> Optional[Dict[str, Any]]:
        row = self._query_one("SELECT * FROM messages WHERE id=?", (message_id,))
        return self._message_with_attachments(row) if row else None

    def _message_with_attachments(self, row: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if not row:
            return None
        attachments = self._query_all("SELECT * FROM attachments WHERE message_id=? ORDER BY id ASC", (row["id"],))
        message = dict(row)
        message["is_read"] = bool(message.get("is_read"))
        message["dlp"] = json.loads(message.get("dlp_json") or "{}")
        message["attachments"] = [
            {
                "id": item["id"],
                "filename": item["filename"],
                "storage_path": item["storage_path"],
                "extracted_text": item["extracted_text"],
                "result": json.loads(item.get("result_json") or "{}"),
            }
            for item in attachments
        ]
        message.pop("dlp_json", None)
        return message

    def update_message(self, message_id: int, **changes: Any) -> Optional[Dict[str, Any]]:
        current = self._query_one("SELECT * FROM messages WHERE id=?", (message_id,))
        if not current:
            return None
        payload = dict(current)
        payload.update(changes)
        dlp_json = payload["dlp_json"] if "dlp_json" in payload else current["dlp_json"]
        if "dlp" in changes:
            dlp_json = json.dumps(changes["dlp"], ensure_ascii=False)
        self._execute(
            """
            UPDATE messages
            SET folder=?, status=?, is_read=?, dlp_json=?, updated_at=?
            WHERE id=?
            """,
            (
                payload.get("folder", current["folder"]),
                payload.get("status", current["status"]),
                1 if payload.get("is_read", current["is_read"]) else 0,
                dlp_json,
                now_iso(),
                message_id,
            ),
        )
        return self.get_message(message_id)

    def list_attachments(self) -> List[Dict[str, Any]]:
        rows = self._query_all(
            """
            SELECT a.*, m.subject, m.sender, m.recipient
            FROM attachments a
            LEFT JOIN messages m ON m.id = a.message_id
            ORDER BY a.created_at DESC
            """
        )
        result = []
        for row in rows:
            item = dict(row)
            item["result"] = json.loads(item.get("result_json") or "{}")
            item.pop("result_json", None)
            result.append(item)
        return result

    def get_attachment(self, attachment_id: int) -> Optional[Dict[str, Any]]:
        row = self._query_one(
            """
            SELECT a.*, m.subject, m.sender, m.recipient, m.folder, m.status AS message_status
            FROM attachments a
            LEFT JOIN messages m ON m.id = a.message_id
            WHERE a.id=?
            """,
            (attachment_id,),
        )
        if not row:
            return None
        item = dict(row)
        item["result"] = json.loads(item.get("result_json") or "{}")
        item.pop("result_json", None)
        return item

    def add_incident(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        incident_id = self._execute(
            """
            INSERT INTO incidents (type, severity, status, summary, actions_json, owner, sender, recipient, subject, message_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["type"],
                payload["severity"],
                payload.get("status", "open"),
                payload["summary"],
                json.dumps(payload.get("actions", []), ensure_ascii=False),
                payload.get("owner"),
                payload.get("sender"),
                payload.get("recipient"),
                payload.get("subject"),
                payload.get("message_id"),
                now_iso(),
            ),
        )
        return self.get_incident(incident_id)

    def get_incident(self, incident_id: int) -> Optional[Dict[str, Any]]:
        row = self._query_one("SELECT * FROM incidents WHERE id=?", (incident_id,))
        if not row:
            return None
        row["actions"] = json.loads(row.get("actions_json") or "[]")
        row.pop("actions_json", None)
        return row

    def list_incidents(self) -> List[Dict[str, Any]]:
        rows = self._query_all("SELECT * FROM incidents ORDER BY created_at DESC")
        out = []
        for row in rows:
            row["actions"] = json.loads(row.get("actions_json") or "[]")
            row.pop("actions_json", None)
            out.append(row)
        return out

    def update_incident(self, incident_id: int, **changes: Any) -> Optional[Dict[str, Any]]:
        current = self._query_one("SELECT * FROM incidents WHERE id=?", (incident_id,))
        if not current:
            return None
        self._execute(
            "UPDATE incidents SET status=?, owner=?, updated_at=? WHERE id=?",
            (
                changes.get("status", current["status"]),
                changes.get("owner", current.get("owner")),
                now_iso(),
                incident_id,
            ),
        )
        return self.get_incident(incident_id)

    def upsert_device(self, device_key: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        current = self._query_one("SELECT * FROM devices WHERE device_key=?", (device_key,))
        if current:
            self._execute(
                """
                UPDATE devices
                SET device_name=?, serial=?, status=?, media_type=?, size_bytes=?, size_gb=?, connection_state=?, policy=?, owner=?, enforcement_json=?, updated_at=?
                WHERE device_key=?
                """,
                (
                    payload.get("device_name", current["device_name"]),
                    payload.get("serial"),
                    payload.get("status"),
                    payload.get("media_type"),
                    payload.get("size_bytes"),
                    payload.get("size_gb"),
                    payload.get("connection_state", current.get("connection_state")),
                    payload.get("policy", current.get("policy")),
                    payload.get("owner", current.get("owner")),
                    json.dumps(payload.get("enforcement")) if payload.get("enforcement") is not None else current.get("enforcement_json"),
                    now_iso(),
                    device_key,
                ),
            )
        else:
            self._execute(
                """
                INSERT INTO devices (device_key, device_name, serial, status, media_type, size_bytes, size_gb, connection_state, policy, owner, enforcement_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    device_key,
                    payload.get("device_name", "USB Device"),
                    payload.get("serial"),
                    payload.get("status"),
                    payload.get("media_type"),
                    payload.get("size_bytes"),
                    payload.get("size_gb"),
                    payload.get("connection_state", "connected"),
                    payload.get("policy", "review"),
                    payload.get("owner"),
                    json.dumps(payload.get("enforcement")) if payload.get("enforcement") is not None else None,
                    now_iso(),
                ),
            )
        return self.get_device(device_key)

    def get_device(self, device_key: str) -> Optional[Dict[str, Any]]:
        row = self._query_one("SELECT * FROM devices WHERE device_key=?", (device_key,))
        if not row:
            return None
        if row.get("enforcement_json"):
            row["enforcement"] = json.loads(row["enforcement_json"])
            row.pop("enforcement_json", None)
        return row

    def list_devices(self) -> List[Dict[str, Any]]:
        rows = self._query_all("SELECT * FROM devices ORDER BY created_at DESC")
        out = []
        for row in rows:
            if row.get("enforcement_json"):
                row["enforcement"] = json.loads(row["enforcement_json"])
            row.pop("enforcement_json", None)
            out.append(row)
        return out

    def update_device(self, device_key: str, **changes: Any) -> Optional[Dict[str, Any]]:
        current = self._query_one("SELECT * FROM devices WHERE device_key=?", (device_key,))
        if not current:
            return None
        enforcement_json = current.get("enforcement_json")
        if "enforcement" in changes:
            enforcement_json = json.dumps(changes["enforcement"], ensure_ascii=False)
        self._execute(
            """
            UPDATE devices
            SET policy=?, owner=?, connection_state=?, enforcement_json=?, updated_at=?
            WHERE device_key=?
            """,
            (
                changes.get("policy", current.get("policy")),
                changes.get("owner", current.get("owner")),
                changes.get("connection_state", current.get("connection_state")),
                enforcement_json,
                now_iso(),
                device_key,
            ),
        )
        return self.get_device(device_key)

    def add_device_event(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        event_id = self._execute(
            """
            INSERT INTO device_events (device_name, device_key, event, notes, severity, policy, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["device_name"],
                payload.get("device_key"),
                payload.get("event", "connected"),
                payload.get("notes"),
                payload.get("severity", "LOW"),
                payload.get("policy"),
                now_iso(),
            ),
        )
        return self._query_one("SELECT * FROM device_events WHERE id=?", (event_id,))

    def list_device_events(self) -> List[Dict[str, Any]]:
        return self._query_all("SELECT * FROM device_events ORDER BY created_at DESC")

    def upsert_device_rule(
        self,
        match_type: str,
        match_value: str,
        policy: str,
        owner: Optional[str] = None,
        notes: str = "",
    ) -> Dict[str, Any]:
        current = self._query_one(
            "SELECT * FROM device_rules WHERE match_type=? AND match_value=?",
            (match_type, match_value),
        )
        if current:
            self._execute(
                """
                UPDATE device_rules
                SET policy=?, owner=?, notes=?, updated_at=?
                WHERE match_type=? AND match_value=?
                """,
                (policy, owner, notes, now_iso(), match_type, match_value),
            )
        else:
            self._execute(
                """
                INSERT INTO device_rules (match_type, match_value, policy, owner, notes, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (match_type, match_value, policy, owner, notes, now_iso(), now_iso()),
            )
        return self.get_device_rule(match_type, match_value)

    def get_device_rule(self, match_type: str, match_value: str) -> Optional[Dict[str, Any]]:
        return self._query_one(
            "SELECT * FROM device_rules WHERE match_type=? AND match_value=?",
            (match_type, match_value),
        )

    def delete_device_rule(self, match_type: str, match_value: str) -> None:
        self._execute(
            "DELETE FROM device_rules WHERE match_type=? AND match_value=?",
            (match_type, match_value),
        )

    def list_device_rules(self) -> List[Dict[str, Any]]:
        return self._query_all("SELECT * FROM device_rules ORDER BY created_at DESC")

    def add_audit_event(self, event_type: str, actor: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        previous = self._query_one("SELECT entry_hash FROM audit_chain ORDER BY id DESC LIMIT 1")
        previous_hash = previous["entry_hash"] if previous else "GENESIS"
        created_at = now_iso()
        payload_json = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        entry_hash = hashlib.sha256(
            json.dumps(
                {
                    "event_type": event_type,
                    "actor": actor,
                    "payload": json.loads(payload_json),
                    "created_at": created_at,
                    "previous_hash": previous_hash,
                },
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()
        audit_id = self._execute(
            "INSERT INTO audit_chain (event_type, actor, payload_json, previous_hash, entry_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (event_type, actor, payload_json, previous_hash, entry_hash, created_at),
        )
        return self._query_one("SELECT * FROM audit_chain WHERE id=?", (audit_id,))

    def list_audit_events(self) -> List[Dict[str, Any]]:
        rows = self._query_all("SELECT * FROM audit_chain ORDER BY id ASC")
        out = []
        for row in rows:
            row["payload"] = json.loads(row.get("payload_json") or "{}")
            row.pop("payload_json", None)
            out.append(row)
        return out

    def verify_audit_chain(self) -> Dict[str, Any]:
        items = self.list_audit_events()
        previous_hash = "GENESIS"
        broken_at = None
        for item in items:
            expected = hashlib.sha256(
                json.dumps(
                    {
                        "event_type": item["event_type"],
                        "actor": item["actor"],
                        "payload": item["payload"],
                        "created_at": item["created_at"],
                        "previous_hash": item["previous_hash"],
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                ).encode("utf-8")
            ).hexdigest()
            if item.get("previous_hash") != previous_hash or item.get("entry_hash") != expected:
                broken_at = item.get("id")
                break
            previous_hash = item["entry_hash"]
        return {"valid": broken_at is None, "length": len(items), "broken_at": broken_at}
