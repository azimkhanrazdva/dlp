function severityBadge(severity) {
  const level = (severity || "SAFE").toLowerCase();
  return `<span class="status-chip severity-${level}">${severity}</span>`;
}

function applyTheme(theme) {
  const body = document.body;
  if (!body) return;
  const isLight = theme === "light";
  body.classList.toggle("light-theme", isLight);
  document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
    const lightLabel = button.dataset.lightLabel || "Light theme";
    const darkLabel = button.dataset.darkLabel || "Dark theme";
    const nextLabel = isLight ? darkLabel : lightLabel;
    button.textContent = isLight ? "☀" : "☾";
    button.setAttribute("aria-label", nextLabel);
    button.setAttribute("title", nextLabel);
  });
}

function initTheme() {
  const savedTheme = localStorage.getItem("securemail-theme") || "dark";
  applyTheme(savedTheme);

  document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
    button.addEventListener("click", () => {
      const nextTheme = document.body.classList.contains("light-theme") ? "dark" : "light";
      localStorage.setItem("securemail-theme", nextTheme);
      applyTheme(nextTheme);
    });
  });
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function formatDateTime(value) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat("ru-RU", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(date);
}

function sortByNewest(items) {
  return (items || []).slice().sort((a, b) => {
    const ad = new Date(a.created_at || 0).getTime();
    const bd = new Date(b.created_at || 0).getTime();
    if (!Number.isNaN(ad) && !Number.isNaN(bd) && ad !== bd) return bd - ad;
    return (Number(b.id) || 0) - (Number(a.id) || 0);
  });
}

function indicatorHtml(indicators) {
  if (!indicators || !indicators.length) {
    return "<p class='muted'>No concrete indicators extracted.</p>";
  }
  return `<div class="indicator-grid">${indicators.slice(0, 8).map((item) => `
    <div class="indicator-pill">
      <strong>${escapeHtml(item.kind)}</strong><br>
      <span>${escapeHtml(item.reason)}</span>
    </div>`).join("")}</div>`;
}

function renderScanResult(result) {
  const attachmentSummary = result.attachment_summary;
  return `
    <div class="feed-card-top">
      <strong>Final DLP decision</strong>
      ${severityBadge(result.severity)}
    </div>
    <p>${escapeHtml(result.summary)}</p>
    <p class="muted">Confidence ${result.score} | Channel ${escapeHtml(result.channel)} | Actions ${(result.actions || []).join(", ")}</p>
    ${attachmentSummary && attachmentSummary.count ? `<p class="muted">Attachments ${attachmentSummary.count} | Max severity ${escapeHtml(attachmentSummary.max_severity)} | Critical ${attachmentSummary.critical_count}</p>` : ""}
    ${indicatorHtml(result.indicators)}
  `;
}

function renderMessages(messages, filter = "") {
  const state = window.mailState || (window.mailState = { folder: "all", selectedId: null, messages: [], severity: "ALL" });
  const normalized = filter.trim().toLowerCase();
  const filteredBySeverity = state.severity === "ALL"
    ? messages
    : messages.filter((item) => String(item.dlp?.severity || "SAFE").toUpperCase() === state.severity);
  const filtered = normalized
    ? filteredBySeverity.filter((item) => [item.sender, item.recipient, item.subject, item.status, item.dlp?.severity].join(" ").toLowerCase().includes(normalized))
    : filteredBySeverity;
  const ordered = filtered.slice().reverse();
  return ordered.length ? ordered.map((message) => `
    <article class="message-row severity-${(message.dlp?.severity || "safe").toLowerCase()} ${message.is_read ? "" : "message-unread"}" data-message-id="${message.id}">
      <div class="message-row-top">
        <strong>${escapeHtml(message.subject || "(no subject)")}</strong>
        <span>${escapeHtml(message.status || "draft")}</span>
      </div>
      <div class="message-markers">
        ${message.privacy_access && !message.privacy_access.granted ? `<span class="privacy-marker restricted"><span class="marker-icon">🔒</span>Restricted body</span>` : ""}
        ${message.privacy_access?.severity === "MEDIUM" && !message.privacy_access?.granted ? `<span class="privacy-marker review"><span class="marker-icon">⏳</span>Approval required</span>` : ""}
      </div>
      <p>${escapeHtml(message.sender)} -> ${escapeHtml(message.recipient)}</p>
      <p class="muted">${escapeHtml(message.dlp?.severity || "SAFE")} | ${escapeHtml(message.dlp?.summary || "")}</p>
    </article>
  `).join("") : "<div class='empty-block'>No messages matched the filter.</div>";
}

function renderAdminMessages(messages) {
  const state = window.adminMessageState || (window.adminMessageState = { severity: "ALL" });
  const filtered = state.severity === "ALL"
    ? (messages || [])
    : (messages || []).filter((item) => String(item.dlp?.severity || "SAFE").toUpperCase() === state.severity);
  if (!filtered.length) {
    return "<div class='empty-block'>No messages for this severity filter.</div>";
  }
  return filtered.slice().reverse().map((message) => `
    <article class="feed-card severity-${String(message.dlp?.severity || "safe").toLowerCase()}" data-message-id="${message.id}">
      <div class="feed-card-top">
        <strong>${escapeHtml(message.subject || "(no subject)")}</strong>
        ${severityBadge(message.dlp?.severity || "SAFE")}
      </div>
      <div class="message-markers">
        ${message.privacy_access && !message.privacy_access.granted ? `<span class="privacy-marker restricted"><span class="marker-icon">🔒</span>Restricted body</span>` : ""}
        ${message.privacy_access?.severity === "MEDIUM" && !message.privacy_access?.granted ? `<span class="privacy-marker review"><span class="marker-icon">⏳</span>Approval required</span>` : ""}
      </div>
      <p>${escapeHtml(message.sender)} -> ${escapeHtml(message.recipient)}</p>
      <p class="muted">${escapeHtml(message.dlp?.summary || "")}</p>
    </article>
  `).join("");
}

function renderIncidents(incidents, adminMode = false) {
  if (!incidents.length) return "<div class='empty-block'>No incidents recorded.</div>";
  return incidents.slice().reverse().map((incident) => `
    <article class="feed-card severity-${incident.severity.toLowerCase()}">
      <div class="feed-card-top">
        <strong>${adminMode ? `#${incident.id} ` : ""}${escapeHtml(incident.type)}</strong>
        <span>${escapeHtml(incident.severity)}</span>
      </div>
      <p>${escapeHtml(incident.summary)}</p>
      ${adminMode ? `<div class="feed-actions">
        <span class="status-chip">${escapeHtml(incident.status || "open")}</span>
        <button class="table-action" type="button" data-incident-id="${incident.id}" data-incident-status="resolved">Resolve</button>
      </div>` : ""}
    </article>
  `).join("");
}

function renderDevices(devices, mode = "cards") {
  if (!devices.length) return "<div class='empty-block'>No devices detected.</div>";
  if (mode === "table") {
    return devices.slice().reverse().map((device) => `
      <tr>
        <td><strong>${escapeHtml(device.device_name)}</strong><div class="muted">${escapeHtml(device.serial || device.device_key)}</div></td>
        <td>${escapeHtml(device.connection_state || "unknown")}</td>
        <td>${escapeHtml(device.policy || "review")}</td>
        <td>${escapeHtml(device.owner || "Unknown")}</td>
        <td>
          <div class="action-row">
            <button class="table-action" type="button" data-device-key="${escapeHtml(device.device_key)}" data-device-policy="authorized">Authorize</button>
            <button class="table-action" type="button" data-device-key="${escapeHtml(device.device_key)}" data-device-policy="review">Review</button>
            <button class="table-action danger" type="button" data-device-key="${escapeHtml(device.device_key)}" data-device-policy="blocked">Block</button>
          </div>
        </td>
      </tr>
    `).join("");
  }
  return devices.slice().reverse().map((device) => `
    <article class="feed-card severity-${device.policy === "blocked" ? "critical" : "low"}">
      <div class="feed-card-top">
        <strong>${escapeHtml(device.device_name)}</strong>
        <span>${escapeHtml(device.policy || "review")}</span>
      </div>
      <p>${escapeHtml(device.connection_state || "unknown")} | ${escapeHtml(device.media_type || "USB")}</p>
    </article>
  `).join("");
}

function renderDeviceEvents(events) {
  if (!events.length) return "<div class='empty-block'>No device events logged.</div>";
  return events.slice().reverse().map((event) => `
    <article class="feed-card severity-${event.severity.toLowerCase()}">
      <div class="feed-card-top">
        <strong>${escapeHtml(event.device_name)}</strong>
        <span>${escapeHtml(event.event)}</span>
      </div>
      <p>${escapeHtml(event.notes || "")}</p>
    </article>
  `).join("");
}

function renderDeviceRules(rules) {
  if (!rules || !rules.length) return "<div class='empty-block'>No persistent USB rules yet.</div>";
  return rules.slice().reverse().map((rule) => `
    <article class="feed-card severity-${rule.policy === "blocked" ? "critical" : "low"}">
      <div class="feed-card-top">
        <strong>${escapeHtml(rule.match_type)}</strong>
        <span>${escapeHtml(rule.policy)}</span>
      </div>
      <p>${escapeHtml(rule.match_value)}</p>
      <p class="muted">${escapeHtml(rule.owner || "Security Admin")}</p>
    </article>
  `).join("");
}

function renderAccounts(accounts) {
  if (!accounts.length) return "<tr><td colspan='6'>No accounts found.</td></tr>";
  return accounts.slice().reverse().map((account) => `
    <tr>
      <td><strong>${escapeHtml(account.name)}</strong><div class="muted">${escapeHtml(account.email)}</div></td>
      <td>${escapeHtml(account.role || account.department || "")}</td>
      <td>${escapeHtml(account.status || "active")}</td>
      <td>${account.can_send ? "Allowed" : "Blocked"}</td>
      <td>${escapeHtml(account.blocked_reason || "-")}</td>
      <td>
        <div class="action-row">
          <button class="table-action" type="button" data-account-email="${escapeHtml(account.email)}" data-account-mode="${account.can_send ? "block" : "allow"}">
            ${account.can_send ? "Block send" : "Allow send"}
          </button>
          <button class="table-action danger" type="button" data-account-delete="${escapeHtml(account.email)}">
            Delete
          </button>
        </div>
      </td>
    </tr>
  `).join("");
}

function renderAgents(agents) {
  if (!agents || !agents.length) {
    return "<tr><td colspan='9'>No endpoint agents registered.</td></tr>";
  }
  return agents.slice().reverse().map((agent) => `
    <tr>
      <td><strong><a class="table-link" href="/admin/agents/${encodeURIComponent(agent.agent_id)}">${escapeHtml(agent.display_name || agent.agent_id)}</a></strong><div class="muted">${escapeHtml(agent.agent_id || "-")}</div></td>
      <td>${escapeHtml(agent.actor_email || "-")}</td>
      <td>${agent.is_online ? '<span class="status-chip severity-low">online</span>' : '<span class="status-chip severity-medium">offline</span>'}</td>
      <td>${escapeHtml(agent.hostname || "-")}</td>
      <td>${escapeHtml(agent.version || "-")}</td>
      <td>${escapeHtml(agent.last_seen_at || "-")}</td>
      <td>${escapeHtml((agent.monitors || []).join(", ") || "-")}</td>
      <td>${escapeHtml((agent.channels || []).join(", ") || "-")}</td>
      <td>
        <div class="action-row">
          <button class="table-action" type="button" data-agent-id="${escapeHtml(agent.agent_id)}" data-agent-action="rotate_key">Rotate key</button>
          ${agent.status === "revoked"
            ? `<button class="table-action" type="button" data-agent-id="${escapeHtml(agent.agent_id)}" data-agent-action="reactivate">Reactivate</button>`
            : `<button class="table-action danger" type="button" data-agent-id="${escapeHtml(agent.agent_id)}" data-agent-action="revoke">Revoke</button>`}
        </div>
      </td>
    </tr>
  `).join("");
}

function renderAgentAudit(events) {
  if (!events || !events.length) return "<div class='empty-block'>No audit events for this agent yet.</div>";
  const humanize = (event) => {
    const payload = event?.payload || {};
    const verdict = payload.verdict || payload.severity || payload.result?.severity;
    const channel = payload.channel || payload.source || payload.origin;
    const target = payload.file || payload.path || payload.filename || payload.device_name || payload.target_name;
    const action = payload.action || payload.event || payload.operation;
    const platform = payload.platform || payload.app || payload.app_name;
    const destination = payload.destination || payload.target || payload.recipient;
    if (event.event_type === "agent_external_inspect") {
      const app = platform ? ` in ${platform}` : "";
      const dest = destination ? ` to ${destination}` : "";
      return `Content${app}${dest} was scanned. Severity: ${verdict || "SAFE"}.`;
    }
    if (event.event_type === "agent_device_event") {
      return `USB/device event from ${target || "device"} (severity ${verdict || "LOW"}).`;
    }
    if (event.event_type === "agent_device_detected") {
      return `New device detected: ${target || "USB device"}.`;
    }
    if (event.event_type === "agent_device_disconnected") {
      return `Device disconnected: ${target || "USB device"}.`;
    }
    if (event.event_type === "agent_heartbeat") {
      return "Agent heartbeat received (status OK).";
    }
    if (event.event_type === "agent_enrolled") {
      return "Agent successfully enrolled and linked to the server.";
    }
    if (event.event_type === "agent_key_rotated") {
      return "Agent key rotated for security.";
    }
    if (verdict && target) return `Detected ${verdict} data in ${target}.`;
    if (verdict && channel) return `Detected ${verdict} data from ${channel}.`;
    if (action && target) return `${action} on ${target}.`;
    if (action) return `${action} recorded by the agent.`;
    return "Agent activity recorded.";
  };
  const ordered = sortByNewest(events);
  return ordered.map((event) => {
    const payload = event?.payload || {};
    const chips = [];
    if (payload.severity || payload.verdict) chips.push(`<span class="audit-chip severity-${String(payload.severity || payload.verdict).toLowerCase()}">${escapeHtml(payload.severity || payload.verdict)}</span>`);
    if (payload.channel) chips.push(`<span class="audit-chip">${escapeHtml(payload.channel)}</span>`);
    if (payload.platform) chips.push(`<span class="audit-chip">${escapeHtml(payload.platform)}</span>`);
    if (payload.destination) chips.push(`<span class="audit-chip">${escapeHtml(payload.destination)}</span>`);
    return `
    <article class="audit-card">
      <div class="audit-header">
        <span class="audit-tag">${escapeHtml(event.event_type || "event")}</span>
        <span class="muted">${escapeHtml(formatDateTime(event.created_at))}</span>
      </div>
      <div class="audit-meta">
        <span class="muted">Actor</span>
        <strong>${escapeHtml(event.actor || "Agent")}</strong>
      </div>
      <p>${escapeHtml(humanize(event))}</p>
      ${chips.length ? `<div class="audit-chips">${chips.join("")}</div>` : ""}
      <details class="payload-details">
        <summary>Show technical details</summary>
        <pre class="payload-pre">${escapeHtml(JSON.stringify(event.payload || {}, null, 2))}</pre>
      </details>
    </article>
  `;
  }).join("");
}

function renderAgentIncidents(incidents) {
  if (!incidents || !incidents.length) return "<div class='empty-block'>No incidents linked to this agent.</div>";
  return incidents.slice().reverse().map((incident) => `
    <article class="feed-card severity-${String(incident.severity || "safe").toLowerCase()}">
      <div class="feed-card-top">
        <strong>${escapeHtml(incident.type || "incident")}</strong>
        <span>${escapeHtml(incident.severity || "SAFE")}</span>
      </div>
      <p>${escapeHtml(incident.summary || "")}</p>
    </article>
  `).join("");
}

function renderAgentDevices(devices) {
  if (!devices || !devices.length) return "<div class='empty-block'>No devices linked to this agent.</div>";
  return devices.slice().reverse().map((device) => `
    <article class="feed-card severity-${device.policy === "blocked" ? "critical" : "low"}">
      <div class="feed-card-top">
        <strong>${escapeHtml(device.device_name || "device")}</strong>
        <span>${escapeHtml(device.policy || "review")}</span>
      </div>
      <p class="muted">${escapeHtml(device.serial || device.device_key || "")}</p>
      <p>${escapeHtml(device.connection_state || "unknown")}</p>
    </article>
  `).join("");
}

function renderMediumMessages(messages) {
  const state = window.adminMediumState || (window.adminMediumState = { filter: "medium" });
  const source = (messages || []).filter((item) => state.filter === "all" || String(item.dlp?.severity || "").toUpperCase() === "MEDIUM");
  if (!source.length) {
    return "<div class='empty-block'>No medium-risk messages require controlled access right now.</div>";
  }
  return source.slice().reverse().map((message) => {
    const granted = Boolean(message.privacy_access?.granted);
    const restricted = Boolean(message.privacy_access && !message.privacy_access.granted);
    return `
      <article class="feed-card severity-${String(message.dlp?.severity || "medium").toLowerCase()}">
        <div class="feed-card-top">
          <strong>${escapeHtml(message.subject || "(no subject)")}</strong>
          <span>${escapeHtml(message.dlp?.severity || "MEDIUM")}</span>
        </div>
        <div class="message-markers">
          ${restricted ? `<span class="privacy-marker restricted"><span class="marker-icon">🔒</span>Restricted body</span>` : ""}
          ${String(message.dlp?.severity || "").toUpperCase() === "MEDIUM" && !granted ? `<span class="privacy-marker review"><span class="marker-icon">⏳</span>Approval required</span>` : ""}
        </div>
        <p>${escapeHtml(message.sender)} -> ${escapeHtml(message.recipient)}</p>
        <p class="muted">${escapeHtml(message.dlp?.summary || "")}</p>
        <div class="feed-actions" style="margin-top:12px;">
          <button class="table-action" type="button" data-message-id="${message.id}">Open</button>
          ${granted ? `<span class="status-chip">Access granted</span>` : `<button class="table-action" type="button" data-message-access-request="${message.id}">Request access</button>`}
        </div>
      </article>
    `;
  }).join("");
}

function renderAudit(events) {
  if (!events.length) return "<div class='empty-block'>No audit data yet.</div>";
  return events.slice().reverse().slice(0, 50).map((event) => `
    <article class="feed-card audit-card">
      <div class="feed-card-top">
        <strong>${escapeHtml(event.event_type)}</strong>
        <span>#${event.id}</span>
      </div>
      <p>${escapeHtml(event.actor)}</p>
      <p class="mono muted">${escapeHtml((event.entry_hash || "").slice(0, 18))}...</p>
    </article>
  `).join("");
}

function renderMessageDetail(message) {
  if (!message) {
    return "Select a message to inspect full content, DLP decision and attachment results.";
  }
  const privacy = message.privacy_access || null;
  const privacyBanner = privacy
    ? `
      <div class="privacy-banner ${privacy.granted ? "granted" : "restricted"}">
        <div>
          <strong>${privacy.granted ? "Governed access granted" : "Protected correspondence"}</strong>
          <p>${privacy.granted
            ? `Access mode: ${escapeHtml(privacy.mode || "direct")}. Sensitive content is still redacted for governance.`
            : `Admins cannot read the full body for ${escapeHtml(privacy.severity || "SAFE")} messages without policy permission.`}</p>
        </div>
        ${!privacy.granted ? `<span class="status-chip">${escapeHtml(privacy.severity || "SAFE")}</span>` : ""}
      </div>
    `
    : "";
  const accessBlock = privacy && privacy.severity === "MEDIUM" && !privacy.granted
    ? `
      <div class="feed-actions request-pane-actions" style="margin: 12px 0;">
        <button class="primary-button" type="button" data-message-access-request="${message.id}">Request access</button>
      </div>
      <p class="muted">For MEDIUM-risk messages, admin access requires approval from both sender and recipient.</p>
    `
    : "";
  const attachmentSummary = message.dlp?.attachment_summary;
  const attachments = (message.attachments || []).length
    ? `<div class="indicator-grid">${message.attachments.map((item) => `
        <div class="indicator-pill">
          <strong>${escapeHtml(item.filename)}</strong><br>
          <span>${escapeHtml(item.result?.severity || "SAFE")} | ${escapeHtml(item.result?.summary || "")}</span><br>
          <span class="muted">${escapeHtml((item.extracted_text || "").slice(0, 100))}</span>
        </div>`).join("")}</div>`
    : "<p class='muted'>No attachments.</p>";
  return `
    <div class="feed-card-top">
      <strong>${escapeHtml(message.subject || "(no subject)")}</strong>
      ${severityBadge(message.dlp?.severity || "SAFE")}
    </div>
    <p class="muted">${escapeHtml(message.sender)} -> ${escapeHtml(message.recipient)} | ${escapeHtml(message.folder || "inbox")}</p>
    ${privacyBanner}
    <p>${escapeHtml(message.body || "")}</p>
    ${accessBlock}
    <p class="muted">${escapeHtml(message.dlp?.summary || "")}</p>
    ${attachmentSummary && attachmentSummary.count ? `<p class="muted">Attachments ${attachmentSummary.count} | Max severity ${escapeHtml(attachmentSummary.max_severity)} | Critical ${attachmentSummary.critical_count}</p>` : ""}
    ${indicatorHtml(message.dlp?.indicators || [])}
    <h3>Attachments</h3>
    ${attachments}
  `;
}

function renderAttachments(items) {
  if (!items.length) return "<div class='empty-block'>No attachments recorded.</div>";
  return items.slice().reverse().map((item) => `
    <article class="feed-card severity-${(item.result?.severity || "safe").toLowerCase()}" data-attachment-id="${item.id}">
      <div class="feed-card-top">
        <strong>${escapeHtml(item.filename)}</strong>
        <span>${escapeHtml(item.result?.severity || "SAFE")}</span>
      </div>
      <p>${escapeHtml(item.subject || "No subject")}</p>
      <p class="muted">${escapeHtml(item.sender || "")} -> ${escapeHtml(item.recipient || "")}</p>
      <p class="muted">${escapeHtml((item.result?.summary || "").slice(0, 120))}</p>
      <p class="mono muted">${escapeHtml((item.extracted_text || "").slice(0, 140))}</p>
    </article>
  `).join("");
}

function renderAttachmentDetail(item) {
  if (!item) return "Select an attachment to inspect extracted text, OCR output and DLP reasoning.";
  return `
    <div class="feed-card-top">
      <strong>${escapeHtml(item.filename)}</strong>
      ${severityBadge(item.result?.severity || "SAFE")}
    </div>
    <p class="muted">${escapeHtml(item.sender || "")} -> ${escapeHtml(item.recipient || "")} | ${escapeHtml(item.subject || "No subject")}</p>
    <p>${escapeHtml(item.result?.summary || "No summary available.")}</p>
    ${indicatorHtml(item.result?.indicators || [])}
    <h3>Extracted text</h3>
    <pre class="detail-pre">${escapeHtml(item.extracted_text || "No extracted text stored.")}</pre>
  `;
}

function renderPolicies(policies) {
  if (!policies || !policies.length) return "<div class='empty-block'>No policy packs configured.</div>";
  return policies.slice().reverse().map((policy) => `
    <article class="feed-card">
      <div class="feed-card-top">
        <strong>${escapeHtml(policy.name)}</strong>
        <span>${escapeHtml(policy.channel)}</span>
      </div>
      <p>${escapeHtml(policy.notes || "")}</p>
      <p class="muted">Quarantine ${escapeHtml(policy.quarantine_threshold)} | Block ${escapeHtml(policy.block_threshold)}</p>
    </article>
  `).join("");
}

function renderJobs(jobs) {
  if (!jobs || !jobs.length) return "<div class='empty-block'>No scan jobs recorded.</div>";
  return jobs.slice().reverse().map((job) => `
    <article class="feed-card severity-${String(job.severity || "safe").toLowerCase()}" data-job-id="${job.id}">
      <div class="feed-card-top">
        <strong>${escapeHtml(job.job_type)}</strong>
        <span>${escapeHtml(job.status || "queued")}</span>
      </div>
      <p>${escapeHtml(job.target_name || "unknown target")}</p>
      <p class="muted">${escapeHtml(job.channel || "email")} | ${escapeHtml(job.severity || "SAFE")} | ${escapeHtml((job.summary || "").slice(0, 120))}</p>
    </article>
  `).join("");
}

function renderJobDetail(job) {
  if (!job) return "Select a scan job to inspect lifecycle, final severity and pipeline output.";
  return `
    <div class="feed-card-top">
      <strong>${escapeHtml(job.job_type)}</strong>
      <span>${escapeHtml(job.status || "queued")}</span>
    </div>
    <p class="muted">${escapeHtml(job.channel || "email")} | ${escapeHtml(job.target_name || "unknown target")}</p>
    <p>${escapeHtml(job.summary || "Job is still being processed.")}</p>
    ${job.result ? `
      ${severityBadge(job.result.severity || job.severity || "SAFE")}
      ${indicatorHtml(job.result.indicators || [])}
      <pre class="detail-pre">${escapeHtml(JSON.stringify(job.result, null, 2))}</pre>
    ` : "<p class='muted'>Awaiting final scan payload.</p>"}
  `;
}

function renderAnalytics(analytics) {
  if (!analytics) return "<div class='empty-block'>No analytics available.</div>";
  const sev = analytics.message_severity || {};
  const jobs = analytics.scan_jobs || {};
  const devices = analytics.devices || {};
  const channels = analytics.channels || {};
  const jobTypes = analytics.job_types || {};
  const timeline = analytics.timeline || { days: [], messages: [], incidents: [], jobs: [] };
  const seriesMax = Math.max(1, ...timeline.messages, ...timeline.incidents, ...timeline.jobs);
  const trendBars = timeline.days.map((day, index) => `
    <div class="trend-day">
      <div class="trend-bars">
        <span class="trend-bar trend-mail" style="height:${Math.max(8, (timeline.messages[index] / seriesMax) * 72)}px" title="Messages ${timeline.messages[index]}"></span>
        <span class="trend-bar trend-incident" style="height:${Math.max(8, (timeline.incidents[index] / seriesMax) * 72)}px" title="Incidents ${timeline.incidents[index]}"></span>
        <span class="trend-bar trend-job" style="height:${Math.max(8, (timeline.jobs[index] / seriesMax) * 72)}px" title="Jobs ${timeline.jobs[index]}"></span>
      </div>
      <small>${escapeHtml(day.slice(5))}</small>
    </div>
  `).join("");
  const breakdown = (entries) => Object.entries(entries).length
    ? Object.entries(entries).map(([key, value]) => `<div class="indicator-pill"><strong>${escapeHtml(key)}</strong><br><span>${escapeHtml(value)}</span></div>`).join("")
    : "<div class='indicator-pill'><strong>None</strong><br><span>0</span></div>";
  return `
    <div class="analytics-stack">
      <div class="indicator-grid">
        <div class="indicator-pill"><strong>SAFE</strong><br><span>${escapeHtml(sev.SAFE || 0)}</span></div>
        <div class="indicator-pill"><strong>LOW</strong><br><span>${escapeHtml(sev.LOW || 0)}</span></div>
        <div class="indicator-pill"><strong>MEDIUM</strong><br><span>${escapeHtml(sev.MEDIUM || 0)}</span></div>
        <div class="indicator-pill"><strong>HIGH</strong><br><span>${escapeHtml(sev.HIGH || 0)}</span></div>
        <div class="indicator-pill"><strong>CRITICAL</strong><br><span>${escapeHtml(sev.CRITICAL || 0)}</span></div>
        <div class="indicator-pill"><strong>Jobs</strong><br><span>${escapeHtml(jobs.completed || 0)} completed</span></div>
        <div class="indicator-pill"><strong>Devices</strong><br><span>${escapeHtml(devices.connected || 0)} connected</span></div>
        <div class="indicator-pill"><strong>Blocked USB</strong><br><span>${escapeHtml(devices.blocked || 0)}</span></div>
      </div>
      <div class="trend-card">
        <div class="feed-card-top">
          <strong>7-day activity trend</strong>
          <span class="muted">Mail / Incidents / Jobs</span>
        </div>
        <div class="trend-chart">${trendBars || "<div class='empty-block'>No trend data.</div>"}</div>
      </div>
      <div class="indicator-grid">
        ${breakdown(channels)}
      </div>
      <div class="indicator-grid">
        ${breakdown(jobTypes)}
      </div>
    </div>
  `;
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let payload = {};
    try {
      payload = await response.json();
    } catch {
      payload = {};
    }
    throw new Error(payload.reason || payload.error || `Request failed: ${response.status}`);
  }
  return response.json();
}

async function refreshMailbox(searchValue = "") {
  const state = window.mailState || (window.mailState = { folder: "all", selectedId: null, messages: [] });
  const [messages, incidents] = await Promise.all([
    fetchJson("/api/messages"),
    fetchJson("/api/incidents"),
  ]);
  state.messages = messages;
  const filteredByFolder = state.folder === "all" ? messages : messages.filter((item) => (item.folder || "inbox") === state.folder);
  const messageList = document.getElementById("message-list");
  const incidentFeed = document.getElementById("incident-feed");
  if (messageList) messageList.innerHTML = renderMessages(filteredByFolder, searchValue);
  if (incidentFeed) incidentFeed.innerHTML = renderIncidents(incidents, false);
  if (state.selectedId) {
    const detail = document.getElementById("message-detail");
    const selected = state.messages.find((item) => Number(item.id) === Number(state.selectedId));
    if (detail && selected) detail.innerHTML = renderMessageDetail(selected);
  }
}

async function refreshAdmin() {
  const [accounts, incidents, devices, deviceEvents, messages] = await Promise.all([
    fetchJson("/api/accounts"),
    fetchJson("/api/incidents"),
    fetchJson("/api/devices"),
    fetchJson("/api/device-events"),
    fetchJson("/api/messages"),
  ]);
  const accountsTable = document.getElementById("accounts-table");
  const adminIncidentFeed = document.getElementById("admin-incident-feed");
  const devicesTable = document.getElementById("devices-table");
  const deviceFeed = document.getElementById("device-feed");
  const mediumFeed = document.getElementById("admin-medium-feed");
  if (accountsTable) accountsTable.innerHTML = renderAccounts(accounts);
  if (adminIncidentFeed) adminIncidentFeed.innerHTML = renderIncidents(incidents, true);
  if (devicesTable) devicesTable.innerHTML = renderDevices(devices, "table");
  if (deviceFeed) deviceFeed.innerHTML = renderDeviceEvents(deviceEvents);
  if (mediumFeed) {
    mediumFeed.innerHTML = renderMediumMessages(messages);
  }
}

async function refreshAgentsPage() {
  const agents = await fetchJson("/api/agents");
  const agentsTable = document.getElementById("agents-table");
  const agentsCount = document.getElementById("agents-count");
  const agentsOnline = document.getElementById("agents-online");
  if (agentsTable) agentsTable.innerHTML = renderAgents(agents);
  if (agentsCount) agentsCount.textContent = String(agents.length);
  if (agentsOnline) agentsOnline.textContent = String(agents.filter((item) => item.is_online).length);
}

async function refreshAgentDetailPage(agentId) {
  if (!agentId) return;
  const activity = await fetchJson(`/api/agents/${encodeURIComponent(agentId)}/activity`);
  const auditFeed = document.getElementById("agent-audit-feed");
  const incidentFeed = document.getElementById("agent-incident-feed");
  const deviceFeed = document.getElementById("agent-devices-feed");
  if (auditFeed) auditFeed.innerHTML = renderAgentAudit(activity.audit_events || []);
  if (incidentFeed) incidentFeed.innerHTML = renderAgentIncidents(activity.incidents || []);
  if (deviceFeed) deviceFeed.innerHTML = renderAgentDevices(activity.devices || []);
}

function renderSimulatorMetrics(stats) {
  const levels = ["safe", "low", "medium", "high", "critical"];
  return levels.map((level) => `
    <article class="metric-card ${level}">
      <span>${level.toUpperCase()}</span>
      <strong>${Number(stats?.[level] || 0)}</strong>
    </article>
  `).join("");
}

function renderSimulatorChannels(stats) {
  const items = [
    ["Mail", stats?.mail_events || 0],
    ["Internet", stats?.external_events || 0],
    ["Endpoint", stats?.endpoint_events || 0],
    ["Admin", stats?.admin_actions || 0],
  ];
  return items.map(([label, value]) => `
    <article class="channel-card">
      <span>${escapeHtml(label)}</span>
      <strong>${Number(value)}</strong>
    </article>
  `).join("");
}

function renderSimulatorParticipants(participants, type) {
  const list = participants?.[type] || [];
  if (!list.length) {
    return "<div class='empty-block'>No simulator participants yet.</div>";
  }
  if (type === "accounts") {
    return list.map((account) => `
      <article class="participant-card">
        <strong>${escapeHtml(account.name)}</strong>
        <span>${escapeHtml(account.email)}</span>
        <small>${escapeHtml(account.department || "-")} | ${escapeHtml(account.status || "active")}${account.can_send === false ? " | send blocked" : ""}</small>
      </article>
    `).join("");
  }
  return list.map((agent) => `
    <article class="participant-card">
      <strong>${escapeHtml(agent.display_name)}</strong>
      <span>${escapeHtml(agent.actor_email || "-")}</span>
      <small>${escapeHtml(agent.hostname || "-")} | ${agent.is_online ? "online" : "offline"} | ${escapeHtml(formatDateTime(agent.last_seen_at))}</small>
    </article>
  `).join("");
}

function renderSimulatorCatalog(catalog) {
  if (!catalog || !catalog.length) return "<div class='empty-block'>No scenarios configured.</div>";
  return catalog.map((item) => `
    <article class="scenario-card">
      <div class="feed-card-top">
        <strong>${escapeHtml(item.title)}</strong>
        <span>${escapeHtml(item.kind)}</span>
      </div>
      <p class="muted">${escapeHtml(item.severity)}</p>
    </article>
  `).join("");
}

function renderSimulatorFeed(events) {
  if (!events || !events.length) {
    return "<div class='empty-block'>No simulation events yet. Start the engine to begin generating activity.</div>";
  }
  return events.map((event) => `
    <article class="feed-card severity-${String(event.severity || "safe").toLowerCase()}">
      <div class="feed-card-top">
        <strong>${escapeHtml(event.title)}</strong>
        ${severityBadge(event.severity || "SAFE")}
      </div>
      <p>${escapeHtml(event.summary)}</p>
      <p class="muted">${escapeHtml(formatDateTime(event.timestamp))} | ${escapeHtml(event.category || "simulation")} | step ${Number(event.step_index || 0)}</p>
    </article>
  `).join("");
}

async function refreshSimulatorPage() {
  const status = await fetchJson("/api/simulator/status");
  const running = document.getElementById("sim-running");
  const profile = document.getElementById("sim-profile");
  const total = document.getElementById("sim-total");
  const incidents = document.getElementById("sim-incidents");
  const metrics = document.getElementById("simulator-metrics");
  const channels = document.getElementById("simulator-channels");
  const users = document.getElementById("simulator-users");
  const agents = document.getElementById("simulator-agents");
  const catalog = document.getElementById("simulator-catalog");
  const feed = document.getElementById("simulator-feed");
  if (running) running.textContent = status.running ? "Yes" : "No";
  if (profile) profile.textContent = status.profile || "balanced";
  if (total) total.textContent = String(status.stats?.events_total || 0);
  if (incidents) incidents.textContent = String(status.stats?.incidents_created || 0);
  if (metrics) metrics.innerHTML = renderSimulatorMetrics(status.stats || {});
  if (channels) channels.innerHTML = renderSimulatorChannels(status.stats || {});
  if (users) users.innerHTML = renderSimulatorParticipants(status.participants || {}, "accounts");
  if (agents) agents.innerHTML = renderSimulatorParticipants(status.participants || {}, "agents");
  if (catalog) catalog.innerHTML = renderSimulatorCatalog(status.catalog || []);
  if (feed) feed.innerHTML = renderSimulatorFeed(status.recent_events || []);
  return status;
}

document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  window.adminMediumState = window.adminMediumState || { filter: "medium" };
  window.adminMessageState = window.adminMessageState || { severity: "ALL" };
  const composeForm = document.getElementById("compose-form");
  const channelForm = document.getElementById("channel-form");
  const pageName = document.querySelector("[data-page]")?.dataset.page || "";
  const scanButton = document.getElementById("scan-button");
  const channelScanButton = document.getElementById("channel-scan-button");
  const scanResult = document.getElementById("scan-result");
  const channelResult = document.getElementById("channel-result");
  const messageSearch = document.getElementById("message-search");
  const refreshMailButton = document.getElementById("refresh-mail");
  const syncDevices = document.getElementById("sync-devices");
  const syncDevicesAdmin = document.getElementById("sync-devices-admin");
  const messageDetail = document.getElementById("message-detail");
  const attachmentDetail = document.getElementById("attachment-detail");
  const jobDetail = document.getElementById("job-detail");
  const moveInbox = document.getElementById("move-inbox");
  const moveQuarantine = document.getElementById("move-quarantine");
  const policyForm = document.getElementById("policy-form");
  const policyResult = document.getElementById("policy-result");
  const refreshAgentsButton = document.getElementById("refresh-agents");
  const agentActionResult = document.getElementById("agent-action-result");
  const agentDetailRefresh = document.getElementById("refresh-agent-detail");
  const agentDetailId = document.querySelector("[data-page='admin-agent-detail']")?.dataset.agentId || "";
  const simulatorStart = document.getElementById("simulator-start");
  const simulatorStop = document.getElementById("simulator-stop");
  const simulatorStep = document.getElementById("simulator-step");
  const simulatorProfile = document.getElementById("simulator-profile");
  const simulatorInterval = document.getElementById("simulator-interval");
  const simulatorActionResult = document.getElementById("simulator-action-result");

  if (scanButton && composeForm && scanResult) {
    scanButton.addEventListener("click", async () => {
      try {
        const result = await fetchJson("/api/scan", { method: "POST", body: new FormData(composeForm) });
        if (result.queued) {
          scanResult.innerHTML = `
            <div class="feed-card-top">
              <strong>Draft scan queued</strong>
              <span>#${escapeHtml(result.job?.id || "")}</span>
            </div>
            <p>${escapeHtml(result.message || "Background scan started.")}</p>
            <p class="muted">Track the lifecycle in Scan Jobs and wait for live updates.</p>
          `;
          if (jobDetail && result.job) jobDetail.innerHTML = renderJobDetail(result.job);
        } else {
          scanResult.innerHTML = renderScanResult(result);
        }
      } catch (error) {
        scanResult.innerHTML = `<div class="empty-block">${escapeHtml(error.message)}</div>`;
      }
    });

    composeForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      try {
        const result = await fetchJson("/api/send", { method: "POST", body: new FormData(composeForm) });
        scanResult.innerHTML = `
          <div class="feed-card-top">
            <strong>Mail ${escapeHtml(result.status)}</strong>
            ${severityBadge(result.final_result.severity)}
          </div>
          <p>${escapeHtml(result.final_result.summary)}</p>
          <p class="muted">Allowed ${String(result.allowed)} | Actions ${(result.final_result.actions || []).join(", ")}</p>
          ${(result.final_result.attachment_summary && result.final_result.attachment_summary.count) ? `<p class="muted">Attachments ${result.final_result.attachment_summary.count} | Max severity ${escapeHtml(result.final_result.attachment_summary.max_severity)}</p>` : ""}
          ${indicatorHtml(result.final_result.indicators)}
        `;
        await refreshMailbox(messageSearch ? messageSearch.value : "");
      } catch (error) {
        scanResult.innerHTML = `<div class="empty-block">${escapeHtml(error.message)}</div>`;
      }
    });
  }

  if (channelScanButton && channelForm && channelResult) {
    channelScanButton.addEventListener("click", async () => {
      try {
        const result = await fetchJson("/api/external-channel/scan", { method: "POST", body: new FormData(channelForm) });
        channelResult.innerHTML = renderScanResult(result);
      } catch (error) {
        channelResult.innerHTML = `<div class="empty-block">${escapeHtml(error.message)}</div>`;
      }
    });
  }

  if (channelForm && channelResult) {
    channelForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      try {
        const result = await fetchJson("/api/external-channel/send", { method: "POST", body: new FormData(channelForm) });
        channelResult.innerHTML = `
          <div class="feed-card-top">
            <strong>External channel ${escapeHtml(result.status)}</strong>
            ${severityBadge(result.final_result.severity)}
          </div>
          <p>${escapeHtml(result.final_result.summary)}</p>
          <p class="muted">Allowed ${String(result.allowed)} | Actions ${(result.final_result.actions || []).join(", ")}</p>
          ${(result.final_result.attachment_summary && result.final_result.attachment_summary.count) ? `<p class="muted">Attachments ${result.final_result.attachment_summary.count} | Max severity ${escapeHtml(result.final_result.attachment_summary.max_severity)}</p>` : ""}
          ${indicatorHtml(result.final_result.indicators)}
        `;
        setTimeout(() => window.location.reload(), 600);
      } catch (error) {
        channelResult.innerHTML = `<div class="empty-block">${escapeHtml(error.message)}</div>`;
      }
    });
  }

  if (messageSearch) {
    messageSearch.addEventListener("input", () => {
      refreshMailbox(messageSearch.value).catch(() => {});
    });
  }

  if (refreshMailButton) {
    refreshMailButton.addEventListener("click", () => refreshMailbox(messageSearch ? messageSearch.value : ""));
  }

  document.querySelectorAll("[data-folder]").forEach((button) => {
    button.addEventListener("click", async () => {
      document.querySelectorAll("[data-folder]").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      const state = window.mailState || (window.mailState = { folder: "all", selectedId: null, messages: [] });
      state.folder = button.dataset.folder || "all";
      await refreshMailbox(messageSearch ? messageSearch.value : "");
    });
  });

  document.querySelectorAll("[data-severity-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      const state = window.mailState || (window.mailState = { folder: "all", selectedId: null, messages: [], severity: "ALL" });
      state.severity = button.dataset.severityFilter || "ALL";
      document.querySelectorAll("[data-severity-filter]").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      if (pageName === "mailbox") {
        await refreshMailbox(messageSearch ? messageSearch.value : "");
      }
    });
  });

  document.querySelectorAll("[data-admin-severity-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      window.adminMessageState.severity = button.dataset.adminSeverityFilter || "ALL";
      document.querySelectorAll("[data-admin-severity-filter]").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      if (pageName === "admin") {
        await refreshAdmin().catch(() => {});
      }
    });
  });

  document.querySelectorAll("[data-medium-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      window.adminMediumState.filter = button.dataset.mediumFilter || "medium";
      document.querySelectorAll("[data-medium-filter]").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      if (pageName === "admin") {
        await refreshAdmin().catch(() => {});
      }
    });
  });

  async function handleDeviceSync() {
    await fetchJson("/api/devices/sync", { method: "POST" });
    await refreshMailbox(messageSearch ? messageSearch.value : "");
    await refreshAdmin();
  }

  if (syncDevices) syncDevices.addEventListener("click", handleDeviceSync);
  if (syncDevicesAdmin) syncDevicesAdmin.addEventListener("click", handleDeviceSync);
  if (refreshAgentsButton) refreshAgentsButton.addEventListener("click", () => refreshAgentsPage().catch(() => {}));
  if (agentDetailRefresh && agentDetailId) {
    agentDetailRefresh.addEventListener("click", () => refreshAgentDetailPage(agentDetailId).catch(() => {}));
  }
  if (simulatorStart) {
    simulatorStart.addEventListener("click", async () => {
      try {
        const status = await fetchJson("/api/simulator/start", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            profile: simulatorProfile ? simulatorProfile.value : "balanced",
            interval_seconds: simulatorInterval ? Number(simulatorInterval.value || 4) : 4,
          }),
        });
        if (simulatorActionResult) {
          simulatorActionResult.textContent = `Simulation started in ${status.profile} mode with ${status.interval_seconds}s interval.`;
        }
        await refreshSimulatorPage().catch(() => {});
      } catch (error) {
        if (simulatorActionResult) simulatorActionResult.textContent = error.message;
      }
    });
  }
  if (simulatorStop) {
    simulatorStop.addEventListener("click", async () => {
      try {
        await fetchJson("/api/simulator/stop", { method: "POST" });
        if (simulatorActionResult) simulatorActionResult.textContent = "Simulation stopped.";
        await refreshSimulatorPage().catch(() => {});
      } catch (error) {
        if (simulatorActionResult) simulatorActionResult.textContent = error.message;
      }
    });
  }
  if (simulatorStep) {
    simulatorStep.addEventListener("click", async () => {
      try {
        const result = await fetchJson("/api/simulator/step", { method: "POST" });
        if (simulatorActionResult) {
          simulatorActionResult.textContent = `${result.event?.title || "Scenario step"} completed with severity ${result.event?.severity || "SAFE"}.`;
        }
        await refreshSimulatorPage().catch(() => {});
      } catch (error) {
        if (simulatorActionResult) simulatorActionResult.textContent = error.message;
      }
    });
  }

  async function moveSelectedMessage(folder) {
    const state = window.mailState || (window.mailState = { folder: "all", selectedId: null, messages: [] });
    if (!state.selectedId) return;
    const message = await fetchJson(`/api/messages/${state.selectedId}/folder`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ folder }),
    });
    state.messages = state.messages.map((item) => Number(item.id) === Number(message.id) ? message : item);
    if (messageDetail) messageDetail.innerHTML = renderMessageDetail(message);
    await refreshMailbox(messageSearch ? messageSearch.value : "");
  }

  if (moveInbox) moveInbox.addEventListener("click", () => moveSelectedMessage("inbox"));
  if (moveQuarantine) moveQuarantine.addEventListener("click", () => moveSelectedMessage("quarantine"));

  if (policyForm && policyResult) {
    policyForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const payload = Object.fromEntries(new FormData(policyForm).entries());
      try {
        const result = await fetchJson("/api/policy/simulate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        policyResult.innerHTML = `
          <div class="feed-card-top">
            <strong>${escapeHtml(result.policy?.name || "Policy simulation")}</strong>
            ${severityBadge(result.result.severity)}
          </div>
          <p>${escapeHtml(result.result.summary)}</p>
          <p class="muted">Simulated action: ${escapeHtml(result.simulated_action)}</p>
          ${indicatorHtml(result.result.indicators || [])}
        `;
      } catch (error) {
        policyResult.innerHTML = `<div class="empty-block">${escapeHtml(error.message)}</div>`;
      }
    });
  }

  document.body.addEventListener("click", async (event) => {
    const messageRow = event.target.closest("[data-message-id]");
    if (messageRow) {
      const state = window.mailState || (window.mailState = { folder: "all", selectedId: null, messages: [] });
      const message = await fetchJson(`/api/messages/${messageRow.dataset.messageId}`);
      state.selectedId = message.id;
      state.messages = state.messages.map((item) => Number(item.id) === Number(message.id) ? message : item);
      if (messageDetail) messageDetail.innerHTML = renderMessageDetail(message);
      await refreshMailbox(messageSearch ? messageSearch.value : "");
      return;
    }

    const accountButton = event.target.closest("[data-account-email]");
    if (accountButton) {
      const email = accountButton.dataset.accountEmail;
      const mode = accountButton.dataset.accountMode;
      await fetchJson(`/api/accounts/${encodeURIComponent(email)}/policy`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: mode === "block" ? "restricted" : "active",
          can_send: mode !== "block",
          blocked_reason: mode === "block" ? "Restricted by security admin" : "",
        }),
      });
      if (pageName === "admin") {
        await refreshAdmin();
      } else {
        window.location.reload();
      }
      return;
    }

    const deleteButton = event.target.closest("[data-account-delete]");
    if (deleteButton) {
      const email = deleteButton.dataset.accountDelete;
      await fetchJson(`/api/accounts/${encodeURIComponent(email)}`, {
        method: "DELETE",
      });
      if (pageName === "admin") {
        await refreshAdmin().catch(() => {});
      }
      window.location.reload();
      return;
    }

    const messageAccessButton = event.target.closest("[data-message-access-request]");
    if (messageAccessButton) {
      await fetchJson(`/api/messages/${messageAccessButton.dataset.messageAccessRequest}/access-request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: "Controlled disclosure requested by admin for medium-risk investigation." }),
      });
      const message = await fetchJson(`/api/messages/${messageAccessButton.dataset.messageAccessRequest}`);
      if (messageDetail) messageDetail.innerHTML = renderMessageDetail(message);
      return;
    }

    const unlockButton = event.target.closest("[data-unlock-request-id]");
    if (unlockButton) {
      await fetchJson(`/api/unlock-requests/${unlockButton.dataset.unlockRequestId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: unlockButton.dataset.unlockRequestStatus, admin_comment: "" }),
      });
      if (pageName === "admin") {
        await refreshAdmin().catch(() => {});
      }
      window.location.reload();
      return;
    }

    const accessDecisionButton = event.target.closest("[data-access-request-id]");
    if (accessDecisionButton) {
      await fetchJson(`/api/access-requests/${accessDecisionButton.dataset.accessRequestId}/decision`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ decision: accessDecisionButton.dataset.accessRequestDecision }),
      });
      window.location.reload();
      return;
    }

    const incidentButton = event.target.closest("[data-incident-id]");
    if (incidentButton) {
      await fetchJson(`/api/incidents/${incidentButton.dataset.incidentId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: incidentButton.dataset.incidentStatus || "resolved", owner: "SOC" }),
      });
      await refreshAdmin();
      await refreshMailbox(messageSearch ? messageSearch.value : "");
      return;
    }

    const deviceButton = event.target.closest("[data-device-key]");
    if (deviceButton) {
      await fetchJson(`/api/devices/${encodeURIComponent(deviceButton.dataset.deviceKey)}/policy`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ policy: deviceButton.dataset.devicePolicy, owner: "Security Admin", persist: true }),
      });
      await refreshAdmin();
      await refreshMailbox(messageSearch ? messageSearch.value : "");
      return;
    }

    const agentButton = event.target.closest("[data-agent-id]");
    if (agentButton) {
      const result = await fetchJson(`/api/agents/${encodeURIComponent(agentButton.dataset.agentId)}/action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: agentButton.dataset.agentAction }),
      });
      if (agentActionResult) {
        const extra = result.agent_key ? `<br><span class="mono">New key: ${escapeHtml(result.agent_key)}</span>` : "";
        agentActionResult.style.display = "block";
        agentActionResult.innerHTML = `Action completed for ${escapeHtml(result.agent?.display_name || agentButton.dataset.agentId)}.${extra}`;
      }
      if (pageName === "admin-agents") {
        await refreshAgentsPage().catch(() => {});
      }
      return;
    }

    const attachmentCard = event.target.closest("[data-attachment-id]");
    if (attachmentCard) {
      const detail = await fetchJson(`/api/attachments/${attachmentCard.dataset.attachmentId}`);
      if (attachmentDetail) attachmentDetail.innerHTML = renderAttachmentDetail(detail);
      return;
    }

    const jobCard = event.target.closest("[data-job-id]");
    if (jobCard) {
      const detail = await fetchJson(`/api/jobs/${jobCard.dataset.jobId}`);
      if (jobDetail) jobDetail.innerHTML = renderJobDetail(detail);
    }
  });

  if (pageName === "mailbox" || pageName === "admin") {
    refreshMailbox(messageSearch ? messageSearch.value : "").catch(() => {});
  }
  if (pageName === "admin") {
    refreshAdmin().catch(() => {});
  }
  if (pageName === "admin-agents") {
    refreshAgentsPage().catch(() => {});
  }
  if (pageName === "admin-agent-detail") {
    refreshAgentDetailPage(agentDetailId).catch(() => {});
  }
  if (pageName === "admin-simulator") {
    refreshSimulatorPage().catch(() => {});
  }

  function connectLiveUpdates() {
    if ("WebSocket" in window && window.location.protocol.startsWith("http")) {
      const scheme = window.location.protocol === "https:" ? "wss" : "ws";
      try {
        const socket = new WebSocket(`${scheme}://${window.location.host}/ws/live`);
        socket.onmessage = () => {
          if (pageName === "mailbox" || pageName === "admin") {
            refreshMailbox(messageSearch ? messageSearch.value : "").catch(() => {});
          }
          if (pageName === "admin") {
            refreshAdmin().catch(() => {});
          }
          if (pageName === "admin-agents") {
            refreshAgentsPage().catch(() => {});
          }
          if (pageName === "admin-agent-detail") {
            refreshAgentDetailPage(agentDetailId).catch(() => {});
          }
          if (pageName === "admin-simulator") {
            refreshSimulatorPage().catch(() => {});
          }
        };
        socket.onerror = () => socket.close();
        socket.onclose = connectSSE;
        return;
      } catch (_) {
      }
    }
    connectSSE();
  }

  function connectSSE() {
    if (!("EventSource" in window)) return;
    const source = new EventSource("/stream/events");
    source.onmessage = () => {
      if (pageName === "mailbox" || pageName === "admin") {
        refreshMailbox(messageSearch ? messageSearch.value : "").catch(() => {});
      }
      if (pageName === "admin") {
        refreshAdmin().catch(() => {});
      }
      if (pageName === "admin-agents") {
        refreshAgentsPage().catch(() => {});
      }
      if (pageName === "admin-agent-detail") {
        refreshAgentDetailPage(agentDetailId).catch(() => {});
      }
      if (pageName === "admin-simulator") {
        refreshSimulatorPage().catch(() => {});
      }
    };
  }

  connectLiveUpdates();

  setInterval(() => {
    if (pageName === "mailbox" || pageName === "admin") {
      refreshMailbox(messageSearch ? messageSearch.value : "").catch(() => {});
    }
    if (pageName === "admin") {
      refreshAdmin().catch(() => {});
    }
    if (pageName === "admin-agents") {
      refreshAgentsPage().catch(() => {});
    }
    if (pageName === "admin-agent-detail") {
      refreshAgentDetailPage(agentDetailId).catch(() => {});
    }
    if (pageName === "admin-simulator") {
      refreshSimulatorPage().catch(() => {});
    }
  }, 12000);
});
