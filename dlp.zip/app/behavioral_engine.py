"""
Behavioral Analytics Engine — tracks per-user risk over time.

Risk accumulates on each incident and decays with a 7-day half-life.
Repeated violations escalate the enforcement level automatically.
"""
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

DB_PATH = Path(__file__).resolve().parent.parent / "agent_data" / "behavioral.db"

# Severity → risk weight
SEVERITY_WEIGHT = {"SAFE": 0, "LOW": 2, "MEDIUM": 6, "HIGH": 15, "CRITICAL": 35}
HALF_LIFE_HOURS = 168  # 7 days

# Risk score thresholds → risk level
RISK_LEVELS = [
    (60, "CRITICAL"),
    (30, "HIGH"),
    (12, "ELEVATED"),
    (0,  "NORMAL"),
]

# Strikes (incidents ≥ MEDIUM in last 7 days) → auto-escalation cap
STRIKE_ESCALATION = {
    1: None,       # first offence: no change
    2: "MEDIUM",   # second: LOW → MEDIUM
    3: "HIGH",     # third:  MEDIUM → HIGH
    5: "CRITICAL", # five+:  HIGH → CRITICAL
}


@dataclass
class UserRisk:
    user: str
    risk_score: float
    risk_level: str          # NORMAL / ELEVATED / HIGH / CRITICAL
    strikes_7d: int          # incidents ≥ MEDIUM in last 7 days
    incidents_30d: int
    last_incident_ts: float
    is_anomalous: bool
    anomaly_reason: str


class BehavioralEngine:
    def __init__(self, db_path: Path = DB_PATH) -> None:
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")   # concurrent readers, single writer
        conn.execute("PRAGMA synchronous=NORMAL") # WAL-safe, faster than FULL
        return conn

    def _init_db(self) -> None:
        with self._conn() as c:
            c.execute("""
                CREATE TABLE IF NOT EXISTS risk_events (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    user        TEXT    NOT NULL,
                    ts          REAL    NOT NULL,
                    severity    TEXT    NOT NULL,
                    channel     TEXT    NOT NULL,
                    incident_id INTEGER,
                    weight      REAL    NOT NULL
                )
            """)
            c.execute("CREATE INDEX IF NOT EXISTS idx_user_ts ON risk_events(user, ts)")

    def record_event(
        self,
        user: str,
        severity: str,
        channel: str = "unknown",
        incident_id: Optional[int] = None,
    ) -> None:
        weight = SEVERITY_WEIGHT.get(severity, 0)
        if weight == 0:
            return
        with self._conn() as c:
            c.execute(
                "INSERT INTO risk_events (user,ts,severity,channel,incident_id,weight) VALUES (?,?,?,?,?,?)",
                (user, time.time(), severity, channel, incident_id, weight),
            )

    def get_user_risk(self, user: str) -> UserRisk:
        now = time.time()
        cutoff_30d = now - 30 * 86400
        cutoff_7d  = now - 7  * 86400

        with self._conn() as c:
            rows = c.execute(
                "SELECT ts, severity, weight FROM risk_events WHERE user=? AND ts>? ORDER BY ts DESC",
                (user, cutoff_30d),
            ).fetchall()

        if not rows:
            return UserRisk(user, 0.0, "NORMAL", 0, 0, 0.0, False, "")

        risk_score = 0.0
        strikes_7d = 0
        last_ts = 0.0
        medium_plus = {"MEDIUM", "HIGH", "CRITICAL"}

        for ts, severity, weight in rows:
            age_h = max((now - ts) / 3600, 0)
            decay = 0.5 ** (age_h / HALF_LIFE_HOURS)
            risk_score += weight * decay
            if ts > cutoff_7d and severity in medium_plus:
                strikes_7d += 1
            if ts > last_ts:
                last_ts = ts

        risk_level = next(lvl for threshold, lvl in RISK_LEVELS if round(risk_score, 2) >= threshold)

        is_anomalous = False
        anomaly_reason = ""
        if strikes_7d >= 3:
            is_anomalous = True
            anomaly_reason = f"Repeated incidents: {strikes_7d} violations in 7 days"
        elif risk_score >= 40:
            is_anomalous = True
            anomaly_reason = f"High accumulated risk score: {risk_score:.1f}"

        return UserRisk(
            user=user,
            risk_score=round(risk_score, 2),
            risk_level=risk_level,
            strikes_7d=strikes_7d,
            incidents_30d=len(rows),
            last_incident_ts=last_ts,
            is_anomalous=is_anomalous,
            anomaly_reason=anomaly_reason,
        )

    def escalate_severity(self, base_severity: str, user: str) -> tuple[str, str]:
        """
        Return (effective_severity, reason).
        Computes the single highest escalation floor from BOTH strike count and risk
        level, then applies it once — prevents double-escalation.
        """
        from app.dlp_engine import SEVERITY_RANK

        risk = self.get_user_risk(user)
        floors: list[tuple[int, str, str]] = []  # (rank, severity, reason_text)

        # Strike-based floor
        for threshold in sorted(STRIKE_ESCALATION, reverse=True):
            if risk.strikes_7d >= threshold and STRIKE_ESCALATION[threshold]:
                floor = STRIKE_ESCALATION[threshold]
                floors.append((
                    SEVERITY_RANK.get(floor, 0),
                    floor,
                    f"escalated due to {risk.strikes_7d} prior violations in 7 days",
                ))
                break

        # Risk-level floor
        bump_map = {"ELEVATED": "MEDIUM", "HIGH": "HIGH", "CRITICAL": "CRITICAL"}
        if risk.risk_level in bump_map:
            floor2 = bump_map[risk.risk_level]
            floors.append((
                SEVERITY_RANK.get(floor2, 0),
                floor2,
                f"elevated risk profile (score={risk.risk_score:.1f}, level={risk.risk_level})",
            ))

        if not floors:
            return base_severity, ""

        # Pick the highest floor among all candidates
        best_rank, best_floor, best_reason = max(floors, key=lambda x: x[0])
        base_rank = SEVERITY_RANK.get(base_severity, 0)

        if best_rank > base_rank:
            return best_floor, best_reason
        return base_severity, ""

    def get_summary(self, user: str) -> dict:
        risk = self.get_user_risk(user)
        return {
            "user": risk.user,
            "risk_score": risk.risk_score,
            "risk_level": risk.risk_level,
            "strikes_7d": risk.strikes_7d,
            "incidents_30d": risk.incidents_30d,
            "is_anomalous": risk.is_anomalous,
            "anomaly_reason": risk.anomaly_reason,
        }
