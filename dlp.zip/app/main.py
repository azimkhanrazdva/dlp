import json
import io
import os
import queue
import re
import hmac
import hashlib
import secrets
import subprocess
import threading
import time
import uuid
import zipfile
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Dict, List, Optional

from flask import Flask, Response, g, jsonify, redirect, render_template, request, send_file, session, url_for
from werkzeug.utils import secure_filename

from app.dlp_engine import DLPScanner, LABELS, SEVERITY_RANK, serialize_result, CONSEQUENCE_MATRIX
from app.behavioral_engine import BehavioralEngine
from app.i18n import SUPPORTED_LANGUAGES, translate
from app.simulator import DemoScenarioSimulator
from app.storage import SqliteStore

try:
    from flask_sock import Sock
except Exception:  # pragma: no cover
    Sock = None

try:
    import pyotp
    import qrcode
    import qrcode.image.svg
    _PYOTP_AVAILABLE = True
except Exception:  # pragma: no cover
    pyotp = None  # type: ignore[assignment]
    _PYOTP_AVAILABLE = False

_APP_START_TIME = time.time()


BASE_DIR = Path(__file__).resolve().parent.parent
UPLOAD_DIR = BASE_DIR / "app" / "uploads"
REPORT_DIR = BASE_DIR / "data" / "reports"

DEFAULT_ACCOUNTS = [
    {
        "name": "demo-user Saparova",
        "email": "analyst@example.test",
        "role": "employee",
        "department": "Finance",
        "risk_profile": "restricted",
        "title": "Finance Specialist",
        "password": "demo-user123!",
    },
    {
        "name": "Dias Akhmetov",
        "email": "dias@securemail.kz",
        "role": "employee",
        "department": "IT Operations",
        "risk_profile": "elevated",
        "title": "Systems Engineer",
        "password": "Dias12345!",
    },
    {
        "name": "Madina Tulegenova",
        "email": "madina@securemail.kz",
        "role": "analyst",
        "department": "Customer Support",
        "risk_profile": "standard",
        "title": "Support Lead",
        "password": "Madina123!",
    },
    {
        "name": "Security Admin",
        "email": "soc@securemail.kz",
        "role": "admin",
        "department": "Security Operations",
        "risk_profile": "privileged",
        "title": "SOC Manager",
        "password": "Soc@Admin2024!",
    },
]

DEFAULT_DB_PATH = REPORT_DIR / "securemail.db"
USB_POLL_INTERVAL = max(10, int(os.environ.get("USB_POLL_INTERVAL_SEC", "30")))
EXTERNAL_CHANNEL_OPTIONS = [
    {"value": "messenger", "label": "Messenger"},
    {"value": "social", "label": "Social Media"},
    {"value": "web", "label": "Web Form"},
    {"value": "public_upload", "label": "Public Upload"},
    {"value": "clipboard", "label": "Clipboard / Paste"},
]


class LiveBus:
    def __init__(self) -> None:
        self.clients: List[queue.Queue] = []

    def subscribe(self) -> queue.Queue:
        client = queue.Queue()
        self.clients.append(client)
        return client

    def unsubscribe(self, client: queue.Queue) -> None:
        if client in self.clients:
            self.clients.remove(client)

    def publish(self, event_type: str, payload: Dict[str, object]) -> None:
        message = json.dumps({"type": event_type, "payload": payload}, ensure_ascii=False)
        for client in list(self.clients):
            try:
                client.put_nowait(message)
            except Exception:
                self.unsubscribe(client)


def scan_usb_inventory() -> List[Dict[str, object]]:
    command = [
        "powershell",
        "-NoProfile",
        "-Command",
        (
            "$items = Get-CimInstance Win32_DiskDrive | "
            "Where-Object { $_.InterfaceType -eq 'USB' } | "
            "Select-Object Model, SerialNumber, DeviceID, PNPDeviceID, Status, Size, MediaType; "
            "if ($items) { $items | ConvertTo-Json -Compress } else { '[]' }"
        ),
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=12, check=False)
        raw = (result.stdout or "[]").strip()
        if not raw:
            return []
        payload = json.loads(raw)
        items = payload if isinstance(payload, list) else [payload]
        out = []
        for item in items:
            size_bytes = int(item.get("Size") or 0)
            out.append(
                {
                    "device_key": item.get("PNPDeviceID") or item.get("DeviceID") or item.get("Model") or str(uuid.uuid4()),
                    "device_name": item.get("Model") or "USB Device",
                    "serial": (item.get("SerialNumber") or "").strip(),
                    "status": item.get("Status") or "Unknown",
                    "media_type": item.get("MediaType") or "Removable",
                    "size_bytes": size_bytes,
                    "size_gb": round(size_bytes / (1024**3), 2) if size_bytes else None,
                    "connection_state": "connected",
                    "policy": "unknown",
                }
            )
        return out
    except Exception:
        return []


def _sanitize_device_key(key: str) -> str:
    """Strip characters that could break PowerShell string literals."""
    return re.sub(r"['\"\r\n`$;|&]", "", key)


def apply_device_policy_enforcement(device: Dict[str, object], policy: str) -> Dict[str, object]:
    if os.environ.get("ENABLE_DEVICE_ENFORCEMENT", "0") != "1":
        return {"applied": False, "reason": "Enforcement disabled by configuration."}
    raw_key = str(device.get("device_key") or "").strip()
    if not raw_key:
        return {"applied": False, "reason": "Missing device key."}
    safe_key = _sanitize_device_key(raw_key)
    if not safe_key:
        return {"applied": False, "reason": "Device key contained only unsafe characters."}
    action = "Disable-PnpDevice" if policy == "blocked" else "Enable-PnpDevice"
    # Pass device key as a PowerShell variable set via -Command with escaped string,
    # using an array-based call to avoid shell injection.
    ps_script = f'$id = "{safe_key}"; {action} -InstanceId $id -Confirm:$false'
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
            capture_output=True, text=True, timeout=15, check=False,
        )
        return {"applied": result.returncode == 0, "stdout": (result.stdout or "").strip(), "stderr": (result.stderr or "").strip()}
    except Exception as exc:
        return {"applied": False, "reason": str(exc)}


def normalize_device_match(value: object) -> str:
    return str(value or "").strip()


def calculate_mailbox_stats(
    store: SqliteStore,
    messages: Optional[List[Dict[str, object]]] = None,
    incidents: Optional[List[Dict[str, object]]] = None,
    accounts: Optional[List[Dict[str, object]]] = None,
) -> Dict[str, object]:
    messages = messages if messages is not None else store.list_messages()
    incidents = incidents if incidents is not None else store.list_incidents()
    devices = store.list_devices()
    accounts = accounts if accounts is not None else store.list_accounts()
    blocked = sum(1 for item in messages if item.get("status") != "delivered")
    open_incidents = sum(1 for item in incidents if item.get("status") == "open")
    restricted = sum(1 for item in accounts if not item.get("can_send", True) or item.get("status") != "active")
    unauthorized = sum(1 for item in devices if item.get("policy") == "blocked" and item.get("connection_state") == "connected")
    return {
        "messages_total": len(messages),
        "messages_blocked": blocked,
        "incidents_open": open_incidents,
        "accounts_restricted": restricted,
        "devices_connected": sum(1 for item in devices if item.get("connection_state") == "connected"),
        "devices_unauthorized": unauthorized,
    }


def summarize_mailbox(store: SqliteStore) -> Dict[str, object]:
    messages = store.list_messages()
    folders = {"inbox": 0, "sent": 0, "quarantine": 0, "drafts": 0}
    unread = 0
    for message in messages:
        folder = message.get("folder", "inbox")
        folders[folder] = folders.get(folder, 0) + 1
        if not message.get("is_read", False):
            unread += 1
    return {"folders": folders, "unread": unread, "stats": calculate_mailbox_stats(store)}


def summarize_attachments(items: List[Dict[str, object]]) -> Dict[str, object]:
    if not items:
        return {"count": 0, "max_severity": "SAFE", "critical_count": 0, "high_count": 0, "filenames": []}
    max_severity = "SAFE"
    critical_count = 0
    high_count = 0
    filenames = []
    for item in items:
        result = item.get("result", {})
        severity = str(result.get("severity", "SAFE")).upper()
        filenames.append(item.get("filename"))
        if severity == "CRITICAL":
            critical_count += 1
        if severity == "HIGH":
            high_count += 1
        if SEVERITY_RANK.get(severity, 0) > SEVERITY_RANK[max_severity]:
            max_severity = severity
    return {
        "count": len(items),
        "max_severity": max_severity,
        "critical_count": critical_count,
        "high_count": high_count,
        "filenames": [name for name in filenames if name],
    }


def external_channel_messages(messages: List[Dict[str, object]]) -> List[Dict[str, object]]:
    external_channels = {item["value"] for item in EXTERNAL_CHANNEL_OPTIONS}
    return [
        item
        for item in messages
        if str((item.get("dlp") or {}).get("channel", "")).lower() in external_channels
    ]


def compact_scan_payload(scan_payload: Dict[str, object], include_sensitive: bool = False) -> Dict[str, object]:
    compact = {
        "severity": scan_payload.get("severity", "SAFE"),
        "score": scan_payload.get("score", 0),
        "summary": scan_payload.get("summary", ""),
        "actions": list(scan_payload.get("actions", [])),
        "channel": scan_payload.get("channel", "email"),
        "attachment_summary": dict(scan_payload.get("attachment_summary", {})),
        "indicator_count": len(scan_payload.get("indicators", []) or []),
        "indicator_kinds": sorted({str(item.get("kind", "")) for item in (scan_payload.get("indicators", []) or []) if item.get("kind")}),
    }
    if include_sensitive:
        compact["indicators"] = scan_payload.get("indicators", [])
        compact["attachments"] = scan_payload.get("attachments", [])
        compact["text_result"] = scan_payload.get("text_result", {})
    else:
        compact["attachments"] = [
            {
                "filename": item.get("filename"),
                "result": {
                    "severity": (item.get("result") or {}).get("severity", "SAFE"),
                    "summary": (item.get("result") or {}).get("summary", ""),
                },
            }
            for item in (scan_payload.get("attachments", []) or [])
        ]
    return compact


def is_privileged(user: Dict[str, object]) -> bool:
    return str(user.get("role", "")).lower() in {"admin", "analyst"}


def can_access_message(user: Dict[str, object], message: Dict[str, object]) -> bool:
    email = str(user.get("email", "")).lower()
    if is_privileged(user):
        return True
    return email in {str(message.get("sender", "")).lower(), str(message.get("recipient", "")).lower()}


def mask_sensitive_text(text: str) -> str:
    if not text:
        return ""
    value = re.sub(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", "[redacted-email]", text)
    value = re.sub(r"(?<!\d)\d(?!\d)", "X", value)
    value = re.sub(r"\d", "X", value)
    return value


def privacy_message_view(store: SqliteStore, user: Dict[str, object], message: Dict[str, object], detailed: bool = False) -> Dict[str, object]:
    view = dict(message)
    if not is_privileged(user):
        return view
    severity = str((message.get("dlp") or {}).get("severity", "SAFE")).upper()
    access_granted = False
    if severity in {"HIGH", "CRITICAL"} or message.get("folder") == "quarantine" or message.get("status") == "blocked":
        access_granted = True
    elif severity == "MEDIUM":
        approved = store.find_approved_message_access(int(message["id"]))
        access_granted = approved is not None
    if not access_granted:
        view["body"] = "[Protected correspondence hidden in privacy mode. Admins see metadata and risk summary only.]"
    else:
        view["body"] = mask_sensitive_text((message.get("body") or "")[:800]) if detailed else "[Sensitive content redacted. Open incident record for governed review.]"
    redacted_attachments = []
    for item in message.get("attachments", []):
        attachment_copy = dict(item)
        attachment_copy["extracted_text"] = mask_sensitive_text((item.get("extracted_text") or "")[:600]) if access_granted and detailed else "[Attachment text hidden in privacy mode.]"
        redacted_attachments.append(attachment_copy)
    view["attachments"] = redacted_attachments
    view["privacy_access"] = {
        "severity": severity,
        "granted": access_granted,
        "mode": "direct" if access_granted and severity in {"HIGH", "CRITICAL"} else ("approved_request" if access_granted else "restricted"),
    }
    return view


def scoped_messages(store: SqliteStore, user: Dict[str, object], detailed: bool = False) -> List[Dict[str, object]]:
    messages = [message for message in store.list_messages() if can_access_message(user, message)]
    return [privacy_message_view(store, user, message, detailed=detailed) for message in messages]


def scoped_message_detail(store: SqliteStore, user: Dict[str, object], message_id: int) -> Optional[Dict[str, object]]:
    message = store.get_message(message_id)
    if not message or not can_access_message(user, message):
        return None
    return privacy_message_view(store, user, message, detailed=True)


def scoped_attachments(store: SqliteStore, user: Dict[str, object]) -> List[Dict[str, object]]:
    messages = {message["id"]: message for message in store.list_messages() if can_access_message(user, message)}
    out = []
    for item in store.list_attachments():
        message_id = item.get("message_id")
        if message_id and message_id in messages:
            attachment = dict(item)
            if is_privileged(user):
                severity = str((attachment.get("result") or {}).get("severity", "SAFE")).upper()
                if severity in {"HIGH", "CRITICAL"} or messages[message_id].get("folder") == "quarantine":
                    attachment["extracted_text"] = mask_sensitive_text((attachment.get("extracted_text") or "")[:600])
                else:
                    attachment["extracted_text"] = "[Attachment text hidden in privacy mode.]"
            out.append(attachment)
    return out


def mailbox_snapshot(messages: List[Dict[str, object]]) -> Dict[str, object]:
    folders = {"inbox": 0, "sent": 0, "quarantine": 0, "drafts": 0}
    unread = 0
    for message in messages:
        folder = message.get("folder", "inbox")
        folders[folder] = folders.get(folder, 0) + 1
        if not message.get("is_read", False):
            unread += 1
    return {"folders": folders, "unread": unread}


def scoped_incidents(store: SqliteStore, user: Dict[str, object]) -> List[Dict[str, object]]:
    incidents = store.list_incidents()
    if is_privileged(user):
        return incidents
    email = str(user.get("email", "")).lower()
    return [
        item
        for item in incidents
        if email in {str(item.get("sender", "")).lower(), str(item.get("recipient", "")).lower()}
    ]


def scoped_analytics(store: SqliteStore, user: Dict[str, object]) -> Dict[str, object]:
    if is_privileged(user):
        return store.analytics_snapshot()
    messages = scoped_messages(store, user)
    incidents = scoped_incidents(store, user)
    severity_counts = {label: 0 for label in LABELS}
    folders: Dict[str, int] = {}
    for message in messages:
        sev = str((message.get("dlp") or {}).get("severity", "SAFE")).upper()
        severity_counts[sev] = severity_counts.get(sev, 0) + 1
        folder = str(message.get("folder", "inbox"))
        folders[folder] = folders.get(folder, 0) + 1
    incident_counts: Dict[str, int] = {}
    for incident in incidents:
        sev = str(incident.get("severity", "LOW")).upper()
        incident_counts[sev] = incident_counts.get(sev, 0) + 1
    return {
        "message_severity": severity_counts,
        "folders": folders,
        "incident_severity": incident_counts,
        "scan_jobs": {},
        "job_types": {},
        "channels": {"email": len(messages)},
        "devices": {"connected": 0, "blocked": 0, "authorized": 0},
        "timeline": {"days": [], "messages": [], "incidents": [], "jobs": []},
    }


def scoped_jobs(store: SqliteStore, user: Dict[str, object]) -> List[Dict[str, object]]:
    jobs = store.list_scan_jobs(50)
    if is_privileged(user):
        return jobs
    email = str(user.get("email", "")).lower()
    return [item for item in jobs if str(item.get("actor", "")).lower() == email]


def begin_scan_job(store: SqliteStore, actor: str, job_type: str, channel: str, target_name: str) -> Dict[str, object]:
    return store.add_scan_job(
        {
            "job_type": job_type,
            "channel": channel,
            "actor": actor,
            "status": "queued",
            "target_name": target_name,
        }
    )


def complete_scan_job(store: SqliteStore, job_id: int, result: Dict[str, object]) -> Dict[str, object]:
    return store.update_scan_job(
        job_id,
        status="completed",
        severity=result.get("severity"),
        summary=result.get("summary"),
        result=result,
    )


def save_uploaded_attachments(files, upload_dir: Path) -> List[Dict[str, object]]:
    return _save_uploaded_attachments(files, upload_dir, persist=True)


def _save_uploaded_attachments(files, upload_dir: Path, persist: bool) -> List[Dict[str, object]]:
    saved = []
    target_dir = upload_dir if persist else (upload_dir / "_staging")
    target_dir.mkdir(parents=True, exist_ok=True)
    for uploaded in files:
        if not uploaded or not uploaded.filename:
            continue
        path = target_dir / f"{uuid.uuid4().hex}_{secure_filename(uploaded.filename)}"
        uploaded.save(path)
        saved.append({"filename": uploaded.filename, "storage_path": str(path)})
    return saved


def finalize_agent_attachment_retention(
    scan_payload: Dict[str, object],
    saved_attachments: List[Dict[str, object]],
    upload_dir: Path,
) -> Dict[str, object]:
    severity = str(scan_payload.get("severity", "SAFE")).upper()
    attachment_results = list(scan_payload.get("attachments", []))
    if not saved_attachments:
        return scan_payload
    for index, staged in enumerate(saved_attachments):
        staged_path = Path(str(staged.get("storage_path", "")))
        result_item = attachment_results[index] if index < len(attachment_results) else None
        if severity == "CRITICAL":
            final_path = upload_dir / f"{uuid.uuid4().hex}_{secure_filename(staged.get('filename', staged_path.name))}"
            if staged_path.exists():
                staged_path.replace(final_path)
            if result_item is not None:
                result_item["storage_path"] = str(final_path)
        else:
            if staged_path.exists():
                staged_path.unlink(missing_ok=True)
            if result_item is not None:
                result_item["storage_path"] = None
    scan_payload["attachments"] = attachment_results
    return scan_payload


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not getattr(g, "current_user", None):
            if request.path.startswith("/api/"):
                return jsonify({"error": "Authentication required"}), 401
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def role_required(*roles: str):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = getattr(g, "current_user", None)
            if not user:
                return jsonify({"error": "Authentication required"}), 401
            if user.get("role") not in roles:
                return jsonify({"error": "Forbidden"}), 403
            return view(*args, **kwargs)

        return wrapped

    return decorator


def create_app() -> Flask:
    app = Flask(__name__, template_folder=str(BASE_DIR / "app" / "templates"), static_folder=str(BASE_DIR / "app" / "static"))
    _secret = os.environ.get("SECUREMAIL_SECRET_KEY", "")
    if not _secret:
        import secrets as _sec
        _secret = _sec.token_hex(32)
        import logging as _log
        _log.getLogger(__name__).warning(
            "SECUREMAIL_SECRET_KEY not set — generated ephemeral key. "
            "Sessions will not survive restarts. Set the env var in production."
        )
    app.secret_key = _secret
    app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = os.environ.get("SESSION_COOKIE_SAMESITE", "Lax")
    app.config["SESSION_COOKIE_SECURE"] = os.environ.get("SESSION_COOKIE_SECURE", "0") == "1"
    app.config["PREFERRED_URL_SCHEME"] = "https" if app.config["SESSION_COOKIE_SECURE"] else "http"
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    scanner = DLPScanner(
        model_path=os.environ.get("DLP_MODEL_PATH") or None,
        aux_model_path=os.environ.get("DLP_AUX_MODEL_PATH") or None,
        stage1_path=os.environ.get("DLP_STAGE1_MODEL_PATH") or None,
        stage2_path=os.environ.get("DLP_STAGE2_MODEL_PATH") or None,
        stage3_path=os.environ.get("DLP_STAGE3_MODEL_PATH") or None,
    )
    behavioral_engine = BehavioralEngine()
    configured_db = os.environ.get("SECUREMAIL_DATABASE_URL") or os.environ.get("SECUREMAIL_DB_PATH", str(DEFAULT_DB_PATH))
    store = SqliteStore(REPORT_DIR, db_path=configured_db)
    store.seed_accounts(DEFAULT_ACCOUNTS)
    for account in DEFAULT_ACCOUNTS:
        email = account.get("email", "").strip().lower()
        if not email:
            continue
        existing = store.get_account(email)
        if not existing:
            store.create_account(account)
            continue
        if not existing.get("password_hash"):
            store.update_account(email, password=account.get("password", "Password123!"))
    store.seed_endpoint_agents(
        [
            {
                "agent_id": os.environ.get("SECUREMAIL_DEFAULT_AGENT_ID", "lab-win01:sen"),
                "display_name": "Finance Workstation Agent",
                "actor_email": "analyst@example.test",
                "platform": "windows",
                "version": "1.0.0",
                "api_key": os.environ.get("SECUREMAIL_AGENT_KEY", "securemail-agent-local"),
                "channels": ["clipboard", "device", "file", "messenger", "social", "web", "public_upload"],
                "monitors": ["clipboard", "usb", "filesystem", "process_context"],
            }
        ]
    )
    store.seed_demo_mailbox()
    store.seed_demo_incidents()
    store.seed_default_policies()
    bus = LiveBus()
    scan_queue: queue.Queue = queue.Queue()

    sock = Sock(app) if Sock else None

    @app.before_request
    def load_user() -> None:
        token = session.get("session_token")
        g.current_user = store.get_session(token) if token else None
        g.lang = session.get("lang", "en")

    @app.context_processor
    def inject_i18n() -> Dict[str, object]:
        return {
            "current_language": getattr(g, "lang", "en"),
            "supported_languages": SUPPORTED_LANGUAGES,
            "t": lambda text: translate(getattr(g, "lang", "en"), text),
        }

    @app.get("/language/<lang>")
    def set_language(lang: str):
        if lang in SUPPORTED_LANGUAGES:
            session["lang"] = lang
        next_url = request.args.get("next") or request.referrer or url_for("login")
        return redirect(next_url)

    def publish(event_type: str, payload: Dict[str, object]) -> None:
        bus.publish(event_type, payload)

    def authenticate_agent_request(payload: Optional[Dict[str, object]] = None) -> Optional[Dict[str, object]]:
        agent_id = request.headers.get("X-Agent-Id") or (payload or {}).get("agent_id")
        api_key = request.headers.get("X-Agent-Key", "")
        timestamp = request.headers.get("X-Agent-Timestamp", "")
        signature = request.headers.get("X-Agent-Signature", "")
        if not agent_id or not api_key or not timestamp or not signature:
            return None
        try:
            request_ts = int(timestamp)
        except ValueError:
            return None
        now_ts = int(datetime.now(timezone.utc).timestamp())
        if abs(now_ts - request_ts) > 300:
            return None
        agent = store.verify_endpoint_agent(str(agent_id), api_key)
        if not agent:
            return None
        raw_body = request.get_data(cache=True) or b""
        body_digest = hashlib.sha256(raw_body).hexdigest()
        signing_payload = f"{request.method.upper()}\n{request.path}\n{timestamp}\n{body_digest}".encode("utf-8")
        expected_signature = hmac.new(api_key.encode("utf-8"), signing_payload, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected_signature, signature):
            return None
        return agent

    def build_scan_payload(text: str, channel: str, saved_attachments: List[Dict[str, object]]) -> Dict[str, object]:
        text_result = scanner.scan_text(text, channel=channel)
        final_result = text_result
        attachment_results = []
        for item in saved_attachments:
            result = scanner.scan_file(Path(str(item["storage_path"])))
            attachment_results.append(
                {
                    "filename": item["filename"],
                    "storage_path": item["storage_path"],
                    "extracted_text": result.extracted_text[:4000],
                    "result": serialize_result(result),
                }
            )
            if SEVERITY_RANK[result.severity] > SEVERITY_RANK[final_result.severity]:
                final_result = result
        payload = serialize_result(final_result)
        payload["text_result"] = serialize_result(text_result)
        payload["attachments"] = attachment_results
        payload["attachment_summary"] = summarize_attachments(attachment_results)
        return payload

    def process_outbound_channel(
        *,
        sender: str,
        recipient: str,
        subject: str,
        body: str,
        channel: str,
        target_name: str,
        saved_attachments: List[Dict[str, object]],
        incident_type: str,
        audit_prefix: str,
    ) -> Dict[str, object]:
        account = store.get_account(sender)
        if not account:
            raise ValueError("Unknown account")
        if account.get("status") != "active" or not account.get("can_send", True):
            raise PermissionError("Sender is blocked by mail governance policy.")

        job = begin_scan_job(store, sender, "outbound_send", channel, target_name)
        store.update_scan_job(int(job["id"]), status="running")
        running_job = store.get_scan_job(int(job["id"]))
        if running_job:
            publish("scan_job", running_job)

        scan_payload = build_scan_payload(body, channel, saved_attachments)
        status = "blocked" if scan_payload["severity"] in {"HIGH", "CRITICAL"} else "delivered"
        folder = "quarantine" if status == "blocked" else "sent"
        message = store.add_message(
            {
                "sender": sender,
                "recipient": recipient,
                "subject": subject,
                "body": body,
                "folder": folder,
                "status": status,
                "is_read": False,
                "dlp": scan_payload,
                "attachments": scan_payload["attachments"],
            }
        )
        completed = complete_scan_job(store, int(job["id"]), scan_payload)
        if completed:
            publish("scan_job", completed)
        store.add_audit_event(
            f"{audit_prefix}_{'sent' if status == 'delivered' else 'blocked'}",
            sender,
            {
                "recipient": recipient,
                "subject": subject,
                "severity": scan_payload["severity"],
                "message_id": message["id"],
                "channel": channel,
            },
        )
        publish("message", message)

        # Behavioral engine: record event and check for escalation
        behavioral_engine.record_event(
            user=sender,
            severity=scan_payload["severity"],
            channel=channel,
            incident_id=None,
        )
        beh_summary = behavioral_engine.get_summary(sender)

        if scan_payload["severity"] in {"HIGH", "CRITICAL"}:
            # Include threat categories and behavioral context in incident
            incident = store.add_incident(
                {
                    "type": incident_type,
                    "severity": scan_payload["severity"],
                    "status": "open",
                    "summary": scan_payload["summary"],
                    "actions": scan_payload["actions"],
                    "sender": sender,
                    "recipient": recipient,
                    "subject": subject,
                    "message_id": message["id"],
                    "owner": "SOC",
                    "threat_categories": scan_payload.get("threat_categories", []),
                    "behavioral_risk": beh_summary,
                    "consequence": CONSEQUENCE_MATRIX.get(scan_payload["severity"], {}).get("description", ""),
                    "penalty": CONSEQUENCE_MATRIX.get(scan_payload["severity"], {}).get("penalty"),
                }
            )
            behavioral_engine.record_event(sender, scan_payload["severity"], channel, incident_id=int(incident["id"]))
            publish("incident", incident)

        if scan_payload["severity"] == "CRITICAL":
            updated_account = store.update_account(
                sender, status="restricted", can_send=False,
                blocked_reason="Automatic LOCKDOWN: critical data leakage attempt detected by AI-DLP.",
            )
            if updated_account:
                store.add_audit_event(
                    "account_auto_locked",
                    sender,
                    {
                        "email": sender,
                        "reason": "CRITICAL leakage — AI-DLP lockdown",
                        "message_id": message["id"],
                        "channel": channel,
                        "threat_categories": scan_payload.get("threat_categories", []),
                        "behavioral_risk_score": beh_summary.get("risk_score", 0),
                    },
                )
                publish("account", updated_account)

        return {"status": status, "message": message, "final_result": scan_payload, "behavioral": beh_summary}

    def scan_worker() -> None:
        while True:
            job_payload = scan_queue.get()
            try:
                job_id = int(job_payload["job_id"])
                store.update_scan_job(job_id, status="running")
                running = store.get_scan_job(job_id)
                if running:
                    publish("scan_job", running)
                result = build_scan_payload(
                    str(job_payload.get("text", "")),
                    str(job_payload.get("channel", "email")),
                    list(job_payload.get("attachments", [])),
                )
                completed = complete_scan_job(store, job_id, result)
                if completed:
                    publish("scan_job", completed)
            except Exception as exc:
                failed = store.update_scan_job(
                    int(job_payload["job_id"]),
                    status="failed",
                    severity="SAFE",
                    summary=f"Scan job failed: {exc}",
                    result={"error": str(exc)},
                )
                if failed:
                    publish("scan_job", failed)
            finally:
                scan_queue.task_done()

    threading.Thread(target=scan_worker, daemon=True, name="securemail-scan-worker").start()

    def resolve_device_policy(device: Dict[str, object], existing: Optional[Dict[str, object]] = None) -> str:
        serial = normalize_device_match(device.get("serial"))
        device_key = normalize_device_match(device.get("device_key"))
        if serial:
            rule = store.get_device_rule("serial", serial)
            if rule:
                return str(rule["policy"])
        if device_key:
            rule = store.get_device_rule("device_key", device_key)
            if rule:
                return str(rule["policy"])
        if existing and existing.get("policy"):
            return str(existing["policy"])
        return "review"

    def sync_agent_usb_inventory(devices: List[Dict[str, object]], actor: str = "endpoint-agent") -> List[Dict[str, object]]:
        known = {item["device_key"]: item for item in store.list_devices()}
        active_keys = set()
        for device in devices:
            key = str(device.get("device_key") or "")
            if not key:
                continue
            active_keys.add(key)
            existing = known.get(key)
            policy = resolve_device_policy(device, existing)
            owner = device.get("owner") or (existing.get("owner") if existing else actor)
            record = store.upsert_device(
                key,
                {
                    **device,
                    "policy": policy,
                    "owner": owner,
                    "connection_state": device.get("connection_state", "connected"),
                },
            )
            if not existing:
                event = store.add_device_event(
                    {
                        "device_name": record["device_name"],
                        "device_key": key,
                        "event": "connected",
                        "notes": "Reported by endpoint agent inventory sync.",
                        "severity": "MEDIUM" if policy == "review" else ("HIGH" if policy == "blocked" else "LOW"),
                        "policy": policy,
                    }
                )
                store.add_audit_event("agent_device_detected", actor, {"device_key": key, "device_name": record["device_name"], "policy": policy})
                publish("device_event", event)
                publish("device", record)
                if policy in {"review", "blocked"}:
                    incident = store.add_incident(
                        {
                            "type": "usb_device_detected",
                            "severity": "HIGH" if policy == "blocked" else "MEDIUM",
                            "status": "open",
                            "summary": f"USB device {record['device_name']} connected with policy {policy}.",
                            "actions": scanner.policy_actions("HIGH" if policy == "blocked" else "MEDIUM", "device"),
                            "owner": "Endpoint Control",
                        }
                    )
                    publish("incident", incident)
            elif existing.get("policy") != policy or existing.get("connection_state") != record.get("connection_state"):
                updated = store.update_device(key, policy=policy, owner=owner, connection_state=device.get("connection_state", "connected")) or record
                store.add_audit_event("agent_device_policy_sync", actor, {"device_key": key, "policy": policy, "connection_state": updated.get("connection_state")})
                publish("device", updated)
        for key, existing in known.items():
            if key not in active_keys and existing.get("connection_state") == "connected":
                disconnected = store.update_device(key, connection_state="disconnected")
                event = store.add_device_event(
                    {
                        "device_name": existing["device_name"],
                        "device_key": key,
                        "event": "disconnected",
                        "notes": "Device removed from endpoint agent inventory.",
                        "severity": "LOW",
                        "policy": existing.get("policy", "review"),
                    }
                )
                store.add_audit_event("agent_device_disconnected", actor, {"device_key": key, "device_name": existing["device_name"]})
                publish("device_event", event)
                if disconnected:
                    publish("device", disconnected)
        return store.list_devices()

    simulator = DemoScenarioSimulator(
        store=store,
        scanner=scanner,
        publish=publish,
        process_outbound_channel=process_outbound_channel,
        sync_agent_usb_inventory=sync_agent_usb_inventory,
    )

    # Simple in-memory rate limiter: max 10 failed login attempts per IP per 10 minutes
    _login_attempts: dict = {}  # {ip: [timestamp, ...]}
    _LOGIN_MAX = 10
    _LOGIN_WINDOW = 600  # seconds

    def _check_login_rate(ip: str) -> bool:
        """Return True if request is allowed, False if rate-limited."""
        now = time.time()
        attempts = [t for t in _login_attempts.get(ip, []) if now - t < _LOGIN_WINDOW]
        _login_attempts[ip] = attempts
        if len(attempts) >= _LOGIN_MAX:
            return False
        return True

    def _record_login_failure(ip: str) -> None:
        _login_attempts.setdefault(ip, []).append(time.time())

    @app.get("/login")
    def login():
        if g.current_user:
            return redirect(url_for("index"))
        return render_template("login.html")

    @app.post("/login")
    def login_post():
        client_ip = request.remote_addr or "unknown"
        if not _check_login_rate(client_ip):
            return render_template("login.html", error="Too many failed attempts. Try again later."), 429
        email = request.form.get("email", "")
        password = request.form.get("password", "")
        account = store.authenticate(email, password)
        if not account:
            _record_login_failure(client_ip)
            return render_template("login.html", error="Invalid email or password"), 401
        totp_secret = store.get_totp_secret(email)
        if totp_secret and _PYOTP_AVAILABLE:
            totp_code = request.form.get("totp_code", "").strip()
            totp = pyotp.TOTP(totp_secret)
            if not totp.verify(totp_code, valid_window=1):
                _record_login_failure(client_ip)
                return render_template("login.html", error="Invalid authenticator code. Please try again.", mfa_required=True, email=email), 401
        session["session_token"] = account["session_token"]
        return redirect(url_for("admin" if account.get("role") == "admin" else "index"))

    @app.get("/register")
    def register():
        if g.current_user:
            return redirect(url_for("index"))
        return render_template("register.html")

    @app.post("/register")
    def register_post():
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        department = request.form.get("department", "Operations").strip() or "Operations"
        title = request.form.get("title", "").strip()
        if len(name) < 2:
            return render_template("register.html", error="Name is too short."), 400
        if "@" not in email or "." not in email:
            return render_template("register.html", error="Enter a valid email address."), 400
        if len(password) < 8:
            return render_template("register.html", error="Password must be at least 8 characters."), 400
        try:
            store.create_account(
                {
                    "name": name,
                    "email": email,
                    "password": password,
                    "role": "employee",
                    "department": department,
                    "risk_profile": "standard",
                    "title": title or "Employee",
                    "status": "active",
                    "can_send": True,
                }
            )
        except ValueError as exc:
            return render_template("register.html", error=str(exc)), 409
        account = store.authenticate(email, password)
        if not account:
            return redirect(url_for("login"))
        session["session_token"] = account["session_token"]
        store.add_audit_event("account_registered", email, {"department": department, "role": "employee"})
        publish("account", store.get_account(email))
        return redirect(url_for("index"))

    @app.get("/logout")
    def logout():
        token = session.get("session_token")
        if token:
            store.clear_session(token)
        session.clear()
        return redirect(url_for("login"))

    @app.get("/")
    @login_required
    def index():
        user_messages = scoped_messages(store, g.current_user)
        user_attachments = scoped_attachments(store, g.current_user)
        user_incidents = scoped_incidents(store, g.current_user)
        user_mailbox = mailbox_snapshot(user_messages)
        available_accounts = store.list_accounts() if is_privileged(g.current_user) else [store.get_account(g.current_user["email"])]
        user_stats = calculate_mailbox_stats(store, messages=user_messages, incidents=user_incidents, accounts=[item for item in available_accounts if item])
        return render_template(
            "index.html",
            current_user=g.current_user,
            accounts=[item for item in available_accounts if item],
            messages=user_messages[:40],
            incidents=user_incidents[:20],
            devices=store.list_devices()[:12],
            attachments=user_attachments[:25],
            policies=store.list_policies(),
            jobs=scoped_jobs(store, g.current_user)[:20],
            analytics=scoped_analytics(store, g.current_user),
            stats=user_stats,
            mailbox=user_mailbox,
            audit=store.verify_audit_chain(),
        )

    @app.get("/profile")
    @login_required
    def profile():
        account = store.get_account(g.current_user["email"])
        requests = [item for item in store.list_unlock_requests() if item["email"].lower() == g.current_user["email"].lower()]
        return render_template("profile.html", current_user=g.current_user, account=account, unlock_requests=requests[:20])

    @app.post("/profile")
    @login_required
    def profile_update():
        account = store.get_account(g.current_user["email"])
        if not account:
            return redirect(url_for("logout"))
        name = request.form.get("name", "").strip()
        department = request.form.get("department", "").strip()
        title = request.form.get("title", "").strip()
        password = request.form.get("password", "").strip()
        changes = {
            "name": name or account["name"],
            "department": department or account.get("department", ""),
            "title": title or account.get("title", ""),
        }
        if password:
            changes["password"] = password
        updated = store.update_account(g.current_user["email"], **changes)
        if updated:
            g.current_user = updated
            store.add_audit_event("profile_updated", g.current_user["email"], {"email": g.current_user["email"]})
        return redirect(url_for("profile"))

    @app.get("/unlock-request")
    @login_required
    def unlock_request():
        requests = [item for item in store.list_unlock_requests() if item["email"].lower() == g.current_user["email"].lower()]
        return render_template("unlock_request.html", current_user=g.current_user, unlock_requests=requests[:20])

    @app.post("/unlock-request")
    @login_required
    def unlock_request_create():
        reason = request.form.get("reason", "").strip()
        file = request.files.get("attachment")
        attachment_name = None
        attachment_path = None
        if file and file.filename:
            saved = save_uploaded_attachments([file], UPLOAD_DIR)
            if saved:
                attachment_name = saved[0]["filename"]
                attachment_path = saved[0]["storage_path"]
        request_row = store.add_unlock_request(
            {
                "email": g.current_user["email"],
                "requester_name": g.current_user["name"],
                "reason": reason or "Please review my blocked account status.",
                "attachment_name": attachment_name,
                "attachment_path": attachment_path,
            }
        )
        store.add_audit_event("unlock_request_created", g.current_user["email"], {"request_id": request_row["id"]})
        publish("unlock_request", request_row)
        return redirect(url_for("unlock_request"))

    @app.get("/access-requests")
    @login_required
    def access_requests():
        email = g.current_user["email"].lower()
        requests = [
            item for item in store.list_message_access_requests()
            if email in {item["sender_email"].lower(), item["recipient_email"].lower(), item["requested_by_email"].lower()}
        ]
        return render_template("access_requests.html", current_user=g.current_user, requests=requests[:30])

    @app.get("/about")
    def about():
        return render_template(
            "about.html",
            current_user=g.current_user,
        )

    @app.get("/getting-started")
    def getting_started():
        return render_template("getting_started.html", current_user=g.current_user)

    @app.get("/download/agent")
    def download_agent():
        package_files = [
            ("run_agent.py", BASE_DIR / "run_agent.py"),
            ("run_desktop_app.py", BASE_DIR / "run_desktop_app.py"),
            ("requirements_agent.txt", BASE_DIR / "requirements_agent.txt"),
            ("agent/windows_agent.py", BASE_DIR / "agent" / "windows_agent.py"),
            ("agent/windows_desktop_app.py", BASE_DIR / "agent" / "windows_desktop_app.py"),
            ("agent/windows_service.py", BASE_DIR / "agent" / "windows_service.py"),
            ("agent/config.example.json", BASE_DIR / "agent" / "config.example.json"),
            ("agent/install_service.ps1", BASE_DIR / "agent" / "install_service.ps1"),
            ("agent/uninstall_service.ps1", BASE_DIR / "agent" / "uninstall_service.ps1"),
            ("agent/README.md", BASE_DIR / "agent" / "README.md"),
            ("agent/__init__.py", BASE_DIR / "agent" / "__init__.py"),
        ]
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
            for arcname, path in package_files:
                if path.exists():
                    archive.writestr(arcname, path.read_bytes())
        bundle.seek(0)
        return send_file(
            bundle,
            mimetype="application/zip",
            as_attachment=True,
            download_name="securemail-endpoint-agent.zip",
        )

    @app.get("/download/windows-app")
    def download_windows_app():
        package_files = [
            ("run_desktop_app.py", BASE_DIR / "run_desktop_app.py"),
            ("run_agent.py", BASE_DIR / "run_agent.py"),
            ("requirements_agent.txt", BASE_DIR / "requirements_agent.txt"),
            ("agent/windows_desktop_app.py", BASE_DIR / "agent" / "windows_desktop_app.py"),
            ("agent/windows_agent.py", BASE_DIR / "agent" / "windows_agent.py"),
            ("agent/windows_service.py", BASE_DIR / "agent" / "windows_service.py"),
            ("agent/config.example.json", BASE_DIR / "agent" / "config.example.json"),
            ("agent/install_service.ps1", BASE_DIR / "agent" / "install_service.ps1"),
            ("agent/uninstall_service.ps1", BASE_DIR / "agent" / "uninstall_service.ps1"),
            ("agent/README.md", BASE_DIR / "agent" / "README.md"),
            ("agent/__init__.py", BASE_DIR / "agent" / "__init__.py"),
        ]
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
            for arcname, path in package_files:
                if path.exists():
                    archive.writestr(arcname, path.read_bytes())
        bundle.seek(0)
        return send_file(
            bundle,
            mimetype="application/zip",
            as_attachment=True,
            download_name="securemail-windows-app.zip",
        )

    @app.get("/download/browser-extension")
    def download_browser_extension():
        package_files = [
            ("browser_extension/manifest.json", BASE_DIR / "browser_extension" / "manifest.json"),
            ("browser_extension/background.js", BASE_DIR / "browser_extension" / "background.js"),
            ("browser_extension/content.js", BASE_DIR / "browser_extension" / "content.js"),
            ("browser_extension/options.html", BASE_DIR / "browser_extension" / "options.html"),
            ("browser_extension/options.js", BASE_DIR / "browser_extension" / "options.js"),
            ("browser_extension/README.md", BASE_DIR / "browser_extension" / "README.md"),
        ]
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
            for arcname, path in package_files:
                if path.exists():
                    archive.writestr(arcname, path.read_bytes())
        bundle.seek(0)
        return send_file(
            bundle,
            mimetype="application/zip",
            as_attachment=True,
            download_name="securemail-browser-guard.zip",
        )

    @app.get("/channels")
    @login_required
    def channels():
        user_messages = scoped_messages(store, g.current_user)
        channel_history = external_channel_messages(user_messages)
        channel_incidents = [
            item for item in scoped_incidents(store, g.current_user)
            if item.get("type") in {"external_channel_leak_attempt", "social_media_leak_attempt", "messenger_leak_attempt"}
        ]
        return render_template(
            "channels.html",
            current_user=g.current_user,
            accounts=[store.get_account(g.current_user["email"])],
            channels=EXTERNAL_CHANNEL_OPTIONS,
            channel_history=channel_history[:30],
            incidents=channel_incidents[:20],
            stats=calculate_mailbox_stats(store, messages=user_messages, incidents=channel_incidents, accounts=[store.get_account(g.current_user["email"])]),
        )

    @app.get("/healthz")
    def healthz():
        audit = store.verify_audit_chain()
        return jsonify(
            {
                "status": "ok",
                "audit_chain_valid": audit["valid"],
                "audit_chain_length": audit["length"],
            }
        )

    @app.get("/admin")
    @login_required
    @role_required("admin", "analyst")
    def admin():
        return render_template(
            "admin.html",
            current_user=g.current_user,
            accounts=store.list_accounts(),
            agents=store.list_endpoint_agents(),
            incidents=store.list_incidents(),
            devices=store.list_devices(),
            device_rules=store.list_device_rules(),
            device_events=store.list_device_events(),
            attachments=store.list_attachments()[:50],
            audit_events=list(reversed(store.list_audit_events()))[:50],
            policies=store.list_policies(),
            jobs=store.list_scan_jobs(30),
            analytics=store.analytics_snapshot(),
            stats=calculate_mailbox_stats(store),
            audit=store.verify_audit_chain(),
        )

    @app.get("/admin/accounts")
    @login_required
    @role_required("admin", "analyst")
    def admin_accounts():
        return render_template("admin_accounts.html", current_user=g.current_user, accounts=store.list_accounts(), stats=calculate_mailbox_stats(store))

    @app.get("/admin/agents")
    @login_required
    @role_required("admin", "analyst")
    def admin_agents():
        return render_template("admin_agents.html", current_user=g.current_user, agents=store.list_endpoint_agents(), stats=calculate_mailbox_stats(store))

    @app.get("/admin/simulator")
    @login_required
    @role_required("admin", "analyst")
    def admin_simulator():
        return render_template("admin_simulator.html", current_user=g.current_user, simulator=simulator.status(), stats=calculate_mailbox_stats(store))

    @app.get("/admin/agents/<path:agent_id>")
    @login_required
    @role_required("admin", "analyst")
    def admin_agent_detail(agent_id: str):
        agent = store.get_endpoint_agent(agent_id)
        if not agent:
            return render_template("error.html", message="Agent not found."), 404
        activity = _agent_activity(agent)
        return render_template(
            "admin_agent_detail.html",
            current_user=g.current_user,
            agent=agent,
            activity=activity,
        )

    @app.get("/admin/unlock-requests")
    @login_required
    @role_required("admin", "analyst")
    def admin_unlock_requests():
        return render_template("admin_unlock_requests.html", current_user=g.current_user, requests=store.list_unlock_requests(), stats=calculate_mailbox_stats(store))

    @app.get("/admin/access-requests")
    @login_required
    @role_required("admin", "analyst")
    def admin_access_requests():
        return render_template("admin_access_requests.html", current_user=g.current_user, requests=store.list_message_access_requests(), stats=calculate_mailbox_stats(store))

    @app.get("/api/summary")
    @login_required
    def api_summary():
        user_messages = scoped_messages(store, g.current_user)
        user_incidents = scoped_incidents(store, g.current_user)
        user_accounts = store.list_accounts() if is_privileged(g.current_user) else [store.get_account(g.current_user["email"])]
        return jsonify({"mailbox": mailbox_snapshot(user_messages), "audit": store.verify_audit_chain(), "stats": calculate_mailbox_stats(store, messages=user_messages, incidents=user_incidents, accounts=[item for item in user_accounts if item]), "analytics": scoped_analytics(store, g.current_user)})

    @app.get("/api/simulator/status")
    @login_required
    @role_required("admin", "analyst")
    def api_simulator_status():
        return jsonify(simulator.status())

    @app.post("/api/simulator/start")
    @login_required
    @role_required("admin", "analyst")
    def api_simulator_start():
        payload = request.get_json(force=True, silent=True) or {}
        interval_seconds = float(payload.get("interval_seconds", 4.0))
        profile = str(payload.get("profile", "balanced"))
        return jsonify(simulator.start(interval_seconds=interval_seconds, profile=profile))

    @app.post("/api/simulator/stop")
    @login_required
    @role_required("admin", "analyst")
    def api_simulator_stop():
        return jsonify(simulator.stop())

    @app.post("/api/simulator/step")
    @login_required
    @role_required("admin", "analyst")
    def api_simulator_step():
        return jsonify(simulator.step())

    @app.get("/api/messages")
    @login_required
    def api_messages():
        return jsonify(scoped_messages(store, g.current_user))

    @app.get("/api/messages/<int:message_id>")
    @login_required
    def api_message_detail(message_id: int):
        raw_message = store.get_message(message_id)
        if not raw_message or not can_access_message(g.current_user, raw_message):
            return jsonify({"error": "Message not found"}), 404
        if not is_privileged(g.current_user):
            store.update_message(message_id, is_read=True)
        else:
            store.add_audit_event("privileged_message_access", g.current_user["email"], {"message_id": message_id})
        message = scoped_message_detail(store, g.current_user, message_id)
        publish("message_read", {"message_id": message_id})
        return jsonify(message)

    @app.get("/api/access-requests")
    @login_required
    def api_access_requests():
        email = g.current_user["email"].lower()
        requests = store.list_message_access_requests()
        if is_privileged(g.current_user):
            return jsonify(requests)
        filtered = [
            item for item in requests
            if email in {item["sender_email"].lower(), item["recipient_email"].lower(), item["requested_by_email"].lower()}
        ]
        return jsonify(filtered)

    @app.get("/api/attachments")
    @login_required
    def api_attachments():
        return jsonify(scoped_attachments(store, g.current_user))

    @app.get("/api/attachments/<int:attachment_id>")
    @login_required
    def api_attachment_detail(attachment_id: int):
        attachment = store.get_attachment(attachment_id)
        if not attachment:
            return jsonify({"error": "Attachment not found"}), 404
        parent = store.get_message(int(attachment.get("message_id") or 0))
        if not parent or not can_access_message(g.current_user, parent):
            return jsonify({"error": "Attachment not found"}), 404
        if is_privileged(g.current_user):
            severity = str((attachment.get("result") or {}).get("severity", "SAFE")).upper()
            if severity in {"HIGH", "CRITICAL"} or parent.get("folder") == "quarantine":
                attachment["extracted_text"] = mask_sensitive_text((attachment.get("extracted_text") or "")[:1200])
            else:
                attachment["extracted_text"] = "[Attachment text hidden in privacy mode.]"
            store.add_audit_event("privileged_attachment_access", g.current_user["email"], {"attachment_id": attachment_id, "message_id": parent["id"]})
        return jsonify(attachment)

    @app.get("/api/incidents")
    @login_required
    def api_incidents():
        return jsonify(scoped_incidents(store, g.current_user))

    @app.get("/api/devices")
    @login_required
    def api_devices():
        return jsonify(store.list_devices())

    @app.get("/api/device-rules")
    @login_required
    @role_required("admin", "analyst")
    def api_device_rules():
        return jsonify(store.list_device_rules())

    @app.get("/api/device-events")
    @login_required
    def api_device_events():
        return jsonify(store.list_device_events())

    @app.get("/api/accounts")
    @login_required
    @role_required("admin", "analyst")
    def api_accounts():
        return jsonify(store.list_accounts())

    @app.get("/api/agents")
    @login_required
    @role_required("admin", "analyst")
    def api_agents():
        return jsonify(store.list_endpoint_agents())

    @app.get("/api/agents/<path:agent_id>")
    @login_required
    @role_required("admin", "analyst")
    def api_agent_detail(agent_id: str):
        agent = store.get_endpoint_agent(agent_id)
        if not agent:
            return jsonify({"error": "Agent not found"}), 404
        return jsonify(agent)

    def _agent_activity(agent: Dict[str, object]) -> Dict[str, object]:
        agent_id = str(agent.get("agent_id") or "").lower()
        actor_email = str(agent.get("actor_email") or "").lower()
        audit_events = list(reversed(store.list_audit_events()))
        filtered_audit = []
        for event in audit_events:
            payload = event.get("payload") or {}
            payload_agent = str(payload.get("agent_id") or "").lower()
            actor = str(event.get("actor") or "").lower()
            if agent_id and (payload_agent == agent_id or actor == actor_email):
                filtered_audit.append(event)
            elif actor_email and actor == actor_email:
                filtered_audit.append(event)
        incidents = store.list_incidents()
        filtered_incidents = [
            item for item in incidents
            if str(item.get("sender") or "").lower() == actor_email
            or str(item.get("owner") or "").lower() == actor_email
        ]
        devices = [
            item for item in store.list_devices()
            if str(item.get("owner") or "").lower() == actor_email
        ]
        return {
            "agent": agent,
            "audit_events": filtered_audit[:80],
            "incidents": filtered_incidents[:40],
            "devices": devices,
        }

    @app.get("/api/agents/<path:agent_id>/activity")
    @login_required
    @role_required("admin", "analyst")
    def api_agent_activity(agent_id: str):
        agent = store.get_endpoint_agent(agent_id)
        if not agent:
            return jsonify({"error": "Agent not found"}), 404
        return jsonify(_agent_activity(agent))

    @app.post("/api/agents/<path:agent_id>/action")
    @login_required
    @role_required("admin")
    def api_agent_action(agent_id: str):
        payload = request.get_json(force=True) or {}
        action = str(payload.get("action") or "").strip().lower()
        agent = store.get_endpoint_agent(agent_id)
        if not agent:
            return jsonify({"error": "Agent not found"}), 404
        if action == "revoke":
            updated = store.update_endpoint_agent(agent_id, status="revoked")
            store.add_audit_event("agent_revoked", g.current_user["email"], {"agent_id": agent_id})
            publish("agent_heartbeat", updated or agent)
            return jsonify({"ok": True, "agent": updated or agent})
        if action == "reactivate":
            updated = store.update_endpoint_agent(agent_id, status="active")
            store.add_audit_event("agent_reactivated", g.current_user["email"], {"agent_id": agent_id})
            publish("agent_heartbeat", updated or agent)
            return jsonify({"ok": True, "agent": updated or agent})
        if action == "rotate_key":
            new_key = secrets.token_urlsafe(32)
            updated = store.update_endpoint_agent(agent_id, api_key=new_key, status="active")
            store.add_audit_event("agent_key_rotated", g.current_user["email"], {"agent_id": agent_id})
            publish("agent_heartbeat", updated or agent)
            return jsonify({"ok": True, "agent": updated or agent, "agent_key": new_key})
        return jsonify({"error": "Unsupported action"}), 400

    @app.get("/api/audit-chain")
    @login_required
    @role_required("admin", "analyst")
    def api_audit_chain():
        return jsonify({"verification": store.verify_audit_chain(), "events": store.list_audit_events()})

    @app.get("/api/policies")
    @login_required
    def api_policies():
        return jsonify(store.list_policies())

    @app.get("/api/jobs")
    @login_required
    def api_jobs():
        return jsonify(scoped_jobs(store, g.current_user))

    @app.get("/api/jobs/<int:job_id>")
    @login_required
    def api_job_detail(job_id: int):
        job = store.get_scan_job(job_id)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        if not is_privileged(g.current_user) and str(job.get("actor", "")).lower() != str(g.current_user.get("email", "")).lower():
            return jsonify({"error": "Job not found"}), 404
        return jsonify(job)

    @app.get("/api/analytics")
    @login_required
    def api_analytics():
        return jsonify(scoped_analytics(store, g.current_user))

    @app.post("/api/policy/simulate")
    @login_required
    def api_policy_simulate():
        payload = request.get_json(force=True)
        text = payload.get("text", "")
        result = scanner.scan_text(text, channel=payload.get("channel", "email"))
        serialized = serialize_result(result)
        policies = store.list_policies()
        chosen = next((item for item in policies if item["channel"] == payload.get("channel", "email")), policies[0] if policies else None)
        action = "allow"
        if chosen:
            if serialized["severity"] in {"HIGH", "CRITICAL"}:
                action = "block"
            elif serialized["severity"] in {"MEDIUM"}:
                action = "quarantine"
        return jsonify({"result": serialized, "policy": chosen, "simulated_action": action})

    @app.post("/api/devices/sync")
    @login_required
    @role_required("admin", "analyst")
    def api_devices_sync():
        devices = store.list_devices()
        payload = {"devices": devices, "verification": store.verify_audit_chain()}
        publish("devices_synced", payload)
        return jsonify(payload)

    @app.post("/api/scan")
    @login_required
    def api_scan():
        text = request.form.get("body", "")
        files = request.files.getlist("attachments")
        job = begin_scan_job(store, g.current_user["email"], "draft_scan", "email", request.form.get("subject", "draft_scan"))
        saved_attachments = save_uploaded_attachments(files, UPLOAD_DIR)
        queued_job = store.get_scan_job(int(job["id"]))
        if queued_job:
            publish("scan_job", queued_job)
        scan_queue.put({"job_id": int(job["id"]), "text": text, "channel": "email", "attachments": saved_attachments})
        return (
            jsonify(
                {
                    "queued": True,
                    "job": queued_job,
                    "message": "Draft scan queued. Live updates and job details will refresh automatically.",
                }
            ),
            202,
        )

    @app.post("/api/send")
    @login_required
    def api_send():
        sender = request.form.get("sender", g.current_user["email"])
        recipient = request.form.get("recipient", "external@example.com")
        subject = request.form.get("subject", "")
        body = request.form.get("body", "")
        files = request.files.getlist("attachments")
        account = store.get_account(sender)
        if not account:
            return jsonify({"status": "rejected", "allowed": False, "reason": "Unknown account"}), 400
        if account.get("status") != "active" or not account.get("can_send", True):
            summary = "Sender is blocked by mail governance policy."
            store.add_audit_event("send_denied", sender, {"reason": summary, "recipient": recipient, "subject": subject})
            return jsonify({"status": "blocked_by_policy", "allowed": False, "reason": summary, "account": account}), 403

        saved_attachments = save_uploaded_attachments(files, UPLOAD_DIR)
        outcome = process_outbound_channel(
            sender=sender,
            recipient=recipient,
            subject=subject,
            body=body,
            channel="email",
            target_name=subject or "outbound_mail",
            saved_attachments=saved_attachments,
            incident_type="email_leak_attempt",
            audit_prefix="mail",
        )
        return jsonify(
            {
                "status": outcome["status"],
                "allowed": outcome["status"] == "delivered",
                "message": outcome["message"],
                "final_result": outcome["final_result"],
            }
        )

    @app.post("/api/external-channel/send")
    @login_required
    def api_external_channel_send():
        sender = request.form.get("sender", g.current_user["email"])
        channel = request.form.get("channel", "messenger").strip().lower()
        if channel not in {item["value"] for item in EXTERNAL_CHANNEL_OPTIONS}:
            return jsonify({"error": "Unsupported channel"}), 400
        platform = request.form.get("platform", "").strip() or "External platform"
        destination = request.form.get("destination", "").strip() or platform
        subject = request.form.get("subject", "").strip() or f"[{channel.upper()}] {platform}"
        body = request.form.get("body", "").strip()
        files = request.files.getlist("attachments")
        saved_attachments = save_uploaded_attachments(files, UPLOAD_DIR)
        try:
            outcome = process_outbound_channel(
                sender=sender,
                recipient=destination,
                subject=subject,
                body=body,
                channel=channel,
                target_name=f"{platform} outbound",
                saved_attachments=saved_attachments,
                incident_type="external_channel_leak_attempt",
                audit_prefix="external_channel",
            )
        except ValueError as exc:
            return jsonify({"status": "rejected", "allowed": False, "reason": str(exc)}), 400
        except PermissionError as exc:
            return jsonify({"status": "blocked_by_policy", "allowed": False, "reason": str(exc)}), 403
        return jsonify(
            {
                "status": outcome["status"],
                "allowed": outcome["status"] == "delivered",
                "message": outcome["message"],
                "final_result": outcome["final_result"],
            }
        )

    @app.post("/api/external-channel/scan")
    @login_required
    def api_external_channel_scan():
        channel = request.form.get("channel", "messenger").strip().lower()
        if channel not in {item["value"] for item in EXTERNAL_CHANNEL_OPTIONS}:
            return jsonify({"error": "Unsupported channel"}), 400
        body = request.form.get("body", "").strip()
        platform = request.form.get("platform", "").strip()
        destination = request.form.get("destination", "").strip()
        context_text = " ".join(part for part in [platform, destination, body] if part).strip()
        files = request.files.getlist("attachments")
        saved_attachments = save_uploaded_attachments(files, UPLOAD_DIR)
        result = build_scan_payload(context_text, channel, saved_attachments)
        return jsonify(result)

    @app.post("/api/agent/inspect")
    def api_agent_inspect():
        if request.is_json:
            incoming_payload = request.get_json(force=True, silent=True) or {}
            agent = authenticate_agent_request(incoming_payload)
        else:
            incoming_payload = {}
            # Read and verify the raw multipart body before Flask parses form/files.
            request.get_data(cache=True, parse_form_data=False)
            agent = authenticate_agent_request()
        if not agent:
            return jsonify({"error": "Unauthorized agent"}), 401

        if request.is_json:
            payload = incoming_payload or {}
            files = []
        else:
            payload = incoming_payload or {}
            files = request.files.getlist("attachments")

        actor = str(payload.get("actor_email") or agent.get("actor_email") or payload.get("sender") or "unknown@endpoint.local").strip().lower()
        channel = str(payload.get("channel") or "messenger").strip().lower()
        platform = str(payload.get("platform") or payload.get("app_name") or "External App").strip()
        destination = str(payload.get("destination") or payload.get("target") or platform).strip()
        text = str(payload.get("text") or payload.get("body") or "").strip()
        attachment_names = payload.get("attachment_names") or []
        if isinstance(attachment_names, str):
            attachment_names = [item.strip() for item in attachment_names.split(",") if item.strip()]
        if channel not in {item["value"] for item in EXTERNAL_CHANNEL_OPTIONS}:
            channel = "messenger"

        saved_attachments = _save_uploaded_attachments(files, UPLOAD_DIR, persist=False)
        context_text = " ".join(part for part in [platform, destination, text] if part).strip()
        try:
            scan_payload = build_scan_payload(context_text, channel, saved_attachments)
            scan_payload = finalize_agent_attachment_retention(scan_payload, saved_attachments, UPLOAD_DIR)
        except Exception:
            for staged in saved_attachments:
                staged_path = Path(str(staged.get("storage_path", "")))
                if staged_path.exists():
                    staged_path.unlink(missing_ok=True)
            raise
        compact_payload = compact_scan_payload(scan_payload, include_sensitive=scan_payload["severity"] == "CRITICAL")

        store.add_audit_event(
            "agent_external_inspect",
            actor,
            {
                "channel": channel,
                "platform": platform,
                "destination": destination,
                "severity": scan_payload["severity"],
                "attachment_names": attachment_names,
                "indicator_count": compact_payload["indicator_count"],
                "indicator_kinds": compact_payload["indicator_kinds"],
            },
        )

        # Behavioral engine: record event and potentially escalate
        if scan_payload["severity"] not in {"SAFE"}:
            behavioral_engine.record_event(actor, scan_payload["severity"], channel)
        beh_summary = behavioral_engine.get_summary(actor)
        effective_severity, beh_reason = behavioral_engine.escalate_severity(scan_payload["severity"], actor)
        if effective_severity != scan_payload["severity"]:
            scan_payload["severity"] = effective_severity
            scan_payload["summary"] += f" [Behavioral escalation: {beh_reason}]"
            scan_payload["actions"] = scanner.policy_actions(effective_severity, channel)

        # Add threat categories to payload
        scan_payload.setdefault("threat_categories", [])
        scan_payload["behavioral_risk"] = beh_summary

        incident = None
        message = None
        if scan_payload["severity"] == "CRITICAL":
            message = store.add_message(
                {
                    "sender": actor,
                    "recipient": destination or platform,
                    "subject": f"[{channel.upper()}] {platform} critical exfiltration",
                    "body": text,
                    "folder": "quarantine",
                    "status": "blocked",
                    "is_read": False,
                    "dlp": scan_payload,
                    "attachments": scan_payload["attachments"],
                }
            )
            incident = store.add_incident(
                {
                    "type": "external_agent_critical_exfiltration",
                    "severity": "CRITICAL",
                    "status": "open",
                    "summary": scan_payload["summary"],
                    "actions": scan_payload["actions"],
                    "sender": actor,
                    "recipient": destination or platform,
                    "subject": f"{platform} outbound blocked",
                    "message_id": message["id"],
                    "owner": "SOC",
                    "threat_categories": scan_payload.get("threat_categories", []),
                    "behavioral_risk": beh_summary,
                    "consequence": CONSEQUENCE_MATRIX.get("CRITICAL", {}).get("description", ""),
                    "penalty": "LOCKDOWN",
                }
            )
            updated_account = store.update_account(actor, status="restricted", can_send=False, blocked_reason="Automatic lock after critical external exfiltration attempt.")
            if updated_account:
                publish("account", updated_account)
            publish("message", message)
            publish("incident", incident)
        elif scan_payload["severity"] == "HIGH":
            incident = store.add_incident(
                {
                    "type": "external_agent_high_risk_attempt",
                    "severity": "HIGH",
                    "status": "open",
                    "summary": scan_payload["summary"],
                    "actions": scan_payload["actions"],
                    "sender": actor,
                    "recipient": destination or platform,
                    "subject": f"{platform} outbound reviewed",
                    "owner": "SOC",
                }
            )
            publish("incident", incident)

        return jsonify(
            {
                "allowed": scan_payload["severity"] not in {"HIGH", "CRITICAL"},
                "channel": channel,
                "platform": platform,
                "retention_mode": "critical_only",
                "stored_content": scan_payload["severity"] == "CRITICAL",
                "result": compact_payload,
                "incident_id": incident["id"] if incident else None,
                "message_id": message["id"] if message else None,
            }
        )

    @app.post("/api/agent/enroll")
    def api_agent_enroll():
        payload = request.get_json(force=True) or {}
        enrollment_key = str(request.headers.get("X-Agent-Enrollment-Key") or payload.get("enrollment_key") or "")
        expected_key = os.environ.get("SECUREMAIL_AGENT_ENROLLMENT_KEY", "example-enrollment-key")
        if not enrollment_key or enrollment_key != expected_key:
            return jsonify({"error": "Invalid enrollment key"}), 401

        agent_id = str(payload.get("agent_id") or "").strip()
        if not agent_id:
            fallback_hostname = str(payload.get("hostname") or "endpoint").strip()
            fallback_user = str(payload.get("username") or "agent").strip()
            agent_id = f"{fallback_hostname}:{fallback_user}"
        actor_email = str(payload.get("actor_email") or "unknown@endpoint.local").strip().lower()
        display_name = str(payload.get("display_name") or payload.get("hostname") or agent_id).strip()
        issued_key = secrets.token_urlsafe(32)
        existing = store.get_endpoint_agent(agent_id)

        if existing:
            agent = store.update_endpoint_agent(
                agent_id,
                display_name=display_name,
                actor_email=actor_email,
                status="active",
                hostname=payload.get("hostname"),
                platform=payload.get("platform", "windows"),
                version=payload.get("version", "1.0"),
                last_ip=request.remote_addr,
                last_seen_at=datetime.now(timezone.utc).isoformat(),
                monitors=payload.get("monitors", existing.get("monitors", [])),
                channels=payload.get("active_channels", existing.get("channels", [])),
                api_key=issued_key,
            )
            mode = "rotated"
        else:
            agent = store.create_endpoint_agent(
                {
                    "agent_id": agent_id,
                    "display_name": display_name,
                    "actor_email": actor_email,
                    "status": "active",
                    "hostname": payload.get("hostname"),
                    "platform": payload.get("platform", "windows"),
                    "version": payload.get("version", "1.0"),
                    "last_ip": request.remote_addr,
                    "last_seen_at": datetime.now(timezone.utc).isoformat(),
                    "monitors": payload.get("monitors", []),
                    "channels": payload.get("active_channels", []),
                    "api_key": issued_key,
                }
            )
            mode = "created"

        store.add_audit_event(
            "agent_enrolled",
            actor_email,
            {
                "agent_id": agent_id,
                "display_name": display_name,
                "hostname": payload.get("hostname"),
                "platform": payload.get("platform", "windows"),
                "mode": mode,
            },
        )
        publish("agent_heartbeat", agent)
        return jsonify(
            {
                "ok": True,
                "mode": mode,
                "agent_id": agent_id,
                "display_name": display_name,
                "agent_key": issued_key,
                "agent": agent,
            }
        )

    @app.post("/api/agent/heartbeat")
    def api_agent_heartbeat():
        payload = request.get_json(force=True) or {}
        agent = authenticate_agent_request(payload)
        if not agent:
            return jsonify({"error": "Unauthorized agent"}), 401
        actor = str(payload.get("actor_email") or agent.get("actor_email") or payload.get("username") or payload.get("agent_id") or "endpoint-agent")
        heartbeat = {
            "agent_id": agent["agent_id"],
            "hostname": payload.get("hostname"),
            "username": payload.get("username"),
            "platform": payload.get("platform", "windows"),
            "version": payload.get("version", "1.0"),
            "active_channels": payload.get("active_channels", []),
            "monitors": payload.get("monitors", []),
            "status": payload.get("status", "online"),
        }
        updated = store.update_endpoint_agent(
            agent["agent_id"],
            display_name=payload.get("display_name", agent.get("display_name")),
            actor_email=payload.get("actor_email", agent.get("actor_email")),
            status="active",
            hostname=payload.get("hostname"),
            platform=payload.get("platform", "windows"),
            version=payload.get("version", "1.0"),
            last_ip=request.remote_addr,
            last_seen_at=datetime.now(timezone.utc).isoformat(),
            monitors=payload.get("monitors", []),
            channels=payload.get("active_channels", []),
        )
        store.add_audit_event("agent_heartbeat", actor, heartbeat)
        publish("agent_heartbeat", updated or heartbeat)
        return jsonify({"ok": True, "heartbeat": updated or heartbeat})

    @app.post("/api/agent/device-event")
    def api_agent_device_event():
        payload = request.get_json(force=True) or {}
        agent = authenticate_agent_request(payload)
        if not agent:
            return jsonify({"error": "Unauthorized agent"}), 401
        actor = str(payload.get("actor_email") or agent.get("actor_email") or payload.get("username") or payload.get("agent_id") or "endpoint-agent")
        notes = str(payload.get("notes", "")).strip()
        device_context = " ".join(
            [
                f"device_name={payload.get('device_name', 'Unknown USB')}",
                f"event={payload.get('event', 'connected')}",
                f"policy={payload.get('policy', 'review')}",
                notes,
            ]
        ).strip()
        device_scan = scanner.scan_text(device_context, channel="device")
        event = store.add_device_event(
            {
                "device_name": payload.get("device_name", "Unknown USB"),
                "device_key": payload.get("device_key", payload.get("device_name", "unknown")),
                "event": payload.get("event", "connected"),
                "notes": notes,
                "severity": device_scan.severity,
                "policy": payload.get("policy", "review"),
            }
        )
        store.add_audit_event("agent_device_event", actor, {"event_id": event["id"], "device_name": event["device_name"], "severity": event["severity"]})
        publish("device_event", event)
        if device_scan.severity in {"HIGH", "CRITICAL"}:
            incident = store.add_incident(
                {
                    "type": "agent_device_event",
                    "severity": device_scan.severity,
                    "status": "open",
                    "summary": f"Endpoint agent detected risky removable media event: {event['device_name']}",
                    "actions": scanner.policy_actions(device_scan.severity, "device"),
                    "owner": "Endpoint Control",
                }
            )
            publish("incident", incident)
        return jsonify({"ok": True, "event": event})

    @app.post("/api/agent/device-sync")
    def api_agent_device_sync():
        payload = request.get_json(force=True) or {}
        agent = authenticate_agent_request(payload)
        if not agent:
            return jsonify({"error": "Unauthorized agent"}), 401
        actor = str(payload.get("actor_email") or agent.get("actor_email") or payload.get("username") or payload.get("agent_id") or "endpoint-agent")
        devices = payload.get("devices") or []
        if not isinstance(devices, list):
            return jsonify({"error": "devices must be a list"}), 400
        synced = sync_agent_usb_inventory(devices, actor=actor)
        return jsonify(
            {
                "ok": True,
                "devices": synced,
                "device_policies": {item["device_key"]: item.get("policy", "review") for item in synced},
            }
        )

    @app.post("/api/messages/<int:message_id>/folder")
    @login_required
    @role_required("admin", "analyst", "employee")
    def api_message_folder(message_id: int):
        payload = request.get_json(force=True)
        message = store.update_message(message_id, folder=payload.get("folder", "inbox"))
        if not message:
            return jsonify({"error": "Message not found"}), 404
        store.add_audit_event("message_reclassified", g.current_user["email"], {"message_id": message_id, "folder": message["folder"]})
        publish("message", message)
        return jsonify(message)

    @app.post("/api/device-event")
    @login_required
    def api_device_event():
        payload = request.get_json(force=True)
        notes = payload.get("notes", "")
        device_context = " ".join(
            [
                f"device_name={payload.get('device_name', 'Unknown USB')}",
                f"event={payload.get('event', 'connected')}",
                f"policy={payload.get('policy', 'review')}",
                notes,
            ]
        ).strip()
        device_scan = scanner.scan_text(device_context, channel="device")
        severity = device_scan.severity
        event = store.add_device_event(
            {
                "device_name": payload.get("device_name", "Unknown USB"),
                "device_key": payload.get("device_key", payload.get("device_name", "unknown")),
                "event": payload.get("event", "connected"),
                "notes": notes,
                "severity": severity,
                "policy": payload.get("policy", "review"),
            }
        )
        store.add_audit_event("device_event", g.current_user["email"], event)
        publish("device_event", event)
        if severity in {"HIGH", "CRITICAL"}:
            incident = store.add_incident(
                {
                    "type": "device_event",
                    "severity": severity,
                    "status": "open",
                    "summary": f"Removable media event: {event['device_name']} ({event['event']})",
                    "actions": scanner.policy_actions(severity, "device"),
                    "owner": "Endpoint Control",
                }
            )
            publish("incident", incident)
        return jsonify(event)

    @app.post("/api/accounts/<path:email>/policy")
    @login_required
    @role_required("admin")
    def api_account_policy(email: str):
        payload = request.get_json(force=True)
        account = store.update_account(email, status=payload.get("status", "active"), can_send=bool(payload.get("can_send", True)), blocked_reason=payload.get("blocked_reason", ""))
        if not account:
            return jsonify({"error": "Account not found"}), 404
        store.add_audit_event("account_policy_changed", g.current_user["email"], {"email": email, "policy": payload})
        publish("account", account)
        return jsonify(account)

    @app.post("/api/messages/<int:message_id>/access-request")
    @login_required
    @role_required("admin", "analyst")
    def api_message_access_request(message_id: int):
        message = store.get_message(message_id)
        if not message:
            return jsonify({"error": "Message not found"}), 404
        severity = str((message.get("dlp") or {}).get("severity", "SAFE")).upper()
        if severity != "MEDIUM":
            return jsonify({"error": "Access request flow is only required for MEDIUM messages."}), 400
        if not store.get_account(message["sender"]) or not store.get_account(message["recipient"]):
            return jsonify({"error": "Controlled access requests require both sender and recipient to exist as local accounts."}), 400
        existing = store.get_open_message_access_request(message_id)
        if existing:
            return jsonify(existing)
        payload = request.get_json(force=True, silent=True) or {}
        req = store.add_message_access_request(
            {
                "message_id": message_id,
                "requested_by_email": g.current_user["email"],
                "requested_by_name": g.current_user["name"],
                "sender_email": message["sender"],
                "recipient_email": message["recipient"],
                "reason": payload.get("reason", "Admin requested controlled access for medium-risk investigation."),
            }
        )
        store.add_audit_event("message_access_requested", g.current_user["email"], {"message_id": message_id, "request_id": req["id"]})
        publish("message_access_request", req)
        return jsonify(req)

    @app.post("/api/access-requests/<int:request_id>/decision")
    @login_required
    def api_access_request_decision(request_id: int):
        row = store.get_message_access_request(request_id)
        if not row:
            return jsonify({"error": "Request not found"}), 404
        email = g.current_user["email"].lower()
        if email not in {row["sender_email"].lower(), row["recipient_email"].lower()}:
            return jsonify({"error": "Not allowed"}), 403
        payload = request.get_json(force=True)
        decision = payload.get("decision", "approved")
        comment = payload.get("comment", "")
        changes = {}
        if email == row["sender_email"].lower():
            changes["sender_decision"] = decision
            changes["sender_comment"] = comment
        if email == row["recipient_email"].lower():
            changes["recipient_decision"] = decision
            changes["recipient_comment"] = comment
        updated = store.update_message_access_request(request_id, **changes)
        if updated:
            store.add_audit_event("message_access_decision", g.current_user["email"], {"request_id": request_id, "decision": decision})
            publish("message_access_request", updated)
        return jsonify(updated)

    @app.delete("/api/accounts/<path:email>")
    @login_required
    @role_required("admin")
    def api_account_delete(email: str):
        target = store.get_account(email)
        if not target:
            return jsonify({"error": "Account not found"}), 404
        if target["email"].lower() == g.current_user["email"].lower():
            return jsonify({"error": "You cannot delete your own account"}), 400
        store.delete_account(email)
        store.add_audit_event("account_deleted", g.current_user["email"], {"email": email})
        publish("account_deleted", {"email": email})
        return jsonify({"deleted": True, "email": email})

    @app.post("/api/unlock-requests/<int:request_id>/status")
    @login_required
    @role_required("admin", "analyst")
    def api_unlock_request_status(request_id: int):
        payload = request.get_json(force=True)
        status = payload.get("status", "reviewed")
        admin_comment = payload.get("admin_comment", "")
        row = store.update_unlock_request(request_id, status=status, admin_comment=admin_comment)
        if not row:
            return jsonify({"error": "Request not found"}), 404
        if status == "approved":
            store.update_account(row["email"], status="active", can_send=True, blocked_reason="")
        store.add_audit_event("unlock_request_status_changed", g.current_user["email"], {"request_id": request_id, "status": status})
        publish("unlock_request", row)
        return jsonify(row)

    @app.post("/api/incidents/<int:incident_id>/status")
    @login_required
    @role_required("admin", "analyst")
    def api_incident_status(incident_id: int):
        payload = request.get_json(force=True)
        incident = store.update_incident(incident_id, status=payload.get("status", "resolved"), owner=payload.get("owner", g.current_user["name"]))
        if not incident:
            return jsonify({"error": "Incident not found"}), 404
        store.add_audit_event("incident_status_changed", g.current_user["email"], {"incident_id": incident_id, "status": incident["status"], "owner": incident.get("owner")})
        publish("incident", incident)
        return jsonify(incident)

    @app.post("/api/devices/<path:device_key>/policy")
    @login_required
    @role_required("admin", "analyst")
    def api_device_policy(device_key: str):
        payload = request.get_json(force=True)
        desired_policy = payload.get("policy", "review")
        persist_rule = bool(payload.get("persist", True))
        device = store.update_device(device_key, policy=desired_policy, owner=payload.get("owner", g.current_user["name"]))
        if not device:
            return jsonify({"error": "Device not found"}), 404
        if persist_rule:
            serial = normalize_device_match(device.get("serial"))
            match_type = "serial" if serial else "device_key"
            match_value = serial or device_key
            store.upsert_device_rule(
                match_type,
                match_value,
                desired_policy,
                owner=payload.get("owner", g.current_user["name"]),
                notes=payload.get("notes", "Persisted from admin console."),
            )
        enforcement = apply_device_policy_enforcement(device, device["policy"])
        device = store.update_device(device_key, enforcement=enforcement) or device
        store.add_audit_event("device_policy_changed", g.current_user["email"], {"device_key": device_key, "policy": device["policy"], "owner": device.get("owner"), "enforcement": enforcement, "persist_rule": persist_rule})
        publish("device", device)
        if device["policy"] == "blocked" and device.get("connection_state") == "connected":
            incident = store.add_incident(
                {
                    "type": "blocked_usb_connected",
                    "severity": "CRITICAL",
                    "status": "open",
                    "summary": f"Blocked USB device {device['device_name']} is still connected.",
                    "actions": scanner.policy_actions("CRITICAL", "device"),
                    "owner": "Endpoint Control",
                }
            )
            publish("incident", incident)
        return jsonify({"device": device, "rules": store.list_device_rules()})

    # ── Health & Metrics ────────────────────────────────────────────────────────

    @app.get("/health")
    def health():
        uptime = int(time.time() - _APP_START_TIME)
        try:
            store.list_incidents()
            db_ok = True
        except Exception:
            db_ok = False
        return jsonify({
            "status": "ok" if db_ok else "degraded",
            "uptime_seconds": uptime,
            "version": "2.0.0",
            "db": "ok" if db_ok else "error",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }), 200 if db_ok else 503

    @app.get("/metrics")
    def metrics():
        try:
            incidents = store.list_incidents()
            messages = store.list_messages()
            agents = store.list_endpoint_agents()
        except Exception:
            return Response("# metrics unavailable\n", mimetype="text/plain; version=0.0.4"), 503
        open_incidents = sum(1 for i in incidents if i.get("status") == "open")
        critical_incidents = sum(1 for i in incidents if i.get("severity") == "CRITICAL")
        total_messages = len(messages)
        blocked_messages = sum(1 for m in messages if m.get("status") != "delivered")
        online_agents = sum(1 for a in agents if a.get("is_online"))
        uptime = int(time.time() - _APP_START_TIME)
        lines = [
            "# HELP dlp_incidents_open Number of open DLP incidents",
            "# TYPE dlp_incidents_open gauge",
            f"dlp_incidents_open {open_incidents}",
            "# HELP dlp_incidents_critical Number of critical-severity incidents",
            "# TYPE dlp_incidents_critical gauge",
            f"dlp_incidents_critical {critical_incidents}",
            "# HELP dlp_messages_total Total messages processed",
            "# TYPE dlp_messages_total gauge",
            f"dlp_messages_total {total_messages}",
            "# HELP dlp_messages_blocked Messages blocked by DLP policy",
            "# TYPE dlp_messages_blocked gauge",
            f"dlp_messages_blocked {blocked_messages}",
            "# HELP dlp_agents_online Online endpoint agents",
            "# TYPE dlp_agents_online gauge",
            f"dlp_agents_online {online_agents}",
            "# HELP dlp_uptime_seconds Application uptime in seconds",
            "# TYPE dlp_uptime_seconds counter",
            f"dlp_uptime_seconds {uptime}",
        ]
        return Response("\n".join(lines) + "\n", mimetype="text/plain; version=0.0.4")

    # ── MFA / TOTP ──────────────────────────────────────────────────────────────

    @app.get("/api/mfa/status")
    @login_required
    def api_mfa_status():
        secret = store.get_totp_secret(g.current_user["email"])
        return jsonify({"enabled": bool(secret)})

    @app.post("/api/mfa/setup")
    @login_required
    def api_mfa_setup():
        if not _PYOTP_AVAILABLE:
            return jsonify({"error": "pyotp not installed"}), 501
        existing = store.get_totp_secret(g.current_user["email"])
        if existing:
            return jsonify({"error": "MFA already enabled. Disable it first."}), 409
        secret = pyotp.random_base32()
        totp = pyotp.TOTP(secret)
        issuer = "SecureMail DLP"
        uri = totp.provisioning_uri(g.current_user["email"], issuer_name=issuer)
        session["pending_totp_secret"] = secret
        try:
            import qrcode as _qr
            import base64
            qr = _qr.make(uri)
            buf = io.BytesIO()
            qr.save(buf, format="PNG")
            qr_b64 = base64.b64encode(buf.getvalue()).decode()
        except Exception:
            qr_b64 = None
        return jsonify({"secret": secret, "uri": uri, "qr_png_base64": qr_b64})

    @app.post("/api/mfa/confirm")
    @login_required
    def api_mfa_confirm():
        if not _PYOTP_AVAILABLE:
            return jsonify({"error": "pyotp not installed"}), 501
        pending = session.get("pending_totp_secret")
        if not pending:
            return jsonify({"error": "No pending MFA setup. Call /api/mfa/setup first."}), 400
        if request.is_json:
            code = (request.get_json(force=True, silent=True) or {}).get("code", "")
        else:
            code = request.form.get("code", "")
        totp = pyotp.TOTP(pending)
        if not totp.verify(str(code), valid_window=1):
            return jsonify({"error": "Invalid TOTP code"}), 401
        store.set_totp_secret(g.current_user["email"], pending)
        session.pop("pending_totp_secret", None)
        store.add_audit_event("mfa_enabled", g.current_user["email"], {})
        return jsonify({"enabled": True})

    @app.post("/api/mfa/disable")
    @login_required
    def api_mfa_disable():
        if not _PYOTP_AVAILABLE:
            return jsonify({"error": "pyotp not installed"}), 501
        existing = store.get_totp_secret(g.current_user["email"])
        if not existing:
            return jsonify({"error": "MFA is not enabled"}), 400
        code = (request.get_json(force=True, silent=True) or {}).get("code", "")
        totp = pyotp.TOTP(existing)
        if not totp.verify(str(code), valid_window=1):
            return jsonify({"error": "Invalid TOTP code"}), 401
        store.set_totp_secret(g.current_user["email"], None)
        store.add_audit_event("mfa_disabled", g.current_user["email"], {})
        return jsonify({"enabled": False})

    if sock is not None:
        @sock.route("/ws/live")
        def ws_live(ws):  # pragma: no cover
            client = bus.subscribe()
            try:
                ws.send(json.dumps({"type": "connected", "payload": {"message": "live updates enabled"}}))
                while True:
                    message = client.get()
                    ws.send(message)
            finally:
                bus.unsubscribe(client)

    @app.get("/stream/events")
    @login_required
    def stream_events():
        client = bus.subscribe()

        def event_stream():
            try:
                yield "data: {\"type\":\"connected\",\"payload\":{\"message\":\"sse enabled\"}}\n\n"
                while True:
                    message = client.get()
                    yield f"data: {message}\n\n"
            finally:
                bus.unsubscribe(client)

        return Response(event_stream(), mimetype="text/event-stream")

    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=True, port=5000)
