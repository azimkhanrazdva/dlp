import random
import threading
from collections import deque
from datetime import datetime, timezone
from typing import Callable, Deque, Dict, List, Optional

from app.dlp_engine import serialize_result


class DemoScenarioSimulator:
    def __init__(
        self,
        *,
        store,
        scanner,
        publish: Callable[[str, Dict[str, object]], None],
        process_outbound_channel: Callable[..., Dict[str, object]],
        sync_agent_usb_inventory: Callable[..., List[Dict[str, object]]],
    ) -> None:
        self.store = store
        self.scanner = scanner
        self.publish = publish
        self.process_outbound_channel = process_outbound_channel
        self.sync_agent_usb_inventory = sync_agent_usb_inventory
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._interval_seconds = 4.0
        self._profile = "balanced"
        self._recent_events: Deque[Dict[str, object]] = deque(maxlen=80)
        self._rng = random.Random()
        self._step_index = 0
        self._stats = {
            "events_total": 0,
            "mail_events": 0,
            "external_events": 0,
            "endpoint_events": 0,
            "admin_actions": 0,
            "incidents_created": 0,
            "safe": 0,
            "low": 0,
            "medium": 0,
            "high": 0,
            "critical": 0,
        }
        self._seed_accounts = [
            {
                "name": "Nurzhan Bekov",
                "email": "nurzhan@securemail.kz",
                "role": "employee",
                "department": "Finance",
                "risk_profile": "elevated",
                "title": "Treasury Analyst",
                "password": "Nurzhan123!",
            },
            {
                "name": "Saltanat Ilyas",
                "email": "saltanat@securemail.kz",
                "role": "employee",
                "department": "HR",
                "risk_profile": "standard",
                "title": "HR Coordinator",
                "password": "Saltanat123!",
            },
            {
                "name": "Timur Sadykov",
                "email": "timur@securemail.kz",
                "role": "employee",
                "department": "Procurement",
                "risk_profile": "standard",
                "title": "Procurement Specialist",
                "password": "Timur12345!",
            },
            {
                "name": "Aruzhan Kairat",
                "email": "aruzhan@securemail.kz",
                "role": "employee",
                "department": "Operations",
                "risk_profile": "standard",
                "title": "Operations Coordinator",
                "password": "Aruzhan123!",
            },
        ]
        self._seed_agents = [
            {
                "agent_id": "fin-win11:nurzhan",
                "display_name": "Finance Endpoint",
                "actor_email": "nurzhan@securemail.kz",
                "hostname": "FIN-WIN11",
                "platform": "windows",
                "version": "1.0.0",
                "monitors": ["clipboard", "usb", "filesystem", "process_context"],
                "channels": ["clipboard", "device", "file", "messenger", "social", "web", "public_upload"],
            },
            {
                "agent_id": "hr-lt22:saltanat",
                "display_name": "HR Laptop",
                "actor_email": "saltanat@securemail.kz",
                "hostname": "HR-LT22",
                "platform": "windows",
                "version": "1.0.0",
                "monitors": ["clipboard", "usb", "filesystem", "process_context"],
                "channels": ["clipboard", "device", "file", "messenger", "social", "web", "public_upload"],
            },
        ]
        self._safe_topics = [
            ("Shift coverage update", "Please review tomorrow's support roster and confirm availability by 18:00."),
            ("Vendor meeting notes", "Meeting moved to 15:30. Agenda covers delivery timelines and invoice approval."),
            ("Quarterly planning", "Draft roadmap uploaded. Please validate milestones before the architecture review."),
        ]
        self._medium_payloads = [
            ("Customer callback sheet", "Customer support callback list includes names, emails, and phone numbers for follow-up today."),
            ("Employee contact register", "Internal register contains employee phone numbers, HR references, and onboarding reminders."),
            ("Shipment coordination export", "Vendor export includes contact names, invoice IDs, and delivery schedule details."),
        ]
        self._critical_payloads = [
            ("Production connection string", "DATABASE_URL=postgresql://admin:secretpass@prod-db.company.kz:5432/prod"),
            ("Secrets bundle", "AWS_SECRET_ACCESS_KEY=EXAMPLE_AWS_SECRET_DO_NOT_USE\nclient_secret=EXAMPLE_CLIENT_SECRET_DO_NOT_USE"),
            ("Infrastructure dump", "redis://cache-admin:Pa55w0rd@corp-cache.company.kz:6379/0\nAuthorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"),
        ]
        self._external_targets = [
            ("Telegram", "External recruiter"),
            ("WhatsApp", "Personal device"),
            ("Public form", "Open web form"),
            ("Google Drive", "Personal cloud"),
        ]

    def scenario_catalog(self) -> List[Dict[str, object]]:
        return [
            {"id": "safe_mail", "title": "Internal safe conversation", "kind": "mail", "severity": "SAFE"},
            {"id": "medium_mail", "title": "Medium-risk internal sharing", "kind": "mail", "severity": "MEDIUM"},
            {"id": "critical_mail", "title": "Critical email leak attempt", "kind": "mail", "severity": "CRITICAL"},
            {"id": "external_share", "title": "External internet channel leak", "kind": "external", "severity": "HIGH / CRITICAL"},
            {"id": "endpoint_clipboard", "title": "Endpoint clipboard inspection", "kind": "endpoint", "severity": "CRITICAL"},
            {"id": "usb_event", "title": "USB insertion and endpoint alert", "kind": "endpoint", "severity": "LOW / HIGH"},
            {"id": "admin_review", "title": "Admin resolves incidents and unlocks users", "kind": "admin", "severity": "CONTROL"},
            {"id": "heartbeat", "title": "Agent heartbeat refresh", "kind": "endpoint", "severity": "SAFE"},
        ]

    def status(self) -> Dict[str, object]:
        with self._lock:
            return {
                "running": bool(self._thread and self._thread.is_alive()),
                "interval_seconds": self._interval_seconds,
                "profile": self._profile,
                "step_index": self._step_index,
                "stats": dict(self._stats),
                "recent_events": list(reversed(self._recent_events)),
                "participants": self._participant_snapshot(),
                "catalog": self.scenario_catalog(),
            }

    def start(self, *, interval_seconds: float = 4.0, profile: str = "balanced") -> Dict[str, object]:
        self._ensure_seed_data(reset_accounts=True)
        with self._lock:
            self._interval_seconds = max(1.0, float(interval_seconds))
            self._profile = profile if profile in {"balanced", "aggressive", "endpoint-heavy"} else "balanced"
            if self._thread and self._thread.is_alive():
                self._push_event("system", "Simulator already running", "The scenario engine is already active.", "SAFE")
            else:
                self._stop_event.clear()
                self._thread = threading.Thread(target=self._run_loop, name="securemail-demo-simulator", daemon=True)
                self._thread.start()
                self._push_event("system", "Simulator started", f"Live traffic started with '{self._profile}' profile.", "SAFE")
        self.publish("simulation", self.status())
        return self.status()

    def stop(self) -> Dict[str, object]:
        self._stop_event.set()
        with self._lock:
            self._push_event("system", "Simulator stopped", "Automatic scenario generation has been paused.", "SAFE")
        self.publish("simulation", self.status())
        return self.status()

    def step(self) -> Dict[str, object]:
        self._ensure_seed_data(reset_accounts=False)
        event = self._simulate_once()
        self.publish("simulation", self.status())
        return {"event": event, "status": self.status()}

    def _run_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                self.step()
            except Exception as exc:  # pragma: no cover
                with self._lock:
                    self._push_event("system", "Simulator error", str(exc), "HIGH")
                self.publish("simulation", self.status())
            self._stop_event.wait(self._interval_seconds)

    def _participant_snapshot(self) -> Dict[str, object]:
        accounts = []
        for email in [item["email"] for item in self._seed_accounts]:
            account = self.store.get_account(email)
            if account:
                accounts.append(
                    {
                        "name": account.get("name"),
                        "email": account.get("email"),
                        "department": account.get("department"),
                        "status": account.get("status"),
                        "can_send": bool(account.get("can_send", True)),
                    }
                )
        agents = []
        for item in self._seed_agents:
            agent = self.store.get_endpoint_agent(item["agent_id"])
            if agent:
                agents.append(
                    {
                        "agent_id": agent.get("agent_id"),
                        "display_name": agent.get("display_name"),
                        "actor_email": agent.get("actor_email"),
                        "hostname": agent.get("hostname"),
                        "is_online": bool(agent.get("is_online")),
                        "last_seen_at": agent.get("last_seen_at"),
                    }
                )
        return {"accounts": accounts, "agents": agents}

    def _ensure_seed_data(self, *, reset_accounts: bool) -> None:
        for account in self._seed_accounts:
            existing = self.store.get_account(account["email"])
            if not existing:
                self.store.create_account(account)
                continue
            if reset_accounts:
                self.store.update_account(
                    account["email"],
                    status="active",
                    can_send=True,
                    blocked_reason="",
                    password=account["password"],
                )
        now_iso = datetime.now(timezone.utc).isoformat()
        for agent in self._seed_agents:
            existing = self.store.get_endpoint_agent(agent["agent_id"])
            if existing:
                self.store.update_endpoint_agent(
                    agent["agent_id"],
                    display_name=agent["display_name"],
                    actor_email=agent["actor_email"],
                    status="active",
                    hostname=agent["hostname"],
                    platform=agent["platform"],
                    version=agent["version"],
                    last_seen_at=now_iso,
                    monitors=agent["monitors"],
                    channels=agent["channels"],
                )
            else:
                self.store.create_endpoint_agent(
                    {
                        "agent_id": agent["agent_id"],
                        "display_name": agent["display_name"],
                        "actor_email": agent["actor_email"],
                        "status": "active",
                        "hostname": agent["hostname"],
                        "platform": agent["platform"],
                        "version": agent["version"],
                        "last_seen_at": now_iso,
                        "monitors": agent["monitors"],
                        "channels": agent["channels"],
                        "api_key": f"sim-{agent['agent_id']}",
                    }
                )

    def _simulate_once(self) -> Dict[str, object]:
        scenario_id = self._pick_scenario()
        handler = getattr(self, f"_scenario_{scenario_id}")
        self._step_index += 1
        event = handler()
        severity_key = str(event.get("severity", "SAFE")).lower()
        with self._lock:
            self._stats["events_total"] += 1
            if severity_key in self._stats:
                self._stats[severity_key] += 1
            kind = event.get("kind")
            if kind == "mail":
                self._stats["mail_events"] += 1
            elif kind == "external":
                self._stats["external_events"] += 1
            elif kind == "endpoint":
                self._stats["endpoint_events"] += 1
            elif kind == "admin":
                self._stats["admin_actions"] += 1
            if event.get("incident_created"):
                self._stats["incidents_created"] += 1
        return event

    def _pick_scenario(self) -> str:
        if self._profile == "aggressive":
            weighted = [
                ("safe_mail", 14),
                ("medium_mail", 15),
                ("critical_mail", 12),
                ("external_share", 16),
                ("endpoint_clipboard", 14),
                ("usb_event", 12),
                ("admin_review", 7),
                ("heartbeat", 10),
            ]
        elif self._profile == "endpoint-heavy":
            weighted = [
                ("safe_mail", 10),
                ("medium_mail", 8),
                ("critical_mail", 7),
                ("external_share", 10),
                ("endpoint_clipboard", 22),
                ("usb_event", 22),
                ("admin_review", 7),
                ("heartbeat", 14),
            ]
        else:
            weighted = [
                ("safe_mail", 20),
                ("medium_mail", 13),
                ("critical_mail", 8),
                ("external_share", 11),
                ("endpoint_clipboard", 9),
                ("usb_event", 12),
                ("admin_review", 9),
                ("heartbeat", 18),
            ]
        choices = [item[0] for item in weighted]
        weights = [item[1] for item in weighted]
        return self._rng.choices(choices, weights=weights, k=1)[0]

    def _push_event(self, category: str, title: str, summary: str, severity: str, meta: Optional[Dict[str, object]] = None) -> Dict[str, object]:
        entry = {
            "id": f"sim-{datetime.now(timezone.utc).timestamp()}-{self._step_index}",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "category": category,
            "title": title,
            "summary": summary,
            "severity": severity,
            "meta": meta or {},
            "step_index": self._step_index,
        }
        self._recent_events.append(entry)
        return entry

    def _eligible_senders(self) -> List[Dict[str, object]]:
        users = []
        for item in self._seed_accounts:
            account = self.store.get_account(item["email"])
            if account and account.get("status") == "active" and account.get("can_send", True):
                users.append(account)
        return users

    def _pick_active_sender(self) -> Dict[str, object]:
        users = self._eligible_senders()
        if not users:
            self._ensure_seed_data(reset_accounts=True)
            users = self._eligible_senders()
        return self._rng.choice(users)

    def _choose_sender_recipient(self):
        users = self._eligible_senders()
        if len(users) < 2:
            self._ensure_seed_data(reset_accounts=True)
            users = self._eligible_senders()
        return self._rng.sample(users, 2)

    def _deliver_internal_copy(self, *, sender: str, recipient: str, subject: str, body: str, dlp_payload: Dict[str, object]) -> None:
        inbox_message = self.store.add_message(
            {
                "sender": sender,
                "recipient": recipient,
                "subject": subject,
                "body": body,
                "folder": "inbox",
                "status": "delivered",
                "is_read": False,
                "dlp": dlp_payload,
                "attachments": [],
            }
        )
        self.publish("message", inbox_message)

    def _scenario_safe_mail(self) -> Dict[str, object]:
        sender, recipient = self._choose_sender_recipient()
        subject, body = self._rng.choice(self._safe_topics)
        outcome = self.process_outbound_channel(
            sender=sender["email"],
            recipient=recipient["email"],
            subject=subject,
            body=body,
            channel="email",
            target_name=subject,
            saved_attachments=[],
            incident_type="email_leak_attempt",
            audit_prefix="mail",
        )
        if outcome["status"] == "delivered":
            self._deliver_internal_copy(
                sender=sender["email"],
                recipient=recipient["email"],
                subject=f"RE: {subject}",
                body=f"Acknowledged. {body}",
                dlp_payload=outcome["final_result"],
            )
        event = self._push_event(
            "mail",
            f"{sender['name']} emailed {recipient['name']}",
            f"Safe internal discussion delivered normally with severity {outcome['final_result']['severity']}.",
            str(outcome["final_result"]["severity"]),
            {"sender": sender["email"], "recipient": recipient["email"], "channel": "email"},
        )
        event["kind"] = "mail"
        event["incident_created"] = False
        return event

    def _scenario_medium_mail(self) -> Dict[str, object]:
        sender, recipient = self._choose_sender_recipient()
        subject, body = self._rng.choice(self._medium_payloads)
        outcome = self.process_outbound_channel(
            sender=sender["email"],
            recipient=recipient["email"],
            subject=subject,
            body=body,
            channel="email",
            target_name=subject,
            saved_attachments=[],
            incident_type="email_leak_attempt",
            audit_prefix="mail",
        )
        if outcome["status"] == "delivered":
            self._deliver_internal_copy(
                sender=sender["email"],
                recipient=recipient["email"],
                subject=subject,
                body=body,
                dlp_payload=outcome["final_result"],
            )
        event = self._push_event(
            "mail",
            f"Medium-risk message from {sender['name']}",
            f"Internal content with contact data was classified as {outcome['final_result']['severity']}.",
            str(outcome["final_result"]["severity"]),
            {"sender": sender["email"], "recipient": recipient["email"], "channel": "email", "status": outcome["status"]},
        )
        event["kind"] = "mail"
        event["incident_created"] = outcome["final_result"]["severity"] in {"HIGH", "CRITICAL"}
        return event

    def _scenario_critical_mail(self) -> Dict[str, object]:
        sender = self._pick_active_sender()
        subject, body = self._rng.choice(self._critical_payloads)
        outcome = self.process_outbound_channel(
            sender=sender["email"],
            recipient="external-partner@example.com",
            subject=subject,
            body=body,
            channel="email",
            target_name=subject,
            saved_attachments=[],
            incident_type="email_leak_attempt",
            audit_prefix="mail",
        )
        event = self._push_event(
            "mail",
            f"Critical email blocked for {sender['name']}",
            "Outbound email to an external address was blocked and the sender was automatically restricted.",
            str(outcome["final_result"]["severity"]),
            {"sender": sender["email"], "recipient": "external-partner@example.com", "status": outcome["status"]},
        )
        event["kind"] = "mail"
        event["incident_created"] = True
        return event

    def _scenario_external_share(self) -> Dict[str, object]:
        sender = self._pick_active_sender()
        platform, destination = self._rng.choice(self._external_targets)
        subject, body = self._rng.choice(self._critical_payloads if self._rng.random() > 0.4 else self._medium_payloads)
        channel = self._rng.choice(["messenger", "social", "web", "public_upload"])
        outcome = self.process_outbound_channel(
            sender=sender["email"],
            recipient=f"{platform} / {destination}",
            subject=f"[{platform}] {subject}",
            body=body,
            channel=channel,
            target_name=platform,
            saved_attachments=[],
            incident_type="external_channel_leak_attempt",
            audit_prefix="external_channel",
        )
        event = self._push_event(
            "external",
            f"{sender['name']} attempted {platform} share",
            f"External {channel} transmission to {destination} finished with status '{outcome['status']}' and severity {outcome['final_result']['severity']}.",
            str(outcome["final_result"]["severity"]),
            {"sender": sender["email"], "platform": platform, "channel": channel, "status": outcome["status"]},
        )
        event["kind"] = "external"
        event["incident_created"] = outcome["final_result"]["severity"] in {"HIGH", "CRITICAL"}
        return event

    def _scenario_endpoint_clipboard(self) -> Dict[str, object]:
        agent = self._rng.choice(self._seed_agents)
        endpoint = self.store.get_endpoint_agent(agent["agent_id"])
        actor = agent["actor_email"]
        platform = self._rng.choice(["Clipboard Monitor", "Telegram Desktop", "Web Browser"])
        destination = self._rng.choice(["Clipboard", "External chat", "Paste target"])
        _, text = self._rng.choice(self._critical_payloads)
        scan_result = serialize_result(self.scanner.scan_text(f"{platform} {destination} {text}", channel="clipboard"))
        self.store.add_audit_event(
            "agent_external_inspect",
            actor,
            {
                "agent_id": agent["agent_id"],
                "channel": "clipboard",
                "platform": platform,
                "destination": destination,
                "severity": scan_result["severity"],
                "indicator_count": len(scan_result.get("indicators", [])),
                "indicator_kinds": [item.get("kind") for item in scan_result.get("indicators", [])],
            },
        )
        incident_created = False
        message_id = None
        if scan_result["severity"] == "CRITICAL":
            message = self.store.add_message(
                {
                    "sender": actor,
                    "recipient": destination,
                    "subject": f"[CLIPBOARD] {platform} blocked transfer",
                    "body": text,
                    "folder": "quarantine",
                    "status": "blocked",
                    "is_read": False,
                    "dlp": scan_result,
                    "attachments": [],
                }
            )
            self.publish("message", message)
            incident = self.store.add_incident(
                {
                    "type": "external_agent_critical_exfiltration",
                    "severity": "CRITICAL",
                    "status": "open",
                    "summary": scan_result["summary"],
                    "actions": scan_result["actions"],
                    "sender": actor,
                    "recipient": destination,
                    "subject": f"{platform} clipboard blocked",
                    "message_id": message["id"],
                    "owner": "SOC",
                }
            )
            self.publish("incident", incident)
            self.store.update_account(actor, status="restricted", can_send=False, blocked_reason="Endpoint simulator triggered critical clipboard leak.")
            message_id = message["id"]
            incident_created = True
        if endpoint:
            updated = self.store.update_endpoint_agent(
                agent["agent_id"],
                last_seen_at=datetime.now(timezone.utc).isoformat(),
                status="active",
                hostname=agent["hostname"],
                platform=agent["platform"],
                version=agent["version"],
                monitors=agent["monitors"],
                channels=agent["channels"],
            )
            self.publish("agent_heartbeat", updated or endpoint)
        event = self._push_event(
            "endpoint",
            f"Endpoint clipboard inspection on {agent['display_name']}",
            f"Clipboard or desktop share on {platform} was classified as {scan_result['severity']} and routed into the endpoint audit trail.",
            str(scan_result["severity"]),
            {"agent_id": agent["agent_id"], "actor": actor, "message_id": message_id},
        )
        event["kind"] = "endpoint"
        event["incident_created"] = incident_created
        return event

    def _scenario_usb_event(self) -> Dict[str, object]:
        agent = self._rng.choice(self._seed_agents)
        actor = agent["actor_email"]
        device_name = self._rng.choice(["Kingston DataTraveler", "SanDisk Ultra", "Personal Backup SSD"])
        dangerous = self._rng.random() > 0.55
        notes = "Potential archive export to removable media." if dangerous else "Routine removable media insertion detected."
        policy = "blocked" if dangerous else "review"
        synced = self.sync_agent_usb_inventory(
            [
                {
                    "device_key": f"{device_name}-{self._step_index}",
                    "device_name": device_name,
                    "serial": f"SIM-{self._step_index:04d}",
                    "status": "OK",
                    "media_type": "Removable Media",
                    "size_bytes": 64 * 1024**3,
                    "size_gb": 64,
                    "connection_state": "connected",
                    "policy": policy,
                    "owner": actor,
                }
            ],
            actor=actor,
        )
        device_context = f"device_name={device_name} event=connected policy={policy} {notes}"
        device_scan = self.scanner.scan_text(device_context, channel="device")
        event_row = self.store.add_device_event(
            {
                "device_name": device_name,
                "device_key": synced[0]["device_key"] if synced else f"{device_name}-{self._step_index}",
                "event": "connected",
                "notes": notes,
                "severity": device_scan.severity,
                "policy": policy,
            }
        )
        self.publish("device_event", event_row)
        incident_created = False
        if device_scan.severity in {"HIGH", "CRITICAL"}:
            incident = self.store.add_incident(
                {
                    "type": "agent_device_event",
                    "severity": device_scan.severity,
                    "status": "open",
                    "summary": f"Endpoint agent detected risky removable media event: {device_name}",
                    "actions": self.scanner.policy_actions(device_scan.severity, "device"),
                    "owner": "Endpoint Control",
                }
            )
            self.publish("incident", incident)
            incident_created = True
        self.store.add_audit_event("agent_device_event", actor, {"event_id": event_row["id"], "device_name": device_name, "severity": event_row["severity"]})
        event = self._push_event(
            "endpoint",
            f"USB event on {agent['display_name']}",
            f"{device_name} connected to {agent['hostname']} with endpoint policy '{policy}' and severity {event_row['severity']}.",
            str(event_row["severity"]),
            {"agent_id": agent["agent_id"], "device_name": device_name, "policy": policy},
        )
        event["kind"] = "endpoint"
        event["incident_created"] = incident_created
        return event

    def _scenario_admin_review(self) -> Dict[str, object]:
        incidents = [item for item in self.store.list_incidents() if item.get("status") == "open"]
        restricted = [self.store.get_account(item["email"]) for item in self._seed_accounts]
        restricted = [item for item in restricted if item and (item.get("status") != "active" or not item.get("can_send", True))]
        summary = "Admin checked the system with no pending action."
        if incidents:
            incident = incidents[0]
            updated_incident = self.store.update_incident(incident["id"], status="resolved", owner="SOC")
            if updated_incident:
                self.publish("incident", updated_incident)
                summary = f"Admin resolved incident #{updated_incident['id']} ({updated_incident['severity']})."
        if restricted:
            account = restricted[0]
            updated_account = self.store.update_account(account["email"], status="active", can_send=True, blocked_reason="")
            if updated_account:
                self.publish("account", updated_account)
                summary += f" Account {updated_account['email']} was re-enabled."
        self.store.add_audit_event("simulation_admin_review", "soc@securemail.kz", {"summary": summary})
        event = self._push_event(
            "admin",
            "Admin intervention",
            summary,
            "SAFE",
            {"open_incidents": len(incidents), "restricted_accounts": len(restricted)},
        )
        event["kind"] = "admin"
        event["incident_created"] = False
        return event

    def _scenario_heartbeat(self) -> Dict[str, object]:
        agent = self._rng.choice(self._seed_agents)
        updated = self.store.update_endpoint_agent(
            agent["agent_id"],
            display_name=agent["display_name"],
            actor_email=agent["actor_email"],
            status="active",
            hostname=agent["hostname"],
            platform=agent["platform"],
            version=agent["version"],
            last_seen_at=datetime.now(timezone.utc).isoformat(),
            monitors=agent["monitors"],
            channels=agent["channels"],
        )
        heartbeat_payload = {
            "agent_id": agent["agent_id"],
            "hostname": agent["hostname"],
            "platform": agent["platform"],
            "version": agent["version"],
            "status": "online",
            "active_channels": agent["channels"],
            "monitors": agent["monitors"],
        }
        self.store.add_audit_event("agent_heartbeat", agent["actor_email"], heartbeat_payload)
        self.publish("agent_heartbeat", updated or heartbeat_payload)
        event = self._push_event(
            "endpoint",
            f"Heartbeat from {agent['display_name']}",
            f"Endpoint agent {agent['hostname']} refreshed health status and stayed online.",
            "SAFE",
            {"agent_id": agent["agent_id"], "hostname": agent["hostname"]},
        )
        event["kind"] = "endpoint"
        event["incident_created"] = False
        return event
