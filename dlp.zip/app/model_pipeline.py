import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
SEVERITY_RANK = {label: idx for idx, label in enumerate(LABELS)}


def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 200) -> List[str]:
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_size)
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = max(0, end - overlap)
    return chunks


def normalize_label(label: str, labels: List[str]) -> str:
    value = str(label).upper()
    if value.startswith("LABEL_"):
        index = int(value.split("_")[-1])
        if 0 <= index < len(labels):
            return labels[index]
    return value


@dataclass
class ModelResult:
    label: str
    score: float


class HFTextClassifier:
    def __init__(self, model_path: Optional[str], labels: List[str]) -> None:
        self.model_path = model_path
        self.labels = labels
        self.pipeline = None
        self.error = None
        if not model_path:
            return
        try:
            import torch
            from transformers import pipeline

            self.pipeline = pipeline(
                "text-classification",
                model=model_path,
                tokenizer=model_path,
                truncation=True,
                max_length=256,
                device=0 if torch.cuda.is_available() else -1,
            )
        except Exception as exc:
            self.error = str(exc)

    def predict(self, text: str) -> Optional[ModelResult]:
        if not self.pipeline:
            return None
        out = self.pipeline(text[:4000])[0]
        return ModelResult(label=normalize_label(out["label"], self.labels), score=float(out["score"]))


class MultiStagePipeline:
    def __init__(self, stage1_path: Optional[str], stage2_path: Optional[str], stage3_path: Optional[str]) -> None:
        self.stage1 = HFTextClassifier(stage1_path, ["SAFE", "RISK"])
        self.stage2 = HFTextClassifier(stage2_path, ["LOW", "MEDIUM", "HIGH", "CRITICAL"])
        self.stage3 = HFTextClassifier(stage3_path, ["SAFE", "SECRET"])

    def predict(self, text: str) -> Tuple[str, float, Dict[str, Dict[str, object]]]:
        chunks = [chunk for chunk in chunk_text(text) if chunk.strip()]
        if not chunks:
            return "SAFE", 0.0, {"stage1": {}, "stage2": {}, "stage3": {}}

        final_label = "SAFE"
        final_score = 0.0
        trace: Dict[str, Dict[str, object]] = {"stage1": {}, "stage2": {}, "stage3": {}}

        for idx, chunk in enumerate(chunks):
            s1 = self.stage1.predict(chunk)
            s3 = self.stage3.predict(chunk)
            s2 = None
            risk = s1 and s1.label == "RISK"
            secret = s3 and s3.label == "SECRET"

            if risk:
                s2 = self.stage2.predict(chunk)
            chunk_label = "SAFE"
            chunk_score = s1.score if s1 else 0.0
            if secret and s3 and s3.score >= 0.7:
                chunk_label = "CRITICAL"
                chunk_score = s3.score
            elif s2:
                chunk_label = s2.label
                chunk_score = s2.score
            elif risk:
                chunk_label = "MEDIUM"
                chunk_score = s1.score if s1 else 0.5

            if SEVERITY_RANK[chunk_label] > SEVERITY_RANK[final_label]:
                final_label = chunk_label
                final_score = chunk_score
            else:
                final_score = max(final_score, chunk_score)

            trace[f"chunk_{idx}"] = {
                "stage1": {"label": s1.label, "score": s1.score} if s1 else None,
                "stage2": {"label": s2.label, "score": s2.score} if s2 else None,
                "stage3": {"label": s3.label, "score": s3.score} if s3 else None,
                "final_label": chunk_label,
                "final_score": chunk_score,
            }

        return final_label, round(final_score, 4), trace
