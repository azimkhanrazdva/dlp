"""
DLP Scanning Engine — AI-first architecture.

Detection pipeline:
  1. Normalize text
  2. BERT multi-stage classifier  ← PRIMARY decision maker
  3. Regex entity extractor       ← Evidence & specific-entity reporting
  4. Bulk-leak adjuster           ← Escalate structured exports
  5. Harmless-noise filter        ← Suppress clear false positives
  6. Verdict + consequence matrix
"""
import math
import re
import xml.etree.ElementTree as ET
from io import BytesIO
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from app.model_pipeline import MultiStagePipeline


# ── Severity ordering ──────────────────────────────────────────────────────
LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
SEVERITY_RANK = {label: idx for idx, label in enumerate(LABELS)}

# ── Context detectors (used for evidence annotation, not primary verdict) ──
RISK_CONTEXT_RE = re.compile(
    r"\b("
    r"password|passwd|secret|token|bearer|authorization|api[_-]?key|client[_-]?secret|"
    r"database[_-]?url|connection[_ -]?string|private[_ -]?key|session[_-]?secret|"
    r"telegram[_-]?token|slack|github|openai|aws|postgres(?:ql)?|mongodb|mysql|redis|"
    r"iin|iban|card|cvv|account|payroll|salary|passport|"
    r"kaspi|halyk|freedom|jusan|forte|atf|centercredit|банк|счёт|счет|"
    r"жеке|куәлік|удостоверение|жалақы|зарплата|клиент|пайдаланушы|"
    r"source[_ -]?code|исходный[_ ]?код|конфиденциально|коммерческая[_ ]?тайна"
    r")\b",
    re.IGNORECASE,
)
CARD_CONTEXT_RE = re.compile(
    r"\b(card|visa|mastercard|maestro|amex|payment|pan|cvv|expiry|exp|debit|credit|"
    r"kaspi|halyk|freedom|jusan|forte|atf|карта|төлем|карточка)\b",
    re.IGNORECASE,
)
ACCOUNT_CONTEXT_RE = re.compile(
    r"\b(account|iban|bank|bik|swift|settlement|beneficiary|recipient|payment details|transfer|"
    r"kaspi|halyk|freedom|jusan|forte|atf|centercredit|шот|аударым|бенефициар|счёт|счет|банк)\b",
    re.IGNORECASE,
)
PASSPORT_CONTEXT_RE = re.compile(
    r"\b(passport|id number|document number|identity document|national id|"
    r"удостоверение|жеке куәлік|паспорт|жеке|куәлік|ЖСН|БИН|ИИН)\b",
    re.IGNORECASE,
)
PLACEHOLDER_CONTEXT_RE = re.compile(
    r"\b(demo|test[- ]?only|placeholder|example only|sample data|training data|mock)\b",
    re.IGNORECASE,
)

# ── Specific token signatures (regex is excellent for these) ───────────────
SECRET_MARKER_RE = re.compile(
    r"("
    r"\bgh[pousr]_[A-Za-z0-9_]{12,}\b|"
    r"\bsk-[A-Za-z0-9\-_]{16,}\b|"
    r"\bAKIA[0-9A-Z]{16}\b|"
    r"\bSG\.[A-Za-z0-9._-]{16,}\b|"
    r"\bAIza[0-9A-Za-z\-_]{20,}\b|"
    r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b|"
    r"\b\d{8,12}:[A-Za-z0-9_-]{24,}\b|"
    r"\bhttps://hooks\.slack\.com/services/[A-Za-z0-9/_-]{20,}\b|"
    r"\bhttps://discord(?:app)?\.com/api/webhooks/[A-Za-z0-9/_-]{20,}\b|"
    r"\bBearer[\s\t]+[A-Za-z0-9._-]{20,}\b|"
    r"\bDATABASE(?:[_ -]?URL)?\b|"
    r"\bSECRET[_ -]?KEY\b|"
    r"\bSESSION[_ -]?SECRET\b|"
    r"\bPRIVATE[_ -]?KEY\b|"
    r"\bpostgres(?:ql)?://|mysql://|mongodb(?:\+srv)?://|redis://|mssql://|"
    r"\bOPENAI\b|\bGITHUB\b|\bAWS\b"
    r")",
    re.IGNORECASE,
)
HARMLESS_NOISE_RE = re.compile(
    r"^\s*("
    r"debug trace=|placeholder token=|cache blob |regex test only |"
    r"harmless OCR garbage |log record session=|Runbook example only:"
    r")",
    re.IGNORECASE,
)
FILENAME_RISK_RE = re.compile(
    r"\b("
    r"payroll|salary|customer|clients?|employee|export|backup|dump|archive|database|db|"
    r"credential|secret|token|key|passport|iin|iban|card|statement|invoice|finance|hr|kyc|env|"
    r"zharaqy|жалақы|клиенттер|деректер|жеке|kualik|bank|kaspi|halyk|freedom|jusan"
    r")\b",
    re.IGNORECASE,
)

# ── Modern threat patterns (2024-2025) ─────────────────────────────────────
AI_TOOL_RE = re.compile(
    r"\b("
    r"chat\.openai\.com|chatgpt\.com|claude\.ai|gemini\.google\.com|"
    r"copilot\.microsoft\.com|bard\.google\.com|perplexity\.ai|"
    r"poe\.com|mistral\.ai|groq\.com|huggingface\.co|cohere\.com|"
    r"character\.ai|phind\.com|you\.com|bing\.com/chat"
    r")\b",
    re.IGNORECASE,
)
SHADOW_IT_RE = re.compile(
    r"\b("
    r"dropbox\.com|drive\.google\.com|onedrive\.live\.com|wetransfer\.com|"
    r"mega\.nz|mediafire\.com|zippyshare\.com|anonfiles\.com|file\.io|"
    r"gofile\.io|pastebin\.com|hastebin\.com|paste\.ee|justpaste\.it|"
    r"anonshare|sendspace|filedropper"
    r")\b",
    re.IGNORECASE,
)
SOURCE_CODE_RE = re.compile(
    r"(?:def\s+\w+|class\s+\w+|function\s+\w+|import\s+\w+|require\s*\(|"
    r"const\s+\w+\s*=|let\s+\w+\s*=|var\s+\w+\s*=|export\s+(?:default\s+)?|"
    r"#!\s*/(?:usr|bin)|package\s+\w+;|namespace\s+\w+|using\s+\w+;|"
    r"@Override|public\s+(?:class|void|static|final)|fn\s+\w+\s*\(|"
    r"SELECT\s+\*\s+FROM|INSERT\s+INTO|CREATE\s+TABLE|ALTER\s+TABLE)",
    re.IGNORECASE,
)

# File types that indicate source code
SOURCE_CODE_SUFFIXES = {
    ".py", ".js", ".ts", ".go", ".java", ".cs", ".cpp", ".c", ".h",
    ".rb", ".php", ".rs", ".swift", ".kt", ".scala", ".sh", ".ps1",
    ".tf", ".yaml", ".yml", ".dockerfile",
}

ZIP_TEXT_SUFFIXES = {".txt", ".log", ".json", ".csv", ".env", ".md", ".yaml", ".yml", ".ini", ".conf", ".cfg"}
ARCHIVE_SUFFIXES = {".zip", ".7z", ".rar"}
ZIP_MAX_ENTRY_BYTES = 5 * 1024 * 1024   # 5 MB per entry
ZIP_MAX_TOTAL_BYTES = 20 * 1024 * 1024  # 20 MB total extracted
OCR_DIGIT_MAP = str.maketrans({"O": "0", "o": "0", "Q": "0", "D": "0", "I": "1", "l": "1", "L": "1", "|": "1", "S": "5", "B": "8"})


# ── Consequence Matrix ─────────────────────────────────────────────────────
# Defines what happens at each severity level — used by server AND agent.
CONSEQUENCE_MATRIX = {
    "SAFE": {
        "server_actions": ["Allow"],
        "endpoint_actions": [],
        "notifications": [],
        "penalty": None,
        "description": "No sensitive content detected.",
    },
    "LOW": {
        "server_actions": ["Allow", "Audit log"],
        "endpoint_actions": ["show_toast_warning"],
        "notifications": ["user"],
        "penalty": "WARNING",
        "description": "Minor sensitive content. User warned.",
    },
    "MEDIUM": {
        "server_actions": ["Block transmission", "Audit log", "Flag for review"],
        "endpoint_actions": ["block_action", "show_toast_warning", "sound_alert"],
        "notifications": ["user", "manager_digest"],
        "penalty": "TEMPORARY_BLOCK",
        "description": "Sensitive content blocked. Manager notified in daily digest.",
    },
    "HIGH": {
        "server_actions": [
            "Block transmission",
            "Quarantine source file",
            "Create SOC incident",
            "Manager immediate alert",
            "HR notification",
        ],
        "endpoint_actions": [
            "block_action",
            "quarantine_file",
            "clear_clipboard",
            "kill_exfil_process",
            "show_alert_dialog",
        ],
        "notifications": ["user", "manager", "hr", "soc"],
        "penalty": "BLOCK",
        "description": "HIGH: Transmission blocked. File quarantined. Manager + HR notified. SOC incident created.",
    },
    "CRITICAL": {
        "server_actions": [
            "Block transmission immediately",
            "Quarantine source file",
            "Create priority SOC incident",
            "IT emergency notification",
            "Manager + HR immediate alert",
            "Legal hold flag activated",
        ],
        "endpoint_actions": [
            "block_action",
            "quarantine_file",
            "clear_clipboard",
            "kill_all_sensitive_processes",
            "lock_workstation",
            "collect_forensic_evidence",
            "show_critical_alert",
        ],
        "notifications": ["user", "manager", "hr", "soc", "it_emergency", "legal"],
        "penalty": "LOCKDOWN",
        "description": "CRITICAL: Full lockdown. Workstation locked. IT emergency. Legal hold. Forensic evidence collected.",
    },
}


# ── Helpers ────────────────────────────────────────────────────────────────
def shannon_entropy(text: str) -> float:
    if not text:
        return 0.0
    probs = [text.count(ch) / len(text) for ch in set(text)]
    return -sum(p * math.log2(p) for p in probs)


def normalize_text(text: str) -> str:
    text = (
        text.replace("[at]", "@").replace(" [at] ", "@").replace("(at)", "@")
        .replace("[dot]", ".").replace(" [dot] ", ".").replace("(dot)", ".")
        .replace("[slash]", "/").replace("(slash)", "/")
        .replace("[colon]", ":").replace("(colon)", ":")
    )
    text = re.sub(r"\bhxxps?\b", lambda m: "https" if m.group(0).lower() == "hxxps" else "http", text, flags=re.IGNORECASE)
    text = re.sub(r"(?<=\w)\s*:\s*(?=\w)", ":", text)
    text = re.sub(r"(?<=\w)\s*=\s*(?=\S)", "=", text)
    text = re.sub(r"(?<=\w)\s*/\s*(?=\w)", "/", text)
    text = re.sub(r"(?<=\w)\s*@\s*(?=\w)", "@", text)
    text = re.sub(r"(?<=\w)\s*\.\s*(?=\w)", ".", text)
    text = re.sub(r"(?<=sk)\s*-\s*(?=proj-)", "-", text, flags=re.IGNORECASE)
    text = re.sub(r"(?<=gh)\s*([pousr])\s*_\s*", r"\1_", text, flags=re.IGNORECASE)
    text = re.sub(r"(?<=AKIA)\s+(?=[0-9A-Z]{4,})", "", text)
    text = re.sub(r"(sk-(?:proj-)?)\s+([A-Za-z0-9\-_]{16,})", r"\1\2", text, flags=re.IGNORECASE)
    text = re.sub(r"(gh[pousr]_)\s+([A-Za-z0-9_]{12,})", r"\1\2", text, flags=re.IGNORECASE)
    text = re.sub(r"(SG\.)\s+([A-Za-z0-9._-]{16,})", r"\1\2", text)
    text = re.sub(r"(AIza)\s+([A-Za-z0-9\-_]{20,})", r"\1\2", text)
    text = re.sub(r"(AKIA)\s+([0-9A-Z]{12,16})", r"\1\2", text)
    text = re.sub(r"(xox[baprs]-)\s+([A-Za-z0-9-]{20,})", r"\1\2", text, flags=re.IGNORECASE)
    text = re.sub(r"(Bearer)\s*[\r\n]+\s*([A-Za-z0-9._-]{20,})", r"\1 \2", text, flags=re.IGNORECASE)
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def has_risk_context(text: str) -> bool:
    return bool(RISK_CONTEXT_RE.search(text))


def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 180) -> List[str]:
    text = text.strip()
    if not text:
        return [""]
    if len(text) <= chunk_size:
        return [text]
    chunks: List[str] = []
    start = 0
    step = max(1, chunk_size - overlap)
    while start < len(text):
        end = min(len(text), start + chunk_size)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start += step
    return chunks or [text]


@dataclass
class Indicator:
    kind: str
    value: str
    severity: str
    reason: str


@dataclass
class ScanResult:
    severity: str
    score: float
    summary: str
    indicators: List[Indicator] = field(default_factory=list)
    actions: List[str] = field(default_factory=list)
    model_info: Dict[str, object] = field(default_factory=dict)
    extracted_text: str = ""
    channel: str = "text"
    threat_categories: List[str] = field(default_factory=list)


class OptionalModel:
    def __init__(self, model_path: Optional[str]) -> None:
        self.model_path = model_path
        self.pipeline = None
        self.error = None
        if not model_path:
            return
        try:
            import torch
            from transformers import pipeline
            self.pipeline = pipeline(
                "text-classification",
                model=model_path,
                tokenizer=model_path,
                truncation=True,
                max_length=256,
                device=0 if torch.cuda.is_available() else -1,
            )
        except Exception as exc:
            self.error = str(exc)

    def predict(self, text: str) -> Optional[Tuple[str, float]]:
        if not self.pipeline:
            return None
        out = self.pipeline(text[:4000])[0]
        label = str(out["label"]).upper()
        if label.startswith("LABEL_"):
            label = LABELS[int(label.split("_")[-1])]
        return label, float(out["score"])


class DLPScanner:
    def __init__(
        self,
        model_path: Optional[str] = None,
        aux_model_path: Optional[str] = None,
        stage1_path: Optional[str] = None,
        stage2_path: Optional[str] = None,
        stage3_path: Optional[str] = None,
    ) -> None:
        self.model = OptionalModel(model_path)
        self.aux_model = OptionalModel(aux_model_path)
        self.pipeline = MultiStagePipeline(stage1_path, stage2_path, stage3_path)

        # Regex patterns — used for EVIDENCE extraction, not primary verdict
        self.patterns = [
            ("email",           re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),                                                                                   "LOW",      "Email address detected"),
            ("phone_kz",        re.compile(r"(?<!\d)(?:\+7\s?(?:7(?:0[0-8]|47|5[01]|6[0-4]|7[15-8]))\s?\d{3}\s?\d{2}\s?\d{2}|8(?:7(?:0[0-8]|47|5[01]|6[0-4]|7[15-8]))\d{7}|\+7\s?\d{3}\s?\d{3}\s?\d{2}\s?\d{2}|8\d{10}|\+7\d{10})(?!\d)"), "LOW", "Kazakhstan phone number detected"),
            ("iin",             re.compile(r"(?<!\d)\d{12}(?!\d)"),                                                                                                                    "HIGH",     "IIN/BIN detected"),
            ("iin_labeled",     re.compile(r"\b(?:ИИН|ЖСН|БИН|BIN|IIN)[:\s#№-]*(\d{12})\b", re.IGNORECASE),                                                                          "HIGH",     "Labeled Kazakhstan IIN/BIN detected"),
            ("kz_id_doc",       re.compile(r"\b(?:удостоверение|куәлік|жеке куәлік)[^0-9]{0,20}(\d{9})\b", re.IGNORECASE),                                                            "HIGH",     "Kazakhstan national ID number detected"),
            ("kz_passport",     re.compile(r"\b[A-ZА-Я]{1,2}\s?\d{7,8}\b"),                                                                                                           "HIGH",     "Kazakhstan passport number detected"),
            ("bin_label",       re.compile(r"\bBIN[:\s-]?\d{6}\b", re.IGNORECASE),                                                                                                    "HIGH",     "Bank identification number detected"),
            ("iban",            re.compile(r"\bKZ\d{2}[A-Z0-9]{16}\b"),                                                                                                               "HIGH",     "Kazakhstan IBAN detected"),
            ("card",            re.compile(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)"),                                                                                                       "HIGH",     "Payment card number detected"),
            ("masked_card",     re.compile(r"(?<!\d)\d{4}[ -]?(?:\*{4}|X{4}|x{4})[ -]?(?:\*{4}|X{4}|x{4})[ -]?\d{4}(?!\d)"),                                                        "HIGH",     "Masked payment card detected"),
            ("card_expiry",     re.compile(r"\b(?:0[1-9]|1[0-2])[\/\-](?:\d{2}|\d{4})\b"),                                                                                           "MEDIUM",   "Card expiry date detected"),
            ("card_cvv",        re.compile(r"\bcvv[:\s-]?\d{3,4}\b", re.IGNORECASE),                                                                                                  "HIGH",     "Card CVV detected"),
            ("bank_account",    re.compile(r"\b(?:account|acct|a/c)[:\s-]*[A-Z0-9\-]{8,24}\b", re.IGNORECASE),                                                                        "HIGH",     "Bank account identifier detected"),
            ("passport",        re.compile(r"\b[A-Z]{1,2}\d{6,8}\b"),                                                                                                                 "HIGH",     "Passport-like identifier detected"),
            ("aws",             re.compile(r"\bAKIA[0-9A-Z]{16}\b"),                                                                                                                  "CRITICAL", "AWS access key detected"),
            ("aws_secret",      re.compile(r"\b(?:aws[_ -]?secret[_ -]?access[_ -]?key|secret[_ -]?access[_ -]?key)[:=\s-]+[A-Za-z0-9/+=]{32,64}\b", re.IGNORECASE),                "CRITICAL", "AWS secret access key detected"),
            ("github",          re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"),                                                                                                       "CRITICAL", "GitHub personal access token detected"),
            ("openai",          re.compile(r"\bsk-[A-Za-z0-9\-_]{20,}\b"),                                                                                                            "CRITICAL", "OpenAI API key detected"),
            ("sendgrid",        re.compile(r"\bSG\.[A-Za-z0-9._-]{16,}\b"),                                                                                                           "CRITICAL", "SendGrid API key detected"),
            ("google_api",      re.compile(r"\bAIza[0-9A-Za-z\-_]{20,}\b"),                                                                                                           "CRITICAL", "Google API key detected"),
            ("slack_token",     re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),                                                                                                      "CRITICAL", "Slack token detected"),
            ("telegram_token",  re.compile(r"\b\d{8,12}:[A-Za-z0-9_-]{24,}\b"),                                                                                                       "CRITICAL", "Telegram bot token detected"),
            ("slack_webhook",   re.compile(r"\bhttps://hooks\.slack\.com/services/[A-Za-z0-9/_-]{20,}\b"),                                                                            "CRITICAL", "Slack webhook URL detected"),
            ("discord_webhook", re.compile(r"\bhttps://discord(?:app)?\.com/api/webhooks/[A-Za-z0-9/_-]{20,}\b"),                                                                     "CRITICAL", "Discord webhook URL detected"),
            ("jwt",             re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9._-]{10,}\.[A-Za-z0-9._-]{10,}\b"),                                                                   "CRITICAL", "JWT token detected"),
            ("bearer",          re.compile(r"\bBearer\s+[A-Za-z0-9._-]{20,}\b", re.IGNORECASE),                                                                                       "CRITICAL", "Bearer token detected"),
            ("db_uri",          re.compile(r"\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|mssql)://[^\s\"']+\b", re.IGNORECASE),                                                "CRITICAL", "Database connection string detected"),
            ("example_private_key",     re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |)?PRIVATE KEY-----"),                                                                               "CRITICAL", "Private cryptographic key detected"),
            # Modern threats
            ("ai_tool_upload",  AI_TOOL_RE,                                                                                                                                            "HIGH",     "Content being sent to AI tool — potential data exfiltration"),
            ("shadow_it",       SHADOW_IT_RE,                                                                                                                                          "HIGH",     "Unauthorized cloud/file sharing service detected"),
            ("source_code",     SOURCE_CODE_RE,                                                                                                                                        "MEDIUM",   "Source code content detected — verify authorization"),
        ]

    # ── KZ validators ──────────────────────────────────────────────────────
    def _valid_iin(self, iin: str) -> bool:
        if not re.fullmatch(r"\d{12}", iin):
            return False
        digits = [int(d) for d in iin]
        w1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
        c = sum(w1[i] * digits[i] for i in range(11)) % 11
        if c == 10:
            w2 = [3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 2]
            c = sum(w2[i] * digits[i] for i in range(11)) % 11
        return c == digits[11]

    def _valid_card(self, candidate: str) -> bool:
        digits = re.sub(r"\D", "", candidate)
        if not (13 <= len(digits) <= 19):
            return False
        total = 0
        for idx, ch in enumerate(digits[::-1]):
            num = int(ch)
            if idx % 2 == 1:
                num *= 2
                if num > 9:
                    num -= 9
            total += num
        return total % 10 == 0

    # ── Context windows ────────────────────────────────────────────────────
    def _looks_like_card_context(self, text: str, start: int, end: int) -> bool:
        w = text[max(0, start - 32): min(len(text), end + 32)]
        return bool(CARD_CONTEXT_RE.search(w))

    def _looks_like_account_context(self, text: str, start: int, end: int) -> bool:
        w = text[max(0, start - 36): min(len(text), end + 36)]
        return bool(ACCOUNT_CONTEXT_RE.search(w))

    def _looks_like_passport_context(self, text: str, start: int, end: int) -> bool:
        w = text[max(0, start - 36): min(len(text), end + 36)]
        return bool(PASSPORT_CONTEXT_RE.search(w))

    def _looks_like_placeholder_context(self, text: str, start: int, end: int) -> bool:
        w = text[max(0, start - 40): min(len(text), end + 40)]
        return bool(PLACEHOLDER_CONTEXT_RE.search(w))

    def _ocr_digit_normalize(self, value: str) -> str:
        return value.translate(OCR_DIGIT_MAP)

    # ── Entity extractors (evidence layer) ─────────────────────────────────
    def _assignment_indicators(self, text: str) -> List[Indicator]:
        out: List[Indicator] = []
        pattern = re.compile(
            r"\b(password|passwd|pwd|api[_-]?key|access[_-]?token|refresh[_-]?token|"
            r"client[_-]?secret|auth[_-]?token|session[_-]?secret)\b\s*[:=]\s*([^\s\"';]{8,})",
            re.IGNORECASE,
        )
        for match in pattern.finditer(text):
            key, value = match.group(1), match.group(2).strip()
            if self._looks_like_placeholder_context(text, match.start(), match.end()):
                continue
            if value.lower() in {"example", "example123", "changeme", "password123", "test12345"}:
                continue
            entropy = shannon_entropy(value)
            mixed = bool(re.search(r"[A-Za-z]", value)) and bool(re.search(r"\d", value))
            if len(value) >= 12 and (entropy >= 3.2 or mixed or has_risk_context(text)):
                out.append(Indicator("credential_assignment", f"{key}={value[:80]}", "CRITICAL", "Credential assignment pattern detected"))
        return out

    def _ocr_fragment_indicators(self, text: str) -> List[Indicator]:
        out: List[Indicator] = []
        card_re = re.compile(r"(?<!\w)(?:[0-9OQDIlLSB|][ \t\r\n-]*){13,28}(?!\w)")
        for match in card_re.finditer(text):
            raw = match.group(0)
            cleaned = re.sub(r"[^0-9A-Za-z|]", "", raw)
            normalized = self._ocr_digit_normalize(cleaned)
            digits = re.sub(r"\D", "", normalized)
            if not (13 <= len(digits) <= 19):
                continue
            if not self._looks_like_card_context(text, match.start(), match.end()) and not self._valid_card(digits):
                continue
            out.append(Indicator("ocr_card", digits[:19], "HIGH", "OCR-obfuscated payment card detected"))

        iban_re = re.compile(r"\bKZ[\s\r\n-]*[0-9OQDIlLSB|]{2}(?:[\s\r\n-]*[A-Z0-9OQDIlLSB|]){16}\b", re.IGNORECASE)
        for match in iban_re.finditer(text):
            normalized = self._ocr_digit_normalize(re.sub(r"[\s\r\n-]+", "", match.group(0))).upper()
            if re.fullmatch(r"KZ\d{2}[A-Z0-9]{16}", normalized):
                out.append(Indicator("ocr_iban", normalized[:34], "HIGH", "OCR-obfuscated IBAN detected"))
        return out

    def _indicators(self, text: str) -> List[Indicator]:
        out = []
        # Pre-pass: collect IIN values rejected by labeled patterns
        # so the plain `iin` pattern cannot re-flag them via label context.
        _rejected_iin_values: set = set()
        for kind, pattern, _severity, _reason in self.patterns:
            if kind not in {"iin_labeled", "kz_id_doc"}:
                continue
            for match in pattern.finditer(text):
                candidate = re.sub(r"\D", "", match.group(0))[-12:]
                if len(candidate) == 12 and not self._valid_iin(candidate):
                    _rejected_iin_values.add(candidate)

        for kind, pattern, severity, reason in self.patterns:
            for match in pattern.finditer(text):
                value = match.group(0)
                if kind == "card":
                    digits = re.sub(r"\D", "", value)
                    if not (13 <= len(digits) <= 19):
                        continue
                    # Require EITHER a valid Luhn checksum OR card-specific context word
                    if not self._valid_card(digits) and not self._looks_like_card_context(text, match.start(), match.end()):
                        continue
                if kind == "iin":
                    raw = re.sub(r"\D", "", value)
                    # Skip if already rejected by a labeled IIN pattern for the same value
                    if raw in _rejected_iin_values:
                        continue
                    # Require EITHER valid IIN checksum OR strong identity-document context
                    if not self._valid_iin(raw) and not self._looks_like_passport_context(text, match.start(), match.end()):
                        continue
                if kind in {"iin_labeled", "kz_id_doc"}:
                    candidate = re.sub(r"\D", "", value)[-12:]
                    # Labeled context is strong; still validate checksum to cut false positives
                    if len(candidate) == 12 and not self._valid_iin(candidate):
                        _rejected_iin_values.add(candidate)
                        continue
                if kind == "kz_passport" and not self._looks_like_passport_context(text, match.start(), match.end()):
                    continue
                if kind == "bank_account":
                    if not self._looks_like_account_context(text, match.start(), match.end()):
                        continue
                    digits = re.sub(r"\D", "", value)
                    if len(digits) < 8 or self._looks_like_placeholder_context(text, match.start(), match.end()):
                        continue
                if kind == "passport" and not self._looks_like_passport_context(text, match.start(), match.end()):
                    continue
                # Source code: only report if also has risk context (key/secret/token nearby)
                if kind == "source_code" and not has_risk_context(text) and not self._has_secret_markers(text):
                    continue
                out.append(Indicator(kind, value[:120], severity, reason))

        out.extend(self._assignment_indicators(text))
        out.extend(self._ocr_fragment_indicators(text))

        # High-entropy tokens (only in risk context to reduce noise)
        if has_risk_context(text):
            for token in re.findall(r"\b[A-Za-z0-9+/=_-]{24,}\b", text):
                if shannon_entropy(token) >= 4.15 and not re.fullmatch(r"[0-9A-Fa-f]{24,}", token):
                    out.append(Indicator("high_entropy", token[:80], "MEDIUM", "High-entropy token in sensitive context"))
        return out

    def _has_secret_markers(self, text: str) -> bool:
        return bool(SECRET_MARKER_RE.search(text))

    def _looks_like_harmless_noise(self, text: str) -> bool:
        return bool(HARMLESS_NOISE_RE.search(text)) or "example only" in text.lower() or "placeholder" in text.lower()

    def _detect_threat_categories(self, text: str, indicators: List[Indicator], channel: str) -> List[str]:
        """Classify the TYPE of threat for better incident reporting."""
        kinds = {ind.kind for ind in indicators}
        categories = []
        lowered = text.lower()

        if kinds & {"openai", "github", "aws", "aws_secret", "google_api", "slack_token", "db_uri", "example_private_key", "credential_assignment"}:
            categories.append("SECRET_CREDENTIAL_LEAK")
        if kinds & {"iin", "iin_labeled", "kz_id_doc", "kz_passport", "passport"}:
            categories.append("PERSONAL_IDENTITY_DATA")
        if kinds & {"iban", "card", "masked_card", "card_cvv", "bank_account", "ocr_card", "ocr_iban"}:
            categories.append("FINANCIAL_DATA")
        if "ai_tool_upload" in kinds or AI_TOOL_RE.search(text):
            categories.append("AI_TOOL_EXFILTRATION")
        if "shadow_it" in kinds or SHADOW_IT_RE.search(text):
            categories.append("SHADOW_IT_UPLOAD")
        if ("source_code" in kinds or SOURCE_CODE_RE.search(text)) and self._has_secret_markers(text):
            categories.append("SOURCE_CODE_WITH_SECRETS")
        if any(kw in lowered for kw in ["payroll", "salary", "жалақы", "зарплата", "employee", "hr export"]):
            categories.append("EMPLOYEE_PII_BULK")
        if any(kw in lowered for kw in ["m&a", "merger", "acquisition", "insider", "quarterly results", "forecast", "нсзи"]):
            categories.append("INSIDER_TRADING_RISK")
        if channel in {"device", "usb"}:
            categories.append("USB_EXFILTRATION")
        if channel == "messenger" and any(kw in lowered for kw in ["telegram", "whatsapp", "discord", "signal"]):
            categories.append("MESSENGER_EXFILTRATION")

        return categories

    def _filename_indicator(self, file_path: Path) -> Optional[Indicator]:
        name = file_path.name.lower()
        if not FILENAME_RISK_RE.search(name):
            return None
        if any(key in name for key in ["secret", "token", "credential", "key", ".env", "dump", "database", "db"]):
            return Indicator("filename_risk", file_path.name, "CRITICAL", "Sensitive filename: secrets or credentials")
        if any(key in name for key in ["payroll", "salary", "employee", "iin", "iban", "card", "passport", "kyc", "finance", "invoice"]):
            return Indicator("filename_risk", file_path.name, "HIGH", "Sensitive filename: personal or financial data")
        return Indicator("filename_risk", file_path.name, "MEDIUM", "Potentially sensitive filename")

    def _compose_channel_text(self, text: str, channel: str, metadata: Optional[Dict[str, str]] = None) -> str:
        metadata = metadata or {}
        parts = [f"channel={channel}"]
        if metadata.get("filename"):
            parts.append(f"filename={metadata['filename']}")
        if metadata.get("suffix"):
            parts.append(f"extension={metadata['suffix']}")
        if metadata.get("source"):
            parts.append(f"source={metadata['source']}")
        prefix = " ".join(parts)
        return f"{prefix}\n{text.strip()}" if text.strip() else prefix

    def _extract_zip_entries(self, archive: zipfile.ZipFile, prefix: str = "", depth: int = 0, _budget: List[int] = None) -> List[str]:
        rows: List[str] = []
        if depth > 1:
            return rows
        if _budget is None:
            _budget = [ZIP_MAX_TOTAL_BYTES]  # mutable shared budget
        for name in archive.namelist()[:25]:
            if _budget[0] <= 0:
                rows.append("[ZIP_BUDGET_EXCEEDED] extraction stopped to prevent zip-bomb")
                break
            full_name = f"{prefix}{name}"
            inner = Path(name)
            suffix = inner.suffix.lower()
            info = archive.getinfo(name)
            if info.flag_bits & 0x1:
                rows.append(f"[ENCRYPTED_ZIP_ENTRY] {full_name}")
                continue
            # Guard against zip-bomb via uncompressed size
            if info.file_size > ZIP_MAX_ENTRY_BYTES:
                rows.append(f"[ZIP_ENTRY_TOO_LARGE] {full_name} ({info.file_size // 1024}KB)")
                continue
            try:
                raw = archive.read(name)
            except Exception:
                continue
            _budget[0] -= len(raw)
            if suffix in ZIP_TEXT_SUFFIXES or inner.name.lower() in {".env", ".gitconfig"}:
                content = raw.decode("utf-8", errors="ignore")
                if content.strip():
                    rows.append(f"[ZIP_ENTRY] {full_name}\n{content[:4000]}")
            elif suffix == ".zip":
                try:
                    nested = zipfile.ZipFile(BytesIO(raw), "r")
                    rows.extend(self._extract_zip_entries(nested, prefix=f"{full_name}/", depth=depth + 1, _budget=_budget))
                except Exception:
                    continue
        return rows

    def _ocr_image_text(self, file_path: Path) -> Tuple[str, List[str]]:
        try:
            from PIL import Image, ImageOps
            import pytesseract
        except ImportError:
            return "", ["Pillow/pytesseract not installed; OCR skipped."]
        warnings: List[str] = []
        img = Image.open(file_path)
        attempts = [img, ImageOps.grayscale(img), ImageOps.autocontrast(ImageOps.grayscale(img))]
        texts = []
        for item in attempts:
            try:
                texts.append(pytesseract.image_to_string(item, lang="eng+rus"))
            except Exception as exc:
                warnings.append(str(exc))
        best = max(texts, key=lambda v: len(v.strip()), default="")
        return best, warnings

    def _extract_svg_text(self, file_path: Path) -> Tuple[str, List[str]]:
        try:
            root = ET.fromstring(file_path.read_text(encoding="utf-8", errors="ignore"))
        except Exception as exc:
            return "", [f"SVG parsing skipped: {exc}"]
        texts = [elem.text.strip() for elem in root.iter() if elem.text and elem.text.strip()]
        return "\n".join(texts), []

    # ── Bulk-leak adjuster ─────────────────────────────────────────────────
    def _bulk_leak_adjustment(self, text: str, indicators: List[Indicator]) -> Optional[Tuple[str, float, str]]:
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        header_text = " ".join(lines[:2]).lower() if lines else ""
        indicator_counts: Dict[str, int] = {}
        for item in indicators:
            indicator_counts[item.kind] = indicator_counts.get(item.kind, 0) + 1

        tabular_markers = sum(1 for m in ["name","email","phone","iin","passport","card","account","iban","beneficiary","client"] if m in header_text)
        row_like = sum(1 for l in lines if l.count(",") >= 1 or l.count("|") >= 1 or l.count(";") >= 1)
        credential_headers = sum(1 for m in ["password","client_secret","access_token","refresh_token","api_key","secret_key","token"] if m in header_text)
        high_like = sum(indicator_counts.get(k, 0) for k in ["iin","passport","iban","bank_account","card","masked_card","ocr_card","ocr_iban"])
        critical_like = sum(indicator_counts.get(k, 0) for k in ["db_uri","openai","github","aws","aws_secret","sendgrid","google_api","slack_token","telegram_token","slack_webhook","discord_webhook","example_private_key","credential_assignment","bearer","jwt"])
        contact_like = sum(indicator_counts.get(k, 0) for k in ["email","phone_kz"])

        if credential_headers >= 2 and row_like >= 2:
            return "CRITICAL", 0.97, "Tabular credential dump detected — multiple credential columns in structured format."
        # Require ≥3 critical indicators, or ≥2 combined with structural evidence (multiple rows + header markers)
        if critical_like >= 3:
            return "CRITICAL", 0.97, "Large-scale API key or secret dump detected."
        if critical_like >= 2 and (row_like >= 3 or tabular_markers >= 2):
            return "CRITICAL", 0.95, "Multiple secrets in structured format detected."
        if high_like >= 4 and (row_like >= 3 or tabular_markers >= 2 or len(lines) >= 6):
            return "CRITICAL", 0.95, "Bulk customer PII export detected — structured format with multiple identity records."
        if high_like >= 3 and contact_like >= 2 and (tabular_markers >= 4 or row_like >= 2):
            return "CRITICAL", 0.94, "Structured banking or customer data export detected."
        if (high_like + contact_like) >= 8 and (row_like >= 3 or len(lines) >= 8):
            return "HIGH", 0.88, "Bulk personal or banking data export detected."
        return None

    # ── Consequence actions ────────────────────────────────────────────────
    def policy_actions(self, severity: str, channel: str) -> List[str]:
        matrix = CONSEQUENCE_MATRIX.get(severity, CONSEQUENCE_MATRIX["SAFE"])
        actions = list(matrix["server_actions"])
        if channel in {"device", "usb"} and severity in {"HIGH", "CRITICAL"}:
            actions.append("Disable USB device session")
        return actions

    def endpoint_actions(self, severity: str, channel: str) -> List[str]:
        matrix = CONSEQUENCE_MATRIX.get(severity, CONSEQUENCE_MATRIX["SAFE"])
        return list(matrix["endpoint_actions"])

    # ── File extraction ────────────────────────────────────────────────────
    def extract_text_from_file(self, file_path: Path):
        warnings = []
        suffix = file_path.suffix.lower()
        name = file_path.name.lower()
        try:
            text_suffixes = {
                ".txt", ".log", ".json", ".csv", ".env", ".md", ".yaml", ".yml",
                ".ini", ".conf", ".cfg", ".pem", ".key", ".crt", ".sql",
            } | SOURCE_CODE_SUFFIXES
            if suffix in text_suffixes or name in {".env", ".gitconfig"}:
                return file_path.read_text(encoding="utf-8", errors="ignore"), warnings
            if suffix == ".docx":
                try:
                    from docx import Document
                    doc = Document(str(file_path))
                    return "\n".join(p.text for p in doc.paragraphs), warnings
                except ImportError:
                    return "", ["python-docx not installed; DOCX parsing skipped."]
            if suffix == ".pdf":
                try:
                    from PyPDF2 import PdfReader
                    reader = PdfReader(str(file_path))
                    return "\n".join(page.extract_text() or "" for page in reader.pages), warnings
                except ImportError:
                    return "", ["PyPDF2 not installed; PDF parsing skipped."]
            if suffix == ".xlsx":
                try:
                    from openpyxl import load_workbook
                    wb = load_workbook(str(file_path), data_only=True)
                    rows = []
                    for ws in wb.worksheets:
                        for row in ws.iter_rows(values_only=True):
                            vals = [str(x) for x in row if x is not None]
                            if vals:
                                rows.append(" | ".join(vals))
                    return "\n".join(rows), warnings
                except ImportError:
                    return "", ["openpyxl not installed; XLSX parsing skipped."]
            if suffix in {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff"}:
                return self._ocr_image_text(file_path)
            if suffix == ".svg":
                return self._extract_svg_text(file_path)
            if suffix == ".zip":
                with zipfile.ZipFile(file_path, "r") as archive:
                    rows = self._extract_zip_entries(archive)
                if rows:
                    return "\n\n".join(rows), warnings
                return "", ["ZIP parsed but no supported text entries found."]
            if suffix in {".7z", ".rar"}:
                return "", [f"Encrypted or unsupported archive type {suffix} requires governed review."]
        except Exception as exc:
            warnings.append(str(exc))
        return "", warnings + [f"Unsupported file type: {suffix}"]

    # ── Main scan pipeline — AI-FIRST ─────────────────────────────────────
    def scan_text(self, text: str, channel: str = "text") -> ScanResult:
        """
        AI-first pipeline:
          1. BERT multi-stage → primary verdict (trusted when confidence ≥ 0.75)
          2. Regex entity extraction → evidence layer
          3. Bulk-leak adjuster → can escalate structured exports
          4. Harmless-noise filter → suppress clear false positives
          5. Final verdict + consequence matrix
        """
        # Normalize once — chunking operates on already-normalized text
        normalized = normalize_text(text)
        chunks = chunk_text(normalized)  # produces overlapping windows of normalized text
        aggregate_indicators: List[Indicator] = []
        best_label = "SAFE"
        best_score = 0.06
        best_summary = "No sensitive content detected."
        best_chunk_idx = 0
        trace: Dict[str, object] = {"chunks": len(chunks)}
        model_mode = "heuristic"

        for idx, chunk in enumerate(chunks):
            # ── Step 1: AI primary classification ─────────────────────────
            ai_label, ai_score = "SAFE", 0.0
            ai_confident = False
            pipeline_trace: Dict[str, object] = {}

            ml_result, ml_score, pipeline_trace = self.pipeline.predict(chunk)
            if ml_result != "SAFE" or ml_score > 0.5:
                ai_label, ai_score = ml_result, ml_score
                # Trust BERT when confidence is high
                ai_confident = ai_score >= 0.75
                model_mode = "multistage"

            if not ai_confident:
                # Fallback to single-model
                pred = self.model.predict(chunk)
                if pred:
                    single_label, single_score = pred
                    if single_score > ai_score:
                        ai_label, ai_score = single_label, single_score
                        ai_confident = ai_score >= 0.75
                        model_mode = "transformers"

            # ── Step 2: Regex entity extraction (evidence) ────────────────
            indicators = self._indicators(chunk)
            aggregate_indicators.extend(indicators)

            has_critical_regex = any(ind.severity == "CRITICAL" for ind in indicators)
            has_high_regex = any(ind.severity == "HIGH" for ind in indicators)
            secret_markers = self._has_secret_markers(chunk)
            harmless_noise = self._looks_like_harmless_noise(chunk)
            risk_context = has_risk_context(chunk)

            # ── Step 3: Decide final label ─────────────────────────────────
            # AI is primary when confident; regex can only escalate, not downgrade
            if ai_confident and not harmless_noise:
                final_label = ai_label
                final_score = ai_score
            elif has_critical_regex or secret_markers:
                # Explicit critical regex — trust regardless of ML
                final_label = "CRITICAL"
                final_score = 0.97
            elif has_high_regex:
                # AI + regex agreement
                final_label = "HIGH" if SEVERITY_RANK.get(ai_label, 0) < SEVERITY_RANK["HIGH"] else ai_label
                final_score = max(ai_score, 0.78)
            else:
                # Lower confidence: blend heuristic with AI
                indicator_sev = max((ind.severity for ind in indicators), key=lambda s: SEVERITY_RANK.get(s, 0), default="SAFE")
                if SEVERITY_RANK.get(ai_label, 0) >= SEVERITY_RANK.get(indicator_sev, 0):
                    final_label, final_score = ai_label, ai_score
                else:
                    final_label, final_score = indicator_sev, 0.7

            # ── Step 4: Harmless noise suppression ────────────────────────
            if harmless_noise and not has_critical_regex and not secret_markers:
                final_label = "SAFE"
                final_score = max(0.8, 1.0 - min(final_score, 0.95))

            # ── Step 5: Generate summary ──────────────────────────────────
            summary = self._build_summary(final_label, indicators, channel)

            # ── Step 6: Bulk-leak escalation ──────────────────────────────
            bulk_adj = self._bulk_leak_adjustment(chunk, indicators)
            if bulk_adj and SEVERITY_RANK[bulk_adj[0]] > SEVERITY_RANK[final_label]:
                final_label, final_score, summary = bulk_adj

            trace[f"chunk_{idx}"] = {
                "label": final_label,
                "score": round(final_score, 4),
                "preview": chunk[:220],
                "indicators": [ind.kind for ind in indicators[:8]],
                "ai_label": ai_label,
                "ai_score": round(ai_score, 4),
                "ai_confident": ai_confident,
                "model": model_mode,
            }

            if SEVERITY_RANK[final_label] > SEVERITY_RANK[best_label] or (final_label == best_label and final_score > best_score):
                best_label = final_label
                best_score = final_score
                best_summary = summary
                best_chunk_idx = idx

        # Deduplicate indicators
        deduped: List[Indicator] = []
        seen: set = set()
        for ind in aggregate_indicators:
            key = (ind.kind, ind.value, ind.severity)
            if key not in seen:
                seen.add(key)
                deduped.append(ind)

        threat_categories = self._detect_threat_categories(normalized, deduped, channel)
        model_info = {"mode": model_mode, "trace": trace, "best_chunk": best_chunk_idx}

        return ScanResult(
            severity=best_label,
            score=round(best_score, 4),
            summary=best_summary,
            indicators=deduped,
            actions=self.policy_actions(best_label, channel),
            model_info=model_info,
            extracted_text=normalized,
            channel=channel,
            threat_categories=threat_categories,
        )

    def _build_summary(self, severity: str, indicators: List[Indicator], channel: str) -> str:
        if severity == "SAFE":
            return "No sensitive content detected."
        kinds = {ind.kind for ind in indicators}
        parts = []
        if kinds & {"openai", "github", "aws", "aws_secret", "google_api", "slack_token", "example_private_key", "credential_assignment"}:
            parts.append("API keys / credentials")
        if kinds & {"iin", "iin_labeled", "kz_id_doc"}:
            parts.append("Kazakhstan IIN/identity data")
        if kinds & {"iban", "card", "masked_card", "card_cvv", "bank_account"}:
            parts.append("financial / banking data")
        if kinds & {"ai_tool_upload"}:
            parts.append("upload to AI service")
        if kinds & {"shadow_it"}:
            parts.append("unauthorized file sharing service")
        if kinds & {"source_code"}:
            parts.append("source code")
        if kinds & {"email", "phone_kz", "passport", "kz_passport"}:
            parts.append("personal contact / identity data")
        content_desc = ", ".join(parts) if parts else "sensitive content"
        consequence = CONSEQUENCE_MATRIX.get(severity, {}).get("description", "")
        return f"{severity}: {content_desc} detected via {channel}. {consequence}"

    def scan_file(self, file_path: Path) -> ScanResult:
        text, warnings = self.extract_text_from_file(file_path)
        contextual_text = self._compose_channel_text(
            text, channel="file",
            metadata={"filename": file_path.name, "suffix": file_path.suffix.lower(), "source": "attachment"},
        )
        result = self.scan_text(contextual_text, channel="file")

        # Source code files with secrets → escalate to CRITICAL
        if file_path.suffix.lower() in SOURCE_CODE_SUFFIXES:
            if self._has_secret_markers(text) and SEVERITY_RANK[result.severity] < SEVERITY_RANK["CRITICAL"]:
                result.severity = "CRITICAL"
                result.score = max(result.score, 0.95)
                result.summary = f"CRITICAL: Source code file '{file_path.name}' contains embedded secrets/credentials."
                result.actions = self.policy_actions("CRITICAL", "file")
                if "SOURCE_CODE_WITH_SECRETS" not in result.threat_categories:
                    result.threat_categories.append("SOURCE_CODE_WITH_SECRETS")

        filename_indicator = self._filename_indicator(file_path)
        if filename_indicator:
            result.indicators.insert(0, filename_indicator)
            if SEVERITY_RANK[filename_indicator.severity] > SEVERITY_RANK[result.severity]:
                result.severity = filename_indicator.severity
                result.score = max(result.score, 0.78 if filename_indicator.severity == "HIGH" else 0.86)
                result.summary = filename_indicator.reason
                result.actions = self.policy_actions(result.severity, "file")

        lower_name = file_path.name.lower()
        encrypted_archive = file_path.suffix.lower() in ARCHIVE_SUFFIXES and (
            "[ENCRYPTED_ZIP_ENTRY]" in result.extracted_text
            or any("unsupported archive type" in w.lower() or "governed review" in w.lower() for w in warnings)
            or any(key in lower_name for key in ["encrypted", "protected", "vault", "archive", "backup"])
        )
        if encrypted_archive and SEVERITY_RANK[result.severity] < SEVERITY_RANK["HIGH"]:
            result.indicators.insert(0, Indicator("encrypted_archive", file_path.name, "HIGH", "Encrypted archive requires review"))
            result.severity = "HIGH"
            result.score = max(result.score, 0.82)
            result.summary = "Encrypted or protected archive requires governed review."
            result.actions = self.policy_actions(result.severity, "file")

        if warnings:
            result.summary = (result.summary + " " + " ".join(warnings)).strip()
        return result


def serialize_result(result: ScanResult) -> Dict[str, object]:
    return {
        "severity": result.severity,
        "score": result.score,
        "summary": result.summary,
        "actions": result.actions,
        "channel": result.channel,
        "model_info": result.model_info,
        "extracted_text": result.extracted_text[:2000],
        "threat_categories": result.threat_categories,
        "indicators": [
            {"kind": x.kind, "value": x.value, "severity": x.severity, "reason": x.reason}
            for x in result.indicators[:50]
        ],
    }
