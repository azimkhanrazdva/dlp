$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$env:HOST = "127.0.0.1"
$env:PORT = "5000"
$env:FLASK_DEBUG = "1"
$env:SESSION_COOKIE_SECURE = "0"
$env:SECUREMAIL_DB_PATH = Join-Path $root "data\reports\securemail_hosted.db"
$env:DLP_MODEL_PATH = Join-Path $root "models\dlp_bert_joint_v3"
$env:DLP_AUX_MODEL_PATH = Join-Path $root "models\dlp_bert_joint_v3_boost_v1"
$env:SECUREMAIL_AGENT_ENROLLMENT_KEY = "example-enrollment-key"

$pythonExe = & (Join-Path $root "ensure_project_python.ps1")
& $pythonExe (Join-Path $root "run_app.py")
