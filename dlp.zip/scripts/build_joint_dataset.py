import argparse
import csv
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def load_csv(path: Path) -> List[dict]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    cleaned = []
    for row in rows:
        text = (row.get("text") or "").strip()
        label = (row.get("label") or "").strip().upper()
        if text and label in LABELS:
            row["label"] = label
            cleaned.append(row)
    return cleaned


def grouped(rows: List[dict]) -> Dict[str, List[dict]]:
    data = defaultdict(list)
    for row in rows:
        data[row["label"]].append(row)
    return data


def mix_split(synth_rows: List[dict], external_rows: List[dict], max_external_ratio: float, rng: random.Random) -> List[dict]:
    synth = grouped(synth_rows)
    ext = grouped(external_rows)
    mixed = []
    for label in LABELS:
        synth_items = list(synth.get(label, []))
        ext_items = list(ext.get(label, []))
        rng.shuffle(synth_items)
        rng.shuffle(ext_items)
        synth_count = len(synth_items)
        ext_take = min(len(ext_items), 1000 if synth_count == 0 else int((synth_count * max_external_ratio) / max(1e-6, 1.0 - max_external_ratio)))
        mixed.extend(synth_items)
        mixed.extend(ext_items[:ext_take])
    rng.shuffle(mixed)
    return mixed


def write_csv(path: Path, rows: List[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row.keys()}) if rows else ["text", "label", "source"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def summarize(rows: List[dict]) -> Dict[str, int]:
    counts = Counter(row["label"] for row in rows)
    return {label: counts.get(label, 0) for label in LABELS}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build joint dataset from synthetic and external PII sources.")
    parser.add_argument("--synth_dir", type=Path, default=Path("data/processed/synth_v3"))
    parser.add_argument("--external_dir", type=Path, default=Path("data/processed/external_pii"))
    parser.add_argument("--out_dir", type=Path, default=Path("data/processed/joint_v2"))
    parser.add_argument("--max_external_ratio", type=float, default=0.3)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    for split in ["train", "val", "test"]:
        synth_rows = load_csv(args.synth_dir / f"{split}.csv")
        ext_rows = load_csv(args.external_dir / f"{split}.csv")
        mixed = mix_split(synth_rows, ext_rows, args.max_external_ratio, rng)
        write_csv(args.out_dir / f"{split}.csv", mixed)
        print(f"{split}: synth={summarize(synth_rows)} external={summarize(ext_rows)} mixed={summarize(mixed)}")


if __name__ == "__main__":
    main()
