import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.dlp_engine import DLPScanner  # noqa: E402
from scripts.noise_test import build_samples  # noqa: E402


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Measure noise false positive rate with consensus DLP scanner.")
    parser.add_argument("--model_path", required=True, type=str)
    parser.add_argument("--aux_model_path", required=True, type=str)
    parser.add_argument("--count", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/noise_consensus"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scanner = DLPScanner(model_path=args.model_path, aux_model_path=args.aux_model_path)
    samples = build_samples(args.count, args.seed)
    counts = {label: 0 for label in LABELS}
    false_positive = 0
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "noise_predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["pred_label", "score", "text"])
        writer.writeheader()
        for text in samples:
            result = scanner.scan_text(text)
            counts[result.severity] += 1
            if result.severity != "SAFE":
                false_positive += 1
            writer.writerow({"pred_label": result.severity, "score": result.score, "text": text})
    summary = {"count": args.count, "false_positive": false_positive, "noise_fp_rate": false_positive / max(1, args.count), "pred_distribution": counts}
    with (args.out_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    print(json.dumps(summary, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
