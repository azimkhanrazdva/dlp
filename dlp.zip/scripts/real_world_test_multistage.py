import argparse
import csv
import json
import random
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List

from docx import Document

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.dlp_engine import DLPScanner


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
BANKS = ["Kaspi", "Halyk", "Forte", "Jusan", "CenterCredit", "Freedom"]
NAMES = ["Aruzhan Saparova", "Dias Akhmetov", "Madina Tulegenova", "Yerlan Omarov", "Kamila Iskakova", "Aidos Nurgaliyev", "Dana Suleimenova", "Bekzat Ryskulov"]


def digits(rng: random.Random, n: int) -> str:
    return "".join(rng.choices("0123456789", k=n))


def email(rng: random.Random) -> str:
    return f"user{rng.randint(1,999)}@example.com"


def phone_kz(rng: random.Random) -> str:
    d = "7" + digits(rng, 9)
    return rng.choice([f"+7{d}", f"+7 {d[:3]} {d[3:6]} {d[6:8]} {d[8:]}", f"8{d}"])


def iin(rng: random.Random) -> str:
    return digits(rng, 12)


def secret(rng: random.Random, prefix: str, size: int = 42) -> str:
    return prefix + "".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=size))


def jwt(rng: random.Random) -> str:
    return ".".join("".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=n)) for n in [24, 72, 32])


def maybe_obfuscate(text: str, rng: random.Random) -> str:
    if rng.random() < 0.3:
        text = text.replace("@", " [at] ").replace(".", " [dot] ")
    if rng.random() < 0.2:
        text = text.replace("Bearer ", "Bearer\t")
    return text


def sample(label: str, rng: random.Random) -> Dict[str, str]:
    if label == "SAFE":
        text = f"Hello team, sharing harmless update on deployment and monitoring. Trace id {digits(rng,8)}."
        stype = "safe"
    elif label == "LOW":
        text = f"Please contact {email(rng)} for the next meeting."
        stype = "low_contact"
    elif label == "MEDIUM":
        text = f"Customer callback: {rng.choice(NAMES)}, {email(rng)}, {phone_kz(rng)}."
        stype = "medium_bundle"
    elif label == "HIGH":
        text = f"{rng.choice(BANKS)} case: {rng.choice(NAMES)}, IIN {iin(rng)}, phone {phone_kz(rng)}."
        stype = "high_sensitive"
    else:
        text = rng.choice([
            f"OpenAI key leaked: {secret(rng, 'sk-proj-')}",
            f"GitHub token exposed: {secret(rng, 'ghp_')}",
            f"Authorization: Bearer {jwt(rng)}",
            f"DATABASE_URL=postgresql://admin:{secret(rng, '')}@prod-db.company.kz:5432/prod",
        ])
        stype = "critical_secret"
    if rng.random() < 0.35:
        text += f" trace={secret(rng, '', 24)}"
    text = maybe_obfuscate(text, rng)
    lang = rng.choice(["ru", "en", "mixed"])
    if lang == "ru":
        text = "Служебное сообщение. " + text
    elif lang == "mixed":
        text = "Internal note. " + text + " Проверить срочно."
    return {"text": text, "expected_label": label, "sample_type": stype, "language": lang}


def generate(count: int, seed: int) -> List[Dict[str, str]]:
    rng = random.Random(seed)
    rows = []
    per = count // len(LABELS)
    rem = count % len(LABELS)
    for idx, label in enumerate(LABELS):
        for _ in range(per + (1 if idx < rem else 0)):
            rows.append(sample(label, rng))
    rng.shuffle(rows)
    return rows


def write_docx(path: Path, summary: Dict[str, object], examples: List[Dict[str, str]]) -> None:
    doc = Document()
    doc.add_heading("Real World Multi-Stage DLP Test Report", level=1)
    for key in ["count", "accuracy", "macro_f1", "weighted_f1"]:
        doc.add_paragraph(f"{key}: {summary[key]}")
    doc.add_paragraph(f"expected_distribution: {summary['expected_distribution']}")
    doc.add_paragraph(f"pred_distribution: {summary['pred_distribution']}")
    doc.add_heading("Examples", level=2)
    for item in examples:
        doc.add_paragraph(f"Expected={item['expected_label']} Predicted={item['pred_label']} Score={item['score']}\n{item['text']}")
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run 10k+ real-world test for multi-stage pipeline.")
    parser.add_argument("--count", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/real_world_multistage"))
    parser.add_argument("--single_model", type=str, default=None)
    parser.add_argument("--stage1_model", type=str, required=True)
    parser.add_argument("--stage2_model", type=str, required=True)
    parser.add_argument("--stage3_model", type=str, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = generate(args.count, args.seed)
    scanner = DLPScanner(
        model_path=args.single_model,
        stage1_path=args.stage1_model,
        stage2_path=args.stage2_model,
        stage3_path=args.stage3_model,
    )
    out_rows = []
    expected = Counter()
    predicted = Counter()
    for row in rows:
        result = scanner.scan_text(row["text"])
        expected[row["expected_label"]] += 1
        predicted[result.severity] += 1
        out_rows.append({**row, "pred_label": result.severity, "score": result.score})

    y_true = [LABELS.index(x["expected_label"]) for x in out_rows]
    y_pred = [LABELS.index(x["pred_label"]) for x in out_rows]

    from sklearn.metrics import f1_score

    summary = {
        "count": len(out_rows),
        "accuracy": sum(1 for x in out_rows if x["expected_label"] == x["pred_label"]) / max(1, len(out_rows)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "expected_distribution": dict(expected),
        "pred_distribution": dict(predicted),
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["expected_label", "pred_label", "score", "sample_type", "language", "text"])
        writer.writeheader()
        writer.writerows(out_rows)
    with (args.out_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    examples = [x for x in out_rows if x["expected_label"] != x["pred_label"]][:20] or out_rows[:20]
    write_docx(args.out_dir / "real_world_report.docx", summary, examples)
    print(json.dumps(summary, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
