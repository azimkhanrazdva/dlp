from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def main() -> None:
    labels = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    values = [95.25, 97.56, 93.28, 96.82, 99.95]

    bg = "#0b1220"
    panel = "#101a2f"
    grid = "#25324a"
    text = "#e5eefc"
    muted = "#93a4bf"
    colors = ["#5B8FF9", "#61DDAA", "#F6BD16", "#78D3F8", "#36CFC9"]
    width, height = 1800, 1050
    image = Image.new("RGB", (width, height), bg)
    draw = ImageDraw.Draw(image)

    try:
        title_font = ImageFont.truetype("arialbd.ttf", 56)
        subtitle_font = ImageFont.truetype("arial.ttf", 24)
        label_font = ImageFont.truetype("arialbd.ttf", 28)
        value_font = ImageFont.truetype("arialbd.ttf", 24)
        note_font = ImageFont.truetype("arial.ttf", 22)
        badge_font = ImageFont.truetype("arialbd.ttf", 18)
    except OSError:
        title_font = ImageFont.load_default()
        subtitle_font = ImageFont.load_default()
        label_font = ImageFont.load_default()
        value_font = ImageFont.load_default()
        note_font = ImageFont.load_default()
        badge_font = ImageFont.load_default()

    panel_box = (90, 110, 1710, 930)
    draw.rounded_rectangle(panel_box, radius=26, fill=panel)

    draw.text((130, 140), "Per-Class F1-Score", fill=text, font=title_font)
    draw.text(
        (132, 215),
        "Preliminary Research Results for the SecureMail AI-DLP model",
        fill=muted,
        font=subtitle_font,
    )

    chart_left = 310
    chart_right = 1520
    chart_top = 315
    row_gap = 110
    bar_height = 52
    max_bar_width = chart_right - chart_left

    for tick in range(0, 101, 20):
        x = chart_left + int(max_bar_width * tick / 100)
        draw.line((x, chart_top - 35, x, chart_top + row_gap * (len(labels) - 1) + 45), fill=grid, width=2)
        tick_text = f"{tick}%"
        bbox = draw.textbbox((0, 0), tick_text, font=note_font)
        draw.text((x - (bbox[2] - bbox[0]) / 2, chart_top - 75), tick_text, fill=muted, font=note_font)

    for idx, (label, value, color) in enumerate(zip(labels, values, colors)):
        y = chart_top + idx * row_gap
        draw.text((130, y - 2), label, fill=text, font=label_font)

        bar_width = int(max_bar_width * value / 100)
        draw.rounded_rectangle((chart_left, y, chart_left + bar_width, y + bar_height), radius=20, fill=color)
        draw.text((chart_left + bar_width + 22, y + 8), f"{value:.2f}%", fill=text, font=value_font)

        if label == "MEDIUM":
            badge_text = "hardest class"
            badge_fill = "#ffe08a"
            badge_text_fill = bg
        elif label == "CRITICAL":
            badge_text = "best detected"
            badge_fill = "#9ef0ea"
            badge_text_fill = bg
        else:
            badge_text = ""

        if badge_text:
            bbox = draw.textbbox((0, 0), badge_text, font=badge_font)
            badge_width = bbox[2] - bbox[0] + 24
            badge_height = bbox[3] - bbox[1] + 14
            badge_x = chart_left + max(20, bar_width - badge_width - 14)
            badge_y = y + 8
            draw.rounded_rectangle(
                (badge_x, badge_y, badge_x + badge_width, badge_y + badge_height),
                radius=15,
                fill=badge_fill,
            )
            draw.text((badge_x + 12, badge_y + 7), badge_text, fill=badge_text_fill, font=badge_font)

    footer = (
        "The model shows near-perfect performance on CRITICAL leak cases "
        "while MEDIUM remains the most ambiguous class."
    )
    draw.text((130, 865), footer, fill=muted, font=note_font)

    output_dir = Path("presentation_package_max/assets")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "preliminary_results_bar_chart.png"
    image.save(output_path)
    print(output_path)


if __name__ == "__main__":
    main()
