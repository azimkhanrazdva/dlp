import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "presentation_package_max"
ASSETS = OUT / "assets"


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def svg_wrap(width: int, height: int, body: str, bg: str = "#0b1220") -> str:
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<rect width="100%" height="100%" fill="{bg}"/>
{body}
</svg>
"""


def build_dataset_svg() -> str:
    body = """
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">Dataset Construction</text>
<rect x="60" y="110" width="220" height="95" rx="18" fill="#12324a" stroke="#5eead4" stroke-width="2"/>
<text x="92" y="145" font-size="22" fill="#f8fafc" font-family="Arial" font-weight="700">Synthetic Data</text>
<text x="82" y="175" font-size="18" fill="#cbd5e1" font-family="Arial">bank leaks, OCR, archives,</text>
<text x="96" y="198" font-size="18" fill="#cbd5e1" font-family="Arial">USB, hard negatives</text>

<rect x="360" y="110" width="220" height="95" rx="18" fill="#14344f" stroke="#60a5fa" stroke-width="2"/>
<text x="396" y="145" font-size="22" fill="#f8fafc" font-family="Arial" font-weight="700">Public Data</text>
<text x="376" y="175" font-size="18" fill="#cbd5e1" font-family="Arial">ai4privacy / Isotonic</text>
<text x="404" y="198" font-size="18" fill="#cbd5e1" font-family="Arial">privacy corpora</text>

<rect x="660" y="95" width="310" height="125" rx="20" fill="#1e293b" stroke="#f59e0b" stroke-width="2"/>
<text x="735" y="140" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Joint Dataset v3</text>
<text x="735" y="173" font-size="20" fill="#f8fafc" font-family="Arial">45,764 labeled samples</text>
<text x="716" y="201" font-size="17" fill="#cbd5e1" font-family="Arial">Train 33,017 | Val 6,358 | Test 6,389</text>

<line x1="280" y1="157" x2="360" y2="157" stroke="#64748b" stroke-width="4"/>
<polygon points="352,149 373,157 352,165" fill="#64748b"/>
<line x1="580" y1="157" x2="660" y2="157" stroke="#64748b" stroke-width="4"/>
<polygon points="652,149 673,157 652,165" fill="#64748b"/>

<rect x="80" y="280" width="860" height="180" rx="22" fill="#111827" stroke="#334155" stroke-width="2"/>
<text x="110" y="325" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Severity Classes</text>
<rect x="110" y="355" width="120" height="54" rx="14" fill="#22c55e"/><text x="147" y="388" font-size="22" fill="#052e16" font-family="Arial" font-weight="700">SAFE</text>
<rect x="250" y="355" width="120" height="54" rx="14" fill="#84cc16"/><text x="292" y="388" font-size="22" fill="#1a2e05" font-family="Arial" font-weight="700">LOW</text>
<rect x="390" y="355" width="140" height="54" rx="14" fill="#facc15"/><text x="417" y="388" font-size="22" fill="#422006" font-family="Arial" font-weight="700">MEDIUM</text>
<rect x="550" y="355" width="120" height="54" rx="14" fill="#fb923c"/><text x="585" y="388" font-size="22" fill="#431407" font-family="Arial" font-weight="700">HIGH</text>
<rect x="690" y="355" width="160" height="54" rx="14" fill="#ef4444"/><text x="718" y="388" font-size="22" fill="#450a0a" font-family="Arial" font-weight="700">CRITICAL</text>
"""
    return svg_wrap(1024, 512, body)


def build_methods_svg() -> str:
    body = """
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">Research Methodology</text>
<rect x="70" y="110" width="250" height="100" rx="18" fill="#102a43" stroke="#38bdf8" stroke-width="2"/>
<text x="114" y="150" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Analytical</text>
<text x="104" y="180" font-size="18" fill="#cbd5e1" font-family="Arial">literature + market review</text>

<rect x="385" y="110" width="250" height="100" rx="18" fill="#132f4c" stroke="#5eead4" stroke-width="2"/>
<text x="446" y="150" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Engineering</text>
<text x="432" y="180" font-size="18" fill="#cbd5e1" font-family="Arial">architecture + implementation</text>

<rect x="700" y="110" width="250" height="100" rx="18" fill="#172554" stroke="#818cf8" stroke-width="2"/>
<text x="746" y="150" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Experimental</text>
<text x="730" y="180" font-size="18" fill="#cbd5e1" font-family="Arial">training + benchmark testing</text>

<rect x="160" y="290" width="700" height="120" rx="24" fill="#111827" stroke="#475569" stroke-width="2"/>
<text x="298" y="335" font-size="26" fill="#f8fafc" font-family="Arial" font-weight="700">Hybrid AI-DLP Pipeline</text>
<text x="212" y="372" font-size="20" fill="#cbd5e1" font-family="Arial">mBERT classifier + specialist model + deterministic rules + channel-aware runtime</text>

<line x1="195" y1="210" x2="510" y2="290" stroke="#64748b" stroke-width="3"/>
<line x1="510" y1="210" x2="510" y2="290" stroke="#64748b" stroke-width="3"/>
<line x1="825" y1="210" x2="510" y2="290" stroke="#64748b" stroke-width="3"/>
"""
    return svg_wrap(1024, 512, body)


def build_results_svg(eval_metrics: dict) -> str:
    report = eval_metrics["classification_report"]
    labels = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    values = [report[label]["f1-score"] * 100 for label in labels]
    colors = ["#22c55e", "#84cc16", "#facc15", "#fb923c", "#ef4444"]
    x_positions = [120, 290, 460, 630, 800]
    bars = []
    for x, label, value, color in zip(x_positions, labels, values, colors):
        height = int((value - 85) * 18)
        top = 410 - height
        bars.append(f'<rect x="{x}" y="{top}" width="90" height="{height}" rx="10" fill="{color}" opacity="0.95"/>')
        bars.append(f'<text x="{x+45}" y="{top-12}" text-anchor="middle" font-size="19" fill="#f8fafc" font-family="Arial" font-weight="700">{value:.2f}%</text>')
        bars.append(f'<text x="{x+45}" y="440" text-anchor="middle" font-size="18" fill="#cbd5e1" font-family="Arial">{label}</text>')
    grid = []
    for val in [85, 90, 95, 100]:
        y = 410 - int((val - 85) * 18)
        grid.append(f'<line x1="80" y1="{y}" x2="930" y2="{y}" stroke="#334155" stroke-width="1"/>')
        grid.append(f'<text x="48" y="{y+5}" font-size="16" fill="#94a3b8" font-family="Arial">{val}</text>')
    body = f"""
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">Per-Class F1-score</text>
<text x="50" y="88" font-size="18" fill="#cbd5e1" font-family="Arial">Core model: Accuracy 96.37% | Macro F1 96.57% | Weighted F1 96.35%</text>
{''.join(grid)}
{''.join(bars)}
"""
    return svg_wrap(1024, 512, body)


def build_confusion_svg(matrix: list[list[int]]) -> str:
    labels = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    max_v = max(max(r) for r in matrix)
    cells = []
    start_x = 240
    start_y = 120
    size = 90
    for i, row in enumerate(matrix):
        for j, value in enumerate(row):
            intensity = int(235 - (value / max_v) * 150)
            fill = f"rgb({intensity},{intensity+5},{255})"
            x = start_x + j * size
            y = start_y + i * size
            txt_color = "#0f172a" if value < max_v * 0.55 else "#ffffff"
            cells.append(f'<rect x="{x}" y="{y}" width="{size}" height="{size}" fill="{fill}" stroke="#1e293b" stroke-width="1.5"/>')
            cells.append(f'<text x="{x+45}" y="{y+52}" text-anchor="middle" font-size="20" fill="{txt_color}" font-family="Arial" font-weight="700">{value}</text>')
    xlabels = []
    ylabels = []
    for idx, label in enumerate(labels):
        x = start_x + idx * size + size / 2
        y = start_y + idx * size + size / 2
        xlabels.append(f'<text x="{x}" y="95" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">{label}</text>')
        ylabels.append(f'<text x="205" y="{y+6}" text-anchor="end" font-size="17" fill="#cbd5e1" font-family="Arial">{label}</text>')
    body = f"""
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">Confusion Matrix</text>
<text x="50" y="88" font-size="18" fill="#cbd5e1" font-family="Arial">Strong diagonal pattern; MEDIUM is the most ambiguous class</text>
<text x="625" y="470" text-anchor="middle" font-size="20" fill="#cbd5e1" font-family="Arial">Predicted label</text>
<text x="72" y="320" transform="rotate(-90 72 320)" text-anchor="middle" font-size="20" fill="#cbd5e1" font-family="Arial">True label</text>
{''.join(cells)}
{''.join(xlabels)}
{''.join(ylabels)}
"""
    return svg_wrap(1024, 540, body)


def build_comparison_svg() -> str:
    categories = ["Synthetic\nbenchmark", "External\nreal data", "Joint\nbenchmark"]
    synth = [100.0, 15.85, 84.48]
    real = [30.08, 85.50, 41.03]
    joint = [96.57, 94.36, 96.57]
    x_positions = [180, 460, 740]
    bars = []
    for x, cat, s, r, j in zip(x_positions, categories, synth, real, joint):
        for offset, val, color in [(-65, s, "#60a5fa"), (0, r, "#34d399"), (65, j, "#f59e0b")]:
            h = int(val * 3)
            y = 430 - h
            bars.append(f'<rect x="{x+offset}" y="{y}" width="48" height="{h}" rx="8" fill="{color}"/>')
            bars.append(f'<text x="{x+offset+24}" y="{y-10}" text-anchor="middle" font-size="15" fill="#f8fafc" font-family="Arial">{val:.1f}</text>')
        bars.append(f'<text x="{x}" y="470" text-anchor="middle" font-size="18" fill="#cbd5e1" font-family="Arial">{cat}</text>')
    legend = """
<rect x="690" y="72" width="18" height="18" fill="#60a5fa"/><text x="718" y="87" font-size="16" fill="#cbd5e1" font-family="Arial">Synthetic-only</text>
<rect x="830" y="72" width="18" height="18" fill="#34d399"/><text x="858" y="87" font-size="16" fill="#cbd5e1" font-family="Arial">Real-only</text>
<rect x="690" y="102" width="18" height="18" fill="#f59e0b"/><text x="718" y="117" font-size="16" fill="#cbd5e1" font-family="Arial">Joint / deployed</text>
"""
    grid = []
    for val in [0, 20, 40, 60, 80, 100]:
        y = 430 - int(val * 3)
        grid.append(f'<line x1="120" y1="{y}" x2="920" y2="{y}" stroke="#334155" stroke-width="1"/>')
        grid.append(f'<text x="85" y="{y+5}" font-size="15" fill="#94a3b8" font-family="Arial">{val}</text>')
    body = f"""
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">Why Joint Training Was Chosen</text>
<text x="50" y="88" font-size="18" fill="#cbd5e1" font-family="Arial">Synthetic-only overfits, real-only undercovers enterprise leak patterns, joint training generalizes best</text>
{legend}
{''.join(grid)}
{''.join(bars)}
"""
    return svg_wrap(1024, 512, body)


def build_architecture_svg() -> str:
    body = """
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">System Architecture</text>

<rect x="50" y="145" width="180" height="90" rx="18" fill="#12324a" stroke="#5eead4" stroke-width="2"/>
<text x="140" y="182" text-anchor="middle" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Inputs</text>
<text x="140" y="210" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">email, text, files,</text>
<text x="140" y="232" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">images, USB, clipboard</text>

<rect x="290" y="145" width="190" height="90" rx="18" fill="#1e293b" stroke="#60a5fa" stroke-width="2"/>
<text x="385" y="182" text-anchor="middle" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Extraction</text>
<text x="385" y="210" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">OCR, parsing, archive</text>
<text x="385" y="232" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">and text normalization</text>

<rect x="540" y="130" width="230" height="120" rx="18" fill="#172554" stroke="#818cf8" stroke-width="2"/>
<text x="655" y="168" text-anchor="middle" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">AI Core</text>
<text x="655" y="198" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">mBERT + specialist model</text>
<text x="655" y="220" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">+ deterministic DLP rules</text>

<rect x="830" y="145" width="145" height="90" rx="18" fill="#3f1d2e" stroke="#f472b6" stroke-width="2"/>
<text x="902" y="182" text-anchor="middle" font-size="22" fill="#f8fafc" font-family="Arial" font-weight="700">Policy</text>
<text x="902" y="210" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">allow / review /</text>
<text x="902" y="232" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">block / incident</text>

<rect x="230" y="330" width="220" height="105" rx="18" fill="#101826" stroke="#38bdf8" stroke-width="2"/>
<text x="340" y="370" text-anchor="middle" font-size="23" fill="#f8fafc" font-family="Arial" font-weight="700">Web Platform</text>
<text x="340" y="398" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">mailbox, admin panel,</text>
<text x="340" y="420" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">incidents, governance</text>

<rect x="575" y="330" width="220" height="105" rx="18" fill="#141b2d" stroke="#22c55e" stroke-width="2"/>
<text x="685" y="370" text-anchor="middle" font-size="23" fill="#f8fafc" font-family="Arial" font-weight="700">Endpoint App</text>
<text x="685" y="398" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">Windows app + agent,</text>
<text x="685" y="420" text-anchor="middle" font-size="17" fill="#cbd5e1" font-family="Arial">device and clipboard control</text>

<line x1="230" y1="190" x2="290" y2="190" stroke="#64748b" stroke-width="4"/><polygon points="282,182 302,190 282,198" fill="#64748b"/>
<line x1="480" y1="190" x2="540" y2="190" stroke="#64748b" stroke-width="4"/><polygon points="532,182 552,190 532,198" fill="#64748b"/>
<line x1="770" y1="190" x2="830" y2="190" stroke="#64748b" stroke-width="4"/><polygon points="822,182 842,190 822,198" fill="#64748b"/>
<line x1="655" y1="250" x2="655" y2="330" stroke="#64748b" stroke-width="4"/><polygon points="647,322 655,342 663,322" fill="#64748b"/>
"""
    return svg_wrap(1024, 540, body)


def build_prototype_svg() -> str:
    body = """
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">Prototype Scope</text>

<rect x="70" y="120" width="280" height="145" rx="20" fill="#111827" stroke="#334155" stroke-width="2"/>
<text x="105" y="158" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">User Side</text>
<text x="100" y="192" font-size="19" fill="#cbd5e1" font-family="Arial">• mailbox UI</text>
<text x="100" y="220" font-size="19" fill="#cbd5e1" font-family="Arial">• profile / registration</text>
<text x="100" y="248" font-size="19" fill="#cbd5e1" font-family="Arial">• controlled message flow</text>

<rect x="385" y="120" width="280" height="145" rx="20" fill="#111827" stroke="#334155" stroke-width="2"/>
<text x="420" y="158" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Admin Side</text>
<text x="415" y="192" font-size="19" fill="#cbd5e1" font-family="Arial">• incidents and accounts</text>
<text x="415" y="220" font-size="19" fill="#cbd5e1" font-family="Arial">• agent and device monitoring</text>
<text x="415" y="248" font-size="19" fill="#cbd5e1" font-family="Arial">• privacy-preserving review</text>

<rect x="700" y="120" width="250" height="145" rx="20" fill="#111827" stroke="#334155" stroke-width="2"/>
<text x="734" y="158" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Endpoint</text>
<text x="730" y="192" font-size="19" fill="#cbd5e1" font-family="Arial">• Windows control center</text>
<text x="730" y="220" font-size="19" fill="#cbd5e1" font-family="Arial">• background agent</text>
<text x="730" y="248" font-size="19" fill="#cbd5e1" font-family="Arial">• USB / clipboard / files</text>

<rect x="150" y="330" width="720" height="115" rx="22" fill="#0f172a" stroke="#5eead4" stroke-width="2"/>
<text x="510" y="370" text-anchor="middle" font-size="24" fill="#f8fafc" font-family="Arial" font-weight="700">Implemented DLP Channels</text>
<text x="510" y="405" text-anchor="middle" font-size="19" fill="#cbd5e1" font-family="Arial">text • files • images/OCR • archives • endpoint events • USB inventory • clipboard</text>
"""
    return svg_wrap(1024, 512, body)


def build_privacy_svg() -> str:
    body = """
<text x="50" y="55" font-size="28" fill="#f8fafc" font-family="Arial" font-weight="700">Privacy and Access Governance</text>
<rect x="80" y="140" width="200" height="90" rx="18" fill="#22c55e" opacity="0.95"/>
<text x="180" y="177" text-anchor="middle" font-size="24" fill="#052e16" font-family="Arial" font-weight="700">SAFE / LOW</text>
<text x="180" y="208" text-anchor="middle" font-size="18" fill="#052e16" font-family="Arial">not visible to admin</text>

<rect x="405" y="128" width="220" height="115" rx="18" fill="#facc15" opacity="0.95"/>
<text x="515" y="168" text-anchor="middle" font-size="24" fill="#422006" font-family="Arial" font-weight="700">MEDIUM</text>
<text x="515" y="198" text-anchor="middle" font-size="17" fill="#422006" font-family="Arial">admin requests access</text>
<text x="515" y="220" text-anchor="middle" font-size="17" fill="#422006" font-family="Arial">sender + recipient approval</text>

<rect x="750" y="140" width="200" height="90" rx="18" fill="#ef4444" opacity="0.95"/>
<text x="850" y="177" text-anchor="middle" font-size="24" fill="#450a0a" font-family="Arial" font-weight="700">HIGH / CRITICAL</text>
<text x="850" y="208" text-anchor="middle" font-size="18" fill="#450a0a" font-family="Arial">incident-response access</text>

<line x1="280" y1="185" x2="405" y2="185" stroke="#64748b" stroke-width="4"/><polygon points="397,177 417,185 397,193" fill="#64748b"/>
<line x1="625" y1="185" x2="750" y2="185" stroke="#64748b" stroke-width="4"/><polygon points="742,177 762,185 742,193" fill="#64748b"/>

<rect x="160" y="320" width="700" height="100" rx="20" fill="#111827" stroke="#334155" stroke-width="2"/>
<text x="510" y="358" text-anchor="middle" font-size="22" fill="#f8fafc" font-family="Arial" font-weight="700">Privacy-by-default principle</text>
<text x="510" y="390" text-anchor="middle" font-size="18" fill="#cbd5e1" font-family="Arial">ordinary correspondence is protected; full content is retained only in critical investigations</text>
"""
    return svg_wrap(1024, 512, body)


def build_assets(eval_metrics: dict) -> None:
    write(ASSETS / "dataset_construction.svg", build_dataset_svg())
    write(ASSETS / "research_methods.svg", build_methods_svg())
    write(ASSETS / "results_f1.svg", build_results_svg(eval_metrics))
    write(ASSETS / "confusion_matrix.svg", build_confusion_svg(eval_metrics["confusion_matrix"]))
    write(ASSETS / "training_comparison.svg", build_comparison_svg())
    write(ASSETS / "system_architecture.svg", build_architecture_svg())
    write(ASSETS / "prototype_scope.svg", build_prototype_svg())
    write(ASSETS / "privacy_governance.svg", build_privacy_svg())


def build_slide_texts() -> str:
    return """# SecureMail AI-DLP Presentation Structure

## Slide 1. Title
Title:
Development of AI-Based Model for Detecting Confidential Data Leakage in Electronic Communications as a Cybersecurity Measure

On-slide text:
- Student: [Your Full Name]
- Group: [Your Group]
- Supervisor: [Supervisor Name]
- Astana IT University

Visual:
- Minimal title slide with project name and logo

## Slide 2. Outline
On-slide text:
1. Problem Statement
2. Research Methods
3. Data and Experimental Design
4. Preliminary Research Results
5. Comparative Analysis
6. Research Tool
7. Project Prototype
8. Architecture
9. Privacy and Governance
10. Conclusion

Visual:
- Clean numbered outline

## Slide 3. Problem Statement
On-slide text:
- Confidential data leakage remains a critical cybersecurity problem in enterprise communications
- Sensitive data can be leaked through emails, files, screenshots, archives, USB devices, and endpoint actions
- Traditional DLP systems rely heavily on static rules and often produce excessive false positives
- Project goal: develop an AI-based DLP model and applied prototype for risk-aware leakage detection

Visual:
- Optional small examples of leak channels

## Slide 4. Research Methods
On-slide text:
- Analytical method: literature review and DLP market analysis
- Engineering method: architecture, data pipeline, web platform, endpoint integration
- Experimental method: model training, validation, runtime benchmarking
- Hybrid approach: multilingual BERT + specialist model + deterministic rules

Visual:
- assets/research_methods.svg

## Slide 5. Data and Experimental Design
On-slide text:
- Main dataset: joint_v3
- Total size: 45,764 labeled samples
- Split: 33,017 train / 6,358 validation / 6,389 test
- Sources: synthetic enterprise scenarios + ai4privacy + Isotonic
- Classes: SAFE, LOW, MEDIUM, HIGH, CRITICAL

Visual:
- assets/dataset_construction.svg

## Slide 6. Core Model and Pipeline
On-slide text:
- Base model: bert-base-multilingual-cased
- Fine-tuned for five severity classes
- Python, PyTorch, Hugging Face Transformers, scikit-learn
- OCR, file extraction, archive parsing, endpoint-aware logic
- Runtime mode: consensus DLP scanner

Visual:
- simplified pipeline icon strip or architecture thumbnail

## Slide 7. Preliminary Research Results
On-slide text:
- Test accuracy: 96.37%
- Macro F1-score: 96.57%
- Weighted F1-score: 96.35%
- Strongest class: CRITICAL
- Hardest class: MEDIUM

Visual:
- assets/results_f1.svg

## Slide 8. Misclassification Dynamics
On-slide text:
- The model shows strong diagonal clustering in the confusion matrix
- Most errors occur between adjacent severity levels
- MEDIUM is the most ambiguous class because it overlaps with both low-risk contacts and high-risk personal data
- CRITICAL is detected almost perfectly

Visual:
- assets/confusion_matrix.svg

## Slide 9. Runtime Evaluation
On-slide text:
- Mixed benchmark accuracy: 94.42%
- Runtime macro F1-score: 94.36%
- Noise false-positive rate: 1.08%
- Specialist benchmark accuracy: 100%
- Strong evidence for banking exports, OCR cases, and secret leakage detection

Visual:
- small metrics card layout

## Slide 10. Comparative Analysis
On-slide text:
- Synthetic-only training overfits artificial patterns
- Real-only training undercovers enterprise leak scenarios
- Joint training generalizes better across both synthetic and real data
- Therefore, the hybrid dataset strategy is experimentally justified

Visual:
- assets/training_comparison.svg

## Slide 11. Research Tool
On-slide text:
- Research tool: SecureMail AI-DLP platform
- Components:
  - AI classifier
  - specialist leak detector
  - web administration system
  - Windows endpoint app and agent
  - privacy-preserving access workflow

Visual:
- assets/system_architecture.svg

## Slide 12. Project Prototype
On-slide text:
- Mailbox UI and message review
- Admin panel with incidents and account governance
- Attachment, image, and archive analysis
- Windows endpoint monitoring for clipboard, files, and USB inventory
- Role-based access and unlock/request workflows

Visual:
- assets/prototype_scope.svg
- plus your real screenshots if available

## Slide 13. Privacy and Governance
On-slide text:
- Privacy-by-default model
- SAFE/LOW correspondence is not openly visible to administrators
- MEDIUM cases require controlled approval workflow
- HIGH/CRITICAL cases are handled through incident-response logic
- Full content retention is limited to critical cases

Visual:
- assets/privacy_governance.svg

## Slide 14. Conclusion
On-slide text:
- Completed:
  - trained and evaluated AI-DLP model
  - built web prototype
  - integrated endpoint agent
  - validated specialist leak scenarios
- Remaining / future work:
  - improve MEDIUM class calibration
  - stronger production hardening
  - larger real multilingual datasets
  - broader enterprise deployment

Speaker ending:
- The project demonstrates that AI-based DLP can move beyond static rules and provide practical protection against confidential data leakage in modern electronic communications.
"""


def build_speaker_notes() -> str:
    return """# Speaker Notes (RU)

## Slide 1
Здесь коротко представляешь тему, себя и руководителя. Сразу говоришь, что работа посвящена AI-based системе для выявления утечки конфиденциальных данных в электронных коммуникациях.

## Slide 2
Покажи структуру выступления. Это важно, потому что комиссия сразу видит исследовательскую логику.

## Slide 3
Объясни проблему: утечки происходят не только через взломы, но и через обычные рабочие каналы — письма, файлы, изображения, экспорт таблиц, флешки, endpoint-события.

## Slide 4
Скажи, что ты использовал аналитический, инженерный и экспериментальный методы исследования. Это один из ключевых критериев предзащиты.

## Slide 5
Подчеркни, что данные были собраны из нескольких источников: synthetic, public privacy datasets, custom enterprise scenarios. Объясни, что это было нужно для лучшей обобщающей способности модели.

## Slide 6
Здесь кратко объясни стек: multilingual BERT как основной AI-компонент, specialist model для сложных секретов, rule layer для структурированных утечек.

## Slide 7
Проговори главные метрики. Не перечисляй слишком много, только самые сильные: accuracy, macro F1, strong CRITICAL detection.

## Slide 8
Поясни confusion matrix. Главный вывод: ошибки чаще всего происходят между соседними уровнями риска, а CRITICAL ловится почти идеально.

## Slide 9
Объясни, что кроме test-set была еще runtime evaluation: mixed benchmark, noise benchmark, specialist benchmark. Это усиливает практическую ценность работы.

## Slide 10
Это один из самых сильных слайдов. Скажи, что ты не просто обучил одну модель, а сравнил разные стратегии и доказал, почему joint training лучше.

## Slide 11
Поясни, что инструмент исследования — это не только модель, а вся SecureMail AI-DLP система: AI-ядро, web platform, endpoint component, privacy workflows.

## Slide 12
Здесь надо показать, что у тебя есть реальный прототип, а не только теоретическая модель. Если сможешь, вставь реальные скриншоты сайта и Windows app.

## Slide 13
Этот слайд полезен для ответа на вопросы про этику и приватность. Подчеркни, что обычные сообщения не раскрываются администраторам без оснований.

## Slide 14
Заверши тем, что проект уже работает как сильный applied AI cybersecurity prototype, но при этом ты понимаешь его ограничения и направления развития.
"""


def build_readme() -> str:
    return """# Presentation Package

This folder contains a full 14-slide presentation structure for the diploma pre-defense / defense.

Files:
- `SLIDES_14_EN.md` - full slide-by-slide text in English
- `SPEAKER_NOTES_RU.md` - speaking notes in Russian
- `assets/` - ready visual diagrams in SVG format

Suggested usage:
1. Build the slides in PowerPoint, Canva, Google Slides, or Figma
2. Use the English slide text directly
3. Use the Russian speaker notes for oral delivery
4. Add 2-3 real screenshots of your web platform and Windows app on Slide 12

Recommended maximum:
- 14 slides

Key advantage of this structure:
- matches the logic of the max-score example
- matches the pre-defense criteria
- combines research + metrics + prototype + architecture
"""


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)
    eval_metrics = load_json(ROOT / "data" / "reports" / "eval_joint_v3_diploma" / "metrics.json")
    build_assets(eval_metrics)
    write(OUT / "SLIDES_14_EN.md", build_slide_texts())
    write(OUT / "SPEAKER_NOTES_RU.md", build_speaker_notes())
    write(OUT / "README.md", build_readme())


if __name__ == "__main__":
    main()
