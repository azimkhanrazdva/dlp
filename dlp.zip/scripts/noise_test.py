import argparse
import csv
import json
import random
from pathlib import Path

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def normalize_pred(label: str) -> str:
    value = str(label).upper()
    if value.startswith("LABEL_"):
        return LABELS[int(value.split("_")[-1])]
    return value


def random_noise(rng: random.Random, alphabet: str, min_len: int, max_len: int) -> str:
    return "".join(rng.choices(alphabet, k=rng.randint(min_len, max_len)))


def build_samples(count: int, seed: int):
    rng = random.Random(seed)
    out = []
    for idx in range(count):
        mode = idx % 6
        if mode == 0:
            out.append(f"debug trace={random_noise(rng, 'abcdef0123456789', 32, 96)} status=200")
        elif mode == 1:
            out.append(f"placeholder token={random_noise(rng, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/_-=', 28, 88)} example only")
        elif mode == 2:
            out.append(f"cache blob {random_noise(rng, 'abcdefghijklmnopqrstuvwxyz0123456789', 24, 64)} {random_noise(rng, 'abcdef0123456789', 32, 64)}")
        elif mode == 3:
            out.append(f"regex test only api_key=not_real_example_{rng.randint(100,999)} no secret should be detected")
        elif mode == 4:
            out.append(f"harmless OCR garbage {random_noise(rng, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 24, 44)} I1O0S5")
        else:
            out.append(f"log record session={random_noise(rng, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 20, 40)} marker=benign")
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Measure noise false positive rate.")
    parser.add_argument("--model_path", required=True, type=str)
    parser.add_argument("--count", type=int, default=5000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--max_length", type=int, default=256)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/noise"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    samples = build_samples(args.count, args.seed)
    tokenizer = AutoTokenizer.from_pretrained(args.model_path)
    model = AutoModelForSequenceClassification.from_pretrained(args.model_path)
    classifier = pipeline("text-classification", model=model, tokenizer=tokenizer, truncation=True, max_length=args.max_length, batch_size=args.batch_size, device=0 if torch.cuda.is_available() else -1)
    outputs = classifier(samples)
    counts = {label: 0 for label in LABELS}
    false_positive = 0
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "noise_predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["pred_label", "score", "text"])
        writer.writeheader()
        for text, out in zip(samples, outputs):
            pred = normalize_pred(out["label"])
            counts[pred] += 1
            if pred != "SAFE":
                false_positive += 1
            writer.writerow({"pred_label": pred, "score": float(out["score"]), "text": text})
    summary = {"count": args.count, "false_positive": false_positive, "noise_fp_rate": false_positive / max(1, args.count), "pred_distribution": counts}
    with (args.out_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    print(json.dumps(summary, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
