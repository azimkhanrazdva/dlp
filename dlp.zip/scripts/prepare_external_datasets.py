import argparse
import ast
import csv
import random
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

from datasets import load_from_disk


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]

LOW_TYPES = {
    "EMAIL",
    "TELEPHONENUM",
    "PHONE",
    "USERNAME",
    "FIRSTNAME",
    "LASTNAME",
    "MIDDLENAME",
    "FULLNAME",
}

MEDIUM_TYPES = {
    "ADDRESS",
    "STREET",
    "CITY",
    "STATE",
    "ZIPCODE",
    "DATEOFBIRTH",
    "DOB",
    "EMPLOYEEID",
}

HIGH_TYPES = {
    "CREDITCARDNUMBER",
    "CREDITCARDCVV",
    "CREDITCARDISSUER",
    "IBAN",
    "BANKACCOUNT",
    "ACCOUNTNUMBER",
    "PASSPORT",
    "PASSPORTNUMBER",
    "NATIONALID",
    "SSN",
    "DRIVERLICENSE",
    "TAXID",
    "VIN",
}

IGNORE_TYPES = {
    "O",
    "DATE",
    "TIME",
    "JOBTYPE",
    "COMPANY",
    "PREFIX",
    "SUFFIX",
    "TITLE",
    "SEX",
    "GENDER",
    "EYECOLOR",
    "HEIGHT",
    "WEIGHT",
}

CRITICAL_CONTEXT_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in [
        r"\bapi[_ -]?key\b",
        r"\baccess[_ -]?token\b",
        r"\bsecret[_ -]?key\b",
        r"\bprivate key\b",
        r"\bbearer\b",
        r"\bdatabase_url\b",
        r"\bpassword\b",
        r"\bssh\b",
    ]
]

HIGH_CONTEXT_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in [
        r"\bpayroll\b",
        r"\bsalary\b",
        r"\bcustomer\b",
        r"\bclient\b",
        r"\bemployee\b",
        r"\bhr\b",
        r"\bcandidate\b",
        r"\bresume\b",
        r"\bcv\b",
        r"\binvoice\b",
        r"\bbank\b",
        r"\bpayment\b",
        r"\btransaction\b",
    ]
]


def normalize_entity(label: str) -> str:
    base = str(label).rsplit("_", 1)[0].upper()
    return re.sub(r"[^A-Z]", "", base)


def parse_isotonic_span_labels(raw_value: str | list) -> List[Sequence[object]]:
    value = raw_value
    if isinstance(value, str):
        try:
            value = ast.literal_eval(value)
        except Exception:
            return []
    if not isinstance(value, (list, tuple)):
        return []
    rows = []
    for item in value:
        if isinstance(item, str):
            try:
                item = ast.literal_eval(item)
            except Exception:
                continue
        if isinstance(item, (list, tuple)) and len(item) >= 3:
            rows.append(item)
    return rows


def isotonic_entities(row: dict) -> List[str]:
    entities = []
    for item in parse_isotonic_span_labels(row.get("span_labels", "")):
        entity = normalize_entity(item[2])
        if entity and entity not in IGNORE_TYPES and entity != "O":
            entities.append(entity)
    return entities


def ai4privacy_entities(row: dict) -> List[str]:
    entities = []
    for item in row.get("privacy_mask", []) or []:
        label = normalize_entity(item.get("label", ""))
        if label and label not in IGNORE_TYPES and label != "O":
            entities.append(label)
    return entities


def classify_record(text: str, entities: Sequence[str]) -> Tuple[str, Dict[str, int]]:
    counts = Counter(entity for entity in entities if entity not in IGNORE_TYPES)
    if not counts:
        return "SAFE", dict(counts)

    if any(pattern.search(text) for pattern in CRITICAL_CONTEXT_PATTERNS):
        return "CRITICAL", dict(counts)

    high_hits = sum(count for entity, count in counts.items() if entity in HIGH_TYPES)
    medium_hits = sum(count for entity, count in counts.items() if entity in MEDIUM_TYPES)
    low_hits = sum(count for entity, count in counts.items() if entity in LOW_TYPES)
    unique_hits = len(counts)
    high_context = any(pattern.search(text) for pattern in HIGH_CONTEXT_PATTERNS)

    if high_hits > 0:
        return "HIGH", dict(counts)
    if high_context and (medium_hits > 0 or low_hits >= 2):
        return "HIGH", dict(counts)
    if medium_hits > 0 and low_hits > 0:
        return "MEDIUM", dict(counts)
    if medium_hits >= 2:
        return "MEDIUM", dict(counts)
    if low_hits >= 2:
        return "MEDIUM", dict(counts)
    if medium_hits == 1:
        return "MEDIUM", dict(counts)
    if low_hits == 1 and unique_hits == 1:
        return "LOW", dict(counts)
    if unique_hits >= 2:
        return "MEDIUM", dict(counts)
    return "SAFE", dict(counts)


def row_to_record(text: str, label: str, source: str, sample_type: str, language: str, entity_counts: Dict[str, int]) -> dict:
    return {
        "text": text.strip(),
        "label": label,
        "source": source,
        "sample_type": sample_type,
        "language": language or "unknown",
        "entity_counts": ";".join(f"{key}:{value}" for key, value in sorted(entity_counts.items())),
    }


def load_isotonic(raw_dir: Path, max_rows: int | None) -> List[dict]:
    split_dir = raw_dir / "Isotonic__pii_masking_200k" / "train"
    ds = load_from_disk(str(split_dir))
    rows = []
    limit = min(len(ds), max_rows) if max_rows else len(ds)
    for idx in range(limit):
        row = ds[idx]
        text = (row.get("unmasked_text") or "").strip()
        if not text:
            continue
        entities = isotonic_entities(row)
        label, counts = classify_record(text, entities)
        rows.append(row_to_record(text, label, "Isotonic/pii-masking-200k", "external_isotonic", row.get("language", "unknown"), counts))
    return rows


def load_ai4privacy(raw_dir: Path, max_rows: int | None) -> List[dict]:
    split_paths = [
        ("train", raw_dir / "ai4privacy__pii_masking_400k" / "train"),
        ("validation", raw_dir / "ai4privacy__pii_masking_400k" / "validation"),
    ]
    rows = []
    remaining = max_rows
    for split_name, split_dir in split_paths:
        ds = load_from_disk(str(split_dir))
        limit = len(ds) if remaining is None else min(len(ds), remaining)
        for idx in range(limit):
            row = ds[idx]
            text = (row.get("source_text") or "").strip()
            if not text:
                continue
            entities = ai4privacy_entities(row)
            label, counts = classify_record(text, entities)
            rows.append(row_to_record(text, label, "ai4privacy/pii-masking-400k", f"external_ai4privacy_{split_name}", row.get("language", "unknown"), counts))
        if remaining is not None:
            remaining -= limit
            if remaining <= 0:
                break
    return rows


def cap_rows(rows: List[dict], per_label_cap: int | None, seed: int) -> List[dict]:
    if per_label_cap is None:
        return rows
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["label"]].append(row)
    rng = random.Random(seed)
    capped = []
    for label in LABELS:
        items = grouped.get(label, [])
        rng.shuffle(items)
        capped.extend(items[:per_label_cap])
    rng.shuffle(capped)
    return capped


def split_rows(rows: List[dict], seed: int) -> Dict[str, List[dict]]:
    rng = random.Random(seed)
    rng.shuffle(rows)
    total = len(rows)
    train_end = int(total * 0.8)
    val_end = int(total * 0.9)
    return {"train": rows[:train_end], "val": rows[train_end:val_end], "test": rows[val_end:]}


def write_csv(path: Path, rows: List[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["text", "label", "source", "sample_type", "language", "entity_counts"])
        writer.writeheader()
        writer.writerows(rows)


def summarize(rows: Iterable[dict]) -> Dict[str, int]:
    counts = Counter(row["label"] for row in rows)
    return {label: counts.get(label, 0) for label in LABELS}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare local external PII datasets into unified CSV files.")
    parser.add_argument("--raw_dir", type=Path, default=Path("data/raw"))
    parser.add_argument("--out_dir", type=Path, default=Path("data/processed/external_pii"))
    parser.add_argument("--max_isotonic", type=int, default=10000)
    parser.add_argument("--max_ai4privacy", type=int, default=20000)
    parser.add_argument("--per_label_cap", type=int, default=12000)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = []
    rows.extend(load_isotonic(args.raw_dir, args.max_isotonic))
    rows.extend(load_ai4privacy(args.raw_dir, args.max_ai4privacy))
    rows = cap_rows(rows, args.per_label_cap, args.seed)
    splits = split_rows(rows, args.seed)
    for split, split_rows_list in splits.items():
        write_csv(args.out_dir / f"{split}.csv", split_rows_list)
        print(f"{split}: {summarize(split_rows_list)} -> {args.out_dir / f'{split}.csv'}")


if __name__ == "__main__":
    main()
