import argparse
import csv
import json
import random
from collections import Counter
from pathlib import Path
from typing import Dict, List

from docx import Document
import torch
from sklearn.metrics import f1_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
BANKS = ["Kaspi", "Halyk", "Forte", "Jusan", "CenterCredit", "Freedom"]
NAMES = ["Aruzhan Saparova", "Dias Akhmetov", "Madina Tulegenova", "Yerlan Omarov", "Kamila Iskakova", "Aidos Nurgaliyev", "Dana Suleimenova", "Bekzat Ryskulov"]


def digits(rng: random.Random, n: int) -> str:
    return "".join(rng.choices("0123456789", k=n))


def email(rng: random.Random) -> str:
    return f"user{rng.randint(1,999)}@example.com"


def phone_kz(rng: random.Random) -> str:
    d = "7" + digits(rng, 9)
    return rng.choice([f"+7{d}", f"+7 {d[:3]} {d[3:6]} {d[6:8]} {d[8:]}", f"8{d}"])


def iin(rng: random.Random) -> str:
    return digits(rng, 12)


def secret(rng: random.Random, prefix: str, size: int = 42) -> str:
    return prefix + "".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=size))


def jwt(rng: random.Random) -> str:
    return ".".join("".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=n)) for n in [24, 72, 32])


def maybe_obfuscate(text: str, rng: random.Random) -> str:
    if rng.random() < 0.3:
        text = text.replace("@", " [at] ").replace(".", " [dot] ")
    if rng.random() < 0.2:
        text = text.replace("Bearer ", "Bearer\t")
    return text


def sample(label: str, rng: random.Random) -> Dict[str, str]:
    if label == "SAFE":
        mode = rng.choice(["safe_text", "safe_attachment", "safe_usb", "safe_archive"])
        if mode == "safe_attachment":
            text = f"Attachment manifest: release_notes.pdf pages={rng.randint(2,20)} classification=internal-only no personal data included."
        elif mode == "safe_usb":
            text = f"USB inventory event: approved device connected for presentation transfer only. Session id {digits(rng,8)}."
        elif mode == "safe_archive":
            text = f"Archive manifest: training_bundle_{rng.randint(10,99)}.zip with demo notes and harmless screenshots only."
        else:
            text = f"Hello team, sharing harmless update on deployment and monitoring. Trace id {digits(rng,8)}."
        stype = mode
    elif label == "LOW":
        text = rng.choice([
            f"Please contact {email(rng)} for the next meeting.",
            f"Attachment note: vendor callback email {email(rng)}.",
        ])
        stype = "low_contact"
    elif label == "MEDIUM":
        text = rng.choice([
            f"Customer callback: {rng.choice(NAMES)}, {email(rng)}, {phone_kz(rng)}.",
            f"Scanned form: client {rng.choice(NAMES)} phone {phone_kz(rng)} email {email(rng)}.",
            f"Attachment contacts.xlsx contains {rng.choice(NAMES)}, {email(rng)}, {phone_kz(rng)}.",
        ])
        stype = "medium_bundle"
    elif label == "HIGH":
        text = rng.choice([
            f"{rng.choice(BANKS)} case: {rng.choice(NAMES)}, IIN {iin(rng)}, phone {phone_kz(rng)}.",
            f"Attachment payroll_export.xlsx employee {rng.choice(NAMES)} IIN {iin(rng)} salary {rng.randint(250000, 990000)} KZT.",
            f"Scanned KYC form: {rng.choice(NAMES)} IIN {iin(rng)} phone {phone_kz(rng)}.",
            "Attachment customer_export.csv prepared for external share.\n"
            + "\n".join([
                "name,email,phone,iin,account,iban,bank",
                f"{rng.choice(NAMES)},{email(rng)},{phone_kz(rng)},{iin(rng)},KZ{digits(rng,18)},KZ{digits(rng,18)},{rng.choice(BANKS)}",
                f"{rng.choice(NAMES)},{email(rng)},{phone_kz(rng)},{iin(rng)},KZ{digits(rng,18)},KZ{digits(rng,18)},{rng.choice(BANKS)}",
                f"{rng.choice(NAMES)},{email(rng)},{phone_kz(rng)},{iin(rng)},KZ{digits(rng,18)},KZ{digits(rng,18)},{rng.choice(BANKS)}",
            ]),
        ])
        stype = "high_sensitive"
    else:
        text = rng.choice([
            f"OpenAI key leaked: {secret(rng, 'sk-proj-')}",
            f"GitHub token exposed: {secret(rng, 'ghp_')}",
            f"Authorization: Bearer {jwt(rng)}",
            f"DATABASE_URL=postgresql://admin:{secret(rng, '')}@prod-db.company.kz:5432/prod",
            f"USB copy detected: finance_backup.zip -> Bearer {jwt(rng)}",
            f"Attachment env_dump.txt SECRET_KEY={secret(rng, '', 28)} DATABASE_URL=postgresql://admin:{secret(rng, '')}@prod-db.company.kz:5432/prod",
            "Large credential dump detected in attachment password_export.csv\n"
            + "\n".join([
                "customer_id,password,client_secret,access_token",
                f"1001,{secret(rng, '', 14)},{secret(rng, '', 22)},{jwt(rng)}",
                f"1002,{secret(rng, '', 14)},{secret(rng, '', 22)},{jwt(rng)}",
                f"1003,{secret(rng, '', 14)},{secret(rng, '', 22)},{jwt(rng)}",
            ]),
            f"Protected archive finance_vault_{rng.randint(100,999)}.rar prepared for transfer with DATABASE_URL=postgresql://admin:{secret(rng, '')}@prod-db.company.kz:5432/prod",
        ])
        stype = "critical_secret"
    if rng.random() < 0.35:
        text += f" trace={secret(rng, '', 24)}"
    text = maybe_obfuscate(text, rng)
    lang = rng.choice(["ru", "en", "mixed"])
    if lang == "ru":
        text = "Служебное сообщение. " + text
    elif lang == "mixed":
        text = "Internal note. " + text + " Проверить срочно."
    return {"text": text, "expected_label": label, "sample_type": stype, "language": lang}


def generate(count: int, seed: int) -> List[Dict[str, str]]:
    rng = random.Random(seed)
    rows = []
    per = count // len(LABELS)
    rem = count % len(LABELS)
    for idx, label in enumerate(LABELS):
        for _ in range(per + (1 if idx < rem else 0)):
            rows.append(sample(label, rng))
    rng.shuffle(rows)
    return rows


def normalize_pred(label: str) -> str:
    v = str(label).upper()
    if v.startswith("LABEL_"):
        return LABELS[int(v.split("_")[-1])]
    return v


def write_docx(path: Path, summary: Dict[str, object], examples: List[Dict[str, str]]) -> None:
    doc = Document()
    doc.add_heading("Real World DLP Test Report", level=1)
    for key in ["count", "accuracy", "macro_f1", "weighted_f1"]:
        doc.add_paragraph(f"{key}: {summary[key]}")
    doc.add_paragraph(f"expected_distribution: {summary['expected_distribution']}")
    doc.add_paragraph(f"pred_distribution: {summary['pred_distribution']}")
    doc.add_heading("Examples", level=2)
    for item in examples:
        doc.add_paragraph(f"Expected={item['expected_label']} Predicted={item['pred_label']} Score={item['score']}\n{item['text']}")
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run 10k+ real-world mixed DLP test.")
    parser.add_argument("--model_path", required=True, type=str)
    parser.add_argument("--count", type=int, default=10000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--max_length", type=int, default=256)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/real_world"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = generate(args.count, args.seed)
    tokenizer = AutoTokenizer.from_pretrained(args.model_path)
    model = AutoModelForSequenceClassification.from_pretrained(args.model_path)
    classifier = pipeline("text-classification", model=model, tokenizer=tokenizer, truncation=True, max_length=args.max_length, batch_size=args.batch_size, device=0 if torch.cuda.is_available() else -1)
    outputs = classifier([row["text"] for row in rows])
    out_rows = []
    expected = Counter()
    predicted = Counter()
    for row, out in zip(rows, outputs):
        pred = normalize_pred(out["label"])
        expected[row["expected_label"]] += 1
        predicted[pred] += 1
        out_rows.append({**row, "pred_label": pred, "score": float(out["score"])})
    y_true = [LABELS.index(x["expected_label"]) for x in out_rows]
    y_pred = [LABELS.index(x["pred_label"]) for x in out_rows]
    summary = {
        "count": len(out_rows),
        "accuracy": sum(1 for x in out_rows if x["expected_label"] == x["pred_label"]) / max(1, len(out_rows)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "expected_distribution": dict(expected),
        "pred_distribution": dict(predicted),
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["expected_label", "pred_label", "score", "sample_type", "language", "text"])
        writer.writeheader()
        writer.writerows(out_rows)
    with (args.out_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    examples = [x for x in out_rows if x["expected_label"] != x["pred_label"]][:20] or out_rows[:20]
    write_docx(args.out_dir / "real_world_report.docx", summary, examples)
    print(json.dumps(summary, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
