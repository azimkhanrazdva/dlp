from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def font(size: int, bold: bool = False):
    candidates = ["arialbd.ttf", "seguisb.ttf"] if bold else ["arial.ttf", "segoeui.ttf"]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            continue
    return ImageFont.load_default()


def round_box(draw, box, fill, outline, radius=14, width=2):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def text_center(draw, box, text, ft, fill, spacing=5):
    x1, y1, x2, y2 = box
    lines = text.split("\n")
    heights = []
    widths = []
    for line in lines:
        b = draw.textbbox((0, 0), line, font=ft)
        widths.append(b[2] - b[0])
        heights.append(b[3] - b[1])
    total_h = sum(heights) + max(0, len(lines) - 1) * spacing
    y = y1 + (y2 - y1 - total_h) / 2
    for line, w, h in zip(lines, widths, heights):
        x = x1 + (x2 - x1 - w) / 2
        draw.text((x, y), line, font=ft, fill=fill)
        y += h + spacing


def text_left(draw, pos, text, ft, fill, spacing=4):
    x, y = pos
    for line in text.split("\n"):
        draw.text((x, y), line, font=ft, fill=fill)
        b = draw.textbbox((0, 0), line, font=ft)
        y += (b[3] - b[1]) + spacing


def arrow(draw, start, end, fill="#314760", width=3):
    draw.line((start, end), fill=fill, width=width)
    x1, y1 = start
    x2, y2 = end
    head = 10
    if abs(x2 - x1) >= abs(y2 - y1):
        if x2 >= x1:
            pts = [(x2, y2), (x2 - head, y2 - head // 2), (x2 - head, y2 + head // 2)]
        else:
            pts = [(x2, y2), (x2 + head, y2 - head // 2), (x2 + head, y2 + head // 2)]
    else:
        if y2 >= y1:
            pts = [(x2, y2), (x2 - head // 2, y2 - head), (x2 + head // 2, y2 - head)]
        else:
            pts = [(x2, y2), (x2 - head // 2, y2 + head), (x2 + head // 2, y2 + head)]
    draw.polygon(pts, fill=fill)


def label(draw, box, text, ft, fill="#314760", bg="#eef2f7", outline=None):
    round_box(draw, box, bg, outline or bg, radius=9, width=1)
    text_center(draw, box, text, ft, fill)


def section_card(draw, x, y, w, h, title, body_lines, header_fill, body_fill, border, title_font, body_font):
    round_box(draw, (x, y, x + w, y + h), fill=body_fill, outline=border, radius=12, width=2)
    round_box(draw, (x, y, x + w, y + 42), fill=header_fill, outline=header_fill, radius=12, width=1)
    draw.rectangle((x, y + 24, x + w, y + 42), fill=header_fill, outline=header_fill)
    text_center(draw, (x + 8, y + 6, x + w - 8, y + 34), title, title_font, "#f8fbff")
    text_left(draw, (x + 18, y + 60), body_lines, body_font, "#27364a", spacing=8)


def main():
    W, H = 1600, 1040
    img = Image.new("RGB", (W, H), "#f4f7fb")
    draw = ImageDraw.Draw(img)

    title_ft = font(34, True)
    header_ft = font(20, True)
    sub_ft = font(15)
    small_ft = font(13)
    tiny_ft = font(11, True)

    navy = "#24466c"
    blue = "#3f69a9"
    outline = "#90a3bc"
    panel = "#f8fbff"
    soft = "#eef3f9"
    mint = "#eaf8ef"
    lavender = "#f3edff"
    peach = "#fff2e6"
    cyan = "#eef8ff"

    # Outer frame
    round_box(draw, (18, 18, W - 18, H - 18), "#f8fafc", "#98a8be", radius=14, width=2)
    text_center(draw, (0, 40, W, 90), "SecureMail AI-DLP Platform Architecture", title_ft, "#243b5a")

    # Left top
    section_card(
        draw, 42, 120, 270, 260,
        "Users & Admins",
        "Web UI\nFlask interface for mailbox, sending, and secure communication\n\nAdmin Portal\nIncidents, accounts, agents, devices, access control",
        navy, panel, outline, header_ft, sub_ft
    )

    # Left bottom
    section_card(
        draw, 42, 415, 270, 345,
        "External Sources",
        "Corporate messages / files\nemails, attachments, images, archives\n\nWindows Control Center\nconfiguration, service mode, logs, manual scan\n\nEndpoint agents\nclipboard, USB, filesystem, process context",
        navy, panel, outline, header_ft, sub_ft
    )

    # Center platform shell
    round_box(draw, (505, 145, 1085, 760), "#f9fbff", "#5f7290", radius=10, width=2)
    round_box(draw, (505, 145, 1085, 190), navy, navy, radius=10, width=1)
    draw.rectangle((505, 170, 1085, 190), fill=navy, outline=navy)
    text_center(draw, (525, 150, 1065, 182), "SecureMail AI-DLP Platform", font(21, True), "#f8fbff")

    # Content extraction
    section_card(
        draw, 530, 220, 530, 145,
        "Content Extraction Layer",
        "Text normalization\nAttachment parsing\nOCR and archive inspection",
        blue, panel, outline, header_ft, font(18)
    )

    # AI core
    section_card(
        draw, 530, 390, 530, 155,
        "AI-DLP Core",
        "Multilingual BERT classifier\nSpecialist leak detection for secrets and banking exports\nRules engine, OCR-aware indicators, file and archive parsers",
        blue, panel, outline, header_ft, sub_ft
    )

    # Policy
    section_card(
        draw, 530, 565, 530, 170,
        "Policy & Governance",
        "Severity scoring: SAFE / LOW / MEDIUM / HIGH / CRITICAL\nIncident management and administrative review\nPrivacy-preserving access control and auto-restriction on CRITICAL",
        blue, panel, outline, header_ft, sub_ft
    )

    # Right API
    section_card(
        draw, 1165, 305, 240, 110,
        "Backend API",
        "Flask REST API", navy, panel, outline, header_ft, font(18)
    )

    # Right storage
    section_card(
        draw, 1165, 495, 240, 180,
        "Storage Layer",
        "SQLite / PostgreSQL\nAccounts, incidents, audits,\npolicies, agents, devices,\nmessages, requests",
        navy, panel, outline, header_ft, font(17)
    )

    # Bottom observability
    round_box(draw, (44, 810, 1510, 165 + 760), "#fbfdff", "#98a8be", radius=10, width=2)
    text_center(draw, (50, 830, 1500, 870), "Monitoring & Observability", font(20, True), "#243b5a")

    bottom_cards = [
        (150, 872, 280, 92, "Logs & Audit Trails", "All privileged actions and decisions"),
        (455, 872, 290, 92, "Alerts & Notifications", "Security and DLP incidents"),
        (770, 872, 300, 92, "Dashboards & Reports", "Analytics, compliance, statistics"),
        (1095, 872, 270, 92, "Agent Health", "Status, heartbeat, telemetry"),
    ]
    for x, y, w, h, t, s in bottom_cards:
        round_box(draw, (x, y, x + w, y + h), soft, "#e2e8f0", radius=10, width=1)
        text_left(draw, (x + 18, y + 22), f"{t}\n{s}", font(16, True), "#233a58", spacing=10)

    # arrows and labels
    arrow(draw, (312, 275), (505, 275))
    label(draw, (360, 240, 450, 266), "HTTPS", tiny_ft)

    arrow(draw, (312, 540), (505, 540))
    label(draw, (340, 505, 495, 531), "Secure Ingestion", tiny_ft)

    arrow(draw, (795, 365), (795, 390))
    arrow(draw, (795, 545), (795, 565))
    arrow(draw, (1060, 315), (1165, 360))
    arrow(draw, (1060, 505), (1165, 545))
    arrow(draw, (1165, 595), (1060, 595))
    label(draw, (1088, 520, 1150, 546), "Read / Write", tiny_ft)
    arrow(draw, (1285, 415), (1285, 495))
    arrow(draw, (795, 735), (795, 810))

    # Subtle side accent cards for style/reference feel
    round_box(draw, (1200, 108, 343 + 1200, 220), "#fafcff", "#d6deea", radius=12, width=2)
    text_left(
        draw,
        (1218, 124),
        "Operational characteristics\n\nBackend: Flask\nAI stack: PyTorch, Transformers\nStorage: SQLite / PostgreSQL\nEndpoint: Windows app + agent",
        font(15, True),
        "#3b4c62",
        spacing=8,
    )

    round_box(draw, (1200, 230, 1435, 355), "#fafcff", "#d6deea", radius=12, width=2)
    text_left(
        draw,
        (1218, 246),
        "Dataset summary\n\n60,000 samples\n43,287 train\n8,336 validation\n8,377 test\n5 severity classes",
        font(15, True),
        "#3b4c62",
        spacing=8,
    )

    out_dir = Path("presentation_package_max/assets")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "securemail_architecture_reference_style.png"
    img.save(out_path)
    print(out_path)


if __name__ == "__main__":
    main()
