import argparse
import sqlite3
from pathlib import Path

import psycopg
from psycopg.rows import dict_row


TABLE_ORDER = [
    "accounts",
    "messages",
    "attachments",
    "incidents",
    "devices",
    "device_events",
    "device_rules",
    "audit_chain",
    "sessions",
    "endpoint_agents",
    "policies",
    "scan_jobs",
    "unlock_requests",
    "message_access_requests",
]

SERIAL_TABLES = {
    "accounts",
    "messages",
    "attachments",
    "incidents",
    "devices",
    "device_events",
    "device_rules",
    "audit_chain",
    "endpoint_agents",
    "policies",
    "scan_jobs",
    "unlock_requests",
    "message_access_requests",
}


def sqlite_rows(db_path: Path, table: str):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = [dict(row) for row in conn.execute(f"SELECT * FROM {table}").fetchall()]
    conn.close()
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Migrate SecureMail data from SQLite to PostgreSQL.")
    parser.add_argument("--sqlite-path", required=True)
    parser.add_argument("--postgres-url", required=True)
    args = parser.parse_args()

    sqlite_path = Path(args.sqlite_path)
    if not sqlite_path.exists():
        raise SystemExit(f"SQLite database not found: {sqlite_path}")

    with psycopg.connect(args.postgres_url, row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            for table in reversed(TABLE_ORDER):
                cur.execute(f'TRUNCATE TABLE "{table}" RESTART IDENTITY CASCADE')
            conn.commit()

            for table in TABLE_ORDER:
                rows = sqlite_rows(sqlite_path, table)
                if not rows:
                    print(f"SKIP {table}")
                    continue
                columns = list(rows[0].keys())
                placeholders = ", ".join(["%s"] * len(columns))
                column_sql = ", ".join(f'"{name}"' for name in columns)
                insert_sql = f'INSERT INTO "{table}" ({column_sql}) VALUES ({placeholders})'
                values = [[row.get(col) for col in columns] for row in rows]
                with conn.cursor() as cur:
                    cur.executemany(insert_sql, values)
                conn.commit()
                print(f"OK {table}: {len(rows)} rows")

            with conn.cursor() as cur:
                for table in SERIAL_TABLES:
                    cur.execute(f'SELECT COALESCE(MAX(id), 1) AS max_id FROM "{table}"')
                    max_id = int(cur.fetchone()["max_id"])
                    cur.execute(
                        "SELECT setval(pg_get_serial_sequence(%s, 'id'), %s, true)",
                        (table, max_id),
                    )
            conn.commit()

    print("Migration complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
