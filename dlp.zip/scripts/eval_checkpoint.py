import argparse
import csv
import json
from collections import Counter
from pathlib import Path
from typing import List

import torch
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def normalize_pred(label: str) -> str:
    value = str(label).upper()
    if value.startswith("LABEL_"):
        return LABELS[int(value.split("_")[-1])]
    return value


def resolve_data_path(source: str, split: str, data_dir: Path | None) -> Path:
    if data_dir is not None:
        return data_dir / f"{split}.csv"
    mapping = {
        "synth": Path("data/processed/synth_v3"),
        "external": Path("data/processed/external_pii"),
        "joint": Path("data/processed/joint_v2"),
    }
    return mapping[source] / f"{split}.csv"


def load_rows(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    return [{"text": (r.get("text") or "").strip(), "label": (r.get("label") or "").strip().upper()} for r in rows if (r.get("text") or "").strip() and (r.get("label") or "").strip().upper() in LABELS]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate a saved checkpoint.")
    parser.add_argument("--model_path", required=True, type=str)
    parser.add_argument("--source", choices=["synth", "external", "joint"], default="joint")
    parser.add_argument("--split", choices=["train", "val", "test"], default="test")
    parser.add_argument("--data_dir", type=Path, default=None)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/eval"))
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--max_length", type=int, default=256)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = load_rows(resolve_data_path(args.source, args.split, args.data_dir))
    tokenizer = AutoTokenizer.from_pretrained(args.model_path)
    model = AutoModelForSequenceClassification.from_pretrained(args.model_path)
    classifier = pipeline("text-classification", model=model, tokenizer=tokenizer, truncation=True, max_length=args.max_length, batch_size=args.batch_size, device=0 if torch.cuda.is_available() else -1)
    outputs = classifier([row["text"] for row in rows])
    preds = [normalize_pred(out["label"]) for out in outputs]
    y_true = [LABELS.index(row["label"]) for row in rows]
    y_pred = [LABELS.index(pred) for pred in preds]
    metrics = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=list(range(len(LABELS)))).tolist(),
        "classification_report": classification_report(y_true, y_pred, labels=list(range(len(LABELS))), target_names=LABELS, output_dict=True, zero_division=0),
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "metrics.json").open("w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2, ensure_ascii=False)
    with (args.out_dir / "predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["true_label", "pred_label", "score", "text"])
        writer.writeheader()
        for row, out, pred in zip(rows, outputs, preds):
            writer.writerow({"true_label": row["label"], "pred_label": pred, "score": float(out["score"]), "text": row["text"]})
    print(f"true_distribution={dict(Counter(row['label'] for row in rows))}")
    print(f"pred_distribution={dict(Counter(preds))}")
    print(json.dumps({k: metrics[k] for k in ['accuracy', 'macro_f1', 'weighted_f1', 'confusion_matrix']}, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
