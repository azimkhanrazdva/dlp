import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.dlp_engine import DLPScanner, serialize_result  # noqa: E402


def main() -> None:
    model_path = str(ROOT / "models" / "dlp_bert_joint_v3")
    aux_model_path = str(ROOT / "models" / "dlp_bert_joint_v3_boost_v1")
    scanner = DLPScanner(model_path=model_path, aux_model_path=aux_model_path)

    outputs = {}

    outputs["device_safe"] = serialize_result(
        scanner.scan_text(
            "device_name=Kingston DataTraveler event=connected policy=authorized USB inventory event for presentation only",
            channel="device",
        )
    )
    outputs["device_critical"] = serialize_result(
        scanner.scan_text(
            "device_name=SanDisk Extreme event=copy policy=review USB copy detected finance_backup.zip DATABASE_URL=postgresql://admin:secret@prod-db.company.kz:5432/prod",
            channel="device",
        )
    )

    with tempfile.TemporaryDirectory() as tmp:
        safe_file = Path(tmp) / "release_notes_q2.pdf.txt"
        safe_file.write_text("Release notes and architecture summary. No personal data included.", encoding="utf-8")
        outputs["file_safe"] = serialize_result(scanner.scan_file(safe_file))

        high_file = Path(tmp) / "payroll_export_2026.xlsx.txt"
        high_file.write_text("Employee Dias Akhmetov IIN 123456789012 salary 550000 KZT", encoding="utf-8")
        outputs["file_high"] = serialize_result(scanner.scan_file(high_file))

        critical_file = Path(tmp) / ".env"
        critical_file.write_text("OPENAI_API_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USEdefabcdefabcdefabcdefabcdefabcdef\nDATABASE_URL=postgresql://admin:secret@prod-db.company.kz:5432/prod", encoding="utf-8")
        outputs["file_critical"] = serialize_result(scanner.scan_file(critical_file))

    print(json.dumps(outputs, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
