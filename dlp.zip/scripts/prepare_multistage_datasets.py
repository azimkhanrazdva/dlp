import argparse
import csv
import random
from collections import defaultdict
from pathlib import Path
from typing import Dict, List


SEVERITY_LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
RISK_LABELS = ["SAFE", "RISK"]
SECRET_LABELS = ["SAFE", "SECRET"]


def load_csv(path: Path) -> List[dict]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    out = []
    for row in rows:
        text = (row.get("text") or "").strip()
        label = (row.get("label") or "").strip().upper()
        if text and label:
            out.append(row)
    return out


def write_csv(path: Path, rows: List[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row.keys()}) if rows else ["text", "label"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def build_stage1(rows: List[dict]) -> List[dict]:
    out = []
    for row in rows:
        label = (row.get("label") or "").upper()
        out.append(
            {
                "text": row["text"],
                "label": "SAFE" if label == "SAFE" else "RISK",
                "source": row.get("source", "unknown"),
                "sample_type": row.get("sample_type", ""),
            }
        )
    return out


def build_stage1_balanced(rows: List[dict], seed: int) -> List[dict]:
    rng = random.Random(seed)
    base_rows = build_stage1(rows)
    safe_rows = [row for row in base_rows if row["label"] == "SAFE"]
    risk_rows = [row for row in base_rows if row["label"] == "RISK"]

    hard_negative_templates = [
        lambda: f"debug trace={''.join(rng.choices('abcdef0123456789', k=64))} status=200 benign=true",
        lambda: f"placeholder token={''.join(rng.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/_-=', k=72))} not a real credential",
        lambda: f"sample docs mention api_key_example_{rng.randint(100,999)} for parser tests only",
        lambda: f"cache blob {''.join(rng.choices('abcdef0123456789', k=48))} {''.join(rng.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=32))}",
        lambda: f"harmless OCR noise I1O0S5 {''.join(rng.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=28))}",
        lambda: f"log record session={''.join(rng.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=30))} marker=normal",
    ]

    target_safe = max(len(safe_rows), min(len(risk_rows), len(safe_rows) * 2 if safe_rows else len(risk_rows)))
    augmented_safe = list(safe_rows)
    while len(augmented_safe) < target_safe:
        template = hard_negative_templates[len(augmented_safe) % len(hard_negative_templates)]
        augmented_safe.append(
            {
                "text": template(),
                "label": "SAFE",
                "source": "synthetic_hard_negative",
                "sample_type": "stage1_safe_hard_negative",
            }
        )

    rng.shuffle(risk_rows)
    target_risk = min(len(risk_rows), max(len(augmented_safe), len(safe_rows)))
    balanced = augmented_safe + risk_rows[:target_risk]
    rng.shuffle(balanced)
    return balanced


def build_stage2(rows: List[dict]) -> List[dict]:
    out = []
    for row in rows:
        label = (row.get("label") or "").upper()
        if label in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}:
            out.append(
                {
                    "text": row["text"],
                    "label": label,
                    "source": row.get("source", "unknown"),
                    "sample_type": row.get("sample_type", ""),
                }
            )
    return out


def build_stage3(rows: List[dict], rng: random.Random) -> List[dict]:
    positives = []
    negatives = []
    secret_markers = ("critical_secret", "github", "openai", "aws", "jwt", "db", "private", "env", "slack")
    for row in rows:
        sample_type = (row.get("sample_type") or "").lower()
        label = (row.get("label") or "").upper()
        payload = {
            "text": row["text"],
            "source": row.get("source", "unknown"),
            "sample_type": row.get("sample_type", ""),
        }
        if label == "CRITICAL" and any(marker in sample_type for marker in secret_markers):
            positives.append({**payload, "label": "SECRET"})
        elif label == "SAFE":
            negatives.append({**payload, "label": "SAFE"})
    rng.shuffle(positives)
    rng.shuffle(negatives)
    cap = min(len(positives), len(negatives))
    return positives[:cap] + negatives[:cap]


def split_copy(rows_by_split: Dict[str, List[dict]], builder, out_dir: Path) -> None:
    for split, rows in rows_by_split.items():
        built = builder(rows)
        write_csv(out_dir / f"{split}.csv", built)
        labels = defaultdict(int)
        for row in built:
            labels[row["label"]] += 1
        print(f"{out_dir.name}:{split} -> {dict(labels)}")


def split_copy_stage1(rows_by_split: Dict[str, List[dict]], out_dir: Path, seed: int) -> None:
    for offset, split in enumerate(["train", "val", "test"]):
        built = build_stage1_balanced(rows_by_split[split], seed + offset)
        write_csv(out_dir / f"{split}.csv", built)
        labels = defaultdict(int)
        for row in built:
            labels[row["label"]] += 1
        print(f"{out_dir.name}:{split} -> {dict(labels)}")


def split_copy_stage3(rows_by_split: Dict[str, List[dict]], out_dir: Path, seed: int) -> None:
    for offset, split in enumerate(["train", "val", "test"]):
        rng = random.Random(seed + offset)
        built = build_stage3(rows_by_split[split], rng)
        rng.shuffle(built)
        write_csv(out_dir / f"{split}.csv", built)
        labels = defaultdict(int)
        for row in built:
            labels[row["label"]] += 1
        print(f"{out_dir.name}:{split} -> {dict(labels)}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare datasets for multi-stage DLP pipeline.")
    parser.add_argument("--joint_dir", type=Path, default=Path("data/processed/joint_v2"))
    parser.add_argument("--out_root", type=Path, default=Path("data/processed"))
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows_by_split = {split: load_csv(args.joint_dir / f"{split}.csv") for split in ["train", "val", "test"]}
    split_copy_stage1(rows_by_split, args.out_root / "stage1_risk", args.seed)
    split_copy(rows_by_split, build_stage2, args.out_root / "stage2_severity")
    split_copy_stage3(rows_by_split, args.out_root / "stage3_secret", args.seed)


if __name__ == "__main__":
    main()
