import argparse
import json
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.dlp_engine import DLPScanner, serialize_result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run multi-stage DLP inference on text or file.")
    parser.add_argument("--text", type=str, default=None)
    parser.add_argument("--file", type=Path, default=None)
    parser.add_argument("--single_model", type=str, default=None)
    parser.add_argument("--stage1_model", type=str, default=None)
    parser.add_argument("--stage2_model", type=str, default=None)
    parser.add_argument("--stage3_model", type=str, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scanner = DLPScanner(
        model_path=args.single_model,
        stage1_path=args.stage1_model,
        stage2_path=args.stage2_model,
        stage3_path=args.stage3_model,
    )
    if args.file is not None:
        result = scanner.scan_file(args.file)
    else:
        result = scanner.scan_text(args.text or "")
    print(json.dumps(serialize_result(result), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
