import argparse
import csv
import html
import json
from pathlib import Path
from typing import Dict, List, Tuple

import torch
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
SOURCE_DIRS = {
    "synth": Path("data/processed/synth_v3"),
    "external": Path("data/processed/external_pii"),
    "joint": Path("data/processed/joint_v3"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare multiple DLP models across datasets and generate a report.")
    parser.add_argument("--models", nargs="+", required=True, help="Pairs in format name=path")
    parser.add_argument("--sources", nargs="+", default=["synth", "external"], choices=["synth", "external", "joint"])
    parser.add_argument("--split", choices=["train", "val", "test"], default="test")
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/model_comparison"))
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--max_length", type=int, default=256)
    return parser.parse_args()


def parse_model_specs(items: List[str]) -> List[Tuple[str, Path]]:
    specs = []
    for item in items:
        if "=" not in item:
            raise ValueError(f"Model spec must be name=path, got: {item}")
        name, raw_path = item.split("=", 1)
        specs.append((name.strip(), Path(raw_path.strip())))
    return specs


def normalize_pred(label: str) -> str:
    value = str(label).upper()
    if value.startswith("LABEL_"):
        return LABELS[int(value.split("_")[-1])]
    return value


def load_rows(path: Path) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    return [
        {"text": (row.get("text") or "").strip(), "label": (row.get("label") or "").strip().upper()}
        for row in rows
        if (row.get("text") or "").strip() and (row.get("label") or "").strip().upper() in LABELS
    ]


def evaluate_model(model_name: str, model_path: Path, rows: List[Dict[str, str]], batch_size: int, max_length: int) -> Dict[str, object]:
    tokenizer = AutoTokenizer.from_pretrained(str(model_path))
    model = AutoModelForSequenceClassification.from_pretrained(str(model_path))
    classifier = pipeline(
        "text-classification",
        model=model,
        tokenizer=tokenizer,
        truncation=True,
        max_length=max_length,
        batch_size=batch_size,
        device=0 if torch.cuda.is_available() else -1,
    )
    outputs = classifier([row["text"] for row in rows])
    preds = [normalize_pred(out["label"]) for out in outputs]
    y_true = [LABELS.index(row["label"]) for row in rows]
    y_pred = [LABELS.index(pred) for pred in preds]
    report = classification_report(y_true, y_pred, labels=list(range(len(LABELS))), target_names=LABELS, output_dict=True, zero_division=0)
    return {
        "model_name": model_name,
        "model_path": str(model_path),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=list(range(len(LABELS)))).tolist(),
        "classification_report": report,
        "pred_distribution": {label: preds.count(label) for label in LABELS},
        "true_distribution": {label: sum(1 for row in rows if row["label"] == label) for label in LABELS},
    }


def svg_bar_chart(rows: List[Dict[str, object]], metric: str, title: str, width: int = 820, height: int = 260) -> str:
    if not rows:
        return ""
    margin_left = 180
    margin_right = 40
    margin_top = 36
    bar_gap = 12
    bar_height = 18
    plot_width = width - margin_left - margin_right
    total_height = margin_top + len(rows) * (bar_height + bar_gap) + 30
    values = [float(row[metric]) for row in rows]
    max_value = max(max(values), 1e-6)
    bars = []
    for index, row in enumerate(rows):
        y = margin_top + index * (bar_height + bar_gap)
        label = f"{row['model']} | {row['source']}"
        value = float(row[metric])
        bar_width = max(2, int((value / max_value) * plot_width))
        bars.append(f"<text x='8' y='{y + 13}' font-size='12' fill='#132235'>{html.escape(label)}</text>")
        bars.append(f"<rect x='{margin_left}' y='{y}' width='{bar_width}' height='{bar_height}' rx='6' fill='#3b6ea8' />")
        bars.append(f"<text x='{margin_left + bar_width + 8}' y='{y + 13}' font-size='12' fill='#5d7087'>{value:.4f}</text>")
    return (
        f"<svg width='{width}' height='{total_height}' viewBox='0 0 {width} {total_height}' xmlns='http://www.w3.org/2000/svg'>"
        f"<text x='{margin_left}' y='20' font-size='15' font-weight='700' fill='#132235'>{html.escape(title)}</text>"
        + "".join(bars)
        + "</svg>"
    )


def build_html(summary_rows: List[Dict[str, object]], deltas: List[Dict[str, object]]) -> str:
    table_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row['model']))}</td>"
        f"<td>{html.escape(str(row['source']))}</td>"
        f"<td>{row['accuracy']:.4f}</td>"
        f"<td>{row['macro_f1']:.4f}</td>"
        f"<td>{row['weighted_f1']:.4f}</td>"
        f"<td>{html.escape(row['best_class'])}</td>"
        f"<td>{html.escape(row['worst_class'])}</td>"
        "</tr>"
        for row in summary_rows
    )
    delta_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row['source']))}</td>"
        f"<td>{html.escape(str(row['left_model']))}</td>"
        f"<td>{html.escape(str(row['right_model']))}</td>"
        f"<td>{row['delta_accuracy']:+.4f}</td>"
        f"<td>{row['delta_macro_f1']:+.4f}</td>"
        f"<td>{html.escape(row['biggest_gap_class'])}</td>"
        "</tr>"
        for row in deltas
    )
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Model Comparison Report</title>
  <style>
    body {{ font-family: Arial, sans-serif; background:#f4f7fb; color:#132235; margin:0; padding:24px; }}
    .card {{ background:#fff; border:1px solid #d7e1ec; border-radius:18px; padding:20px; margin-bottom:20px; }}
    table {{ width:100%; border-collapse:collapse; }}
    th, td {{ padding:10px 12px; border-bottom:1px solid #e6edf5; text-align:left; }}
    th {{ font-size:12px; text-transform:uppercase; color:#5d7087; }}
    h1, h2 {{ margin-top:0; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>Model Comparison Report</h1>
    <p>Comparison across synthetic and real datasets.</p>
  </div>
  <div class="card">
    <h2>Summary</h2>
    <table>
      <thead>
        <tr><th>Model</th><th>Source</th><th>Accuracy</th><th>Macro F1</th><th>Weighted F1</th><th>Best Class Recall</th><th>Worst Class Recall</th></tr>
      </thead>
      <tbody>{table_rows}</tbody>
    </table>
  </div>
  <div class="card">
    <h2>Accuracy</h2>
    {svg_bar_chart(summary_rows, "accuracy", "Accuracy by model and dataset")}
  </div>
  <div class="card">
    <h2>Macro F1</h2>
    {svg_bar_chart(summary_rows, "macro_f1", "Macro F1 by model and dataset")}
  </div>
  <div class="card">
    <h2>Direct Deltas</h2>
    <table>
      <thead>
        <tr><th>Source</th><th>Left Model</th><th>Right Model</th><th>Delta Accuracy</th><th>Delta Macro F1</th><th>Largest Class Recall Gap</th></tr>
      </thead>
      <tbody>{delta_rows}</tbody>
    </table>
  </div>
</body>
</html>"""


def main() -> None:
    args = parse_args()
    model_specs = parse_model_specs(args.models)
    args.out_dir.mkdir(parents=True, exist_ok=True)

    per_source_rows = {source: load_rows(SOURCE_DIRS[source] / f"{args.split}.csv") for source in args.sources}
    raw_results: Dict[str, Dict[str, object]] = {}
    summary_rows: List[Dict[str, object]] = []

    for model_name, model_path in model_specs:
        for source in args.sources:
            result = evaluate_model(model_name, model_path, per_source_rows[source], args.batch_size, args.max_length)
            raw_results[f"{model_name}::{source}"] = result
            class_recalls = {label: float(result["classification_report"][label]["recall"]) for label in LABELS}
            best_class = max(class_recalls, key=class_recalls.get)
            worst_class = min(class_recalls, key=class_recalls.get)
            summary_rows.append(
                {
                    "model": model_name,
                    "source": source,
                    "accuracy": result["accuracy"],
                    "macro_f1": result["macro_f1"],
                    "weighted_f1": result["weighted_f1"],
                    "best_class": f"{best_class} ({class_recalls[best_class]:.3f})",
                    "worst_class": f"{worst_class} ({class_recalls[worst_class]:.3f})",
                }
            )
            print(f"{model_name} on {source}: accuracy={result['accuracy']:.4f}, macro_f1={result['macro_f1']:.4f}")

    deltas: List[Dict[str, object]] = []
    if len(model_specs) >= 2:
        left_model, right_model = model_specs[0][0], model_specs[1][0]
        for source in args.sources:
            left = raw_results[f"{left_model}::{source}"]
            right = raw_results[f"{right_model}::{source}"]
            left_recalls = {label: float(left["classification_report"][label]["recall"]) for label in LABELS}
            right_recalls = {label: float(right["classification_report"][label]["recall"]) for label in LABELS}
            recall_gaps = {label: right_recalls[label] - left_recalls[label] for label in LABELS}
            biggest_gap_class = max(recall_gaps, key=lambda key: abs(recall_gaps[key]))
            deltas.append(
                {
                    "source": source,
                    "left_model": left_model,
                    "right_model": right_model,
                    "delta_accuracy": float(right["accuracy"]) - float(left["accuracy"]),
                    "delta_macro_f1": float(right["macro_f1"]) - float(left["macro_f1"]),
                    "biggest_gap_class": f"{biggest_gap_class} ({recall_gaps[biggest_gap_class]:+.3f})",
                }
            )

    with (args.out_dir / "summary.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["model", "source", "accuracy", "macro_f1", "weighted_f1", "best_class", "worst_class"])
        writer.writeheader()
        writer.writerows(summary_rows)

    with (args.out_dir / "deltas.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["source", "left_model", "right_model", "delta_accuracy", "delta_macro_f1", "biggest_gap_class"])
        writer.writeheader()
        writer.writerows(deltas)

    with (args.out_dir / "raw_results.json").open("w", encoding="utf-8") as handle:
        json.dump(raw_results, handle, indent=2, ensure_ascii=False)

    with (args.out_dir / "report.html").open("w", encoding="utf-8") as handle:
        handle.write(build_html(summary_rows, deltas))

    print(f"Saved comparison artifacts to {args.out_dir}")


if __name__ == "__main__":
    main()
