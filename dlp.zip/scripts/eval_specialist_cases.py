import argparse
import csv
import json
import sys
from pathlib import Path

from sklearn.metrics import accuracy_score, f1_score

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.dlp_engine import DLPScanner  # noqa: E402


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate consensus DLP scanner on curated specialist leak cases.")
    parser.add_argument("--model_path", required=True, type=str)
    parser.add_argument("--aux_model_path", required=True, type=str)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/specialist_eval"))
    return parser.parse_args()


def build_cases() -> list[dict]:
    files = Path("data/test_samples/files")
    images = Path("data/test_samples/images")
    return [
        {"id": "bulk_bank_export", "mode": "file", "path": files / "13_critical_bulk_banking_export.csv", "expected": "CRITICAL"},
        {"id": "encrypted_archive", "mode": "file", "path": files / "14_high_encrypted_archive_backup.rar", "expected": "HIGH"},
        {"id": "password_dump", "mode": "file", "path": files / "15_critical_password_dump.txt", "expected": "CRITICAL"},
        {"id": "prod_env", "mode": "file", "path": files / "09_critical_prod_env.env", "expected": "CRITICAL"},
        {"id": "card_photo_svg", "mode": "file", "path": images / "17_high_card_photo.svg", "expected": "HIGH"},
        {"id": "ocr_split_card_svg", "mode": "file", "path": images / "18_high_ocr_split_card.svg", "expected": "HIGH"},
        {"id": "db_uri_svg", "mode": "file", "path": images / "19_critical_database_url.svg", "expected": "CRITICAL"},
        {
            "id": "bulk_text_export",
            "mode": "text",
            "text": (
                "name,email,phone,iin,iban,beneficiary\n"
                "demo-user Saparova,demo-user@corp.kz,+77011234567,970101123456,KZ439261501234567890,Kaspi client\n"
                "Dias Akhmetov,dias@corp.kz,+77021234567,980202654321,KZ129261501111222233,Payroll export"
            ),
            "expected": "CRITICAL",
        },
        {
            "id": "obfuscated_secret_dump",
            "mode": "text",
            "text": (
                "USB copy: env_dump.zip\n"
                "DATABASE URL=postgresql://admin:UltraSecretPass123@prod-db.company.kz:5432/prod\n"
                "token=EXAMPLE_GITHUB_TOKEN_DO_NOT_USE\n"
                "Bearer eyJhbGciOiJIUzI1NiJ9.abcdefghijklmnopqrstuvwxyz1234567890.signatureblock"
            ),
            "expected": "CRITICAL",
        },
        {
            "id": "safe_archive_manifest",
            "mode": "text",
            "text": "Archive manifest only: backup_demo_2026.zip contains release notes and deployment checklist. placeholder demo only.",
            "expected": "SAFE",
        },
    ]


def main() -> None:
    args = parse_args()
    scanner = DLPScanner(model_path=args.model_path, aux_model_path=args.aux_model_path)
    rows = []
    for case in build_cases():
        if case["mode"] == "file":
            result = scanner.scan_file(Path(case["path"]))
            payload = str(case["path"])
        else:
            result = scanner.scan_text(case["text"])
            payload = case["text"]
        rows.append(
            {
                "id": case["id"],
                "mode": case["mode"],
                "expected": case["expected"],
                "predicted": result.severity,
                "score": result.score,
                "summary": result.summary,
                "payload": payload[:400],
            }
        )

    y_true = [LABELS.index(row["expected"]) for row in rows]
    y_pred = [LABELS.index(row["predicted"]) for row in rows]
    summary = {
        "count": len(rows),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
    }

    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["id", "mode", "expected", "predicted", "score", "summary", "payload"])
        writer.writeheader()
        writer.writerows(rows)
    with (args.out_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    print(json.dumps(summary, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
