import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.dlp_engine import DLPScanner, serialize_result  # noqa: E402


CASES = [
    {"name": "masked_card_bundle", "text": "Payment card 4400 **** **** 9012 expiry 12/28 cvv 847", "min_severity": "HIGH"},
    {"name": "bank_account_context", "text": "Bank transfer details: account KZ439261501234567890 beneficiary demo-user Saparova", "min_severity": "HIGH"},
    {"name": "passport_context", "text": "Passport AB1234567 issued for client demo-user Saparova phone +0 000 000 00 07", "min_severity": "HIGH"},
    {"name": "ocr_split_card", "text": "payment card 44OO 1234\n5678 9O12 cvv 847", "min_severity": "HIGH"},
    {"name": "ocr_split_iban", "text": "iban KZ43 9261 5O12\n3456 789O beneficiary payroll", "min_severity": "HIGH"},
    {"name": "openai_spaced", "text": "OPENAI_API_KEY = sk - proj-abcdefghijklmnopqrstuvwx1234567890ABCDE", "min_severity": "CRITICAL"},
    {"name": "github_spaced", "text": "token leaked: gh p_abcdefghijklmnopqrstuvwxyz1234567890", "min_severity": "CRITICAL"},
    {"name": "sendgrid_token", "text": "SENDGRID_API_KEY=SG.abcdefghijklmnopqrstuvwxyz0123456789ABCD", "min_severity": "CRITICAL"},
    {"name": "google_api_key", "text": "google maps key AIza SyA1234567890abcdefghijklmnopqrs", "min_severity": "CRITICAL"},
    {"name": "telegram_token", "text": "telegram bot token EXAMPLE_TELEGRAM_BOT_TOKEN_DO_NOT_USE", "min_severity": "CRITICAL"},
    {"name": "slack_webhook", "text": "notify hook https://hooks.slack.com/services/T000/B000/abcdefghijklmnopqrstuvwxyz123456", "min_severity": "CRITICAL"},
    {"name": "discord_webhook", "text": "discord webhook https://discord.example.test/webhook/EXAMPLE_DO_NOT_USE", "min_severity": "CRITICAL"},
    {"name": "aws_secret", "text": "AWS_SECRET_ACCESS_KEY = ABCDEFGHIJKLMNOPQRSTUVWXYZabcd1234567890/+", "min_severity": "CRITICAL"},
    {"name": "password_assignment", "text": "prod credentials password = EXAMPLE_PASSWORD_DO_NOT_USE client_secret=EXAMPLE_CLIENT_SECRET_DO_NOT_USE", "min_severity": "CRITICAL"},
    {"name": "safe_demo_account", "text": "Reference account TEST-ONLY-123456 for demo only", "expected_severity": "SAFE"},
    {"name": "safe_placeholder_secret", "text": "example only password=example123 placeholder token=demo-token-value", "expected_severity": "SAFE"},
    {"name": "safe_numeric_noise", "text": "Weekly metrics 1234 5678 9012 3456 and deployment ref only", "expected_severity": "SAFE"},
]

RANK = {"SAFE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


def main() -> None:
    scanner = DLPScanner(
        model_path=str(ROOT / "models" / "dlp_bert_joint_v3"),
        aux_model_path=str(ROOT / "models" / "dlp_bert_joint_v3_boost_v1"),
    )
    outputs = []
    failures = []
    for case in CASES:
        result = serialize_result(scanner.scan_text(case["text"]))
        outputs.append({"name": case["name"], "result": result})
        if "expected_severity" in case and result["severity"] != case["expected_severity"]:
            failures.append({"name": case["name"], "expected": case["expected_severity"], "actual": result["severity"]})
        if "min_severity" in case and RANK[result["severity"]] < RANK[case["min_severity"]]:
            failures.append({"name": case["name"], "expected_min": case["min_severity"], "actual": result["severity"]})
    print(json.dumps({"failures": failures, "outputs": outputs}, indent=2, ensure_ascii=False))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
