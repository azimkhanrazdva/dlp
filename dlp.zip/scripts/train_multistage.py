import argparse
import sys
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
if str(THIS_DIR) not in sys.path:
    sys.path.insert(0, str(THIS_DIR))

from train import main as train_main


TASK_TO_DIR = {
    "stage1": Path("data/processed/stage1_risk"),
    "stage2": Path("data/processed/stage2_severity"),
    "stage3": Path("data/processed/stage3_secret"),
}

TASK_TO_OUTPUT = {
    "stage1": Path("models/dlp_stage1_risk"),
    "stage2": Path("models/dlp_stage2_severity"),
    "stage3": Path("models/dlp_stage3_secret"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Wrapper for training multi-stage DLP models.")
    parser.add_argument("--task", choices=["stage1", "stage2", "stage3"], required=True)
    parser.add_argument("--base_model", type=str, default="bert-base-multilingual-cased")
    parser.add_argument("--output_dir", type=Path, default=None)
    parser.add_argument("--epochs", type=float, default=3.0)
    parser.add_argument("--train_batch_size", type=int, default=16)
    parser.add_argument("--eval_batch_size", type=int, default=32)
    parser.add_argument("--learning_rate", type=float, default=2e-5)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--resume_from", type=str, default=None)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    output_dir = args.output_dir or TASK_TO_OUTPUT[args.task]

    sys.argv = [
        "train.py",
        "--source",
        "joint",
        "--data_dir",
        str(TASK_TO_DIR[args.task]),
        "--base_model",
        args.base_model,
        "--output_dir",
        str(output_dir),
        "--epochs",
        str(args.epochs),
        "--train_batch_size",
        str(args.train_batch_size),
        "--eval_batch_size",
        str(args.eval_batch_size),
        "--learning_rate",
        str(args.learning_rate),
    ]
    if args.resume:
        sys.argv.append("--resume")
    if args.resume_from:
        sys.argv.extend(["--resume_from", args.resume_from])
    train_main()
