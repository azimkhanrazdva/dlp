import argparse
import csv
import random
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
NAMES = ["Aruzhan Saparova", "Dias Akhmetov", "Madina Tulegenova", "Yerlan Omarov", "Kamila Iskakova", "Aidos Nurgaliyev"]
BANKS = ["Kaspi", "Halyk", "Forte", "Jusan", "CenterCredit", "Freedom"]


@dataclass
class Sample:
    text: str
    label: str
    source: str
    sample_type: str


def read_rows(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_rows(path: Path, rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["text", "label", "source", "sample_type"])
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "text": row["text"],
                    "label": row["label"],
                    "source": row.get("source", "boost"),
                    "sample_type": row.get("sample_type", "boost"),
                }
            )


def digits(rng: random.Random, n: int) -> str:
    return "".join(rng.choices("0123456789", k=n))


def token(rng: random.Random, prefix: str, size: int) -> str:
    return prefix + "".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=size))


def jwt(rng: random.Random) -> str:
    return ".".join("".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=n)) for n in [24, 72, 32])


def noise(rng: random.Random, alphabet: str, min_len: int, max_len: int) -> str:
    return "".join(rng.choices(alphabet, k=rng.randint(min_len, max_len)))


def obfuscate(text: str, rng: random.Random) -> str:
    text = text.replace("@", " [at] ").replace(".", " [dot] ")
    text = text.replace("Bearer ", rng.choice(["Bearer ", "Bearer\t", "Bearer  "]))
    if rng.random() < 0.5:
        text = text.replace("DATABASE_URL", "DATABASE URL")
    if rng.random() < 0.5:
        text = text.replace("SECRET_KEY", "SEC RET KEY")
    if rng.random() < 0.5:
        text = text.replace("token", "tok en").replace("Token", "Tok en")
    return text


def safe_entropy_blob(rng: random.Random) -> Sample:
    return Sample(
        text=(
            f"cache blob {noise(rng, 'abcdefghijklmnopqrstuvwxyz0123456789', 36, 84)} "
            f"{noise(rng, 'abcdef0123456789', 32, 80)} generated for parser benchmark only"
        ),
        label="SAFE",
        source="boost",
        sample_type="safe_entropy_blob",
    )


def safe_ocr_noise(rng: random.Random) -> Sample:
    return Sample(
        text=f"harmless OCR garbage {noise(rng, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 28, 52)} I1O0S5 placeholder screenshot only",
        label="SAFE",
        source="boost",
        sample_type="safe_ocr_noise",
    )


def safe_fake_secret_doc(rng: random.Random) -> Sample:
    return Sample(
        text=(
            f"Runbook example only: DATABASE_URL=postgresql://demo_user:example_{digits(rng, 4)}@sandbox.local:5432/demo "
            "OPENAI_API_KEY=your_key_here GITHUB_TOKEN=<paste-token-here>"
        ),
        label="SAFE",
        source="boost",
        sample_type="safe_fake_secret_doc",
    )


def low_contact(rng: random.Random) -> Sample:
    return Sample(
        text=f"Attachment comment: please contact user{rng.randint(1,999)}@example.com for the next review cycle.",
        label="LOW",
        source="boost",
        sample_type="low_contact",
    )


def medium_attachment(rng: random.Random) -> Sample:
    return Sample(
        text=(
            f"Attachment contacts.xlsx contains {rng.choice(NAMES)}, user{rng.randint(1,999)}@example.com, "
            f"+7 701 {digits(rng,3)} {digits(rng,2)} {digits(rng,2)}."
        ),
        label="MEDIUM",
        source="boost",
        sample_type="medium_attachment",
    )


def high_export(rng: random.Random) -> Sample:
    return Sample(
        text=(
            f"External send review: payroll_export_{digits(rng,3)}.xlsx employee {rng.choice(NAMES)} "
            f"IIN {digits(rng,12)} salary {rng.randint(250000,900000)} KZT bank {rng.choice(BANKS)}."
        ),
        label="HIGH",
        source="boost",
        sample_type="high_export",
    )


def critical_obfuscated_secret(rng: random.Random) -> Sample:
    text = rng.choice(
        [
            f"Internal note. DATABASE_URL=postgresql://admin:{token(rng, '', 30)}@prod-db.company.kz:5432/prod Проверить срочно.",
            f"Internal note. GitHub token exposed: {token(rng, 'ghp_', 36)} Проверить срочно.",
            f"Internal note. Authorization: Bearer {jwt(rng)} Проверить срочно.",
            f"Internal note. OpenAI key leaked: {token(rng, 'sk-proj-', 42)} trace={token(rng, '', 24)} Проверить срочно.",
            f"Attachment env_dump.txt SECRET_KEY={token(rng, '', 28)} DATABASE_URL=postgresql://admin:{token(rng, '', 18)}@prod-db.company.kz:5432/prod",
            f"USB copy detected: finance_backup.zip -> Bearer {jwt(rng)}",
        ]
    )
    return Sample(text=obfuscate(text, rng), label="CRITICAL", source="boost", sample_type="critical_obfuscated_secret")


TARGETED_GENERATORS = {
    "SAFE": [safe_entropy_blob, safe_ocr_noise, safe_fake_secret_doc],
    "LOW": [low_contact],
    "MEDIUM": [medium_attachment],
    "HIGH": [high_export],
    "CRITICAL": [critical_obfuscated_secret],
}


def generate_targeted(counts: Dict[str, int], rng: random.Random) -> List[dict]:
    rows: List[dict] = []
    for label, count in counts.items():
        for _ in range(count):
            sample = rng.choice(TARGETED_GENERATORS[label])(rng)
            rows.append(
                {
                    "text": sample.text,
                    "label": sample.label,
                    "source": sample.source,
                    "sample_type": sample.sample_type,
                }
            )
    rng.shuffle(rows)
    return rows


def summarize(rows: Iterable[dict]) -> Dict[str, int]:
    counts = Counter((row.get("label") or "").upper() for row in rows)
    return {label: counts.get(label, 0) for label in LABELS}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Augment joint_v3 with targeted boost examples.")
    parser.add_argument("--base_dir", type=Path, default=Path("data/processed/joint_v3"))
    parser.add_argument("--out_dir", type=Path, default=Path("data/processed/joint_v3_boost_v1"))
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    configs = {
        "train": {"SAFE": 2500, "LOW": 300, "MEDIUM": 500, "HIGH": 700, "CRITICAL": 2500},
        "val": {"SAFE": 500, "LOW": 60, "MEDIUM": 100, "HIGH": 140, "CRITICAL": 500},
        "test": {"SAFE": 500, "LOW": 60, "MEDIUM": 100, "HIGH": 140, "CRITICAL": 500},
    }
    for split, counts in configs.items():
        base_rows = read_rows(args.base_dir / f"{split}.csv")
        targeted_rows = generate_targeted(counts, rng)
        merged = base_rows + targeted_rows
        rng.shuffle(merged)
        write_rows(args.out_dir / f"{split}.csv", merged)
        print(
            f"{split}: base={summarize(base_rows)} targeted={summarize(targeted_rows)} "
            f"merged={summarize(merged)} -> {args.out_dir / f'{split}.csv'}"
        )


if __name__ == "__main__":
    main()
