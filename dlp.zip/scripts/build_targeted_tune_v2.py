import argparse
import csv
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
TARGET_SAMPLE_TYPES = {
    "SAFE": {
        "safe_archive_training",
        "safe_attachment_manifest",
        "safe_usb_admin",
        "safe_fragmented_noise",
        "safe_fake_db_uri",
    },
    "HIGH": {
        "high_bulk_bank_export",
        "high_ocr_card_scan",
        "high_attachment_export",
        "high_ocr_sensitive",
        "high_iban",
        "high_card",
    },
    "CRITICAL": {
        "critical_bulk_credential_dump",
        "critical_encrypted_archive",
        "critical_attachment_secret",
        "critical_ocr_secret",
        "critical_usb_export",
        "critical_db",
        "critical_openai",
        "critical_github",
    },
}


def read_rows(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    out = []
    for row in rows:
        text = (row.get("text") or "").strip()
        label = (row.get("label") or "").strip().upper()
        if text and label in LABELS:
            row["label"] = label
            out.append(row)
    return out


def write_rows(path: Path, rows: List[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["text", "label", "source", "sample_type"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "text": row.get("text", ""),
                    "label": row.get("label", ""),
                    "source": row.get("source", "targeted_tune_v2"),
                    "sample_type": row.get("sample_type", "targeted_tune_v2"),
                }
            )


def summarize(rows: Iterable[dict]) -> Dict[str, int]:
    counts = Counter((row.get("label") or "").upper() for row in rows)
    return {label: counts.get(label, 0) for label in LABELS}


def select_targeted(rows: List[dict], target_counts: Dict[str, int], rng: random.Random) -> List[dict]:
    grouped: Dict[str, List[dict]] = defaultdict(list)
    for row in rows:
        label = row["label"]
        sample_type = row.get("sample_type", "")
        if sample_type in TARGET_SAMPLE_TYPES.get(label, set()):
            grouped[label].append(dict(row))
    selected: List[dict] = []
    for label, count in target_counts.items():
        pool = grouped.get(label, [])
        if not pool:
            continue
        rng.shuffle(pool)
        if len(pool) >= count:
            selected.extend(pool[:count])
        else:
            expanded = []
            while len(expanded) < count:
                batch = [dict(item) for item in pool]
                rng.shuffle(batch)
                expanded.extend(batch)
            selected.extend(expanded[:count])
    return selected


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build targeted tune dataset from joint_v3 base and v5 hard cases.")
    parser.add_argument("--base_dir", type=Path, default=Path("data/processed/joint_v3"))
    parser.add_argument("--augment_dir", type=Path, default=Path("data/processed/synth_v5"))
    parser.add_argument("--out_dir", type=Path, default=Path("data/processed/targeted_tune_v2"))
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    configs = {
        "train": {"SAFE": 1800, "HIGH": 2200, "CRITICAL": 2600},
        "val": {"SAFE": 360, "HIGH": 440, "CRITICAL": 520},
        "test": {"SAFE": 360, "HIGH": 440, "CRITICAL": 520},
    }
    for split, counts in configs.items():
        base_rows = read_rows(args.base_dir / f"{split}.csv")
        augment_rows = read_rows(args.augment_dir / f"{split}.csv")
        selected = select_targeted(augment_rows, counts, rng)
        merged = base_rows + selected
        rng.shuffle(merged)
        write_rows(args.out_dir / f"{split}.csv", merged)
        print(
            f"{split}: base={summarize(base_rows)} targeted={summarize(selected)} "
            f"merged={summarize(merged)} -> {args.out_dir / f'{split}.csv'}"
        )


if __name__ == "__main__":
    main()
