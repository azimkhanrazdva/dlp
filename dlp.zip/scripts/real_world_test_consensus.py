import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

from docx import Document
from sklearn.metrics import f1_score

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.dlp_engine import DLPScanner  # noqa: E402
from scripts.real_world_test import LABELS, generate  # noqa: E402


def write_docx(path: Path, summary: dict, examples: list[dict]) -> None:
    doc = Document()
    doc.add_heading("Consensus Real World DLP Test Report", level=1)
    for key in ["count", "accuracy", "macro_f1", "weighted_f1"]:
        doc.add_paragraph(f"{key}: {summary[key]}")
    doc.add_paragraph(f"expected_distribution: {summary['expected_distribution']}")
    doc.add_paragraph(f"pred_distribution: {summary['pred_distribution']}")
    doc.add_heading("Examples", level=2)
    for item in examples:
        doc.add_paragraph(f"Expected={item['expected_label']} Predicted={item['pred_label']} Score={item['score']}\n{item['text']}")
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run real-world mixed DLP test with consensus scanner.")
    parser.add_argument("--model_path", required=True, type=str)
    parser.add_argument("--aux_model_path", required=True, type=str)
    parser.add_argument("--count", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/real_world_consensus"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scanner = DLPScanner(model_path=args.model_path, aux_model_path=args.aux_model_path)
    rows = generate(args.count, args.seed)
    out_rows = []
    expected = Counter()
    predicted = Counter()
    for row in rows:
        result = scanner.scan_text(row["text"])
        pred = result.severity
        expected[row["expected_label"]] += 1
        predicted[pred] += 1
        out_rows.append({**row, "pred_label": pred, "score": float(result.score)})
    y_true = [LABELS.index(x["expected_label"]) for x in out_rows]
    y_pred = [LABELS.index(x["pred_label"]) for x in out_rows]
    summary = {
        "count": len(out_rows),
        "accuracy": sum(1 for x in out_rows if x["expected_label"] == x["pred_label"]) / max(1, len(out_rows)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "expected_distribution": dict(expected),
        "pred_distribution": dict(predicted),
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["expected_label", "pred_label", "score", "sample_type", "language", "text"])
        writer.writeheader()
        writer.writerows(out_rows)
    with (args.out_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    examples = [x for x in out_rows if x["expected_label"] != x["pred_label"]][:20] or out_rows[:20]
    write_docx(args.out_dir / "real_world_report.docx", summary, examples)
    print(json.dumps(summary, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
