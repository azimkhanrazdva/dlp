from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def load_font(name: str, size: int, bold: bool = False):
    candidates = []
    if bold:
        candidates.extend(["arialbd.ttf", "seguisb.ttf", "calibrib.ttf"])
    else:
        candidates.extend(["arial.ttf", "segoeui.ttf", "calibri.ttf"])
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            continue
    return ImageFont.load_default()


def rounded_box(draw, box, fill, outline=None, radius=18, width=2):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def centered_text(draw, box, text, font, fill, line_spacing=6):
    x1, y1, x2, y2 = box
    lines = text.split("\n")
    line_heights = []
    widths = []
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        widths.append(bbox[2] - bbox[0])
        line_heights.append(bbox[3] - bbox[1])
    total_height = sum(line_heights) + max(0, len(lines) - 1) * line_spacing
    y = y1 + (y2 - y1 - total_height) / 2
    for line, w, h in zip(lines, widths, line_heights):
        x = x1 + (x2 - x1 - w) / 2
        draw.text((x, y), line, font=font, fill=fill)
        y += h + line_spacing


def draw_arrow(draw, start, end, fill, width=4, head=12):
    draw.line((start, end), fill=fill, width=width)
    x1, y1 = start
    x2, y2 = end
    if abs(x2 - x1) > abs(y2 - y1):
        if x2 >= x1:
            pts = [(x2, y2), (x2 - head, y2 - head // 2), (x2 - head, y2 + head // 2)]
        else:
            pts = [(x2, y2), (x2 + head, y2 - head // 2), (x2 + head, y2 + head // 2)]
    else:
        if y2 >= y1:
            pts = [(x2, y2), (x2 - head // 2, y2 - head), (x2 + head // 2, y2 - head)]
        else:
            pts = [(x2, y2), (x2 - head // 2, y2 + head), (x2 + head // 2, y2 + head)]
    draw.polygon(pts, fill=fill)


def label(draw, pos, text, font, fill, bg=None):
    bbox = draw.textbbox((0, 0), text, font=font)
    x, y = pos
    pad_x, pad_y = 10, 6
    if bg:
        draw.rounded_rectangle(
            (x, y, x + (bbox[2] - bbox[0]) + pad_x * 2, y + (bbox[3] - bbox[1]) + pad_y * 2),
            radius=10,
            fill=bg,
        )
        draw.text((x + pad_x, y + pad_y), text, font=font, fill=fill)
    else:
        draw.text((x, y), text, font=font, fill=fill)


def main() -> None:
    width, height = 1900, 980
    bg = "#f5f7fb"
    dark = "#101828"
    navy = "#0f172a"
    border = "#243042"
    line = "#1f2937"
    text = "#111827"
    muted = "#475467"
    light_panel = "#ffffff"
    soft = "#d0d5dd"
    accent = "#1d4ed8"

    image = Image.new("RGB", (width, height), bg)
    draw = ImageDraw.Draw(image)

    title_font = load_font("arialbd.ttf", 36, bold=True)
    section_font = load_font("arialbd.ttf", 21, bold=True)
    box_font = load_font("arial.ttf", 20)
    dark_box_font = load_font("arialbd.ttf", 19, bold=True)
    small_font = load_font("arial.ttf", 16)
    tiny_font = load_font("arial.ttf", 14)

    draw.text((56, 28), "SecureMail AI-DLP Architecture", font=title_font, fill=text)
    draw.text((58, 74), "Integrated AI-based leakage detection platform for web communications and Windows endpoints", font=box_font, fill=muted)

    # Outer system boundary
    system = (180, 185, 1835, 920)
    rounded_box(draw, system, fill=(245, 247, 251), outline=soft, radius=20, width=3)
    label(draw, (950, 162), "SecureMail AI-DLP Platform", section_font, text, bg="#e5e7eb")

    # External systems
    ext = (875, 105, 1215, 300)
    rounded_box(draw, ext, fill="#f8fafc", outline=soft, radius=16, width=3)
    centered_text(draw, (875, 114, 1215, 146), "External Systems", section_font, text)

    ext1 = (915, 155, 1175, 220)
    ext2 = (915, 235, 1175, 285)
    rounded_box(draw, ext1, fill=navy, outline=border, radius=10)
    rounded_box(draw, ext2, fill=navy, outline=border, radius=10)
    centered_text(draw, ext1, "Corporate messages / files\nEmails, images, archives", dark_box_font, "#f8fafc")
    centered_text(draw, ext2, "Endpoint events\nUSB, clipboard, filesystem", dark_box_font, "#f8fafc")

    # Left user side
    user_box = (30, 455, 135, 520)
    rounded_box(draw, user_box, fill=navy, outline=border, radius=10)
    centered_text(draw, user_box, "Users /\nAdmins", dark_box_font, "#f8fafc")

    # Web app
    web_box = (205, 435, 405, 535)
    rounded_box(draw, web_box, fill=navy, outline=border, radius=10)
    centered_text(draw, web_box, "Web Platform\nFlask UI + Admin Panel", dark_box_font, "#f8fafc")

    # Windows app
    win_box = (205, 620, 405, 720)
    rounded_box(draw, win_box, fill=navy, outline=border, radius=10)
    centered_text(draw, win_box, "Windows Control Center\nConfig + Service + Logs", dark_box_font, "#f8fafc")

    # API
    api_box = (1285, 350, 1470, 440)
    rounded_box(draw, api_box, fill=navy, outline=border, radius=10)
    centered_text(draw, api_box, "Backend API\nFlask REST", dark_box_font, "#f8fafc")

    # AI core
    ai_box = (980, 520, 1270, 655)
    rounded_box(draw, ai_box, fill=navy, outline=border, radius=12)
    centered_text(
        draw,
        ai_box,
        "AI-DLP Core\nmBERT classifier + specialist model\nrules + OCR + file parsers",
        dark_box_font,
        "#f8fafc",
    )

    # Policy/governance
    policy_box = (1285, 515, 1565, 655)
    rounded_box(draw, policy_box, fill=navy, outline=border, radius=12)
    centered_text(
        draw,
        policy_box,
        "Policy & Governance\nseverity decision\nincident creation\nprivacy-preserving access",
        dark_box_font,
        "#f8fafc",
    )

    # Agent
    agent_box = (495, 625, 790, 735)
    rounded_box(draw, agent_box, fill=navy, outline=border, radius=12)
    centered_text(
        draw,
        agent_box,
        "Endpoint Agent\nclipboard, USB, filesystem,\nprocess context monitoring",
        dark_box_font,
        "#f8fafc",
    )

    # Message/file extraction
    ingestion_box = (520, 365, 815, 460)
    rounded_box(draw, ingestion_box, fill=light_panel, outline=soft, radius=12, width=2)
    centered_text(
        draw,
        ingestion_box,
        "Content Extraction Layer\ntext normalization, attachment parsing,\nOCR and archive inspection",
        section_font,
        text,
    )

    # Database
    db_box = (1630, 470, 1810, 650)
    draw.ellipse((1630, 470, 1810, 535), fill=navy, outline=border, width=2)
    draw.rectangle((1630, 502, 1810, 618), fill=navy, outline=border, width=2)
    draw.ellipse((1630, 585, 1810, 650), fill=navy, outline=border, width=2)
    centered_text(
        draw,
        (1640, 516, 1800, 608),
        "Storage Layer\nSQLite / PostgreSQL\naccounts, incidents,\nmessages, audits,\nagents, devices",
        dark_box_font,
        "#f8fafc",
    )

    # Labels
    label(draw, (430, 454), "HTTP(S)", small_font, text, bg="#e5e7eb")
    label(draw, (430, 655), "Local setup / service control", small_font, text, bg="#e5e7eb")
    label(draw, (838, 385), "message body / attachments", small_font, text, bg="#e5e7eb")
    label(draw, (822, 662), "agent events", small_font, text, bg="#e5e7eb")
    label(draw, (1280, 675), "block / allow / restrict / audit", small_font, text, bg="#e5e7eb")
    label(draw, (1490, 377), "read / write", small_font, text, bg="#e5e7eb")
    label(draw, (1195, 312), "external communication inputs", small_font, text, bg="#e5e7eb")

    # Arrows
    draw_arrow(draw, (135, 487), (205, 487), line)
    draw_arrow(draw, (405, 487), (520, 412), line)
    draw_arrow(draw, (405, 670), (495, 680), line)
    draw_arrow(draw, (790, 680), (980, 590), line)
    draw_arrow(draw, (815, 412), (1285, 395), line)
    draw_arrow(draw, (1215, 205), (1368, 350), line)
    draw_arrow(draw, (1215, 260), (1125, 520), line)
    draw_arrow(draw, (1270, 590), (1285, 590), line)
    draw_arrow(draw, (1565, 590), (1630, 560), line)
    draw_arrow(draw, (1470, 395), (1630, 530), line)
    draw_arrow(draw, (1630, 618), (1490, 640), line)
    draw_arrow(draw, (1490, 640), (1490, 655), line)
    draw_arrow(draw, (1565, 560), (1470, 430), line)

    # Footer notes
    note_box = (205, 770, 1750, 885)
    rounded_box(draw, note_box, fill="#eef2ff", outline="#c7d2fe", radius=14, width=2)
    draw.text((230, 795), "Core implementation logic", font=section_font, fill=accent)
    notes = [
        "1. Web users send messages or files through the platform; endpoint users generate local events through the Windows agent.",
        "2. Content is extracted and normalized before being processed by the AI-DLP core.",
        "3. The AI layer combines multilingual BERT, specialist secret detection, and deterministic risk indicators.",
        "4. Policy and governance logic decides whether to allow, block, restrict, or escalate content as an incident.",
        "5. Storage keeps only the required operational and audit data, while sensitive endpoint content is retained only for critical cases.",
    ]
    y = 825
    for note in notes:
        draw.text((232, y), note, font=small_font, fill=text)
        y += 24

    out_dir = Path("presentation_package_max/assets")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "defense_architecture_detailed.png"
    image.save(out_path)
    print(out_path)


if __name__ == "__main__":
    main()
