import argparse
import csv
import random
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Sequence


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
TARGET_TYPES = {
    "SAFE": {
        "safe_archive_training",
        "safe_attachment_manifest",
        "safe_usb_admin",
        "safe_fragmented_noise",
        "safe_fake_db_uri",
        "safe_entropy_blob",
        "safe_ocr_noise",
        "safe_fake_secret_doc",
    },
    "LOW": {"low_contact"},
    "MEDIUM": {"medium_attachment"},
    "HIGH": {
        "high_bulk_bank_export",
        "high_ocr_card_scan",
        "high_attachment_export",
        "high_ocr_sensitive",
        "high_iban",
        "high_card",
        "high_export",
    },
    "CRITICAL": {
        "critical_bulk_credential_dump",
        "critical_encrypted_archive",
        "critical_attachment_secret",
        "critical_ocr_secret",
        "critical_usb_export",
        "critical_db",
        "critical_openai",
        "critical_github",
        "critical_obfuscated_secret",
    },
}


def read_rows(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_rows(path: Path, rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["text", "label", "source", "sample_type"])
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "text": row["text"],
                    "label": row["label"],
                    "source": row.get("source", "boost_v2"),
                    "sample_type": row.get("sample_type", "boost_v2"),
                }
            )


def summarize(rows: Iterable[dict]) -> Dict[str, int]:
    counts = Counter((row.get("label") or "").upper() for row in rows)
    return {label: counts.get(label, 0) for label in LABELS}


def select_targeted(rows: List[dict], limits: Dict[str, int], rng: random.Random) -> List[dict]:
    buckets: Dict[str, List[dict]] = {label: [] for label in LABELS}
    for row in rows:
        label = (row.get("label") or "").upper()
        sample_type = row.get("sample_type") or ""
        if label not in buckets:
            continue
        if sample_type in TARGET_TYPES.get(label, set()):
            buckets[label].append(row)
    selected: List[dict] = []
    for label, items in buckets.items():
        rng.shuffle(items)
        selected.extend(items[: limits.get(label, 0)])
    return selected


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build boost_v2 dataset specialized for bank exports and protected leaks.")
    parser.add_argument("--base_dir", type=Path, default=Path("data/processed/joint_v3"))
    parser.add_argument("--augment_dir", type=Path, default=Path("data/processed/synth_v5"))
    parser.add_argument("--out_dir", type=Path, default=Path("data/processed/joint_v3_boost_v2"))
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    limits = {
        "train": {"SAFE": 2600, "LOW": 200, "MEDIUM": 300, "HIGH": 3400, "CRITICAL": 3600},
        "val": {"SAFE": 520, "LOW": 40, "MEDIUM": 60, "HIGH": 680, "CRITICAL": 720},
        "test": {"SAFE": 520, "LOW": 40, "MEDIUM": 60, "HIGH": 680, "CRITICAL": 720},
    }
    for split, per_label in limits.items():
        base_rows = read_rows(args.base_dir / f"{split}.csv")
        augment_rows = read_rows(args.augment_dir / f"{split}.csv")
        targeted = select_targeted(augment_rows, per_label, rng)
        merged = base_rows + targeted
        rng.shuffle(merged)
        write_rows(args.out_dir / f"{split}.csv", merged)
        print(
            f"{split}: base={summarize(base_rows)} targeted={summarize(targeted)} "
            f"merged={summarize(merged)} -> {args.out_dir / f'{split}.csv'}"
        )


if __name__ == "__main__":
    main()
