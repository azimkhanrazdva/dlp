import argparse
import csv
import random
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Sequence


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
NAMES = ["Aruzhan Saparova", "Dias Akhmetov", "Madina Tulegenova", "Yerlan Omarov", "Kamila Iskakova", "Aidos Nurgaliyev"]
BANKS = ["Kaspi", "Halyk", "Forte", "Jusan", "CenterCredit", "Freedom"]


@dataclass
class Sample:
    text: str
    label: str
    source: str
    sample_type: str


def digits(rng: random.Random, n: int) -> str:
    return "".join(rng.choices("0123456789", k=n))


def secret(rng: random.Random, prefix: str, size: int = 36) -> str:
    return prefix + "".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=size))


def jwt(rng: random.Random) -> str:
    return ".".join("".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=n)) for n in [24, 72, 32])


def noise(rng: random.Random, alphabet: str, min_len: int, max_len: int) -> str:
    return "".join(rng.choices(alphabet, k=rng.randint(min_len, max_len)))


def obfuscate(text: str, rng: random.Random) -> str:
    text = text.replace("@", " [at] ").replace(".", " [dot] ")
    if rng.random() < 0.5:
        text = text.replace("Bearer ", "Bearer\t")
    if rng.random() < 0.5:
        text = text.replace("SECRET", "SEC RET").replace("TOKEN", "TOK EN")
    return text


def safe_entropy_blob(rng: random.Random) -> Sample:
    return Sample(
        f"cache blob {noise(rng, 'abcdefghijklmnopqrstuvwxyz0123456789', 24, 64)} {noise(rng, 'abcdef0123456789', 32, 72)} generated for parser benchmark only",
        "SAFE",
        "hard_tune",
        "safe_entropy_blob",
    )


def safe_ocr_noise(rng: random.Random) -> Sample:
    return Sample(
        f"harmless OCR garbage {noise(rng, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 24, 44)} I1O0S5 placeholder screenshot only",
        "SAFE",
        "hard_tune",
        "safe_ocr_noise",
    )


def safe_fake_secret_doc(rng: random.Random) -> Sample:
    return Sample(
        f"Runbook example only: DATABASE_URL=postgresql://demo_user:example_{digits(rng,4)}@sandbox.local:5432/demo OPENAI_API_KEY=your_key_here",
        "SAFE",
        "hard_tune",
        "safe_fake_secret_doc",
    )


def low_contact(rng: random.Random) -> Sample:
    return Sample(
        f"Attachment comment: please contact user{rng.randint(1,999)}@example.com for the next review cycle.",
        "LOW",
        "hard_tune",
        "low_contact",
    )


def medium_attachment(rng: random.Random) -> Sample:
    return Sample(
        f"Attachment contacts.xlsx contains {rng.choice(NAMES)}, user{rng.randint(1,999)}@example.com, +7 701 {digits(rng,3)} {digits(rng,2)} {digits(rng,2)}.",
        "MEDIUM",
        "hard_tune",
        "medium_attachment",
    )


def high_export(rng: random.Random) -> Sample:
    return Sample(
        f"External send review: payroll_export_{digits(rng,3)}.xlsx employee {rng.choice(NAMES)} IIN {digits(rng,12)} salary {rng.randint(250000,900000)} KZT bank {rng.choice(BANKS)}.",
        "HIGH",
        "hard_tune",
        "high_export",
    )


def critical_obfuscated_secret(rng: random.Random) -> Sample:
    text = rng.choice([
        f"OpenAI key leaked: {secret(rng, 'sk-proj-', 42)}",
        f"GitHub token exposed: {secret(rng, 'ghp_', 36)}",
        f"Authorization: Bearer {jwt(rng)}",
        f"DATABASE_URL=postgresql://admin:{secret(rng, '', 24)}@prod-db.company.kz:5432/prod",
        f"Attachment env_dump.txt SECRET_KEY={secret(rng, '', 28)} DATABASE_URL=postgresql://admin:{secret(rng, '', 18)}@prod-db.company.kz:5432/prod",
        f"USB copy detected: finance_backup.zip -> Bearer {jwt(rng)}",
    ])
    return Sample(obfuscate(text, rng), "CRITICAL", "hard_tune", "critical_obfuscated_secret")


GENERATORS = {
    "SAFE": [safe_entropy_blob, safe_ocr_noise, safe_fake_secret_doc],
    "LOW": [low_contact],
    "MEDIUM": [medium_attachment],
    "HIGH": [high_export],
    "CRITICAL": [critical_obfuscated_secret],
}


def build_split(counts: Dict[str, int], rng: random.Random) -> List[Sample]:
    rows: List[Sample] = []
    for label, count in counts.items():
        for _ in range(count):
            rows.append(rng.choice(GENERATORS[label])(rng))
    rng.shuffle(rows)
    return rows


def write_csv(path: Path, rows: Sequence[Sample]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["text", "label", "source", "sample_type"])
        writer.writeheader()
        for row in rows:
            writer.writerow({"text": row.text, "label": row.label, "source": row.source, "sample_type": row.sample_type})


def summarize(rows: Sequence[Sample]) -> Dict[str, int]:
    counts = Counter(row.label for row in rows)
    return {label: counts.get(label, 0) for label in LABELS}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build hard-negative tuning dataset for post-training calibration.")
    parser.add_argument("--out_dir", type=Path, default=Path("data/processed/hard_negative_tune_v1"))
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    configs = {
        "train": {"SAFE": 6000, "LOW": 1000, "MEDIUM": 1500, "HIGH": 2000, "CRITICAL": 4500},
        "val": {"SAFE": 1200, "LOW": 200, "MEDIUM": 300, "HIGH": 400, "CRITICAL": 900},
        "test": {"SAFE": 1200, "LOW": 200, "MEDIUM": 300, "HIGH": 400, "CRITICAL": 900},
    }
    for split, counts in configs.items():
        rows = build_split(counts, rng)
        write_csv(args.out_dir / f"{split}.csv", rows)
        print(f"{split}: {summarize(rows)} -> {args.out_dir / f'{split}.csv'}")


if __name__ == "__main__":
    main()
