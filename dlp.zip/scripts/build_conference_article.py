import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt


ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "conference_assets"
OUTPUT = ROOT / "conference_article_package"


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_default_font(document: Document) -> None:
    style = document.styles["Normal"]
    style.font.name = "Times New Roman"
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    style.font.size = Pt(12)


def add_paragraph(document: Document, text: str = "", *, bold: bool = False, italic: bool = False, align=WD_ALIGN_PARAGRAPH.JUSTIFY, spacing_after=0) -> None:
    p = document.add_paragraph()
    p.alignment = align
    p.paragraph_format.space_after = Pt(spacing_after)
    p.paragraph_format.line_spacing = 1.0
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    run.font.size = Pt(12)


def save_class_f1_figure(eval_metrics: dict, out_path: Path) -> None:
    report = eval_metrics["classification_report"]
    labels = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    values = [report[label]["f1-score"] * 100 for label in labels]
    colors = ["#5B8FF9", "#61DDAA", "#F6BD16", "#F08BB4", "#7262FD"]

    plt.figure(figsize=(8.2, 4.8))
    bars = plt.bar(labels, values, color=colors, edgecolor="#1f2937", linewidth=0.8)
    plt.ylim(85, 101)
    plt.ylabel("F1-score (%)")
    plt.title("Per-Class F1-score of SecureMail AI-DLP")
    plt.grid(axis="y", linestyle="--", alpha=0.3)
    for bar, value in zip(bars, values):
        plt.text(bar.get_x() + bar.get_width() / 2, value + 0.15, f"{value:.2f}", ha="center", va="bottom", fontsize=9)
    plt.tight_layout()
    plt.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close()


def save_training_strategy_figure(summary_csv: Path, out_path: Path) -> None:
    rows = []
    with summary_csv.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)

    mapping = {}
    for row in rows:
        mapping[(row["model"], row["source"])] = float(row["macro_f1"]) * 100

    categories = ["Synthetic test", "External real data", "Joint dataset"]
    synth_only = [
        mapping.get(("synth_only", "synth"), 0.0),
        mapping.get(("synth_only", "external"), 0.0),
        mapping.get(("synth_only", "joint"), 0.0),
    ]
    real_only = [
        mapping.get(("real_only", "synth"), 0.0),
        mapping.get(("real_only", "external"), 0.0),
        mapping.get(("real_only", "joint"), 0.0),
    ]
    joint = [100.0, 94.36, 96.57]

    x = list(range(len(categories)))
    width = 0.24

    plt.figure(figsize=(8.6, 4.8))
    plt.bar([i - width for i in x], synth_only, width=width, label="Synthetic-only", color="#5B8FF9")
    plt.bar(x, real_only, width=width, label="Real-only", color="#61DDAA")
    plt.bar([i + width for i in x], joint, width=width, label="Joint / deployed", color="#F08BB4")
    plt.xticks(x, categories)
    plt.ylabel("Macro F1-score (%)")
    plt.ylim(0, 105)
    plt.title("Comparison of Training Strategies")
    plt.legend()
    plt.grid(axis="y", linestyle="--", alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close()


def save_confusion_matrix_figure(eval_metrics: dict, out_path: Path) -> None:
    labels = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    matrix = eval_metrics["confusion_matrix"]

    plt.figure(figsize=(6.8, 5.4))
    plt.imshow(matrix, cmap="Blues")
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.xticks(range(len(labels)), labels)
    plt.yticks(range(len(labels)), labels)
    plt.xlabel("Predicted label")
    plt.ylabel("True label")
    plt.title("Confusion Matrix of the Core Model")

    max_value = max(max(row) for row in matrix)
    threshold = max_value * 0.5
    for i, row in enumerate(matrix):
        for j, value in enumerate(row):
            color = "white" if value > threshold else "#111827"
            plt.text(j, i, str(value), ha="center", va="center", color=color, fontsize=9)

    plt.tight_layout()
    plt.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close()


def build_article() -> Path:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)

    training_summary = load_json(ROOT / "models" / "dlp_bert_joint_v3" / "training_summary.json")
    eval_metrics = load_json(ROOT / "data" / "reports" / "eval_joint_v3_diploma" / "metrics.json")
    noise_summary = load_json(ROOT / "data" / "reports" / "diploma_noise_fresh" / "summary.json")
    real_world_summary = load_json(ROOT / "data" / "reports" / "diploma_real_world_fresh" / "summary.json")
    specialist_summary = load_json(ROOT / "data" / "reports" / "diploma_specialist_fresh" / "summary.json")

    class_f1_path = ASSETS / "figure_class_f1.png"
    confusion_path = ASSETS / "figure_confusion_matrix.png"
    save_class_f1_figure(eval_metrics, class_f1_path)
    save_confusion_matrix_figure(eval_metrics, confusion_path)

    document = Document()
    set_default_font(document)

    section = document.sections[0]
    section.top_margin = Cm(2)
    section.bottom_margin = Cm(2)
    section.left_margin = Cm(2)
    section.right_margin = Cm(2)

    add_paragraph(document, "UDC 004.056.5", align=WD_ALIGN_PARAGRAPH.LEFT)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.line_spacing = 1.0
    run = title.add_run("DEVELOPMENT OF AN AI-BASED MODEL FOR DETECTING CONFIDENTIAL DATA LEAKAGE IN ELECTRONIC COMMUNICATIONS AS A CYBERSECURITY MEASURE")
    run.bold = True
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    run.font.size = Pt(12)

    add_paragraph(document, "[Author Full Name]", align=WD_ALIGN_PARAGRAPH.CENTER)
    add_paragraph(document, "[author_email@example.com]", align=WD_ALIGN_PARAGRAPH.CENTER)
    add_paragraph(document, "Bachelor Student, Astana IT University, Astana, Kazakhstan", align=WD_ALIGN_PARAGRAPH.CENTER)
    add_paragraph(document, "Scientific Supervisor – [Supervisor Full Name]", align=WD_ALIGN_PARAGRAPH.CENTER, spacing_after=6)

    abstract = (
        "Abstract. Preventing confidential data leakage in electronic communications remains a critical challenge for modern organizations, "
        "especially in banking, fintech, public administration, and other sectors that routinely exchange sensitive records. "
        "This paper presents SecureMail AI-DLP, a hybrid data loss prevention system that combines a multilingual transformer-based classifier, "
        "specialist auxiliary models, deterministic rules, and endpoint-aware channel logic to detect confidential content in text, files, images, archives, and communication events. "
        "The main model is based on bert-base-multilingual-cased and was fine-tuned for five severity classes: SAFE, LOW, MEDIUM, HIGH, and CRITICAL. "
        "The final training corpus contained 45,764 labeled samples collected from synthetic enterprise leak scenarios and public privacy datasets. "
        "Experimental evaluation demonstrated 96.37% accuracy, 96.57% macro F1-score, and 96.35% weighted F1-score on the held-out test set. "
        "Runtime evaluation in the deployed consensus mode achieved 94.42% accuracy on a mixed benchmark and a low noise false-positive rate of 1.08%. "
        "The proposed approach shows strong potential as a practical cybersecurity measure for insider-risk reduction and confidential data protection in enterprise communications."
    )
    add_paragraph(document, abstract)
    add_paragraph(document, "Keywords: data leakage prevention, cybersecurity, confidential data detection, multilingual BERT, transformer, electronic communications, insider threat.", italic=True)

    add_paragraph(document, "1. Introduction", bold=True, align=WD_ALIGN_PARAGRAPH.LEFT)
    intro_1 = (
        "The increasing digitalization of business processes has significantly expanded the amount of sensitive information exchanged through electronic communications. "
        "Organizations now transmit customer data, financial records, personal identifiers, credentials, API secrets, and operational documents through emails, chats, attachments, archives, and endpoint-mediated workflows. "
        "As a result, confidential data leakage has become a major cybersecurity concern not only in the context of external attacks, but also in the context of accidental disclosure, insider misuse, and weak governance over communication channels [1, 2]."
    )
    intro_2 = (
        "Traditional data loss prevention systems commonly rely on static regular expressions and keyword rules. While such mechanisms are effective for certain structured secrets, they frequently lack semantic context, are sensitive to obfuscation, and may generate excessive false positives in routine communication. "
        "Recent advances in transformer-based language models create an opportunity to improve content-aware leak detection through contextual classification, multilingual generalization, and hybrid decision-making [3–6]."
    )
    intro_3 = (
        "This study proposes SecureMail AI-DLP, an AI-based DLP prototype designed to detect confidential data leakage in electronic communications. "
        "The system combines a multilingual transformer classifier, specialist secret-detection logic, OCR- and file-aware preprocessing, and endpoint-driven inspection. "
        "The main contribution of the work is a hybrid detection architecture evaluated on a mixed dataset that reflects both realistic privacy corpora and synthetic enterprise leak scenarios tailored to banking-style and Kazakhstan-specific contexts."
    )
    add_paragraph(document, intro_1)
    add_paragraph(document, intro_2)
    add_paragraph(document, intro_3)

    add_paragraph(document, "2. Methods and Experimental Design", bold=True, align=WD_ALIGN_PARAGRAPH.LEFT)
    methods_1 = (
        "The core model is a transformer-based classifier built on the bert-base-multilingual-cased backbone. "
        "The model was fine-tuned using Python, PyTorch, and Hugging Face Transformers for multiclass severity classification with five target labels: SAFE, LOW, MEDIUM, HIGH, and CRITICAL. "
        "The final training configuration used a maximum sequence length of 256 tokens, a learning rate of 2e-5, weight decay of 0.01, and 3 training epochs. "
        "Evaluation was performed on separate validation and test splits using accuracy, macro F1-score, weighted F1-score, and confusion-matrix analysis."
    )
    methods_2 = (
        "A purely neural approach was considered insufficient for real DLP usage because structured secrets, banking exports, and obfuscated tokens require deterministic high-confidence handling. "
        "Therefore, the deployed system uses a hybrid consensus runtime that combines the main transformer model with a specialist auxiliary model and a set of contextual rules for credentials, cards, IBANs, private keys, database connection strings, OCR fragments, archives, and endpoint events. "
        "This hybrid design was selected to improve recall on high-severity leak cases while maintaining low false-positive rates on noisy or placeholder content."
    )
    methods_3 = (
        "The preprocessing pipeline includes tokenization, truncation, dynamic padding, normalization of obfuscated secrets, extraction from spreadsheets and text documents, OCR processing for image-based content, and rule-based contextual post-processing. "
        "The experimental procedure consisted of three stages: training and validating the core classifier, comparing alternative training strategies, and performing runtime evaluation in a realistic consensus configuration using mixed-channel scenarios."
    )
    add_paragraph(document, methods_1)
    add_paragraph(document, methods_2)
    add_paragraph(document, methods_3)

    add_paragraph(document, "3. Dataset Construction", bold=True, align=WD_ALIGN_PARAGRAPH.LEFT)
    dataset_1 = (
        "The principal training corpus was the joint_v3 dataset, which contains 45,764 labeled samples. "
        "The split consisted of 33,017 training samples (72.2%), 6,358 validation samples (13.9%), and 6,389 test samples (14.0%). "
        "The data were collected from three main sources: in-house synthetic enterprise DLP scenarios, ai4privacy/pii-masking-400k, and Isotonic/pii-masking-200k."
    )
    dataset_2 = (
        "The synthetic component was designed specifically for the thesis domain and included email-like text, contact bundles, payroll fragments, banking exports, OCR-like distortions, attachment notes, USB transfer events, encrypted archive scenarios, and hard negatives such as placeholders, documentation examples, and safe fake database URIs. "
        "This strategy allowed the model to learn both semantic distinctions and practical DLP-specific categories encountered in enterprise security operations."
    )
    add_paragraph(document, dataset_1)
    add_paragraph(document, dataset_2)

    table_title = document.add_paragraph()
    table_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    table_title.add_run("Table 1. Summary of the Main Experimental Results").italic = True

    table = document.add_table(rows=1, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    hdr[0].text = "Metric"
    hdr[1].text = "Value"
    hdr[2].text = "Evaluation stage"
    for cell in hdr:
        set_cell_shading(cell, "D9EAF7")
        for p in cell.paragraphs:
            for r in p.runs:
                r.bold = True
                r.font.name = "Times New Roman"
                r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
                r.font.size = Pt(11)

    rows = [
        ("Test accuracy", f"{eval_metrics['accuracy'] * 100:.2f}%", "Core model test set"),
        ("Test macro F1-score", f"{eval_metrics['macro_f1'] * 100:.2f}%", "Core model test set"),
        ("Test weighted F1-score", f"{eval_metrics['weighted_f1'] * 100:.2f}%", "Core model test set"),
        ("Noise false-positive rate", f"{noise_summary['noise_fp_rate'] * 100:.2f}%", "Consensus runtime"),
        ("Runtime mixed accuracy", f"{real_world_summary['accuracy'] * 100:.2f}%", "Consensus runtime"),
        ("Runtime mixed macro F1-score", f"{real_world_summary['macro_f1'] * 100:.2f}%", "Consensus runtime"),
        ("Specialist benchmark accuracy", f"{specialist_summary['accuracy'] * 100:.2f}%", "Domain-specific hard cases"),
    ]
    for metric, value, stage in rows:
        cells = table.add_row().cells
        cells[0].text = metric
        cells[1].text = value
        cells[2].text = stage
        for cell in cells:
            for p in cell.paragraphs:
                for r in p.runs:
                    r.font.name = "Times New Roman"
                    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
                    r.font.size = Pt(11)

    add_paragraph(document, "4. Results and Discussion", bold=True, align=WD_ALIGN_PARAGRAPH.LEFT)
    results_1 = (
        "The main model demonstrated strong overall performance on the held-out test set, achieving 96.37% accuracy and 96.57% macro F1-score. "
        "The per-class analysis showed that the CRITICAL class, which contains explicit secrets, production credentials, private keys, and mass banking exports, was detected almost perfectly. "
        "The MEDIUM class remained the most ambiguous category because it overlaps semantically with both low-risk contact data and higher-risk personal or financial records."
    )
    results_2 = (
        "The deployed consensus runtime achieved 94.42% accuracy on a 10,000-sample mixed benchmark while preserving a very low false-positive rate of 1.08% on 5,000 noise samples. "
        "This result is operationally important because DLP systems must maintain high sensitivity to critical leaks without generating unacceptable alert fatigue. "
        "A specialist benchmark covering encrypted archives, password dumps, production environment files, OCR-based images, and database URI screenshots reached 100% accuracy, indicating that the hybrid runtime is particularly well suited to high-risk enterprise cases."
    )
    results_3 = (
        "Comparative experiments further justified the hybrid data strategy. "
        "A model trained only on synthetic data achieved perfect synthetic performance but generalized poorly to external real data. "
        "Conversely, a real-only model performed well on external privacy data but underperformed on the joint enterprise benchmark. "
        "These findings confirm that the combination of public privacy corpora and domain-specific synthetic scenarios is necessary for building a practical AI-DLP system."
    )
    add_paragraph(document, results_1)
    add_paragraph(document, results_2)
    add_paragraph(document, results_3)

    document.add_picture(str(class_f1_path), width=Inches(5.8))
    fig1 = document.paragraphs[-1]
    fig1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_paragraph(document, "Figure 1. Per-class F1-score of the core SecureMail AI-DLP classifier.", italic=True, align=WD_ALIGN_PARAGRAPH.CENTER)

    document.add_picture(str(confusion_path), width=Inches(5.4))
    fig2 = document.paragraphs[-1]
    fig2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_paragraph(document, "Figure 2. Confusion matrix of the core SecureMail AI-DLP classifier on the held-out test set.", italic=True, align=WD_ALIGN_PARAGRAPH.CENTER)

    add_paragraph(document, "5. Conclusion", bold=True, align=WD_ALIGN_PARAGRAPH.LEFT)
    conclusion = (
        "The study demonstrates that AI-based DLP systems can effectively move beyond static regular expressions and support context-dependent confidential data leakage detection in modern electronic communications. "
        "SecureMail AI-DLP integrates multilingual transformer semantics, specialist leak detection, OCR-aware preprocessing, and enterprise-oriented runtime logic into a single hybrid architecture. "
        "The resulting system achieved strong classification quality, low false-positive rates in noisy settings, and reliable performance on specialist banking and credential-leak scenarios. "
        "The practical significance of the work lies in its applicability to enterprise mail monitoring, insider-risk reduction, banking export screening, and security operations triage. "
        "Future work should focus on larger real multilingual datasets, stronger calibration for borderline severity classes, and deeper integration with browser- and network-layer communication channels."
    )
    add_paragraph(document, conclusion)

    add_paragraph(document, "References", bold=True, align=WD_ALIGN_PARAGRAPH.LEFT)
    references = [
        "1. Hasan, M. T., Ahmed, I. AI-Driven Anomaly Detection for Data Loss Prevention and Security Assurance in Electronic Health Records // Review of Applied Science and Technology. 2025. Vol. 4, No. 3. P. 35-67.",
        "2. European Parliament and Council of the European Union. Regulation (EU) 2016/679 (GDPR). 2016.",
        "3. Petrolini, M., Cagnoni, S., Mordonini, M. Automatic Detection of Sensitive Data Using Transformer-Based Classifiers // Future Internet. 2022. Vol. 14, No. 8. Art. 228.",
        "4. Devlin, J., Chang, M.-W., Lee, K., Toutanova, K. BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding // Proceedings of NAACL-HLT. 2019. P. 4171-4186.",
        "5. Vaswani, A., Shazeer, N., Parmar, N., et al. Attention Is All You Need // Advances in Neural Information Processing Systems. 2017. P. 5998-6008.",
        "6. Pires, T., Schlinger, E., Garrette, D. How Multilingual is Multilingual BERT? // Proceedings of ACL. 2019. P. 4996-5007.",
        "7. Mishra, K., Pagare, H., Sharma, K. A hybrid rule-based NLP and machine learning approach for PII detection and anonymization in financial documents // Scientific Reports. 2025. Vol. 15. Art. 22729.",
        "8. Liu, S., Kuhn, D. R. Data Loss Prevention // IT Professional. 2010. Vol. 12, No. 2. P. 10-13.",
    ]
    for item in references:
        add_paragraph(document, item, align=WD_ALIGN_PARAGRAPH.LEFT)

    output_docx = OUTPUT / "Conference_Article_AI_DLP_FINAL_v2.docx"
    document.save(output_docx)
    return output_docx


if __name__ == "__main__":
    path = build_article()
    print(path)
