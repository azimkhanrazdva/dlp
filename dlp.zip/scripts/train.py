import argparse
import csv
import inspect
import json
import os
from collections import Counter
from pathlib import Path
from typing import Dict, List

import numpy as np
import torch
from datasets import Dataset
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer, DataCollatorWithPadding, Trainer, TrainingArguments, set_seed


DEFAULT_LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def discover_labels(paths: List[Path], preferred_order: List[str]) -> List[str]:
    discovered = []
    seen = set()
    for path in paths:
        with path.open("r", encoding="utf-8", newline="") as handle:
            for row in csv.DictReader(handle):
                label = (row.get("label") or "").strip().upper()
                if label and label not in seen:
                    seen.add(label)
                    discovered.append(label)
    ordered = [label for label in preferred_order if label in seen]
    extras = sorted(label for label in discovered if label not in ordered)
    return ordered + extras


def load_rows(path: Path, label2id: Dict[str, int]) -> List[dict]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    out = []
    for row in rows:
        text = (row.get("text") or "").strip()
        label = (row.get("label") or "").strip().upper()
        if text and label in label2id:
            out.append({"text": text, "label": label2id[label]})
    return out


def as_dataset(path: Path, label2id: Dict[str, int]) -> Dataset:
    return Dataset.from_list(load_rows(path, label2id))


def data_dir_for_source(source: str, data_dir: Path | None) -> Path:
    if data_dir is not None:
        return data_dir
    mapping = {
        "synth": Path("data/processed/synth_v3"),
        "external": Path("data/processed/external_pii"),
        "joint": Path("data/processed/joint_v2"),
    }
    return mapping[source]


def summarize(name: str, ds: Dataset, labels: List[str], id2label: Dict[int, str]) -> None:
    counts = Counter(id2label[row["label"]] for row in ds)
    payload = {label: counts.get(label, 0) for label in labels}
    print(f"{name}: {payload}")


def tokenize_batch(batch: Dict[str, List[str]], tokenizer, max_length: int):
    return tokenizer(batch["text"], truncation=True, max_length=max_length)


def training_args_from(args: argparse.Namespace) -> TrainingArguments:
    sig = inspect.signature(TrainingArguments.__init__)
    kwargs = {
        "output_dir": str(args.output_dir),
        "num_train_epochs": args.epochs,
        "per_device_train_batch_size": args.train_batch_size,
        "per_device_eval_batch_size": args.eval_batch_size,
        "learning_rate": args.learning_rate,
        "weight_decay": args.weight_decay,
        "logging_dir": str(args.output_dir / "logs"),
        "logging_steps": args.logging_steps,
        "save_steps": args.save_steps,
        "eval_steps": args.eval_steps,
        "save_total_limit": args.save_total_limit,
        "load_best_model_at_end": True,
        "metric_for_best_model": "macro_f1",
        "greater_is_better": True,
        "report_to": [],
        "seed": args.seed,
    }
    if "eval_strategy" in sig.parameters:
        kwargs["eval_strategy"] = "steps"
    elif "evaluation_strategy" in sig.parameters:
        kwargs["evaluation_strategy"] = "steps"
    if "save_strategy" in sig.parameters:
        kwargs["save_strategy"] = "steps"
    if "fp16" in sig.parameters:
        kwargs["fp16"] = torch.cuda.is_available()
    if "save_safetensors" in sig.parameters:
        kwargs["save_safetensors"] = False
    return TrainingArguments(**kwargs)


def build_compute_metrics(labels: List[str]):
    def compute_metrics(eval_pred):
        logits, raw_labels = eval_pred
        preds = np.argmax(logits, axis=1)
        cm = confusion_matrix(raw_labels, preds, labels=list(range(len(labels))))
        return {
            "accuracy": float(accuracy_score(raw_labels, preds)),
            "macro_f1": float(f1_score(raw_labels, preds, average="macro", zero_division=0)),
            "weighted_f1": float(f1_score(raw_labels, preds, average="weighted", zero_division=0)),
            **{f"cm_{labels[idx].lower()}": int(cm[idx, idx]) for idx in range(len(labels))},
        }
    return compute_metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fine-tune BERT for DLP severity classification.")
    parser.add_argument("--source", choices=["synth", "external", "joint"], default="joint")
    parser.add_argument("--data_dir", type=Path, default=None)
    parser.add_argument("--base_model", type=str, default="bert-base-multilingual-cased")
    parser.add_argument("--output_dir", type=Path, default=Path("models/dlp_bert_joint_v2"))
    parser.add_argument("--max_length", type=int, default=256)
    parser.add_argument("--epochs", type=float, default=3.0)
    parser.add_argument("--train_batch_size", type=int, default=16)
    parser.add_argument("--eval_batch_size", type=int, default=32)
    parser.add_argument("--learning_rate", type=float, default=2e-5)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--logging_steps", type=int, default=50)
    parser.add_argument("--eval_steps", type=int, default=200)
    parser.add_argument("--save_steps", type=int, default=200)
    parser.add_argument("--save_total_limit", type=int, default=2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--resume_from", type=str, default=None)
    return parser.parse_args()


def save_summary(output_dir: Path, metrics: Dict[str, float], args: argparse.Namespace, data_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = {"source": args.source, "data_dir": str(data_dir), "base_model": args.base_model, "resume": args.resume, "resume_from": args.resume_from, "metrics": metrics}
    with (output_dir / "training_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    data_dir = data_dir_for_source(args.source, args.data_dir)
    labels = discover_labels([data_dir / "train.csv", data_dir / "val.csv", data_dir / "test.csv"], DEFAULT_LABELS)
    label2id = {label: idx for idx, label in enumerate(labels)}
    id2label = {idx: label for label, idx in label2id.items()}

    train_ds = as_dataset(data_dir / "train.csv", label2id)
    val_ds = as_dataset(data_dir / "val.csv", label2id)
    test_ds = as_dataset(data_dir / "test.csv", label2id)

    summarize("train", train_ds, labels, id2label)
    summarize("val", val_ds, labels, id2label)
    summarize("test", test_ds, labels, id2label)

    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    train_ds = train_ds.map(lambda b: tokenize_batch(b, tokenizer, args.max_length), batched=True)
    val_ds = val_ds.map(lambda b: tokenize_batch(b, tokenizer, args.max_length), batched=True)
    test_ds = test_ds.map(lambda b: tokenize_batch(b, tokenizer, args.max_length), batched=True)

    model = AutoModelForSequenceClassification.from_pretrained(
        args.base_model,
        num_labels=len(labels),
        id2label=id2label,
        label2id=label2id,
    )

    trainer = Trainer(
        model=model,
        args=training_args_from(args),
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=DataCollatorWithPadding(tokenizer=tokenizer),
        compute_metrics=build_compute_metrics(labels),
    )

    resume_checkpoint = args.resume_from or True if args.resume else None
    if args.resume:
        print(f"Resuming trainer state from: {resume_checkpoint}")
    else:
        print(f"Starting fine-tuning from base_model={args.base_model}")
    trainer.train(resume_from_checkpoint=resume_checkpoint)
    trainer.save_model(str(args.output_dir))
    tokenizer.save_pretrained(str(args.output_dir))

    val_metrics = trainer.evaluate(eval_dataset=val_ds, metric_key_prefix="val")
    test_metrics = trainer.evaluate(eval_dataset=test_ds, metric_key_prefix="test")
    preds = trainer.predict(test_ds)
    cm = confusion_matrix(preds.label_ids, np.argmax(preds.predictions, axis=1), labels=list(range(len(labels))))
    with (args.output_dir / "test_confusion_matrix.json").open("w", encoding="utf-8") as handle:
        json.dump({"labels": labels, "matrix": cm.tolist()}, handle, indent=2)
    merged = {**val_metrics, **test_metrics}
    save_summary(args.output_dir, merged, args, data_dir)
    print("Training complete.")
    print(json.dumps(merged, indent=2))
    print(f"Artifacts saved to {args.output_dir}")


if __name__ == "__main__":
    main()
