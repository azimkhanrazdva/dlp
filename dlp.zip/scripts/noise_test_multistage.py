import argparse
import csv
import json
import random
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.dlp_engine import DLPScanner, serialize_result


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def random_noise(rng: random.Random, alphabet: str, min_len: int, max_len: int) -> str:
    return "".join(rng.choices(alphabet, k=rng.randint(min_len, max_len)))


def build_samples(count: int, seed: int):
    rng = random.Random(seed)
    out = []
    for idx in range(count):
        mode = idx % 8
        if mode == 0:
            out.append(f"debug trace={random_noise(rng, 'abcdef0123456789', 32, 96)} status=200")
        elif mode == 1:
            out.append(f"placeholder token={random_noise(rng, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/_-=', 28, 88)} example only")
        elif mode == 2:
            out.append(f"cache blob {random_noise(rng, 'abcdefghijklmnopqrstuvwxyz0123456789', 24, 64)} {random_noise(rng, 'abcdef0123456789', 32, 64)}")
        elif mode == 3:
            out.append(f"regex test only api_key=not_real_example_{rng.randint(100,999)} no secret should be detected")
        elif mode == 4:
            out.append(f"harmless OCR garbage {random_noise(rng, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 24, 44)} I1O0S5")
        elif mode == 5:
            out.append(f"log record session={random_noise(rng, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 20, 40)} marker=benign")
        elif mode == 6:
            out.append(f"sample docs mention database_url_example but not real credential id={rng.randint(1000,9999)}")
        else:
            out.append(f"email placeholder name at example dot com generated for parser tests {random_noise(rng, 'abcdefghijklmnopqrstuvwxyz', 16, 32)}")
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Measure noise FP for multi-stage pipeline.")
    parser.add_argument("--count", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out_dir", type=Path, default=Path("data/reports/noise_multistage"))
    parser.add_argument("--single_model", type=str, default=None)
    parser.add_argument("--stage1_model", type=str, required=True)
    parser.add_argument("--stage2_model", type=str, required=True)
    parser.add_argument("--stage3_model", type=str, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scanner = DLPScanner(
        model_path=args.single_model,
        stage1_path=args.stage1_model,
        stage2_path=args.stage2_model,
        stage3_path=args.stage3_model,
    )
    samples = build_samples(args.count, args.seed)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    counts = {label: 0 for label in LABELS}
    false_positive = 0
    with (args.out_dir / "noise_predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["pred_label", "score", "text"])
        writer.writeheader()
        for text in samples:
            result = scanner.scan_text(text)
            counts[result.severity] += 1
            if result.severity != "SAFE":
                false_positive += 1
            writer.writerow({"pred_label": result.severity, "score": result.score, "text": text})
    summary = {"count": args.count, "false_positive": false_positive, "noise_fp_rate": false_positive / max(1, args.count), "pred_distribution": counts}
    with (args.out_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    print(json.dumps(summary, indent=2))
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()
