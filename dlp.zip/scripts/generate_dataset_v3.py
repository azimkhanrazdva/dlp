import argparse
import csv
import random
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Sequence


LABELS = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]

KZ_FIRST = ["Aruzhan", "demo-user", "Madina", "Ainur", "Dana", "Asel", "Kamila", "Zhanel", "Nursultan", "Dias", "Alisher", "Bekzat", "Aidos", "Yerlan", "Arman", "Miras"]
KZ_LAST = ["Saparov", "Tulegenova", "Nurgaliyev", "Akhmetov", "Kenzhebek", "Abdrazakova", "Iskakov", "Baitursyn", "Ryskulov", "Kudaibergen", "Suleimenova", "Omarov"]
KZ_CITIES = ["Almaty", "Astana", "Shymkent", "Karaganda", "Aktobe", "Atyrau", "Taraz", "Pavlodar", "Kostanay"]
KZ_STREETS = ["Abylai Khan Ave", "Dostyk Ave", "Mangilik El Ave", "Satpayev St", "Tole Bi St", "Al-Farabi Ave", "Tauelsizdik Ave"]
KZ_BANKS = ["Kaspi", "Halyk", "Forte", "Jusan", "CenterCredit", "Freedom"]
SAFE_TOPICS = ["release planning", "backend sync", "QA checklist", "monitoring cleanup", "architecture review", "healthcheck report"]
NOISE_WORDS = ["trace", "buffer", "cache", "worker", "normal", "debug", "harmless", "sample", "placeholder"]


@dataclass
class Sample:
    text: str
    label: str
    source: str
    sample_type: str


def random_person(rng: random.Random) -> str:
    return f"{rng.choice(KZ_FIRST)} {rng.choice(KZ_LAST)}"


def random_email(rng: random.Random, person: str | None = None) -> str:
    local = (person or rng.choice(KZ_FIRST)).split()[0].lower()
    return f"{local}{rng.randint(1,999)}@{rng.choice(['mail.kz', 'gmail.com', 'corp.kz', 'example.com'])}"


def random_phone_kz(rng: random.Random) -> str:
    digits = "7" + "".join(rng.choices("0123456789", k=9))
    return rng.choice([f"+7{digits}", f"+7 {digits[:3]} {digits[3:6]} {digits[6:8]} {digits[8:]}", f"8{digits}"])


def random_iin(rng: random.Random) -> str:
    return "".join(rng.choices("0123456789", k=12))


def random_bin(rng: random.Random) -> str:
    return "".join(rng.choices("0123456789", k=12))


def random_address(rng: random.Random) -> str:
    return f"{rng.choice(KZ_CITIES)}, {rng.choice(KZ_STREETS)}, building {rng.randint(1,180)}, apt {rng.randint(1,220)}"


def random_iban(rng: random.Random) -> str:
    return f"KZ{rng.randint(10,99)}ABC{''.join(rng.choices('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=13))}"


def random_iban_digits(rng: random.Random) -> str:
    return f"KZ{rng.randint(10,99)}{''.join(rng.choices('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=16))}"


def luhn_digit(base: str) -> int:
    total = 0
    for idx, ch in enumerate(base[::-1]):
        n = int(ch)
        if idx % 2 == 0:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return (10 - total % 10) % 10


def random_card(rng: random.Random) -> str:
    body = rng.choice(["400000", "440563", "516949", "535302"]) + "".join(rng.choices("0123456789", k=9))
    digits = body + str(luhn_digit(body))
    return f"{digits[:4]} {digits[4:8]} {digits[8:12]} {digits[12:]}"


def random_secret(rng: random.Random, prefix: str, size: int) -> str:
    return prefix + "".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=size))


def random_jwt(rng: random.Random) -> str:
    return ".".join("".join(rng.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", k=n)) for n in [24, 72, 32])


def random_noise(rng: random.Random, min_len: int = 24, max_len: int = 96, alphabet: str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/_-=:") -> str:
    return "".join(rng.choices(alphabet, k=rng.randint(min_len, max_len)))


def maybe_ocr(text: str, rng: random.Random) -> str:
    replacements = {"0": "O", "1": "I", "5": "S", "@": "a", "e": "c"}
    result = []
    for ch in text:
        if ch in replacements and rng.random() < 0.08:
            result.append(replacements[ch])
        elif ch == " " and rng.random() < 0.05:
            result.append(rng.choice([" ", "  ", "\n"]))
        else:
            result.append(ch)
    return "".join(result)


def bulk_banking_export(rng: random.Random, rows: int = 5) -> str:
    header = "name,email,phone,iin,account,iban,bank"
    data = [header]
    for _ in range(rows):
        person = random_person(rng)
        data.append(
            f"{person},{random_email(rng, person)},{random_phone_kz(rng)},{random_iin(rng)},{random_iban_digits(rng)},{random_iban_digits(rng)},{rng.choice(KZ_BANKS)}"
        )
    return "\n".join(data)


def safe_plain(rng: random.Random) -> Sample:
    return Sample(f"Team update: {rng.choice(SAFE_TOPICS)} completed successfully. No personal data or credentials are included.", "SAFE", "synthetic", "safe_plain")


def safe_noise_blob(rng: random.Random) -> Sample:
    return Sample(f"debug {rng.choice(NOISE_WORDS)}={random_noise(rng)} trace={random_noise(rng)} placeholder_token={random_noise(rng, 16, 32)}", "SAFE", "synthetic", "safe_noise_blob")


def safe_pseudo_secret(rng: random.Random) -> Sample:
    return Sample(f"Sample credential for documentation only: api_key=example_not_real_{rng.randint(1000,9999)} token=dummy_value_{rng.randint(100,999)}", "SAFE", "synthetic", "safe_pseudo_secret")


def safe_base64_hex(rng: random.Random) -> Sample:
    hex_blob = "".join(rng.choices("abcdef0123456789", k=64))
    b64_blob = random_noise(rng, 48, 88, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=")
    return Sample(f"harmless binary preview hex={hex_blob} base64={b64_blob} generated for parser testing only", "SAFE", "synthetic", "safe_base64_hex")


def safe_fake_db_uri(rng: random.Random) -> Sample:
    secret = f"example_{rng.randint(1000, 9999)}_not_real"
    text = (
        "Sample documentation snippet only: "
        f"DATABASE_URL=postgresql://demo_user:{secret}@sandbox.local:5432/example_db "
        "This connection string is fictional and must not be used in production."
    )
    return Sample(text, "SAFE", "synthetic", "safe_fake_db_uri")


def safe_truncated_secret(rng: random.Random) -> Sample:
    text = (
        "Security training example: "
        f"token_prefix=ghp_{''.join(rng.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=8))}...redacted "
        f"api_key_hint=sk-test-{''.join(rng.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=10))}...masked"
    )
    return Sample(text, "SAFE", "synthetic", "safe_truncated_secret")


def safe_config_template(rng: random.Random) -> Sample:
    text = (
        "Template values for onboarding only: "
        "OPENAI_API_KEY=your_key_here "
        "AWS_SECRET_ACCESS_KEY=replace_me "
        "JWT_SECRET=<set-in-local-env> "
        f"example_run_id={rng.randint(10000, 99999)}"
    )
    return Sample(text, "SAFE", "synthetic", "safe_config_template")


def safe_fragmented_noise(rng: random.Random) -> Sample:
    parts = [
        random_noise(rng, 8, 16),
        random_noise(rng, 8, 16),
        random_noise(rng, 8, 16),
    ]
    text = (
        "OCR artifact from harmless screenshot: "
        f"sec ret={parts[0]} db ur l={parts[1]} auth tok en={parts[2]} "
        "These fragments are broken placeholders and not valid credentials."
    )
    return Sample(text, "SAFE", "synthetic", "safe_fragmented_noise")


def safe_fake_kz_record(rng: random.Random) -> Sample:
    text = (
        "Demo customer card for UI testing only: "
        f"name {random_person(rng)}, IIN 000000000000, phone +7 700 000 00 00, "
        "account TEST-ONLY. All values are synthetic placeholders."
    )
    return Sample(text, "SAFE", "synthetic", "safe_fake_kz_record")


def safe_attachment_manifest(rng: random.Random) -> Sample:
    text = (
        f"Attachment manifest: file=release_notes_q{rng.randint(1,4)}.pdf "
        f"classification=internal-only pages={rng.randint(3,18)} "
        "Contains product updates, architecture review and harmless screenshots."
    )
    return Sample(text, "SAFE", "synthetic", "safe_attachment_manifest")


def safe_usb_admin(rng: random.Random) -> Sample:
    text = (
        f"USB inventory event: device Kingston DataTraveler {rng.randint(16,128)}GB connected to kiosk workstation. "
        "Policy state authorized. No copy, export or sensitive material detected."
    )
    return Sample(text, "SAFE", "synthetic", "safe_usb_admin")


def safe_archive_training(rng: random.Random) -> Sample:
    text = (
        f"Archive manifest only: backup_training_{rng.randint(100,999)}.zip "
        f"contains release notes, demo screenshots and harmless logs. "
        "Example only, no customer data, no credentials."
    )
    return Sample(text, "SAFE", "synthetic", "safe_archive_training")


def low_contact(rng: random.Random) -> Sample:
    mode = rng.choice(["email", "phone", "name"])
    person = random_person(rng)
    if mode == "email":
        text = f"Please contact {random_email(rng, person)} for schedule confirmation."
    elif mode == "phone":
        text = f"Temporary callback number: {random_phone_kz(rng)}."
    else:
        text = f"Attendee registered: {person}."
    return Sample(text, "LOW", "synthetic", "low_contact")


def medium_pii(rng: random.Random) -> Sample:
    mode = rng.choice(["contact_bundle", "attachment_note", "ocr_fragment"])
    person = random_person(rng)
    if mode == "contact_bundle":
        text = f"Customer callback request: {person}, {random_email(rng, person)}, {random_phone_kz(rng)}."
        if rng.random() < 0.4:
            text += f" Address: {random_address(rng)}."
    elif mode == "attachment_note":
        text = (
            f"Attachment review: customer_contacts.xlsx prepared by {person}. "
            f"Sheet contains callback list with {random_email(rng, person)} and {random_phone_kz(rng)}."
        )
    else:
        text = maybe_ocr(
            f"Scanned support form: name {person} phone {random_phone_kz(rng)} email {random_email(rng, person)}",
            rng,
        )
    return Sample(text, "MEDIUM", "synthetic", f"medium_{mode}")


def high_pii(rng: random.Random) -> Sample:
    mode = rng.choice(["iin", "card", "payroll", "iban", "attachment_export", "ocr_sensitive", "bulk_bank_export", "ocr_card_scan"])
    person = random_person(rng)
    if mode == "iin":
        text = f"Verification form: {person}, IIN {random_iin(rng)}, phone {random_phone_kz(rng)}, address {random_address(rng)}."
    elif mode == "card":
        text = f"{rng.choice(KZ_BANKS)} dispute: customer {person}, card {random_card(rng)}, BIN {random_bin(rng)}."
    elif mode == "iban":
        text = f"Bank transfer details: {person}, IBAN {random_iban(rng)}, bank {rng.choice(KZ_BANKS)}."
    elif mode == "attachment_export":
        text = (
            f"Attachment payroll_export_{rng.randint(100,999)}.xlsx queued for external send. "
            f"Employee {person}, IIN {random_iin(rng)}, salary {rng.randint(280000,1200000)} KZT, bank {rng.choice(KZ_BANKS)}."
        )
    elif mode == "ocr_sensitive":
        text = maybe_ocr(
            f"Scanned banking form: {person} IIN {random_iin(rng)} IBAN {random_iban(rng)}",
            rng,
        )
    elif mode == "bulk_bank_export":
        text = (
            f"Attachment customer_export_{rng.randint(100,999)}.csv prepared for external share.\n"
            + bulk_banking_export(rng, rows=rng.randint(4, 7))
        )
    elif mode == "ocr_card_scan":
        text = maybe_ocr(
            f"payment card {random_card(rng)} cvv {rng.randint(100,999)} expiry {rng.randint(1,12):02d}/{rng.randint(26,31)}",
            rng,
        )
    else:
        text = f"Payroll fragment: employee {person}, IIN {random_iin(rng)}, salary {rng.randint(280000,1200000)} KZT."
    return Sample(text, "HIGH", "synthetic", f"high_{mode}")


def critical_secret(rng: random.Random) -> Sample:
    mode = rng.choice(["aws", "github", "openai", "jwt", "db", "private", "env", "slack", "usb_export", "attachment_secret", "ocr_secret", "bulk_credential_dump", "encrypted_archive"])
    if mode == "aws":
        text = f"AWS credential leak: AKIA{''.join(rng.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=16))}"
    elif mode == "github":
        text = f"GitHub token exposed: {random_secret(rng, 'ghp_', 36)}"
    elif mode == "openai":
        text = f"OpenAI secret leaked in chat: {random_secret(rng, 'sk-proj-', 48)}"
    elif mode == "jwt":
        text = f"Authorization header leaked: Bearer {random_jwt(rng)}"
    elif mode == "db":
        text = f"DATABASE_URL=postgresql://admin:{random_secret(rng, '', 20)}@prod-db.company.kz:5432/prod"
    elif mode == "private":
        text = f"-----BEGIN EXAMPLE PRIVATE KEY-----\n{random_noise(rng, 96, 128, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=')}\n-----END EXAMPLE PRIVATE KEY-----"
    elif mode == "env":
        text = f"ENV dump SECRET_KEY={random_secret(rng, '', 32)} SESSION_SECRET={random_secret(rng, '', 28)} TELEGRAM_TOKEN={random_secret(rng, '', 32)}"
    elif mode == "usb_export":
        text = (
            f"USB copy detected: device SanDisk Extreme connected. "
            f"Exporting archive finance_backup.zip with DATABASE_URL=postgresql://admin:{random_secret(rng, '', 20)}@prod-db.company.kz:5432/prod "
            f"and token {random_secret(rng, 'ghp_', 36)}."
        )
    elif mode == "attachment_secret":
        text = (
            f"Attachment env_dump.txt contains OPENAI_API_KEY={random_secret(rng, 'sk-proj-', 40)} "
            f"and AWS credential AKIA{''.join(rng.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=16))}."
        )
    elif mode == "ocr_secret":
        text = maybe_ocr(
            f"Scanned note: Bearer {random_jwt(rng)} SECRET_KEY={random_secret(rng, '', 24)}",
            rng,
        )
    elif mode == "bulk_credential_dump":
        lines = ["customer_id,password,client_secret,access_token"]
        for idx in range(rng.randint(3, 6)):
            lines.append(
                f"{1000 + idx},"
                f"{random_secret(rng, '', 14)},"
                f"{random_secret(rng, '', 22)},"
                f"{random_jwt(rng)}"
            )
        text = "Large credential dump detected in attachment password_export.csv\n" + "\n".join(lines)
    elif mode == "encrypted_archive":
        text = (
            f"Protected archive finance_vault_{rng.randint(100,999)}.rar prepared for transfer. "
            f"Encrypted backup contains DATABASE_URL=postgresql://admin:{random_secret(rng, '', 20)}@prod-db.company.kz:5432/prod "
            f"and OPENAI_API_KEY={random_secret(rng, 'sk-proj-', 36)}."
        )
    else:
        text = f"Slack bot token xoxb-{rng.randint(100000000000,999999999999)}-{rng.randint(100000000000,999999999999)}-{random_secret(rng, '', 24)}"
    return Sample(maybe_ocr(text, rng), "CRITICAL", "synthetic", f"critical_{mode}")


GENERATORS: Dict[str, Sequence[Callable[[random.Random], Sample]]] = {
    "SAFE": [
        safe_plain,
        safe_noise_blob,
        safe_pseudo_secret,
        safe_base64_hex,
        safe_fake_db_uri,
        safe_truncated_secret,
        safe_config_template,
        safe_fragmented_noise,
        safe_fake_kz_record,
        safe_attachment_manifest,
        safe_usb_admin,
        safe_archive_training,
    ],
    "LOW": [low_contact],
    "MEDIUM": [medium_pii],
    "HIGH": [high_pii],
    "CRITICAL": [critical_secret],
}


def build_split(size: int, rng: random.Random) -> List[Sample]:
    out = []
    per_label = size // len(LABELS)
    remainder = size % len(LABELS)
    for idx, label in enumerate(LABELS):
        target = per_label + (1 if idx < remainder else 0)
        for _ in range(target):
            out.append(rng.choice(GENERATORS[label])(rng))
    rng.shuffle(out)
    return out


def write_csv(path: Path, rows: Sequence[Sample]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["text", "label", "source", "sample_type"])
        writer.writeheader()
        for row in rows:
            writer.writerow({"text": row.text, "label": row.label, "source": row.source, "sample_type": row.sample_type})


def summarize(rows: Sequence[Sample]) -> Dict[str, int]:
    counts = Counter(row.label for row in rows)
    return {label: counts.get(label, 0) for label in LABELS}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate balanced synthetic dataset with stronger hard negatives.")
    parser.add_argument("--out_dir", type=Path, default=Path("data/processed/synth_v3"))
    parser.add_argument("--train_size", type=int, default=25000)
    parser.add_argument("--val_size", type=int, default=5000)
    parser.add_argument("--test_size", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    for split, size in [("train", args.train_size), ("val", args.val_size), ("test", args.test_size)]:
        rows = build_split(size, rng)
        write_csv(args.out_dir / f"{split}.csv", rows)
        print(f"{split}: {summarize(rows)} -> {args.out_dir / f'{split}.csv'}")


if __name__ == "__main__":
    main()
