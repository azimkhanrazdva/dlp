from pathlib import Path

from agent.windows_agent import AgentConfig, EndpointAgent


def main() -> int:
    config_path = Path("agent/config.json")
    if not config_path.exists():
        example = Path("agent/config.example.json")
        config_path.write_text(example.read_text(encoding="utf-8"), encoding="utf-8")
    config = AgentConfig.load(config_path)
    agent = EndpointAgent(config, config_path=config_path)
    agent.enroll_if_needed()
    agent.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
