"""Full chain demo: Agent enrollment -> Telegram CSV intercept -> DLP -> SOC incident."""
import json
import sys
import time
from pathlib import Path

# Use the real agent classes so HMAC signing works correctly
sys.path.insert(0, str(Path(__file__).parent))
from agent.windows_agent import AgentConfig, EndpointAgent

SERVER = "http://127.0.0.1:5000"
SEP = "=" * 62

def show(step: int, title: str) -> None:
    print(f"\n[{step}] {title}")

def main() -> None:
    print(SEP)
    print("  ПОЛНАЯ ЦЕПОЧКА DLP — ДЕМОНСТРАЦИЯ")
    print(SEP)

    # ── 1. Build agent config ────────────────────────────────────
    show(1, "Создаём конфигурацию агента...")
    config = AgentConfig(
        server_url=SERVER,
        agent_key="",
        actor_email="analyst@example.test",
        agent_id="DEMO-PC:demo-user",
        display_name="DEMO-PC endpoint",
        enrollment_key="example-enrollment-key",
        allow_insecure_localhost=True,
    )
    agent = EndpointAgent(config)
    print(f"    actor  : {config.actor_email}")
    print(f"    server : {config.server_url}")

    # ── 2. Enroll ────────────────────────────────────────────────
    show(2, "Регистрируем агента на сервере...")
    ok = agent.enroll_if_needed(force=True)
    if ok and agent.config.agent_key:
        print(f"    OK  agent_id={agent.config.agent_id}")
        print(f"    key = {agent.config.agent_key[:18]}...")
    else:
        print("    WARN: енролмент не удался, пробуем без ключа")

    time.sleep(0.3)

    # ── 3. Show what agent detected ─────────────────────────────
    show(3, "Telegram.exe обнаружен в процессах.")
    print("    Файл появился в Telegram Downloads...")
    print("    Агент перехватывает: kaspi_clients_export_2024.csv")

    csv_content = (
        "client_id,ИИН,ФИО,Телефон,IBAN,Баланс\n"
        "1,870930400213,Сейткали Айгерим,+77012345678,KZ86125KZT5004100100,1250000\n"
        "2,850720300147,Турегелді Диас,+77771234567,KZ24551KZT3409001200,890000\n"
        "3,010412650089,Нурланова Асем,+77051234567,KZ19722KZT8800200345,3400000\n"
        "4,960315450132,Бекова Жансая,+77752223344,KZ75125KZT2070001234,450000\n"
        "5,771105300074,Ержан Бауыржан,+77073334455,KZ86125KZT5001234567,2100000\n"
    )
    print(f"    Размер : {len(csv_content)} байт")
    print(f"    Канал  : messenger / Telegram")

    # ── 4. DLP Engine inspect ────────────────────────────────────
    show(4, "Отправляем в DLP Engine (regex + entropy + BERT ML)...")
    result = agent.inspect_text(
        text=csv_content,
        channel="messenger",
        platform="Telegram",
        destination="Внешний чат Telegram",
    )

    if result is None:
        print("    ERROR: сервер не ответил")
        return

    severity = (
        result.get("severity")
        or (result.get("result") or {}).get("severity", "UNKNOWN")
    )
    summary = (
        result.get("summary")
        or (result.get("result") or {}).get("summary", "")
    )
    incident_id = result.get("incident_id")
    message_id  = result.get("message_id")
    text_result = result.get("text_result") or result.get("result") or {}
    indicators  = text_result.get("indicators") or []
    actions     = text_result.get("actions") or []

    print(f"\n    Severity   : {severity}")
    print(f"    Summary    : {summary}")

    if indicators:
        print(f"    Indicators : {len(indicators)} найдено")
        for ind in indicators[:10]:
            kind = ind.get("kind", "?")
            sev  = ind.get("severity", "?")
            val  = str(ind.get("value", ""))[:55]
            print(f"      [{sev:8}] {kind:25} -> {val}")

    if actions:
        print(f"\n    Actions :")
        for a in actions:
            print(f"      - {a}")

    # ── 5. SOC incident ──────────────────────────────────────────
    show(5, "Результат зафиксирован в SOC-консоли:")
    if incident_id:
        print(f"    ИНЦИДЕНТ #{incident_id} СОЗДАН")
        print(f"    Просмотр  -> {SERVER}/dashboard")
        print(f"    Прямая    -> {SERVER}/incidents/{incident_id}")
    else:
        print(f"    Инцидент не создан (severity={severity})")
    if message_id:
        print(f"    Message ID: {message_id}")

    # ── 6. Endpoint enforcement ──────────────────────────────────
    show(6, "Агент применяет политики на endpoint:")
    if severity == "CRITICAL":
        print("    [x] Clipboard очищен")
        print("    [x] Файл перемещён в карантин: agent_data/quarantine/")
        print("    [x] Процесс Telegram ОСТАНОВЛЕН (kill_process_on_critical)")
    elif severity == "HIGH":
        print("    [x] Clipboard очищен")
        print("    [x] Файл перемещён в карантин")
        print("    [ ] Процесс не остановлен (только HIGH)")
    else:
        print(f"    [ ] Только аудит-лог (severity={severity})")

    print("\n" + SEP)
    print(f"  ИТОГ: {severity}  |  Инцидент #{incident_id}  |  SOC уведомлён")
    print(SEP)

    print("\nПолный ответ сервера:")
    print(json.dumps(result, ensure_ascii=False, indent=2)[:3500])


if __name__ == "__main__":
    main()
