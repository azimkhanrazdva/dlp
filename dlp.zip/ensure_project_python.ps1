$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$venvDir = Join-Path $root ".venv"
$pythonExe = Join-Path $venvDir "Scripts\python.exe"

function Get-BootstrapPython {
  $candidates = @(
    @{ Command = "py"; Args = @("-3.10", "-c", "import sys; print(sys.executable)") },
    @{ Command = "py"; Args = @("-3", "-c", "import sys; print(sys.executable)") },
    @{ Command = "python"; Args = @("-c", "import sys; print(sys.executable)") }
  )

  foreach ($candidate in $candidates) {
    try {
      $result = & $candidate.Command @($candidate.Args) 2>$null
      if ($LASTEXITCODE -eq 0 -and $result) {
        return ($result | Select-Object -First 1).Trim()
      }
    } catch {
    }
  }

  throw "Could not find a usable bootstrap Python interpreter. Install Python 3.10+ and try again."
}

function Ensure-ProjectVenv {
  if (Test-Path $pythonExe) {
    try {
      & $pythonExe --version *> $null
      if ($LASTEXITCODE -eq 0) {
        return $pythonExe
      }
    } catch {
    }
  }

  if (Test-Path $venvDir) {
    Remove-Item -LiteralPath $venvDir -Recurse -Force
  }

  $bootstrapPython = Get-BootstrapPython
  & $bootstrapPython -m venv $venvDir
  if (-not (Test-Path $pythonExe)) {
    throw "Virtual environment was created, but python.exe was not found in .venv\\Scripts."
  }

  & $pythonExe -m pip install --upgrade pip setuptools wheel
  & $pythonExe -m pip install -r (Join-Path $root "requirements_web.txt") -r (Join-Path $root "requirements_agent.txt") -r (Join-Path $root "requirements_train.txt")
  return $pythonExe
}

Ensure-ProjectVenv
