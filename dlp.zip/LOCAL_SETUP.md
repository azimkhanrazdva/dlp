# SecureMail Local Setup

## Fastest start

Run the full local stack:

```powershell
powershell -ExecutionPolicy Bypass -File .\start_local_stack.ps1
```

This opens:

- local SecureMail web platform
- local SecureMail Windows desktop app

## Manual start

### Site

```powershell
powershell -ExecutionPolicy Bypass -File .\start_local_site.ps1
```

### Agent

```powershell
powershell -ExecutionPolicy Bypass -File .\start_local_agent.ps1
```

### Windows app

```powershell
powershell -ExecutionPolicy Bypass -File .\start_windows_app.ps1
```

## URLs

- Site: `http://127.0.0.1:5000/`
- Admin: `http://127.0.0.1:5000/admin`
- Agents: `http://127.0.0.1:5000/admin/agents`
- Getting started: `http://127.0.0.1:5000/getting-started`

## Demo accounts

- `soc@securemail.kz / 123123123`
- `analyst@example.test / demo-user123!`

## Agent config

The local endpoint agent config is already prepared here:

- `agent/config.json`

## Windows app

Use the Windows desktop app to:

- save local config
- enroll and rotate agent key
- install or remove the Windows service
- start or stop the service
- run manual text or file inspections

## Notes

- The start scripts now auto-rebuild `.venv` if it is missing or broken.
- Admin simulator: `http://127.0.0.1:5000/admin/simulator`
