"""
Diploma test dataset — 150 labelled samples across all severity levels.
Each sample has: text, expected_severity, category, language, channel.

Categories:
  SAFE: normal business communication
  LOW: single PII fragment, low risk
  MEDIUM: moderate PII or financial context
  HIGH: sensitive identity / banking / source code
  CRITICAL: credentials, bulk PII, production secrets
"""
from dataclasses import dataclass
from typing import List


@dataclass
class Sample:
    text: str
    expected: str      # SAFE / LOW / MEDIUM / HIGH / CRITICAL
    category: str      # threat category label
    language: str      # ru / kk / en / mixed
    channel: str       # email / clipboard / file / messenger


SAMPLES: List[Sample] = [

    # ══════════════════════════════════════════════════════════════════════
    # SAFE — 30 samples
    # ══════════════════════════════════════════════════════════════════════
    Sample(
        "Добрый день! Прошу вас утвердить квартальный отчёт по операционным расходам за Q2 2024. "
        "Все документы приложены в системе. С уважением, Айгерим.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Hi team, the sprint review is scheduled for Friday at 3 PM. "
        "Please prepare your demos. No blockers reported so far.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Сәлем Диас, кездесуді бейсенбіге ауыстыра аламыз ба? Маған 14:00 ыңғайлы.",
        "SAFE", "business_communication", "kk", "messenger"
    ),
    Sample(
        "Please review the attached proposal for the new office supplies vendor. "
        "Total estimated annual spend: 450,000 tenge. Approval needed by EOD.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Коллеги, напоминаю о корпоративном тренинге по кибербезопасности в следующий вторник. "
        "Явка обязательна для всех сотрудников отдела ИТ.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "The deployment to staging was successful. All smoke tests passed. "
        "Promoting to production is scheduled for Saturday 02:00 UTC.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Уважаемый Азиз, направляю вам презентацию о продуктовой стратегии на 2025 год. "
        "Буду рад обсудить детали на встрече.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Команда финансов просит предоставить отчёт о командировочных расходах до 15 числа. "
        "Форма доступна на корпоративном портале.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Hello, I wanted to follow up on the status of the procurement request #4521. "
        "Has it been reviewed by the legal team yet?",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Мемлекеттік сатып алу бойынша есеп дайындалды. Барлық деректер архивте.",
        "SAFE", "business_communication", "kk", "email"
    ),
    Sample(
        "All system services are operational. No incidents reported in the last 24 hours. "
        "Next maintenance window: Sunday 01:00-03:00.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Добрый день, прошу подтвердить получение договора. Ждём подписанный экземпляр.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "The marketing campaign results for March: 12,400 impressions, CTR 3.2%, 42 conversions. "
        "Full analytics dashboard shared in Confluence.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Итоги совещания 5 мая: утверждён план развития на полугодие, бюджет согласован. "
        "Следующая встреча — 19 мая в 11:00.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Dear partner, thank you for attending our annual conference. "
        "The recording will be available on our portal within 48 hours.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "function calculateTax(income, rate) {\n  return income * rate / 100;\n}\n"
        "// Standard tax calculation utility, no sensitive data",
        "SAFE", "source_code_clean", "en", "file"
    ),
    Sample(
        "SELECT name, department, hire_date FROM employees WHERE department = 'Finance' ORDER BY name;",
        "SAFE", "source_code_clean", "en", "clipboard"
    ),
    Sample(
        "Клиентская база обновлена. Всего активных клиентов: 4 821. Новых за месяц: 134.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Reminder: annual security training deadline is May 31. "
        "Please complete the 45-minute course on the learning portal.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Архив документов за 2023 год перенесён на новый сервер. "
        "Доступ через корпоративную сеть, раздел 'Архив 2023'.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Сәлеметсіздер ме, жаңа нұсқаулық дайын. Барлығына жіберілді.",
        "SAFE", "business_communication", "kk", "email"
    ),
    Sample(
        "The HR department will be closed on Monday due to the public holiday. "
        "All requests submitted on Monday will be processed on Tuesday.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Добрый день, направляем ссылку на корпоративный портал для подачи заявок. "
        "Логин — ваш корпоративный email.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Project Orion is now in UAT phase. Please report any bugs to the JIRA board. "
        "Go-live target: June 1.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Уважаемые коллеги, приглашаем на корпоративный субботник 18 мая. "
        "Сбор у главного входа в 10:00. Форма одежды — спортивная.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "import os\nimport sys\nfrom pathlib import Path\n\ndef get_config_path():\n    return Path.home() / '.config' / 'app'\n",
        "SAFE", "source_code_clean", "en", "file"
    ),
    Sample(
        "Жылдық есеп 2023 жыл. Кіріс: 1 200 000 000 теңге. Шығыс: 980 000 000 теңге.",
        "SAFE", "business_communication", "kk", "file"
    ),
    Sample(
        "Please confirm attendance for the board meeting on May 20 at 10:00 AM in Conference Room B.",
        "SAFE", "business_communication", "en", "email"
    ),
    Sample(
        "Отчёт об использовании офисного оборудования за апрель передан в бухгалтерию.",
        "SAFE", "business_communication", "ru", "email"
    ),
    Sample(
        "Version 2.3.1 released. Changelog: fixed pagination bug, improved search performance, "
        "updated dependencies. No breaking changes.",
        "SAFE", "business_communication", "en", "email"
    ),

    # ══════════════════════════════════════════════════════════════════════
    # LOW — 30 samples
    # ══════════════════════════════════════════════════════════════════════
    Sample(
        "Позвоните мне, пожалуйста: +0 000 000 00 00. Буду на связи до 18:00.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "Мой рабочий email: demo-user.saparova@kaspi.kz — можете писать напрямую.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "For inquiries, contact our support line: +7 727 300 50 00 (Mon-Fri, 9-18).",
        "LOW", "contact_info", "en", "email"
    ),
    Sample(
        "Дата рождения сотрудника: 12 мая 1990 года. Отдел кадров, для внутреннего учёта.",
        "LOW", "personal_info", "ru", "file"
    ),
    Sample(
        "Маған хабарласыңыз: +7 747 555 12 34. Жұмыс уақыты 09:00-18:00.",
        "LOW", "contact_info", "kk", "messenger"
    ),
    Sample(
        "Customer email on file: customer@example.test. Updated as of Q1 2024.",
        "LOW", "contact_info", "en", "file"
    ),
    Sample(
        "Рабочий телефон Мадины: +7 775 444 33 22. Внутренний добавочный: 4412.",
        "LOW", "contact_info", "ru", "messenger"
    ),
    Sample(
        "Направляем ваш рабочий адрес: г. Алматы, пр. Достык, д. 38, офис 205.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "Employee DOB on record: 03/15/1985. Required for insurance form processing.",
        "LOW", "personal_info", "en", "email"
    ),
    Sample(
        "Контактное лицо: Дауренов Аслан, тел. +7 (701) 987-65-43, email: a.daurenov@example.test",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "Support ticket raised by: dias@corp.kz. Issue: VPN access not working.",
        "LOW", "contact_info", "en", "messenger"
    ),
    Sample(
        "Кері байланыс нөмірі: +7 702 111 22 33. Жауап беру мерзімі — 2 жұмыс күні.",
        "LOW", "contact_info", "kk", "email"
    ),
    Sample(
        "Адрес доставки: Нур-Султан, ул. Кунаева, д. 14, кв. 7, Исатаева Жания.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "Please update the delivery contact to: +7 708 321 09 87 (Aizat Bekova).",
        "LOW", "contact_info", "en", "email"
    ),
    Sample(
        "Сотрудник: Жаксыбеков Берик, дата рождения: 22.08.1992, должность: аналитик.",
        "LOW", "personal_info", "ru", "file"
    ),
    Sample(
        "For billing questions contact: billing@example.test or call +7 727 250 10 20.",
        "LOW", "contact_info", "en", "email"
    ),
    Sample(
        "Автор заявки: seitkali@fintech.kz. Приоритет: низкий. Срок: 30 мая.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "Delivery address: 34 Alatau street, Almaty. Recipient: Demo Person Bukhanova.",
        "LOW", "contact_info", "en", "email"
    ),
    Sample(
        "Байланыс: Ержан Сейітқали, ұялы: +7 775 800 90 10, жұмыс: +7 727 201 11 02.",
        "LOW", "contact_info", "kk", "email"
    ),
    Sample(
        "Обновите контакт: телефон изменился на +7 705 678 43 21. Имя прежнее.",
        "LOW", "contact_info", "ru", "messenger"
    ),
    Sample(
        "User profile created: login=asel.nurlan@bank.kz, role=viewer, created=2024-05-01.",
        "LOW", "contact_info", "en", "file"
    ),
    Sample(
        "Прошу указать актуальный email для рассылки: предыдущий madina@old-domain.kz недействителен.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "Информация для связи: руководитель проекта — Seiit Nurbek, +7 701 000 12 12.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "New vendor contact added: vendor_support@techkz.com, phone +7 727 388 00 11.",
        "LOW", "contact_info", "en", "email"
    ),
    Sample(
        "Менің телефоным: +7 747 321 54 76. Telegram да жазсаңыз болады.",
        "LOW", "contact_info", "kk", "messenger"
    ),
    Sample(
        "Сотрудник уволен 30.04.2024. Контактный email для архива: ex-staff@example.test",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "HR record: name=Aliya Bekova, hire date=2021-03-01, dept=Finance.",
        "LOW", "personal_info", "en", "file"
    ),
    Sample(
        "Мекенжай: Алматы қаласы, Медеу ауданы, Достық даңғылы 180.",
        "LOW", "contact_info", "kk", "email"
    ),
    Sample(
        "Обновление профиля: dias.akhmetov@securemail.kz, отдел ИТ, внутренний 2201.",
        "LOW", "contact_info", "ru", "email"
    ),
    Sample(
        "Callback number for client Seitkali Nurlanov: +7 (702) 555-77-88.",
        "LOW", "contact_info", "en", "email"
    ),

    # ══════════════════════════════════════════════════════════════════════
    # MEDIUM — 30 samples
    # ══════════════════════════════════════════════════════════════════════
    Sample(
        "Список контактов клиентов:\n1. +0 000 000 00 06 — Айгерим К.\n"
        "2. +7 702 222 33 44 — Нурлан А.\n3. +7 705 333 44 55 — Мадина Т.\n"
        "4. +7 747 444 55 66 — Берик Ж.\n5. +7 771 555 66 77 — Асель Н.",
        "MEDIUM", "contact_list", "ru", "email"
    ),
    Sample(
        "Кадровый реестр (фрагмент):\nСейткали Ержан, должность: менеджер, оклад: 450,000 тг\n"
        "Жаксыбеков Берик, должность: аналитик, оклад: 380,000 тг\n"
        "Мухамеджанова Зарина, должность: бухгалтер, оклад: 420,000 тг",
        "MEDIUM", "hr_data", "ru", "file"
    ),
    Sample(
        "Customer callback sheet:\ndemo-user S. — +0 000 000 00 07, email: customer-a@example.test\n"
        "Dias A. — +0 000 000 00 08, email: customer-b@example.test\n"
        "Madina T. — +7 703 345 67 89",
        "MEDIUM", "contact_list", "en", "email"
    ),
    Sample(
        "Финансовый отчёт сотрудника: Сейткали Н., зарплатная карта Kaspi, остаток: 125,400 тенге. "
        "Плановые выплаты: 15 и 30 числа.",
        "MEDIUM", "financial_data", "ru", "email"
    ),
    Sample(
        "Medical record summary: patient DOB 12/05/1988, diagnosis code J45.0, "
        "prescribed medication: Salbutamol 100mcg. Insurance policy #KZ-2024-8821.",
        "MEDIUM", "medical_data", "en", "email"
    ),
    Sample(
        "Список сотрудников на командировку:\n"
        "Ахметов Д. — загранпаспорт, +7 701 000 11 22\n"
        "Сапарова А. — удостоверение личности, +7 702 000 22 33\n"
        "Тулегенова М. — загранпаспорт, +7 705 000 33 44",
        "MEDIUM", "hr_data", "ru", "email"
    ),
    Sample(
        "Transaction history (partial): 2024-04-01: 15,000 KZT transfer to Halyk Bank. "
        "2024-04-05: 8,500 KZT utility payment. 2024-04-12: 45,000 KZT salary credit.",
        "MEDIUM", "financial_data", "en", "file"
    ),
    Sample(
        "Клиенты на обзвон (сегодня):\n- Нурланов, 8 701 111 00 22, продукт Kasko\n"
        "- Бекова, +7 702 222 00 33, продукт ОСМС\n- Сейтжанов, +7 747 333 00 44, VIP клиент",
        "MEDIUM", "contact_list", "ru", "messenger"
    ),
    Sample(
        "Внутренний отчёт HR: количество сотрудников — 234, средняя зарплата — 312,000 тг, "
        "текучесть кадров за квартал — 4.2%, отдел с наибольшей текучестью — продажи.",
        "MEDIUM", "hr_data", "ru", "email"
    ),
    Sample(
        "Client data for CRM import:\nname,email,phone,city\n"
        "Demo Person A,person-a@example.test,+00000000001,Almaty\n"
        "Berik Zhak,berik@inbox.kz,+00000000002,Astana\n"
        "Demo Person B,person-b@example.test,+00000000004,Shymkent",
        "MEDIUM", "contact_list", "en", "file"
    ),
    Sample(
        "Агент по страхованию — данные клиента: Исатаева Жания Каиратовна, "
        "дата рождения 14.02.1987, полис ОСМС №KZ-2024-114592, страховая сумма 5 000 000 тг.",
        "MEDIUM", "insurance_data", "ru", "email"
    ),
    Sample(
        "Salary benchmarking report Q1 2024: IT dept average 580,000 KZT, "
        "Finance dept average 420,000 KZT, Operations avg 310,000 KZT.",
        "MEDIUM", "hr_data", "en", "file"
    ),
    Sample(
        "Задолженность клиентов (фрагмент):\n- Ахметов А.А.: 45,600 тг\n"
        "- Нурлан Б.Б.: 12,300 тг\n- Зарина К.К.: 78,900 тг\nОбщая сумма: 136,800 тг",
        "MEDIUM", "financial_data", "ru", "email"
    ),
    Sample(
        "Employee survey results: 67% satisfied with workload, 54% want flexible hours, "
        "31% considering leaving in next 12 months. Department breakdown attached.",
        "MEDIUM", "hr_data", "en", "email"
    ),
    Sample(
        "Контракт №2024-0481: сумма 1,200,000 тг, срок исполнения — 3 месяца, "
        "ответственное лицо — Дауренова Айнур, тел. +7 701 800 90 01.",
        "MEDIUM", "contract_data", "ru", "email"
    ),
    Sample(
        "Абоненттік база: 1234 белсенді қолданушы, орташа шот 8,500 теңге, "
        "байланыс нөмірлері жаңартылды.",
        "MEDIUM", "customer_data", "kk", "file"
    ),
    Sample(
        "Loyalty program members exported: 890 records including name, phone, tier (gold/silver/bronze). "
        "Shared with marketing team for campaign targeting.",
        "MEDIUM", "customer_data", "en", "email"
    ),
    Sample(
        "Детальная выписка по зарплатному проекту: подразделение «Розничные продажи», "
        "24 сотрудника, суммарный фонд оплаты труда — 7,680,000 тг/месяц.",
        "MEDIUM", "financial_data", "ru", "file"
    ),
    Sample(
        "Vendor invoice list: 12 invoices totalling 4.2M KZT. "
        "Oldest unpaid: vendor Techline KZ, 890,000 KZT, 45 days overdue.",
        "MEDIUM", "financial_data", "en", "email"
    ),
    Sample(
        "Feedback form responses (100 clients): avg satisfaction 7.2/10, "
        "NPS score 34, includes client names and contact emails.",
        "MEDIUM", "customer_data", "en", "file"
    ),
    Sample(
        "Рекламная база клиентов Kaspi: 3 500 email-адресов, сегмент — активные вкладчики. "
        "Файл передан агентству Digital KZ для рассылки.",
        "MEDIUM", "customer_data", "ru", "email"
    ),
    Sample(
        "Страховой случай №INS-2024-8821: застрахованный Нурлан Ахметов, "
        "сумма выплаты 340,000 тг, дата ДТП 12.04.2024, полис КАСКО.",
        "MEDIUM", "insurance_data", "ru", "email"
    ),
    Sample(
        "Procurement vendor data exported: 45 vendors, including contact persons, "
        "phone numbers, and bank account details for KZT settlements.",
        "MEDIUM", "financial_data", "en", "file"
    ),
    Sample(
        "Таблица расходов сотрудников за апрель:\nАхметов Д.: командировка 85,000 тг\n"
        "Сапарова А.: представительские 32,000 тг\nТулегенова М.: обучение 120,000 тг",
        "MEDIUM", "financial_data", "ru", "file"
    ),
    Sample(
        "Reinsurance portfolio summary: total insured value 45B KZT, "
        "top 10 policyholders and their coverage amounts included in attachment.",
        "MEDIUM", "financial_data", "en", "email"
    ),
    Sample(
        "Клиентская CRM выгрузка: 450 клиентов. Поля: имя, дата рождения, телефон, баланс.",
        "MEDIUM", "customer_data", "ru", "clipboard"
    ),
    Sample(
        "Tender evaluation results: 6 bidders, scores and pricing breakdown for each. "
        "Winning bid: KZ-Stroy Ltd, 12.4M KZT. Marked commercial-in-confidence.",
        "MEDIUM", "financial_data", "en", "email"
    ),
    Sample(
        "Данные для проверки: сотрудник Берик Жаксыбеков, год рождения 1992, "
        "образование — ВШЭ, регион — Алматы. Запрос из отдела безопасности.",
        "MEDIUM", "personal_info", "ru", "email"
    ),
    Sample(
        "Support case: client Aizat Bekova, DOB 1990-07-21, account opened 2018-03-15, "
        "complaint about transaction dated 2024-04-30.",
        "MEDIUM", "personal_info", "en", "email"
    ),
    Sample(
        "Экспорт данных CRM: клиент Нурланов Азиз, телефон +7 705 100 20 30, "
        "сегмент Premium, менеджер Айгерим С., дата последнего контакта: 02.05.2024.",
        "MEDIUM", "customer_data", "ru", "clipboard"
    ),

    # ══════════════════════════════════════════════════════════════════════
    # HIGH — 30 samples
    # ══════════════════════════════════════════════════════════════════════
    Sample(
        "Реквизиты для перевода: КЗ75125КЗТ1001234567890, АО «Народный Банк Казахстана». "
        "Сумма: 2,500,000 тенге. Назначение платежа: оплата по договору №2024-0481.",
        "HIGH", "banking_data", "ru", "email"
    ),
    Sample(
        "Удостоверение личности: Demo Person A Ерланович, ИИН 000000000101, "
        "номер УЛ: 027348921, выдан 15.03.2019, срок действия до 2029 года.",
        "HIGH", "identity_document", "ru", "email"
    ),
    Sample(
        "Wire transfer details: IBAN KZ891250000012345678, beneficiary: Asel Investments LLP, "
        "Jusan Bank Kazakhstan, SWIFT: TSESKZKA, amount: USD 18,500.",
        "HIGH", "banking_data", "en", "email"
    ),
    Sample(
        "Паспорт: Demo Person B Болатовна, №N09834512, выдан МВД РК 22.11.2020, "
        "ИИН: 000000000102. Действителен до 22.11.2030.",
        "HIGH", "identity_document", "ru", "file"
    ),
    Sample(
        "Карта клиента Visa: 4111 1111 1111 1111, держатель NURLAN AKHMETOV, "
        "срок 12/26, CVV 234. Лимит карты: 500,000 тенге.",
        "HIGH", "payment_card", "ru", "email"
    ),
    Sample(
        "Employee tax record: IIN 000000000103, full name Madina Tulegenova, "
        "annual income 5,400,000 KZT, tax paid 648,000 KZT. Year: 2023.",
        "HIGH", "identity_document", "en", "file"
    ),
    Sample(
        "Счёт для оплаты: KZ091830000000123456, АО Freedom Finance Bank. "
        "БИК: KCJBKZKX. Получатель: ТОО «Алтын Технологии». Сумма: 890,000 тг.",
        "HIGH", "banking_data", "ru", "email"
    ),
    Sample(
        "Банктік деректемелер: IBAN KZ56125KZT1000023456, Халық Банкі АҚ. "
        "ЖСН: 870622300087. Сома: 1 200 000 теңге.",
        "HIGH", "banking_data", "kk", "email"
    ),
    Sample(
        "Credit card details for hotel booking: MasterCard 5500 0000 0000 0004, "
        "name: DIAS AKHMETOV, expiry: 09/27, billing address: 45 Dostyk Ave, Almaty.",
        "HIGH", "payment_card", "en", "email"
    ),
    Sample(
        "Налоговая декларация: ЖСН 950108450234, Жаксыбеков Берик Маратович, "
        "доход за 2023 год: 4,200,000 тг. Регистрация в КГД МФ РК.",
        "HIGH", "identity_document", "ru", "file"
    ),
    Sample(
        "KYC document: customer IIN 780930600045, name Demo Person Bukhamejanova, "
        "passport number AB123456, issued 2018, Halyk Bank onboarding record.",
        "HIGH", "identity_document", "en", "file"
    ),
    Sample(
        "Платёжное поручение: получатель ТОО «КазМунай Сервис», IBAN KZ241640000000987654, "
        "сумма 4,700,000 тг, назначение: оплата нефтепродуктов по счёту №44-2024.",
        "HIGH", "banking_data", "ru", "email"
    ),
    Sample(
        "Patient record: IIN 001024500123, full name Aizat Bekova, "
        "diagnosis: hypertension stage 2, prescribed medication, cardiologist referral attached.",
        "HIGH", "medical_data", "en", "file"
    ),
    Sample(
        "Акционерный реестр: Сейткали Нурлан Ержанович, ИИН 870412350099, "
        "количество акций 4,500 шт., текущая стоимость пакета 22,500,000 тг.",
        "HIGH", "financial_data", "ru", "file"
    ),
    Sample(
        "SWIFT transfer confirmation: sender account KZ36914000000001234567 (Kaspi Bank), "
        "receiver IBAN DE89370400440532013000, amount EUR 12,000, ref INV2024-1142.",
        "HIGH", "banking_data", "en", "email"
    ),
    Sample(
        "Исходный код с конфигурацией базы данных:\nHOST = 'prod-db.internal'\n"
        "PORT = 5432\nDATABASE = 'customers'\nUSER = 'app_user'\nPASSWORD = 'Str0ng#Pass'",
        "HIGH", "source_code_config", "ru", "clipboard"
    ),
    Sample(
        "Реестр вкладчиков (5 записей):\n"
        "ИИН 000000000101, Ахметов Д., вклад 5,000,000 тг\n"
        "ИИН 000000000102, Сапарова А., вклад 2,000,000 тг\n"
        "ИИН 000000000103, Тулегенова М., вклад 1,500,000 тг",
        "HIGH", "banking_data", "ru", "file"
    ),
    Sample(
        "Loan application: applicant Berik Zhaksy, IIN 901205000087, "
        "IBAN KZ751250000001234567, requested 3,000,000 KZT, Kaspi Gold card limit 800,000 KZT.",
        "HIGH", "banking_data", "en", "file"
    ),
    Sample(
        "config.py:\nDEBUG = False\nSECRET_KEY = 'prod-key-abc123xyz'\n"
        "DB_HOST = 'prod-postgres.internal'\nDB_PASS = 'DbP@ss2024!'",
        "HIGH", "source_code_config", "en", "clipboard"
    ),
    Sample(
        "Клиент: Нурланов Азиз Болатович, ИИН 791130400033, карта Halyk Visa 4532 0151 1283 0366, "
        "остаток: 340,000 тг. Запрос на выпуск дополнительной карты.",
        "HIGH", "payment_card", "ru", "email"
    ),
    Sample(
        "Court case ref: plaintiff IIN 001024500123, defendant IIN 000000000101, "
        "civil case №2024-ГД-08821, court of Almaty district. Confidential.",
        "HIGH", "legal_data", "en", "file"
    ),
    Sample(
        "Акт сверки: ТОО «Alina Pharma», БИН 090840002581, IBAN KZ891250000000567890, "
        "сальдо задолженности: 1,240,000 тг. Подтверждено двумя сторонами.",
        "HIGH", "financial_data", "ru", "file"
    ),
    Sample(
        "Mortgage document: borrower IIN 780930600045, collateral: apartment at 34 Alatau St, "
        "Almaty, loan amount 18,000,000 KZT, Jusan Bank, term 240 months.",
        "HIGH", "banking_data", "en", "file"
    ),
    Sample(
        "Биометрические данные сотрудника: ИИН 950108450234, Жаксыбеков Берик, "
        "отпечаток пальца записан в системе СКУД, доступ — уровень 3.",
        "HIGH", "biometric_data", "ru", "file"
    ),
    Sample(
        "Insurance claim: policy holder IIN 870622300087, Halyk insurance policy #2024-LF-44512, "
        "claim amount 850,000 KZT, supporting medical records attached.",
        "HIGH", "insurance_data", "en", "email"
    ),
    Sample(
        "Реквизиты для зарплатной ведомости:\nАхметов Д.Е. — IBAN KZ751250000001111111\n"
        "Сапарова А.Б. — IBAN KZ751250000002222222\n"
        "Тулегенова М.С. — IBAN KZ751250000003333333",
        "HIGH", "banking_data", "ru", "file"
    ),
    Sample(
        "Trading account: IIN 000000000103, Freedom Finance account #KZ-FF-2024-81234, "
        "portfolio value 12,450,000 KZT, positions: KASE blue chips, 45 transactions in April.",
        "HIGH", "financial_data", "en", "file"
    ),
    Sample(
        "Медицинская карта: пациент ИИН 001024500123, диагноз F32.1 (умеренный депрессивный эпизод), "
        "лечение: Эсциталопрам 10 мг. Конфиденциально, психиатрическая клиника.",
        "HIGH", "medical_data", "ru", "file"
    ),
    Sample(
        "Cadastral record: land plot owner IIN 000000000101, plot #0504-222-001-1234, "
        "area 800 sq.m., Almaty region, estimated value 4,500,000 KZT.",
        "HIGH", "legal_data", "en", "file"
    ),
    Sample(
        "Счёт-фактура №2024-0892: продавец АО «Kaspi Bank», БИН 971240001315, "
        "НДС рег. №123456789012, сумма НДС 120,000 тг, итого 920,000 тг.",
        "HIGH", "financial_data", "ru", "email"
    ),

    # ══════════════════════════════════════════════════════════════════════
    # CRITICAL — 30 samples
    # ══════════════════════════════════════════════════════════════════════
    Sample(
        "AWS credentials leaked:\nAWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE\n"
        "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n"
        "Region: ap-southeast-1. DO NOT SHARE.",
        "CRITICAL", "cloud_credentials", "en", "clipboard"
    ),
    Sample(
        "Production database:\nDATABASE_URL=postgresql://admin:Sup3rS3cr3t!@prod-db.kaspi.kz:5432/customers_prod\n"
        "Replicas: 3 read-only nodes. 4.2M customer records.",
        "CRITICAL", "database_credentials", "en", "email"
    ),
    Sample(
        "OpenAI API key for production:\nEXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKL\n"
        "Monthly limit: $5,000. Shared with data science team.",
        "CRITICAL", "api_key", "en", "messenger"
    ),
    Sample(
        "Массовая выгрузка клиентской базы:\n"
        "ИИН,ФИО,телефон,карта,IBAN\n"
        "000000000101,Demo Person A,+00000000001,4111111111111110,KZ751250000001234567\n"
        "000000000102,Demo Person B,+00000000002,5500000000000000,KZ891250000002345678\n"
        "000000000103,Demo Person C,+00000000003,4532015112830360,KZ761640000003456789\n"
        "870622300087,Жаксыбеков Берик,+77475554567,4916338506082830,KZ131240000004567890\n"
        "950108450234,Бекова Айзат,+77015555678,5425233430109903,KZ651250000005678901",
        "CRITICAL", "bulk_pii", "ru", "email"
    ),
    Sample(
        "Private key (RSA 4096):\n-----BEGIN EXAMPLE RSA PRIVATE KEY-----\n"
        "MIIJKAIBAAKCAgEA0Z3VS5JJcds3xHn/ygWep4oSE+UaWU/JNpyTHvVWdmq8\n"
        "yPHvOJpD8CvmObRQD43EUYkGWHCkrFTNL+VK6Jbc0OJaFPzGCXKHJxuQDJJz\n"
        "-----END EXAMPLE RSA PRIVATE KEY-----",
        "CRITICAL", "example_private_key", "en", "clipboard"
    ),
    Sample(
        "Telegram bot token для уведомлений:\n"
        "BOT_TOKEN=EXAMPLE_TELEGRAM_BOT_TOKEN_DO_NOT_USE\n"
        "Webhook: https://api.telegram.org/bot{token}/setWebhook\n"
        "Продакшн канал: -1001234567890",
        "CRITICAL", "api_key", "ru", "messenger"
    ),
    Sample(
        "Source code with hardcoded credentials (pushed to GitHub):\n"
        "KASPI_API_KEY = 'live_sk_kz_8f7d3c2a1b9e4f5g6h7i8j9k'\n"
        "KASPI_SECRET = 'production_secret_xyz_abc_12345'\n"
        "KASPI_MERCHANT_ID = '102345'\n"
        "# TODO: move to env vars",
        "CRITICAL", "api_key", "en", "clipboard"
    ),
    Sample(
        "Полная база данных пользователей (dump):\n"
        "id,iin,full_name,email,phone,password_hash,card_number,balance\n"
        "1,000000000101,Demo Person A,person-c@example.test,+00000000001,$2b$12$hash1,4111111111111110,450000\n"
        "2,000000000102,Demo Person B,demo-user@example.test,+00000000002,$2b$12$hash2,5500000000000000,230000\n"
        "3,000000000103,Demo Person C,person-d@example.test,+00000000003,$2b$12$hash3,4532015112830360,180000",
        "CRITICAL", "database_dump", "ru", "email"
    ),
    Sample(
        "JWT Secret and session keys:\nJWT_SECRET_KEY=eyJzZWNyZXQiOiJ2ZXJ5X3NlY3JldF9rZXlfcHJvZHVjdGlvbn0\n"
        "SESSION_KEY=prod-session-f8e7d6c5b4a3\n"
        "ENCRYPTION_KEY=AES256:4f5g6h7i8j9k0l1m2n3o4p5q6r7s8t9u",
        "CRITICAL", "encryption_key", "en", "clipboard"
    ),
    Sample(
        "Данные инсайдерской торговли:\nАхметов Д. приобрёл акции KEGOC за день до объявления о слиянии.\n"
        "ИИН: 000000000101, счёт Freedom Finance: KZ-FF-2024-81234.\n"
        "Покупка: 10,000 акций по 1,850 тг. Прибыль после объявления: +42%.",
        "CRITICAL", "insider_trading", "ru", "email"
    ),
    Sample(
        "GitHub Actions secret exposed in log:\nSECRET_TOKEN=EXAMPLE_GITHUB_TOKEN_DO_NOT_USE\n"
        "DEPLOY_KEY=base64:LS0tLS1CRUdJTiBPUEVOU1NIIFBSSVZBVEUgS0VZLS0tLS0\n"
        "Environment: production",
        "CRITICAL", "api_key", "en", "clipboard"
    ),
    Sample(
        "Карточные данные клиентов (50 записей):\n"
        "4111111111111110|12/26|123|DIAS AKHMETOV\n"
        "5500000000000000|09/27|456|demo-user SAPAROVA\n"
        "4916338506082830|03/25|789|MADINA TULEGENOVA\n"
        "4532015112830360|07/28|012|BERIK ZHAKSYBEKOV\n"
        "... (46 more records)",
        "CRITICAL", "payment_card_bulk", "ru", "email"
    ),
    Sample(
        "Production server credentials:\nSSH: root@10.0.1.45 password: Pr0d_S3rv3r!2024\n"
        "VPN: user=sysadmin pass=VPN#Kz2024Secure\n"
        "Admin panel: https://admin.internal:8443 user=superadmin pass=Admin@123!",
        "CRITICAL", "server_credentials", "en", "clipboard"
    ),
    Sample(
        "Исходный код содержит секреты Kaspi API:\nimport requests\n\n"
        "KASPI_LIVE_KEY = 'live_private_a1b2c3d4e5f6g7h8i9j0'\n"
        "def process_payment(amount, card_token):\n"
        "    headers = {'Authorization': f'Bearer {KASPI_LIVE_KEY}'}\n"
        "    return requests.post('https://api.kaspi.kz/v1/pay', ...)",
        "CRITICAL", "api_key", "ru", "clipboard"
    ),
    Sample(
        "Pension fund data breach — full subscriber list:\n"
        "IIN,surname,birth_year,monthly_contribution,total_savings\n"
        "000000000101,Akhmetov,1986,42000,5040000\n"
        "000000000102,Saparova,1992,36000,3240000\n"
        "000000000103,Tulegenova,1993,31000,2480000\n"
        "(1,240 records total)",
        "CRITICAL", "bulk_pii", "en", "email"
    ),
    Sample(
        ".env file shared externally:\nFLASK_SECRET=8f3k9d2p1m7n4q5r6s\n"
        "SENDGRID_API_KEY=SG.abc123XYZxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n"
        "STRIPE_SECRET=sk_live_51NxKzTGqSomethinglongkey0001\n"
        "DB_URL=mysql://root:root123@prod.db.internal/payments",
        "CRITICAL", "api_key", "en", "file"
    ),
    Sample(
        "Клиент отправил данные карты в мессенджер:\nНомер карты: 4111 1111 1111 1111\n"
        "Срок: 03/27\nCVV: 777\nИмя на карте: NURLAN SEITKALI\n"
        "Перевод на сумму 150,000 тг.",
        "CRITICAL", "payment_card", "ru", "messenger"
    ),
    Sample(
        "Exported Redis cache with session tokens:\n"
        "user:1234:session=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.abc.xyz\n"
        "user:5678:session=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.def.uvw\n"
        "Contains 45,000 active sessions.",
        "CRITICAL", "session_tokens", "en", "email"
    ),
    Sample(
        "Секретные ключи шифрования базы данных:\n"
        "MASTER_KEY=Tbk8Yp3Xc9Lm2Nq7Rv1Sf4Uw6Zj0Ao5Bh\n"
        "COLUMN_KEY=Gd4Hn8Kp2Ls7Mt3Nv9Ow1Px5Qy0Rz6Sa\n"
        "Используются для шифрования ИИН и номеров карт в БД.",
        "CRITICAL", "encryption_key", "ru", "clipboard"
    ),
    Sample(
        "Полная выгрузка транзакций за 2024 год:\n"
        "ИИН отправителя, ИИН получателя, сумма, дата\n"
        "000000000101, 000000000102, 500000, 2024-01-15\n"
        "000000000103, 870622300087, 1200000, 2024-02-22\n"
        "... (48,210 записей) — файл загружен в облако без шифрования",
        "CRITICAL", "bulk_pii", "ru", "email"
    ),
    Sample(
        "Halyk Bank internal API credentials:\nclient_id=halyk_prod_8f7d3c2a\n"
        "client_secret=HBK_SECRET_2024_xK9mNpQ2rT4vW6\n"
        "API endpoint: https://api-gw.hb.kz/v2/payments\n"
        "Scope: payments:write accounts:read transfers:execute",
        "CRITICAL", "api_key", "en", "clipboard"
    ),
    Sample(
        "Биометрическая база данных (фрагмент):\n"
        "ИИН 000000000101 — отпечаток: [base64_fingerprint_data_1234]\n"
        "ИИН 000000000102 — распознавание лица: [base64_face_embedding_5678]\n"
        "Всего 12,400 записей. Не для внешней передачи.",
        "CRITICAL", "biometric_data", "ru", "email"
    ),
    Sample(
        "MongoDB Atlas connection string:\n"
        "mongodb+srv://produser:Pr0dP@ssw0rd!@cluster0.abc123.mongodb.net/"
        "customers?retryWrites=true&w=majority\n"
        "Database: customers_prod. Collections: users, transactions, cards.",
        "CRITICAL", "database_credentials", "en", "clipboard"
    ),
    Sample(
        "Утечка HR базы: 3,400 сотрудников, поля — ИИН, ФИО, зарплата, банковский счёт, "
        "адрес, IBAN для зарплаты. Файл обнаружен на публичном S3 bucket.",
        "CRITICAL", "bulk_pii", "ru", "email"
    ),
    Sample(
        "Heroku config vars exported:\nDATABASE_URL=postgres://xyzadmin:S3cretPass@ec2.compute.amazonaws.com/prod\n"
        "REDIS_URL=redis://:RedisPass123@cache.internal:6379\n"
        "SECRET_KEY=django-insecure-abc123xyz789\n"
        "SENDGRID_KEY=SG.verylongapikey1234567890",
        "CRITICAL", "api_key", "en", "clipboard"
    ),
    Sample(
        "Передача в ChatGPT исходного кода с секретами:\n"
        "Пользователь загрузил файл config.py:\n"
        "PROD_DB='postgresql://superadmin:Sup3r@prod.db.kz:5432/fin_data'\n"
        "API_KEY='live_kz_8f7d3c2a1b'\n"
        "Канал: ChatGPT upload. Риск: критическая утечка.",
        "CRITICAL", "ai_tool_exfiltration", "ru", "clipboard"
    ),
    Sample(
        "Tax authority database exported without authorization:\n"
        "1,240 taxpayer records including IIN, name, declared income, tax debt.\n"
        "Format: CSV, unencrypted. Uploaded to personal Dropbox account.",
        "CRITICAL", "bulk_pii", "en", "email"
    ),
    Sample(
        "SSH private key (ed25519) for production server:\n"
        "-----BEGIN EXAMPLE OPENSSH PRIVATE KEY-----\n"
        "b3BlbnNzaC1rZXktdjEAAAAA...AAAAAAAAAA==\n"
        "-----END OPENSSH PRIVATE KEY-----\n"
        "Server: prod-app-01.internal (172.16.0.10)",
        "CRITICAL", "example_private_key", "en", "clipboard"
    ),
    Sample(
        "Полный дамп таблицы accounts:\n"
        "id,iin,email,phone,card,balance,password_hash\n"
        "1,000000000101,dias@corp.kz,+00000000001,4111111111111110,4500000,bcrypt_hash_1\n"
        "2,000000000102,demo-user@corp.kz,+00000000002,5500000000000000,2300000,bcrypt_hash_2\n"
        "3,000000000103,madina@corp.kz,+00000000003,4532015112830360,1800000,bcrypt_hash_3\n"
        "Экспортировано без санкции: 89,450 записей.",
        "CRITICAL", "database_dump", "ru", "email"
    ),
    Sample(
        "Google Cloud service account key:\n"
        '{"type":"service_account","project_id":"prod-finance-kz","example_example_private_key_id":"abc123","example_private_key":"-----BEGIN EXAMPLE RSA PRIVATE KEY-----\\nMIIEowIBAAKCAQEA...\\n-----END EXAMPLE RSA PRIVATE KEY-----",'
        '"client_email":"prod@prod-finance-kz.iam.gserviceaccount.com"}',
        "CRITICAL", "cloud_credentials", "en", "file"
    ),
]


def get_by_severity(severity: str) -> List[Sample]:
    return [s for s in SAMPLES if s.expected == severity]


def get_by_category(category: str) -> List[Sample]:
    return [s for s in SAMPLES if s.category == category]


def get_by_channel(channel: str) -> List[Sample]:
    return [s for s in SAMPLES if s.channel == channel]


SEVERITY_COUNTS = {
    "SAFE": len(get_by_severity("SAFE")),
    "LOW": len(get_by_severity("LOW")),
    "MEDIUM": len(get_by_severity("MEDIUM")),
    "HIGH": len(get_by_severity("HIGH")),
    "CRITICAL": len(get_by_severity("CRITICAL")),
}
