"""
Расширенные тесты паттернов DLP-движка.
Охватывают: KZ-специфику, международные паттерны, ложные срабатывания,
граничные случаи, нормализацию текста и каналы.
"""
import pytest


def scan(scanner, text, channel="email"):
    return scanner.scan_text(text, channel=channel)


# ═══════════════════════════════════════════════════════════════
# Блок 1: Казахстанский ИИН — правильные случаи
# ═══════════════════════════════════════════════════════════════

class TestKazakhIIN:
    # Валидные ИИН (проверены алгоритмом двух весов):
    VALID_IINS = [
        "000000000001",  # 86.05.12 + check=0
        "000000000002",  # 87.06.23 + check=5 (через второй вес)
        "000000000003",  # 88.07.34 + check=9
        "000000000004",  # 89.08.45 + check=8 (через второй вес)
        "000000000005",  # 90.09.16 + check=1
    ]

    def test_iin_with_label_iin(self, scanner):
        result = scan(scanner, f"IIN: {self.VALID_IINS[0]}")
        assert result.severity not in {"SAFE"}

    def test_iin_with_label_jsn(self, scanner):
        result = scan(scanner, f"JSN: {self.VALID_IINS[1]}")
        assert result.severity not in {"SAFE"}

    def test_iin_with_label_bin(self, scanner):
        result = scan(scanner, f"BIN: {self.VALID_IINS[2]}")
        assert result.severity not in {"SAFE"}

    def test_iin_in_context_bank_transfer(self, scanner):
        iin = self.VALID_IINS[0]
        result = scan(scanner, f"Bank transfer for client IIN {iin}, amount 250000 KZT, Kaspi Bank")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_multiple_iins_escalates(self, scanner):
        lines = [f"IIN: {iin}" for iin in self.VALID_IINS]
        result = scan(scanner, "\n".join(lines))
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_iin_invalid_checksum_skipped(self, scanner):
        # 000000000001 has invalid checksum — must not be flagged
        result = scan(scanner, "Number: 000000000001")
        assert result.severity in {"SAFE", "LOW"}

    def test_iin_in_passport_context(self, scanner):
        iin = self.VALID_IINS[0]
        result = scan(scanner, f"Passport AB1234567, IIN {iin}, Kazakhstan")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_iin_bulk_export_critical(self, scanner):
        header = "client_id,name,iin,phone"
        rows = [f"{i},Client{i},{self.VALID_IINS[i % len(self.VALID_IINS)]},+77012345670" for i in range(5)]
        result = scan(scanner, "\n".join([header] + rows))
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}


# ═══════════════════════════════════════════════════════════════
# Блок 2: Казахстанские телефоны
# ═══════════════════════════════════════════════════════════════

class TestKazakhPhones:
    def test_single_kz_phone_low(self, scanner):
        result = scan(scanner, "+0 000 000 00 00")
        assert result.severity in {"SAFE", "LOW"}

    def test_kz_operator_700(self, scanner):
        result = scan(scanner, "Звонить: +0 000 000 00 04")
        assert result.severity in {"SAFE", "LOW"}

    def test_kz_operator_747(self, scanner):
        result = scan(scanner, "Контакт: +0 000 000 00 02")
        assert result.severity in {"SAFE", "LOW"}

    def test_kz_operator_778(self, scanner):
        result = scan(scanner, "Телефон менеджера: +0 000 000 00 03")
        assert result.severity in {"SAFE", "LOW"}

    def test_five_phones_escalates(self, scanner):
        phones = "\n".join([f"+7 70{i} 111 22 3{i}" for i in range(5)])
        result = scan(scanner, phones)
        assert result.severity in {"LOW", "MEDIUM", "HIGH"}

    def test_ten_phones_high_severity(self, scanner):
        phones = "\n".join([f"+7 701 000 {i:02d} {i:02d}" for i in range(10)])
        result = scan(scanner, phones)
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_phone_with_banking_context(self, scanner):
        result = scan(scanner, "Client Kasymov, phone +0 000 000 00 01, account at Kaspi Bank")
        assert result.severity in {"LOW", "MEDIUM", "HIGH"}


# ═══════════════════════════════════════════════════════════════
# Блок 3: Казахстанский IBAN и банковские счета
# ═══════════════════════════════════════════════════════════════

class TestKazakhIBAN:
    def test_kz_iban_standard_format(self, scanner):
        result = scan(scanner, "IBAN: KZ00EXAMPLE000000000")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_kz_iban_halyk(self, scanner):
        # 20-символьный KZ IBAN: KZ + 2 check + 3 bank_code + 13 account
        result = scan(scanner, "Recipient account: KZ75601A1234567890123 Halyk Bank")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_kz_iban_kaspi(self, scanner):
        result = scan(scanner, "Kaspi account: KZ00EXAMPLE000000000")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_multiple_ibans_escalates(self, scanner):
        text = "\n".join([
            "KZ00EXAMPLE000000000",
            "KZ00EXAMPLE000000001",
            "KZ00EXAMPLE000000002",
        ])
        result = scan(scanner, text)
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_iban_with_salary_context(self, scanner):
        result = scan(scanner, "Payroll: IBAN KZ00EXAMPLE000000000, salary 350000 KZT")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}


# ═══════════════════════════════════════════════════════════════
# Блок 4: Платёжные карты
# ═══════════════════════════════════════════════════════════════

class TestCreditCards:
    def test_visa_with_cvv(self, scanner):
        result = scan(scanner, "Card: 4539578763621486, CVV: 123, Exp: 05/26")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_mastercard_standard(self, scanner):
        result = scan(scanner, "5500-0000-0000-0000")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_amex_format(self, scanner):
        result = scan(scanner, "AMEX: 3782 822463 10000")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_kaspi_card_context(self, scanner):
        result = scan(scanner, "Мой Kaspi Gold: 4400430175354010")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_luhn_invalid_not_flagged(self, scanner):
        # Luhn fails → should NOT be flagged
        result = scan(scanner, "Reference: 4111111111111112")
        assert result.severity in {"SAFE", "LOW"}

    def test_multiple_cards_bulk(self, scanner):
        cards = "\n".join([
            "4111111111111110",
            "5500000000000000",
            "4539578763621486",
            "4916338506082830",
        ])
        result = scan(scanner, cards)
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_masked_card_low_severity(self, scanner):
        result = scan(scanner, "Карта ****1234 (заблокирована)")
        assert result.severity in {"SAFE", "LOW", "MEDIUM"}


# ═══════════════════════════════════════════════════════════════
# Блок 5: Секреты и API-ключи
# ═══════════════════════════════════════════════════════════════

class TestSecretsAndAPIKeys:
    def test_openai_key(self, scanner):
        result = scan(scanner, "OPENAI_API_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEF")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_github_token_ghu(self, scanner):
        result = scan(scanner, "token: ghu_16C7e42F292c6912E7710c838347Ae178B4a")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_github_token_ghp(self, scanner):
        result = scan(scanner, "EXAMPLE_GITHUB_TOKEN_DO_NOT_USE")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_aws_access_key(self, scanner):
        result = scan(scanner, "AWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_aws_secret_key(self, scanner):
        result = scan(scanner, "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_sendgrid_key(self, scanner):
        result = scan(scanner, "SENDGRID_API_KEY=EXAMPLE_SENDGRID_TOKEN_DO_NOT_USEpQrStUvWxYz0123456789AB")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_google_api_key(self, scanner):
        result = scan(scanner, "key=EXAMPLE_GOOGLE_API_KEY_DO_NOT_USE")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_slack_token(self, scanner):
        result = scan(scanner, "slack_token=EXAMPLE_SLACK_BOT_TOKEN_DO_NOT_USE429E")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_telegram_token(self, scanner):
        result = scan(scanner, "BOT_TOKEN=110201543:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_jwt_bearer_token(self, scanner):
        result = scan(scanner, "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_db_uri_postgresql(self, scanner):
        result = scan(scanner, "DATABASE_URL=postgresql://admin:password123@db.prod.internal:5432/customers")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_db_uri_mysql(self, scanner):
        result = scan(scanner, "DB_URL=mysql://root:secret@localhost:3306/production_db")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_example_private_key_header(self, scanner):
        result = scan(scanner, "-----BEGIN EXAMPLE RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0Z3VS5JJcds3xHn/ygWep4O")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_credential_dump_critical(self, scanner):
        text = """username,password,api_key,secret
admin,SuperSecret123!,EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE,wJalrXUtnFEMI
ops,Pass@word1,EXAMPLE_OPENAI_KEY_DO_NOT_USE123def456,ghp_token123abc"""
        result = scan(scanner, text)
        assert result.severity == "CRITICAL"


# ═══════════════════════════════════════════════════════════════
# Блок 6: Паспорт и документы удостоверяющие личность
# ═══════════════════════════════════════════════════════════════

class TestPassportAndDocuments:
    def test_kz_national_id(self, scanner):
        result = scan(scanner, "Удостоверение личности: AB1234567")
        assert result.severity in {"LOW", "MEDIUM", "HIGH"}

    def test_passport_context(self, scanner):
        result = scan(scanner, "Паспорт: N12345678, гражданин Казахстана")
        assert result.severity in {"LOW", "MEDIUM", "HIGH"}

    def test_passport_and_iin_combined(self, scanner):
        result = scan(scanner, "Паспорт N12345678, ИИН 860512300125, Алматы")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}


# ═══════════════════════════════════════════════════════════════
# Блок 7: Ложные срабатывания — безопасный текст
# ═══════════════════════════════════════════════════════════════

class TestFalsePositiveSuppression:
    def test_regular_office_email(self, scanner):
        result = scan(scanner, "Добрый день! Прикрепляю отчёт за Q3. Жду обратной связи.")
        assert result.severity == "SAFE"

    def test_meeting_notes(self, scanner):
        result = scan(scanner, "Meeting notes: discussed Q4 planning, budget allocation, team OKRs.")
        assert result.severity == "SAFE"

    def test_code_review_comment(self, scanner):
        result = scan(scanner, "LGTM. Minor nit: rename `data` to `payload` for clarity. +1 on the approach.")
        assert result.severity == "SAFE"

    def test_tracking_number_not_card(self, scanner):
        # Looks like digits but not a card (Luhn fails, no context)
        result = scan(scanner, "Your tracking number: 1234567890123456")
        assert result.severity in {"SAFE", "LOW"}

    def test_book_isbn_not_flagged(self, scanner):
        result = scan(scanner, "ISBN: 978-3-16-148410-0")
        assert result.severity == "SAFE"

    def test_phone_in_email_signature(self, scanner):
        result = scan(scanner, "Best regards,\nJohn Smith\nSenior Engineer\nTel: +7 701 000 11 22")
        assert result.severity in {"SAFE", "LOW"}

    def test_year_not_card(self, scanner):
        result = scan(scanner, "Report for fiscal year 2024, covering Q1 through Q4 results.")
        assert result.severity == "SAFE"

    def test_version_number_not_flagged(self, scanner):
        result = scan(scanner, "App version 4.11.1111.1111 released on March 15, 2024.")
        assert result.severity == "SAFE"

    def test_lorem_ipsum_safe(self, scanner):
        result = scan(scanner, "Lorem ipsum dolor sit amet, consectetur adipiscing elit.")
        assert result.severity == "SAFE"

    def test_demo_placeholder_filtered(self, scanner):
        result = scan(scanner, "placeholder token=test-12345 example only")
        assert result.severity in {"SAFE", "LOW"}


# ═══════════════════════════════════════════════════════════════
# Блок 8: Каналы передачи данных
# ═══════════════════════════════════════════════════════════════

class TestChannelSpecific:
    def test_clipboard_channel_risky_text(self, scanner):
        result = scan(scanner, "Our internal salary spreadsheet data for all employees.", channel="clipboard")
        assert result.severity in {"SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_social_channel_pii(self, scanner):
        result = scan(scanner, f"IIN: 000000000001, phone: +0 000 000 00 00", channel="social")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_public_upload_secrets(self, scanner):
        result = scan(scanner, "API_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEF", channel="public_upload")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_messenger_card_data(self, scanner):
        result = scan(scanner, "Карта 4111111111111110 CVV 123", channel="messenger")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_web_form_safe(self, scanner):
        result = scan(scanner, "Hello, I have a question about your services.", channel="web")
        assert result.severity == "SAFE"


# ═══════════════════════════════════════════════════════════════
# Блок 9: Нормализация текста (обфускация)
# ═══════════════════════════════════════════════════════════════

class TestTextNormalization:
    def test_obfuscated_at_sign(self, scanner):
        result = scan(scanner, "Send to user[at]domain[dot]com with API key EXAMPLE_OPENAI_KEY_DO_NOT_USE123def456xyz789long")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_aws_key_with_variable_name(self, scanner):
        # AWS key in assignment form — always detected regardless of spacing
        result = scan(scanner, "AWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE\nAWS region: us-east-1")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_hxxps_url_normalized(self, scanner):
        result = scan(scanner, "hxxps://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX")
        assert result.severity in {"HIGH", "CRITICAL"}


# ═══════════════════════════════════════════════════════════════
# Блок 10: Shadow IT и AI-инструменты
# ═══════════════════════════════════════════════════════════════

class TestShadowITAndAITools:
    def test_dropbox_upload_detected(self, scanner):
        result = scan(scanner, "Uploading to dropbox.com/sh/abc123def456/AABCxyz")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}

    def test_pastebin_secrets(self, scanner):
        result = scan(scanner, "Shared on pastebin.com: AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI")
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_chatgpt_with_pii(self, scanner):
        result = scan(scanner, "Sending to chat.openai.com: client ИИН 860512300125")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}

    def test_wetransfer_file(self, scanner):
        result = scan(scanner, "Employee database uploaded to wetransfer.com link: we.tl/t-abc123")
        assert result.severity in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}


# ═══════════════════════════════════════════════════════════════
# Блок 11: Структурированные дампы данных
# ═══════════════════════════════════════════════════════════════

class TestBulkDataExports:
    def test_employee_salary_dump(self, scanner):
        text = """name,iin,phone,salary
Ivanov Ivan,000000000001,+77011234567,350000
Petrov Petr,000000000002,+77012345678,420000
Sidorov Sidor,000000000003,+77013456789,280000
Kasymov Arman,000000000004,+00000000000,510000"""
        result = scan(scanner, text)
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_customer_database_export(self, scanner):
        text = """id,client_name,iin,card,iban
1,Demo Person Aovna,000000000001,4111111111111110,KZ00EXAMPLE000000000
2,Bolat Seitkali,000000000002,5500000000000000,KZ00EXAMPLE000000001
3,Dana Bekova,000000000003,4539578763621486,KZ00EXAMPLE000000002"""
        result = scan(scanner, text)
        assert result.severity == "CRITICAL"

    def test_api_keys_bulk(self, scanner):
        text = """service,key
openai,EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEF
github,EXAMPLE_GITHUB_TOKEN_DO_NOT_USE
aws,EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE"""
        result = scan(scanner, text)
        assert result.severity == "CRITICAL"


# ═══════════════════════════════════════════════════════════════
# Блок 12: Исходный код с секретами
# ═══════════════════════════════════════════════════════════════

class TestSourceCodeSecrets:
    def test_python_config_with_db(self, scanner):
        code = """
import os
DATABASE_URL = "postgresql://admin:SuperSecret123@prod.db.internal:5432/app"
REDIS_URL = "redis://:redispass@cache.internal:6379/0"
SECRET_KEY = "django-insecure-abc123xyz"
"""
        result = scan(scanner, code)
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_env_file_leak(self, scanner):
        env = """SECRET_KEY=my-very-secret-django-key-12345
DATABASE_URL=postgresql://user:pass@localhost/mydb
AWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"""
        result = scan(scanner, env)
        assert result.severity == "CRITICAL"

    def test_javascript_hardcoded_key(self, scanner):
        code = """
const apiKey = 'EXAMPLE_GOOGLE_API_KEY_DO_NOT_USE';
const client = new GoogleGenerativeAI(apiKey);
"""
        result = scan(scanner, code)
        assert result.severity in {"HIGH", "CRITICAL"}

    def test_sql_with_customer_data(self, scanner):
        sql = """INSERT INTO customers (iin, name, card_number, balance)
VALUES ('860512300125', 'Demo Person Aovna', '4111111111111110', 500000);"""
        result = scan(scanner, sql)
        assert result.severity in {"HIGH", "CRITICAL"}


# ═══════════════════════════════════════════════════════════════
# Блок 13: Email специфические сценарии
# ═══════════════════════════════════════════════════════════════

class TestEmailScenarios:
    def test_safe_business_email(self, scanner):
        result = scan(scanner, """Dear team,
Please find attached the Q3 summary report. We've achieved 115% of our targets.
Key highlights: new partnerships in the Almaty region, expanded SME portfolio.
Best regards, Marketing team""")
        assert result.severity == "SAFE"

    def test_financial_report_with_iban(self, scanner):
        result = scan(scanner, """Уважаемый клиент,
Подтверждаем получение перевода на счёт KZ00EXAMPLE000000000
Сумма: 1,500,000 KZT. Дата зачисления: 07.05.2026.""")
        assert result.severity in {"LOW", "MEDIUM", "HIGH"}

    def test_phishing_credential_request(self, scanner):
        result = scan(scanner, """URGENT: Please verify your account.
Send your password and API key immediately to confirm identity.
Your current session_secret will expire in 10 minutes.""")
        assert result.severity in {"MEDIUM", "HIGH", "CRITICAL"}
