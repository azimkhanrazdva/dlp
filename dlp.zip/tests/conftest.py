"""Shared pytest fixtures for all test modules."""
import os
import sys
import tempfile
from pathlib import Path

import pytest

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Disable AI models and external services for tests
os.environ.setdefault("SECUREMAIL_SECRET_KEY", "test-secret-key-not-for-prod")
os.environ.setdefault("SECUREMAIL_STAGE1_MODEL", "")
os.environ.setdefault("SECUREMAIL_STAGE2_MODEL", "")
os.environ.setdefault("SECUREMAIL_STAGE3_MODEL", "")
os.environ.setdefault("ENABLE_DEVICE_ENFORCEMENT", "0")


@pytest.fixture()
def tmp_db(tmp_path):
    """Temporary SQLite database path."""
    return tmp_path / "test.db"


@pytest.fixture()
def store(tmp_db):
    """Initialized SqliteStore backed by a temp DB."""
    from app.storage import SqliteStore
    return SqliteStore(root=tmp_db.parent, db_path=tmp_db)


@pytest.fixture()
def app_instance(tmp_db):
    """Flask app with isolated temp database."""
    os.environ["SECUREMAIL_DB_PATH"] = str(tmp_db)
    from app.main import create_app
    flask_app = create_app()
    flask_app.config["TESTING"] = True
    flask_app.config["WTF_CSRF_ENABLED"] = False
    return flask_app


@pytest.fixture()
def client(app_instance):
    """Flask test client."""
    with app_instance.test_client() as c:
        yield c


@pytest.fixture()
def auth_client(client, store):
    """Test client pre-logged in as admin."""
    store.create_account({
        "name": "Test Admin",
        "email": "admin@test.local",
        "password": "AdminPass123!",
        "role": "admin",
        "department": "Security",
    })
    resp = client.post("/login", data={"email": "admin@test.local", "password": "AdminPass123!"})
    assert resp.status_code in (200, 302)
    return client


@pytest.fixture()
def scanner():
    """DLP scanner instance with no AI models loaded."""
    from app.dlp_engine import DLPScanner
    return DLPScanner(stage1_path=None, stage2_path=None, stage3_path=None)


@pytest.fixture()
def behavioral_db(tmp_path):
    """BehavioralEngine backed by temp DB."""
    from app.behavioral_engine import BehavioralEngine
    return BehavioralEngine(db_path=tmp_path / "behavioral.db")
