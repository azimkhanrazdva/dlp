"""Unit tests for app/storage.py — SQLite backend."""
import pytest


def test_create_and_get_account(store):
    account = store.create_account({
        "name": "Test User",
        "email": "test@example.com",
        "password": "TestPass123!",
        "role": "employee",
    })
    assert account["email"] == "test@example.com"
    assert account["name"] == "Test User"
    assert account["role"] == "employee"


def test_duplicate_account_raises(store):
    store.create_account({"name": "A", "email": "dup@example.com", "password": "Pass123!"})
    with pytest.raises(ValueError):
        store.create_account({"name": "B", "email": "dup@example.com", "password": "Pass456!"})


def test_authenticate_success(store):
    store.create_account({"name": "A", "email": "auth@example.com", "password": "Pass123!"})
    result = store.authenticate("auth@example.com", "Pass123!")
    assert result is not None
    assert result["email"] == "auth@example.com"
    assert "session_token" in result


def test_authenticate_wrong_password(store):
    store.create_account({"name": "A", "email": "auth2@example.com", "password": "Pass123!"})
    result = store.authenticate("auth2@example.com", "WrongPass!")
    assert result is None


def test_get_session(store):
    store.create_account({"name": "A", "email": "sess@example.com", "password": "Pass123!"})
    account = store.authenticate("sess@example.com", "Pass123!")
    token = account["session_token"]
    session = store.get_session(token)
    assert session is not None
    assert session["email"] == "sess@example.com"


def test_clear_session(store):
    store.create_account({"name": "A", "email": "clr@example.com", "password": "Pass123!"})
    account = store.authenticate("clr@example.com", "Pass123!")
    token = account["session_token"]
    store.clear_session(token)
    assert store.get_session(token) is None


def test_update_account(store):
    store.create_account({"name": "A", "email": "upd@example.com", "password": "Pass123!"})
    updated = store.update_account("upd@example.com", status="restricted", can_send=False, blocked_reason="Test block")
    assert updated["status"] == "restricted"
    assert not updated["can_send"]
    assert updated["blocked_reason"] == "Test block"


def test_delete_account(store):
    store.create_account({"name": "A", "email": "del@example.com", "password": "Pass123!"})
    store.delete_account("del@example.com")
    assert store.get_account("del@example.com") is None


def test_add_and_get_message(store):
    msg = store.add_message({
        "sender": "a@example.com",
        "recipient": "b@example.com",
        "subject": "Test subject",
        "body": "Hello world",
        "folder": "inbox",
        "status": "delivered",
        "dlp": {"severity": "SAFE", "score": 0.99},
    })
    assert msg["id"] is not None
    fetched = store.get_message(msg["id"])
    assert fetched["subject"] == "Test subject"
    assert fetched["dlp"]["severity"] == "SAFE"


def test_add_and_list_incidents(store):
    store.add_incident({
        "type": "test_leak",
        "severity": "HIGH",
        "summary": "Test incident",
        "actions": ["Block", "Alert"],
    })
    incidents = store.list_incidents()
    assert len(incidents) >= 1
    assert incidents[0]["severity"] == "HIGH"


def test_audit_chain_valid(store):
    store.add_audit_event("test_event", "actor@example.com", {"key": "value"})
    store.add_audit_event("second_event", "actor@example.com", {"key2": "value2"})
    result = store.verify_audit_chain()
    assert result["valid"] is True
    assert result["length"] == 2


def test_add_device_and_upsert(store):
    device = store.upsert_device("USB\\VID_1234&PID_5678", {
        "device_name": "SanDisk USB",
        "serial": "SN12345",
        "connection_state": "connected",
        "policy": "review",
    })
    assert device["device_key"] == "USB\\VID_1234&PID_5678"
    # Upsert again with new policy
    updated = store.upsert_device("USB\\VID_1234&PID_5678", {"device_name": "SanDisk USB", "policy": "blocked"})
    assert updated["policy"] == "blocked"


def test_totp_secret_set_and_get(store):
    store.create_account({"name": "MFA User", "email": "mfa@example.com", "password": "Pass123!"})
    assert store.get_totp_secret("mfa@example.com") is None
    store.set_totp_secret("mfa@example.com", "JBSWY3DPEHPK3PXP")
    assert store.get_totp_secret("mfa@example.com") == "JBSWY3DPEHPK3PXP"


def test_totp_secret_clear(store):
    store.create_account({"name": "MFA User2", "email": "mfa2@example.com", "password": "Pass123!"})
    store.set_totp_secret("mfa2@example.com", "JBSWY3DPEHPK3PXP")
    store.set_totp_secret("mfa2@example.com", None)
    assert store.get_totp_secret("mfa2@example.com") is None


def test_analytics_snapshot(store):
    snapshot = store.analytics_snapshot()
    assert "message_severity" in snapshot
    assert "timeline" in snapshot
    assert "devices" in snapshot


def test_seed_accounts(store):
    accounts_data = [
        {"name": "Seed User", "email": "seed@example.com", "password": "Pass123!", "role": "employee"}
    ]
    store.seed_accounts(accounts_data)
    assert store.get_account("seed@example.com") is not None
    # Second call should not duplicate
    store.seed_accounts(accounts_data)
    accounts = store.list_accounts()
    assert sum(1 for a in accounts if a["email"] == "seed@example.com") == 1


def test_list_accounts(store):
    store.create_account({"name": "List User", "email": "list@example.com", "password": "Pass123!"})
    accounts = store.list_accounts()
    assert any(a["email"] == "list@example.com" for a in accounts)
