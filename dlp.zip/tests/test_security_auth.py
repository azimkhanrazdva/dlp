"""
Тесты безопасности и аутентификации.
Охватывают: срок жизни сессий, CSRF, обход авторизации,
инъекции, rate limiting, MFA, роли доступа.
"""
import time
import pytest
from datetime import datetime, timezone, timedelta


# ═══════════════════════════════════════════════════════════════
# Блок 1: Аутентификация и сессии
# ═══════════════════════════════════════════════════════════════

class TestAuthentication:
    def test_login_valid_credentials(self, client, store):
        store.create_account({"name": "Auth Test", "email": "authtest@sec.local", "password": "ExamplePass123!", "role": "employee"})
        resp = client.post("/login", data={"email": "authtest@sec.local", "password": "ExamplePass123!"})
        assert resp.status_code in (200, 302)

    def test_login_wrong_password_returns_401(self, client, store):
        store.create_account({"name": "Auth Test2", "email": "authtest2@sec.local", "password": "ExamplePass123!", "role": "employee"})
        resp = client.post("/login", data={"email": "authtest2@sec.local", "password": "wrong-example-password"})
        assert resp.status_code == 401

    def test_login_nonexistent_user_returns_401(self, client):
        resp = client.post("/login", data={"email": "nobody@nowhere.local", "password": "anything"})
        assert resp.status_code == 401

    def test_login_empty_credentials(self, client):
        resp = client.post("/login", data={"email": "", "password": ""})
        assert resp.status_code in (400, 401, 422)

    def test_logout_clears_session(self, client, store):
        store.create_account({"name": "Logout Test", "email": "logout@sec.local", "password": "ExamplePass123!", "role": "employee"})
        client.post("/login", data={"email": "logout@sec.local", "password": "ExamplePass123!"})
        resp = client.get("/logout", follow_redirects=False)
        assert resp.status_code in (302, 200)

    def test_session_created_after_login(self, store):
        store.create_account({"name": "Session Test", "email": "sesstest@sec.local", "password": "ExamplePass123!", "role": "employee"})
        result = store.authenticate("sesstest@sec.local", "ExamplePass123!")
        assert result is not None
        assert "session_token" in result
        token = result["session_token"]
        session = store.get_session(token)
        assert session is not None
        assert session["email"] == "sesstest@sec.local"

    def test_session_expires_after_8_hours(self, store):
        """Сессия должна истечь через 8 часов."""
        from app.storage import now_iso
        store.create_account({"name": "Expiry Test", "email": "expiry@sec.local", "password": "ExamplePass123!", "role": "employee"})
        result = store.authenticate("expiry@sec.local", "ExamplePass123!")
        token = result["session_token"]
        # Симулируем устаревшую сессию — ставим expires_at в прошлое
        past = (datetime.now(timezone.utc) - timedelta(hours=9)).isoformat()
        store._execute("UPDATE sessions SET expires_at=? WHERE token=?", (past, token))
        # get_session должен вернуть None и удалить запись
        assert store.get_session(token) is None
        # Убеждаемся что сессия удалена из БД
        row = store._query_one("SELECT * FROM sessions WHERE token=?", (token,))
        assert row is None

    def test_fresh_session_not_expired(self, store):
        """Новая сессия должна быть валидной."""
        store.create_account({"name": "Fresh Test", "email": "fresh@sec.local", "password": "ExamplePass123!", "role": "employee"})
        result = store.authenticate("fresh@sec.local", "ExamplePass123!")
        token = result["session_token"]
        assert store.get_session(token) is not None

    def test_session_expires_at_is_future(self, store):
        """expires_at должен быть в будущем (сейчас + 8ч)."""
        store.create_account({"name": "Expiry Check", "email": "expcheck@sec.local", "password": "ExamplePass123!", "role": "employee"})
        store.authenticate("expcheck@sec.local", "ExamplePass123!")
        row = store._query_one("SELECT expires_at FROM sessions WHERE email=lower(?)", ("expcheck@sec.local",))
        assert row is not None
        exp = datetime.fromisoformat(row["expires_at"].replace("Z", "+00:00"))
        assert exp > datetime.now(timezone.utc)
        # Должен быть примерно через 8 часов (±5 мин)
        delta = exp - datetime.now(timezone.utc)
        assert timedelta(hours=7, minutes=55) < delta < timedelta(hours=8, minutes=5)

    def test_clear_session_invalidates(self, store):
        store.create_account({"name": "Clear Test", "email": "clear@sec.local", "password": "ExamplePass123!", "role": "employee"})
        result = store.authenticate("clear@sec.local", "ExamplePass123!")
        token = result["session_token"]
        store.clear_session(token)
        assert store.get_session(token) is None


# ═══════════════════════════════════════════════════════════════
# Блок 2: Авторизация и роли
# ═══════════════════════════════════════════════════════════════

class TestAuthorization:
    def test_unauthenticated_api_returns_401(self, client):
        resp = client.get("/api/accounts")
        assert resp.status_code in (302, 401)

    def test_unauthenticated_admin_returns_401_or_redirect(self, client):
        resp = client.get("/admin", follow_redirects=False)
        assert resp.status_code in (302, 401)

    def test_admin_can_access_accounts_api(self, auth_client):
        resp = auth_client.get("/api/accounts")
        assert resp.status_code == 200

    def test_admin_can_access_incidents(self, auth_client):
        resp = auth_client.get("/api/incidents")
        assert resp.status_code == 200

    def test_employee_cannot_access_admin_panel(self, client, store):
        store.create_account({
            "name": "Regular Employee",
            "email": "employee@sec.local",
            "password": "ExamplePass123!",
            "role": "employee",
        })
        client.post("/login", data={"email": "employee@sec.local", "password": "ExamplePass123!"})
        resp = client.get("/api/accounts", follow_redirects=False)
        # employee role should be forbidden
        assert resp.status_code in (302, 401, 403)


# ═══════════════════════════════════════════════════════════════
# Блок 3: Rate Limiting
# ═══════════════════════════════════════════════════════════════

class TestRateLimiting:
    def test_brute_force_triggers_lockout(self, client, store):
        store.create_account({"name": "BF Target", "email": "bftarget@sec.local", "password": "ExamplePass123!", "role": "employee"})
        for _ in range(10):
            client.post("/login", data={"email": "bftarget@sec.local", "password": "wrong"})
        resp = client.post("/login", data={"email": "bftarget@sec.local", "password": "wrong"})
        assert resp.status_code == 429

    def test_correct_password_after_lockout_blocked(self, client, store):
        """После lockout даже правильный пароль должен быть заблокирован."""
        store.create_account({"name": "BF Target2", "email": "bftarget2@sec.local", "password": "ExamplePass123!", "role": "employee"})
        for _ in range(10):
            client.post("/login", data={"email": "bftarget2@sec.local", "password": "wrong"})
        resp = client.post("/login", data={"email": "bftarget2@sec.local", "password": "ExamplePass123!"})
        assert resp.status_code == 429


# ═══════════════════════════════════════════════════════════════
# Блок 4: Защита от раскрытия информации
# ═══════════════════════════════════════════════════════════════

class TestInformationDisclosure:
    def test_healthz_no_db_path(self, client):
        """/healthz не должен раскрывать путь к БД."""
        resp = client.get("/healthz")
        assert resp.status_code == 200
        data = resp.get_json()
        assert "db_path" not in data
        assert "model_primary" not in data
        assert "model_aux" not in data

    def test_healthz_returns_status(self, client):
        resp = client.get("/healthz")
        assert resp.status_code == 200
        data = resp.get_json()
        assert "status" in data
        assert data["status"] == "ok"

    def test_health_endpoint_no_internal_paths(self, client):
        resp = client.get("/health")
        data = resp.get_json()
        # Убеждаемся что нет внутренних путей
        assert "db_path" not in data
        text = str(data)
        assert "C:\\" not in text and "/home/" not in text

    def test_api_errors_no_stack_trace(self, client):
        """API-ошибки не должны возвращать трейсбэк."""
        resp = client.post("/api/agent/inspect", json={})
        assert resp.status_code in (400, 401, 422)
        data = resp.get_json() or {}
        assert "Traceback" not in str(data)
        assert "File " not in str(data)


# ═══════════════════════════════════════════════════════════════
# Блок 5: Регистрация пользователей — валидация
# ═══════════════════════════════════════════════════════════════

class TestRegistrationValidation:
    def test_register_valid_user(self, client):
        resp = client.post("/register", data={
            "name": "Valid User",
            "email": "valid@register.local",
            "password": "ValidExamplePass123!",
            "department": "Engineering",
            "title": "Developer",
        })
        assert resp.status_code in (200, 302)

    def test_register_too_short_name(self, client):
        resp = client.post("/register", data={
            "name": "X",
            "email": "short_name@register.local",
            "password": "ValidExamplePass123!",
        })
        assert resp.status_code == 400

    def test_register_short_password(self, client):
        resp = client.post("/register", data={
            "name": "Valid Name",
            "email": "short_pass@register.local",
            "password": "abc",
        })
        assert resp.status_code == 400

    def test_register_duplicate_email(self, client, store):
        store.create_account({"name": "Existing", "email": "dup@register.local", "password": "ExamplePass123!"})
        resp = client.post("/register", data={
            "name": "Duplicate",
            "email": "dup@register.local",
            "password": "AnotherExamplePass123!",
        })
        assert resp.status_code in (400, 409)

    def test_register_no_email(self, client):
        resp = client.post("/register", data={
            "name": "No Email User",
            "email": "",
            "password": "ValidExamplePass123!",
        })
        assert resp.status_code in (400, 422)


# ═══════════════════════════════════════════════════════════════
# Блок 6: Аутентификация агента (HMAC)
# ═══════════════════════════════════════════════════════════════

class TestAgentAuthentication:
    def test_agent_enroll_no_key_returns_401(self, client):
        resp = client.post("/api/agent/enroll", json={"agent_id": "test-agent"})
        assert resp.status_code == 401

    def test_agent_enroll_wrong_key_returns_401(self, client):
        resp = client.post(
            "/api/agent/enroll",
            json={"agent_id": "test-agent"},
            headers={"X-Agent-Enrollment-Key": "wrong-key"},
        )
        assert resp.status_code == 401

    def test_agent_enroll_valid_key_success(self, client, app_instance):
        import os
        os.environ["SECUREMAIL_AGENT_ENROLLMENT_KEY"] = "example-enrollment-key"
        resp = client.post(
            "/api/agent/enroll",
            json={
                "agent_id": "diploma-agent:user",
                "hostname": "diploma-host",
                "username": "user",
                "actor_email": "user@example.test",
                "platform": "windows",
                "version": "2.0.0",
            },
            headers={"X-Agent-Enrollment-Key": "example-enrollment-key"},
        )
        assert resp.status_code == 200
        data = resp.get_json()
        assert data.get("ok") is True
        assert "agent_key" in data

    def test_agent_inspect_without_auth_returns_401(self, client):
        resp = client.post("/api/agent/inspect", json={"text": "test"})
        assert resp.status_code == 401

    def test_agent_inspect_bad_signature_returns_401(self, client):
        resp = client.post(
            "/api/agent/inspect",
            json={"agent_id": "fake-agent", "text": "test"},
            headers={
                "X-Agent-Id": "fake-agent",
                "X-Agent-Key": "fake-key",
                "X-Agent-Timestamp": "1000000",
                "X-Agent-Signature": "badsignature",
            },
        )
        assert resp.status_code == 401
