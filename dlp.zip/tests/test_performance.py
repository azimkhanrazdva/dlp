"""
Тесты производительности DLP-движка.
Измеряют время отклика при разных нагрузках и объёмах текста.
Все пороги рассчитаны на CPU-only (без GPU).
"""
import time
import pytest


# ═══════════════════════════════════════════════════════════════
# Блок 1: Скорость сканирования текста
# ═══════════════════════════════════════════════════════════════

class TestScanSpeed:
    def test_short_text_under_1_second(self, scanner):
        """Короткий текст должен сканироваться быстрее 1с."""
        text = "Hello, please review this message and reply."
        start = time.perf_counter()
        scanner.scan_text(text, channel="email")
        elapsed = time.perf_counter() - start
        assert elapsed < 1.0, f"Scan took {elapsed:.3f}s — слишком медленно"

    def test_medium_text_under_2_seconds(self, scanner):
        """Текст ~500 слов — менее 2с."""
        text = "This is a test email. " * 100
        start = time.perf_counter()
        scanner.scan_text(text, channel="email")
        elapsed = time.perf_counter() - start
        assert elapsed < 2.0, f"Scan took {elapsed:.3f}s"

    def test_large_text_under_5_seconds(self, scanner):
        """Большой текст ~5000 слов — менее 5с."""
        text = ("Quarterly financial report showing revenue growth. " * 200 +
                "Customer data is protected by KZ DLP system. " * 100)
        start = time.perf_counter()
        scanner.scan_text(text, channel="email")
        elapsed = time.perf_counter() - start
        assert elapsed < 5.0, f"Scan took {elapsed:.3f}s"

    def test_pii_detection_under_1_second(self, scanner):
        """Текст с PII (ИИН + телефон) — менее 1с."""
        text = "Клиент: ИИН 860512300125, тел. +0 000 000 00 00"
        start = time.perf_counter()
        scanner.scan_text(text, channel="email")
        elapsed = time.perf_counter() - start
        assert elapsed < 1.0, f"PII scan took {elapsed:.3f}s"

    def test_api_key_detection_under_1_second(self, scanner):
        """Текст с API-ключами — менее 1с."""
        text = "OPENAI_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEF"
        start = time.perf_counter()
        scanner.scan_text(text, channel="clipboard")
        elapsed = time.perf_counter() - start
        assert elapsed < 1.0, f"API key scan took {elapsed:.3f}s"


# ═══════════════════════════════════════════════════════════════
# Блок 2: Пропускная способность
# ═══════════════════════════════════════════════════════════════

class TestThroughput:
    def test_10_scans_under_5_seconds(self, scanner):
        """10 последовательных сканирований — менее 5с суммарно."""
        texts = [f"Test message number {i} with random content." for i in range(10)]
        start = time.perf_counter()
        for text in texts:
            scanner.scan_text(text, channel="email")
        elapsed = time.perf_counter() - start
        assert elapsed < 5.0, f"10 scans took {elapsed:.3f}s"

    def test_50_short_scans_under_10_seconds(self, scanner):
        """50 коротких сканирований — менее 10с суммарно."""
        text = "Regular office communication about project timeline."
        start = time.perf_counter()
        for _ in range(50):
            scanner.scan_text(text, channel="email")
        elapsed = time.perf_counter() - start
        assert elapsed < 10.0, f"50 scans took {elapsed:.3f}s"

    def test_mixed_severity_batch_performance(self, scanner):
        """Батч из текстов с разным severity — менее 8с."""
        texts = [
            "Regular meeting notes",                                           # SAFE
            "ИИН: 860512300125",                                               # MEDIUM+
            "OPENAI_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDE", # HIGH
            "Card: 4111111111111110 CVV 123",                                  # HIGH+
        ] * 5
        start = time.perf_counter()
        for text in texts:
            scanner.scan_text(text, channel="email")
        elapsed = time.perf_counter() - start
        assert elapsed < 8.0, f"Mixed batch took {elapsed:.3f}s"


# ═══════════════════════════════════════════════════════════════
# Блок 3: Производительность хранилища
# ═══════════════════════════════════════════════════════════════

class TestStoragePerformance:
    def test_100_accounts_read_fast(self, store):
        """Чтение 100 аккаунтов — менее 1с."""
        for i in range(100):
            store.create_account({
                "name": f"User {i}",
                "email": f"perf{i}@example.test",
                "password": "ExamplePass123!",
                "role": "employee",
            })
        start = time.perf_counter()
        accounts = store.list_accounts()
        elapsed = time.perf_counter() - start
        assert len(accounts) >= 100
        assert elapsed < 1.0, f"list_accounts took {elapsed:.3f}s"

    def test_200_incidents_list_fast(self, store):
        """Список 200 инцидентов — менее 2с."""
        for i in range(200):
            store.add_incident({
                "type": "perf_test",
                "severity": ["LOW", "MEDIUM", "HIGH", "CRITICAL"][i % 4],
                "summary": f"Performance test incident {i}",
                "actions": [],
            })
        start = time.perf_counter()
        incidents = store.list_incidents()
        elapsed = time.perf_counter() - start
        assert len(incidents) >= 200
        assert elapsed < 2.0, f"list_incidents took {elapsed:.3f}s"

    def test_audit_chain_verify_100_events_fast(self, store):
        """Верификация цепочки из 100 событий — менее 2с."""
        for i in range(100):
            store.add_audit_event(f"event_{i}", f"actor{i}@example.test", {"i": i})
        start = time.perf_counter()
        result = store.verify_audit_chain()
        elapsed = time.perf_counter() - start
        assert result["valid"] is True
        assert result["length"] == 100
        assert elapsed < 2.0, f"verify_audit_chain took {elapsed:.3f}s"


# ═══════════════════════════════════════════════════════════════
# Блок 4: Производительность поведенческого движка
# ═══════════════════════════════════════════════════════════════

class TestBehavioralPerformance:
    def test_1000_events_insert_fast(self, behavioral_db):
        """Запись 1000 событий — менее 20с (SQLite WAL, одна транзакция на вставку)."""
        start = time.perf_counter()
        for i in range(1000):
            sev = ["LOW", "MEDIUM", "HIGH"][i % 3]
            behavioral_db.record_event(f"user{i % 10}@example.test", sev, "email")
        elapsed = time.perf_counter() - start
        assert elapsed < 20.0, f"1000 events took {elapsed:.3f}s"

    def test_get_risk_with_many_events_fast(self, behavioral_db):
        """Расчёт риска при 500 событиях — менее 0.5с."""
        for i in range(500):
            behavioral_db.record_event("heavyuser@example.test", "LOW", "email")
        start = time.perf_counter()
        risk = behavioral_db.get_user_risk("heavyuser@example.test")
        elapsed = time.perf_counter() - start
        assert risk.incidents_30d == 500
        assert elapsed < 0.5, f"get_user_risk took {elapsed:.3f}s"
