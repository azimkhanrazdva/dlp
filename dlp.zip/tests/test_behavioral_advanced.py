"""
Расширенные тесты поведенческого движка.
Охватывают: накопление риска, decay-функцию, эскалацию,
аномалии, многопользовательские сценарии, граничные случаи.
"""
import time
import pytest


# ═══════════════════════════════════════════════════════════════
# Блок 1: Базовые сценарии риска
# ═══════════════════════════════════════════════════════════════

class TestRiskAccumulation:
    def test_low_severity_adds_2_points(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "LOW", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert 1.5 <= risk.risk_score <= 2.5  # weight=2, почти новый → ~2.0

    def test_medium_severity_adds_6_points(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert 5.0 <= risk.risk_score <= 7.0

    def test_high_severity_adds_15_points(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "HIGH", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert 12.0 <= risk.risk_score <= 17.0

    def test_critical_severity_adds_35_points(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "CRITICAL", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert 30.0 <= risk.risk_score <= 38.0

    def test_safe_events_do_not_add_score(self, behavioral_db):
        for _ in range(10):
            behavioral_db.record_event("user@example.test", "SAFE", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.risk_score == 0.0
        assert risk.incidents_30d == 0

    def test_scores_accumulate_additively(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "LOW", "email")
        risk1 = behavioral_db.get_user_risk("user@example.test")
        behavioral_db.record_event("user@example.test", "LOW", "email")
        risk2 = behavioral_db.get_user_risk("user@example.test")
        assert risk2.risk_score > risk1.risk_score


# ═══════════════════════════════════════════════════════════════
# Блок 2: Уровни риска
# ═══════════════════════════════════════════════════════════════

class TestRiskLevels:
    def test_zero_score_is_normal(self, behavioral_db):
        risk = behavioral_db.get_user_risk("clean@example.test")
        assert risk.risk_level == "NORMAL"

    def test_score_12_plus_is_elevated(self, behavioral_db):
        # 2 × MEDIUM (6+6=12) → ELEVATED
        for _ in range(2):
            behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.risk_level in {"ELEVATED", "HIGH", "CRITICAL"}

    def test_score_30_plus_is_high(self, behavioral_db):
        # 2 × HIGH (15+15=30) → HIGH
        for _ in range(2):
            behavioral_db.record_event("user@example.test", "HIGH", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.risk_level in {"HIGH", "CRITICAL"}

    def test_score_60_plus_is_critical(self, behavioral_db):
        # 2 × CRITICAL (35+35=70) → CRITICAL
        for _ in range(2):
            behavioral_db.record_event("user@example.test", "CRITICAL", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.risk_level == "CRITICAL"


# ═══════════════════════════════════════════════════════════════
# Блок 3: Стрики и аномалии
# ═══════════════════════════════════════════════════════════════

class TestStrikesAndAnomalies:
    def test_first_medium_no_strike_anomaly(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.strikes_7d == 1
        assert not risk.is_anomalous  # 1 удар — ещё не аномалия

    def test_three_medium_events_anomalous(self, behavioral_db):
        for _ in range(3):
            behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.strikes_7d == 3
        assert risk.is_anomalous

    def test_anomaly_reason_not_empty(self, behavioral_db):
        for _ in range(3):
            behavioral_db.record_event("user@example.test", "MEDIUM", "clipboard")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.is_anomalous
        assert len(risk.anomaly_reason) > 0

    def test_low_severity_no_strike(self, behavioral_db):
        """LOW severity не даёт стрик (только MEDIUM+)."""
        for _ in range(5):
            behavioral_db.record_event("user@example.test", "LOW", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.strikes_7d == 0

    def test_high_score_anomaly(self, behavioral_db):
        """Высокий score (>=40) тоже даёт аномалию."""
        for _ in range(2):
            behavioral_db.record_event("user@example.test", "CRITICAL", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.risk_score >= 40
        assert risk.is_anomalous


# ═══════════════════════════════════════════════════════════════
# Блок 4: Эскалация severity
# ═══════════════════════════════════════════════════════════════

class TestSeverityEscalation:
    def test_no_history_no_escalation(self, behavioral_db):
        sev, reason = behavioral_db.escalate_severity("LOW", "clean@example.test")
        assert sev == "LOW"
        assert reason == ""

    def test_two_strikes_escalates_low_to_medium(self, behavioral_db):
        for _ in range(2):
            behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        sev, reason = behavioral_db.escalate_severity("LOW", "user@example.test")
        assert sev in {"MEDIUM", "HIGH", "CRITICAL"}
        assert reason

    def test_three_strikes_escalates_medium_to_high(self, behavioral_db):
        for _ in range(3):
            behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        sev, reason = behavioral_db.escalate_severity("MEDIUM", "user@example.test")
        assert sev in {"HIGH", "CRITICAL"}

    def test_five_strikes_escalates_to_critical(self, behavioral_db):
        for _ in range(5):
            behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        sev, reason = behavioral_db.escalate_severity("LOW", "user@example.test")
        assert sev == "CRITICAL"

    def test_escalation_never_downgrades(self, behavioral_db):
        """Если base=CRITICAL, эскалация не может понизить до HIGH."""
        for _ in range(2):
            behavioral_db.record_event("user@example.test", "LOW", "email")
        sev, _ = behavioral_db.escalate_severity("CRITICAL", "user@example.test")
        assert sev == "CRITICAL"

    def test_risk_level_floor_elevated_escalates_to_medium(self, behavioral_db):
        """При уровне ELEVATED — LOW → минимум MEDIUM."""
        for _ in range(2):
            behavioral_db.record_event("user@example.test", "MEDIUM", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.risk_level in {"ELEVATED", "HIGH", "CRITICAL"}
        sev, reason = behavioral_db.escalate_severity("LOW", "user@example.test")
        assert sev in {"MEDIUM", "HIGH", "CRITICAL"}
        assert reason

    def test_escalation_reason_mentions_violations(self, behavioral_db):
        for _ in range(3):
            behavioral_db.record_event("user@example.test", "HIGH", "email")
        _, reason = behavioral_db.escalate_severity("LOW", "user@example.test")
        assert reason  # не пустая строка


# ═══════════════════════════════════════════════════════════════
# Блок 5: Изоляция пользователей
# ═══════════════════════════════════════════════════════════════

class TestUserIsolation:
    def test_different_users_isolated(self, behavioral_db):
        """События одного пользователя не влияют на другого."""
        behavioral_db.record_event("alice@example.test", "CRITICAL", "email")
        risk_bob = behavioral_db.get_user_risk("bob@example.test")
        assert risk_bob.risk_score == 0.0
        assert risk_bob.risk_level == "NORMAL"

    def test_multiple_users_tracked_independently(self, behavioral_db):
        users = ["user1@example.test", "user2@example.test", "user3@example.test"]
        severities = ["LOW", "HIGH", "CRITICAL"]
        for user, sev in zip(users, severities):
            behavioral_db.record_event(user, sev, "email")
        risks = [behavioral_db.get_user_risk(u) for u in users]
        # У каждого пользователя свой уникальный score
        scores = [r.risk_score for r in risks]
        assert len(set(round(s, 1) for s in scores)) == 3  # все разные


# ═══════════════════════════════════════════════════════════════
# Блок 6: Summary и каналы
# ═══════════════════════════════════════════════════════════════

class TestSummaryAndChannels:
    def test_summary_contains_all_fields(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "HIGH", "clipboard")
        summary = behavioral_db.get_summary("user@example.test")
        required = ["user", "risk_score", "risk_level", "strikes_7d", "incidents_30d", "is_anomalous", "anomaly_reason"]
        for field in required:
            assert field in summary

    def test_summary_new_user_safe_defaults(self, behavioral_db):
        summary = behavioral_db.get_summary("newuser@example.test")
        assert summary["risk_score"] == 0.0
        assert summary["risk_level"] == "NORMAL"
        assert summary["strikes_7d"] == 0
        assert summary["incidents_30d"] == 0
        assert not summary["is_anomalous"]

    def test_channel_recorded_in_db(self, behavioral_db):
        behavioral_db.record_event("chanuser@example.test", "HIGH", "clipboard", incident_id=99)
        risk = behavioral_db.get_user_risk("chanuser@example.test")
        assert risk.incidents_30d == 1

    def test_incident_id_stored(self, behavioral_db):
        behavioral_db.record_event("user@example.test", "MEDIUM", "email", incident_id=42)
        # Проверяем что строка в БД содержит incident_id
        rows = behavioral_db._conn().execute(
            "SELECT incident_id FROM risk_events WHERE user=?", ("user@example.test",)
        ).fetchall()
        assert len(rows) == 1
        assert rows[0][0] == 42


# ═══════════════════════════════════════════════════════════════
# Блок 7: Граничные случаи
# ═══════════════════════════════════════════════════════════════

class TestEdgeCases:
    def test_unknown_severity_weight_zero(self, behavioral_db):
        """Неизвестный severity не должен добавлять weight."""
        behavioral_db.record_event("user@example.test", "UNKNOWN_LEVEL", "email")
        risk = behavioral_db.get_user_risk("user@example.test")
        assert risk.risk_score == 0.0
        assert risk.incidents_30d == 0

    def test_many_events_do_not_crash(self, behavioral_db):
        """100 событий обрабатываются без ошибок."""
        for i in range(100):
            sev = ["LOW", "MEDIUM", "HIGH"][i % 3]
            behavioral_db.record_event("heavy@example.test", sev, "email")
        risk = behavioral_db.get_user_risk("heavy@example.test")
        assert risk.incidents_30d == 100
        assert risk.risk_score > 0

    def test_escalation_not_above_critical(self, behavioral_db):
        """Эскалация никогда не выходит за CRITICAL."""
        for _ in range(10):
            behavioral_db.record_event("maxuser@example.test", "CRITICAL", "email")
        sev, _ = behavioral_db.escalate_severity("SAFE", "maxuser@example.test")
        assert sev in {"SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"}
        assert sev != "OVER_CRITICAL"
