"""Unit tests for app/behavioral_engine.py."""
import time
import pytest


def test_new_user_returns_normal(behavioral_db):
    risk = behavioral_db.get_user_risk("new_user@test.local")
    assert risk.risk_score == 0.0
    assert risk.risk_level == "NORMAL"
    assert risk.strikes_7d == 0
    assert risk.incidents_30d == 0
    assert not risk.is_anomalous


def test_safe_event_not_recorded(behavioral_db):
    behavioral_db.record_event("user@test.local", "SAFE", "email")
    risk = behavioral_db.get_user_risk("user@test.local")
    assert risk.risk_score == 0.0
    assert risk.incidents_30d == 0


def test_low_event_adds_score(behavioral_db):
    behavioral_db.record_event("user@test.local", "LOW", "email")
    risk = behavioral_db.get_user_risk("user@test.local")
    assert risk.risk_score > 0
    assert risk.incidents_30d == 1


def test_critical_event_gives_high_score(behavioral_db):
    behavioral_db.record_event("user@test.local", "CRITICAL", "email")
    risk = behavioral_db.get_user_risk("user@test.local")
    assert risk.risk_score >= 30
    assert risk.risk_level in {"HIGH", "CRITICAL"}


def test_multiple_medium_events_creates_strikes(behavioral_db):
    for _ in range(4):
        behavioral_db.record_event("user@test.local", "MEDIUM", "email")
    risk = behavioral_db.get_user_risk("user@test.local")
    assert risk.strikes_7d == 4
    assert risk.is_anomalous


def test_strike_escalation_low_severity(behavioral_db):
    # Two prior violations → LOW should be escalated to at least MEDIUM
    for _ in range(2):
        behavioral_db.record_event("user@test.local", "MEDIUM", "email")
    effective, reason = behavioral_db.escalate_severity("LOW", "user@test.local")
    assert effective in {"MEDIUM", "HIGH", "CRITICAL"}
    assert reason  # non-empty reason


def test_no_escalation_for_clean_user(behavioral_db):
    effective, reason = behavioral_db.escalate_severity("LOW", "clean_user@test.local")
    assert effective == "LOW"
    assert reason == ""


def test_escalation_does_not_downgrade(behavioral_db):
    # If base is CRITICAL and strikes exist, result stays CRITICAL (never lowers)
    for _ in range(3):
        behavioral_db.record_event("user@test.local", "LOW", "email")
    effective, _ = behavioral_db.escalate_severity("CRITICAL", "user@test.local")
    assert effective == "CRITICAL"


def test_risk_level_elevated(behavioral_db):
    # 3 × MEDIUM = 18 weight → well above ELEVATED threshold of 12
    behavioral_db.record_event("user@test.local", "MEDIUM", "email")
    behavioral_db.record_event("user@test.local", "MEDIUM", "email")
    behavioral_db.record_event("user@test.local", "MEDIUM", "email")
    risk = behavioral_db.get_user_risk("user@test.local")
    assert risk.risk_level in {"ELEVATED", "HIGH", "CRITICAL"}


def test_get_summary_returns_dict(behavioral_db):
    behavioral_db.record_event("user@test.local", "HIGH", "email")
    summary = behavioral_db.get_summary("user@test.local")
    for key in ["user", "risk_score", "risk_level", "strikes_7d", "incidents_30d", "is_anomalous"]:
        assert key in summary


def test_no_double_escalation(behavioral_db):
    """Strike floor and risk-level floor should not both apply — only max is used."""
    for _ in range(5):
        behavioral_db.record_event("user@test.local", "MEDIUM", "email")
    effective, reason = behavioral_db.escalate_severity("LOW", "user@test.local")
    # Should be exactly one escalation applied (highest floor wins)
    assert effective in {"MEDIUM", "HIGH", "CRITICAL"}
    # Make sure severity was not escalated beyond CRITICAL
    assert effective != "OVER_CRITICAL"


def test_incident_count_30d(behavioral_db):
    for _ in range(5):
        behavioral_db.record_event("user@test.local", "HIGH", "email")
    risk = behavioral_db.get_user_risk("user@test.local")
    assert risk.incidents_30d == 5


def test_channel_stored(behavioral_db):
    behavioral_db.record_event("user@test.local", "HIGH", "clipboard", incident_id=42)
    risk = behavioral_db.get_user_risk("user@test.local")
    assert risk.incidents_30d == 1
