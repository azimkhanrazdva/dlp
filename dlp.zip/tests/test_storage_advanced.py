"""
Расширенные тесты хранилища данных (SqliteStore).
Охватывают: инциденты, устройства, политики, scan jobs,
аудит-цепочку, аналитику, endpoint-агентов.
"""
import pytest
from datetime import datetime, timezone, timedelta


# ═══════════════════════════════════════════════════════════════
# Блок 1: Сообщения
# ═══════════════════════════════════════════════════════════════

class TestMessages:
    def test_add_message_returns_id(self, store):
        msg = store.add_message({
            "sender": "a@example.test",
            "recipient": "b@example.test",
            "subject": "Test",
            "body": "Body text",
            "folder": "inbox",
            "status": "delivered",
            "dlp": {"severity": "SAFE", "score": 0.99},
        })
        assert msg["id"] is not None

    def test_message_dlp_json_preserved(self, store):
        msg = store.add_message({
            "sender": "x@example.test",
            "recipient": "y@example.test",
            "subject": "DLP Test",
            "body": "Content",
            "folder": "quarantine",
            "status": "blocked",
            "dlp": {"severity": "CRITICAL", "score": 0.97, "indicators": ["card", "iin"]},
        })
        fetched = store.get_message(msg["id"])
        assert fetched["dlp"]["severity"] == "CRITICAL"
        assert "card" in fetched["dlp"]["indicators"]

    def test_list_messages_returns_all(self, store):
        for i in range(5):
            store.add_message({
                "sender": f"sender{i}@example.test",
                "recipient": "recv@example.test",
                "subject": f"Msg {i}",
                "body": "Body",
                "folder": "inbox",
                "status": "delivered",
                "dlp": {"severity": "SAFE"},
            })
        messages = store.list_messages()
        assert len(messages) >= 5

    def test_message_folder_quarantine(self, store):
        msg = store.add_message({
            "sender": "blocked@example.test",
            "recipient": "recv@example.test",
            "subject": "Blocked",
            "body": "Body",
            "folder": "quarantine",
            "status": "blocked",
            "dlp": {"severity": "HIGH"},
        })
        assert msg["folder"] == "quarantine"


# ═══════════════════════════════════════════════════════════════
# Блок 2: Инциденты
# ═══════════════════════════════════════════════════════════════

class TestIncidents:
    def test_create_incident_high(self, store):
        inc = store.add_incident({
            "type": "data_leak",
            "severity": "HIGH",
            "summary": "HIGH severity test",
            "actions": ["Block", "Notify SOC"],
            "sender": "sender@example.test",
            "recipient": "external@evil.com",
        })
        assert inc["id"] is not None
        assert inc["severity"] == "HIGH"

    def test_incident_status_default_open(self, store):
        inc = store.add_incident({
            "type": "test",
            "severity": "LOW",
            "summary": "Test incident",
            "actions": [],
        })
        assert inc["status"] == "open"

    def test_update_incident_status(self, store):
        inc = store.add_incident({
            "type": "test",
            "severity": "MEDIUM",
            "summary": "Will be resolved",
            "actions": [],
        })
        updated = store.update_incident(inc["id"], status="resolved")
        assert updated["status"] == "resolved"

    def test_list_incidents_by_severity(self, store):
        for sev in ["LOW", "MEDIUM", "HIGH", "CRITICAL"]:
            store.add_incident({"type": "t", "severity": sev, "summary": f"{sev} incident", "actions": []})
        incidents = store.list_incidents()
        severities = {i["severity"] for i in incidents}
        assert {"LOW", "MEDIUM", "HIGH", "CRITICAL"}.issubset(severities)

    def test_incident_owner_assignment(self, store):
        inc = store.add_incident({
            "type": "test",
            "severity": "HIGH",
            "summary": "Assigned incident",
            "actions": [],
            "owner": "soc@example.test",
        })
        assert inc["owner"] == "soc@example.test"

    def test_multiple_incidents_ordered(self, store):
        for i in range(3):
            store.add_incident({
                "type": "seq",
                "severity": "LOW",
                "summary": f"Incident {i}",
                "actions": [],
            })
        incidents = store.list_incidents()
        assert len(incidents) >= 3


# ═══════════════════════════════════════════════════════════════
# Блок 3: Устройства (USB/endpoint)
# ═══════════════════════════════════════════════════════════════

class TestDevices:
    def test_upsert_device_new(self, store):
        device = store.upsert_device("USB\\VID_0001&PID_0001", {
            "device_name": "Kingston USB",
            "serial": "KST12345",
            "connection_state": "connected",
            "policy": "review",
        })
        assert device["device_key"] == "USB\\VID_0001&PID_0001"
        assert device["device_name"] == "Kingston USB"

    def test_upsert_device_updates_existing(self, store):
        store.upsert_device("USB\\VID_0002&PID_0002", {
            "device_name": "SanDisk USB",
            "connection_state": "connected",
            "policy": "authorized",
        })
        updated = store.upsert_device("USB\\VID_0002&PID_0002", {
            "device_name": "SanDisk USB",
            "connection_state": "disconnected",
            "policy": "blocked",
        })
        assert updated["policy"] == "blocked"
        assert updated["connection_state"] == "disconnected"

    def test_list_devices_returns_all(self, store):
        for i in range(3):
            store.upsert_device(f"USB\\VID_000{i}&PID_000{i}", {
                "device_name": f"Device {i}",
                "connection_state": "connected",
                "policy": "review",
            })
        devices = store.list_devices()
        assert len(devices) >= 3

    def test_device_event_recorded(self, store):
        store.add_device_event({
            "device_name": "Kingston USB",
            "device_key": "USB\\VID_KNGST",
            "event": "connected",
            "severity": "LOW",
            "policy": "review",
        })
        events = store.list_device_events()
        assert len(events) >= 1

    def test_device_policy_blocked(self, store):
        device = store.upsert_device("USB\\VID_BLOCK", {
            "device_name": "Blocked Device",
            "connection_state": "connected",
            "policy": "blocked",
        })
        assert device["policy"] == "blocked"


# ═══════════════════════════════════════════════════════════════
# Блок 4: Аудит-цепочка
# ═══════════════════════════════════════════════════════════════

class TestAuditChain:
    def test_audit_chain_starts_empty_valid(self, store):
        result = store.verify_audit_chain()
        assert result["valid"] is True
        assert result["length"] == 0

    def test_single_event_valid(self, store):
        store.add_audit_event("login", "user@example.test", {"ip": "127.0.0.1"})
        result = store.verify_audit_chain()
        assert result["valid"] is True
        assert result["length"] == 1

    def test_multiple_events_chain_valid(self, store):
        actors = ["user1@example.test", "user2@example.test", "admin@example.test"]
        events = ["login", "file_access", "export"]
        for actor, event in zip(actors, events):
            store.add_audit_event(event, actor, {"action": event})
        result = store.verify_audit_chain()
        assert result["valid"] is True
        assert result["length"] == 3

    def test_audit_events_listed(self, store):
        store.add_audit_event("test_event", "actor@example.test", {"key": "value"})
        events = store.list_audit_events()
        assert len(events) >= 1
        last = events[-1]
        assert last["event_type"] == "test_event"
        assert last["actor"] == "actor@example.test"


# ═══════════════════════════════════════════════════════════════
# Блок 5: Scan Jobs
# ═══════════════════════════════════════════════════════════════

class TestScanJobs:
    def test_add_scan_job(self, store):
        job = store.add_scan_job({
            "job_type": "file_scan",
            "channel": "email",
            "actor": "user@example.test",
            "status": "queued",
            "target_name": "document.pdf",
        })
        assert job["id"] is not None
        assert job["status"] == "queued"

    def test_update_scan_job_running(self, store):
        job = store.add_scan_job({
            "job_type": "text_scan",
            "channel": "clipboard",
            "actor": "user@example.test",
            "status": "queued",
            "target_name": "clipboard",
        })
        updated = store.update_scan_job(job["id"], status="running")
        assert updated["status"] == "running"

    def test_update_scan_job_completed(self, store):
        job = store.add_scan_job({
            "job_type": "text_scan",
            "channel": "email",
            "actor": "user@example.test",
            "status": "queued",
            "target_name": "test",
        })
        updated = store.update_scan_job(
            job["id"],
            status="completed",
            severity="HIGH",
            summary="HIGH content detected",
            result={"severity": "HIGH", "score": 0.91},
        )
        assert updated["status"] == "completed"
        assert updated["severity"] == "HIGH"

    def test_list_scan_jobs(self, store):
        for i in range(4):
            store.add_scan_job({
                "job_type": "scan",
                "channel": "email",
                "actor": f"user{i}@example.test",
                "status": "completed",
                "target_name": f"file{i}.txt",
            })
        jobs = store.list_scan_jobs(10)
        assert len(jobs) >= 4


# ═══════════════════════════════════════════════════════════════
# Блок 6: Endpoint агенты
# ═══════════════════════════════════════════════════════════════

class TestEndpointAgents:
    def test_create_endpoint_agent(self, store):
        agent = store.create_endpoint_agent({
            "agent_id": "test-host:testuser",
            "display_name": "Test Workstation",
            "actor_email": "agent-user@example.test",
            "platform": "windows",
            "version": "2.0.0",
            "api_key": "test-api-key-12345",
        })
        assert agent is not None
        assert agent["agent_id"] == "test-host:testuser"

    def test_get_endpoint_agent(self, store):
        store.create_endpoint_agent({
            "agent_id": "host1:user1",
            "display_name": "Host 1",
            "actor_email": "agent-one@example.test",
            "platform": "windows",
            "version": "1.0.0",
            "api_key": "key-abc-123",
        })
        agent = store.get_endpoint_agent("host1:user1")
        assert agent is not None
        assert agent["actor_email"] == "agent-one@example.test"

    def test_agent_verify_correct_key(self, store):
        store.create_endpoint_agent({
            "agent_id": "verify-host:user",
            "display_name": "Verify Host",
            "actor_email": "verified-user@example.test",
            "platform": "linux",
            "version": "2.0.0",
            "api_key": "correct-api-key-xyz",
        })
        result = store.verify_endpoint_agent("verify-host:user", "correct-api-key-xyz")
        assert result is not None

    def test_agent_verify_wrong_key_fails(self, store):
        store.create_endpoint_agent({
            "agent_id": "wrongkey-host:user",
            "display_name": "Wrong Key Host",
            "actor_email": "worker-user@example.test",
            "platform": "linux",
            "version": "2.0.0",
            "api_key": "correct-key-here",
        })
        result = store.verify_endpoint_agent("wrongkey-host:user", "wrong-key")
        assert result is None

    def test_list_endpoint_agents(self, store):
        for i in range(3):
            store.create_endpoint_agent({
                "agent_id": f"agent{i}:user",
                "display_name": f"Agent {i}",
                "actor_email": f"agent{i}@example.test",
                "platform": "windows",
                "version": "2.0.0",
                "api_key": f"key-agent-{i}",
            })
        agents = store.list_endpoint_agents()
        assert len(agents) >= 3

    def test_agent_is_online_status(self, store):
        from app.storage import now_iso
        store.create_endpoint_agent({
            "agent_id": "online-host:user",
            "display_name": "Online Host",
            "actor_email": "online@example.test",
            "platform": "windows",
            "version": "2.0.0",
            "api_key": "online-key",
        })
        # Обновляем last_seen_at — агент считается online при разнице ≤90с
        store._execute(
            "UPDATE endpoint_agents SET last_seen_at=? WHERE agent_id=?",
            (now_iso(), "online-host:user")
        )
        agent = store.get_endpoint_agent("online-host:user")
        assert agent["is_online"] is True


# ═══════════════════════════════════════════════════════════════
# Блок 7: Аналитика
# ═══════════════════════════════════════════════════════════════

class TestAnalytics:
    def test_analytics_snapshot_structure(self, store):
        snap = store.analytics_snapshot()
        required_keys = ["message_severity", "timeline", "devices", "job_types", "channels"]
        for key in required_keys:
            assert key in snap

    def test_analytics_counts_messages(self, store):
        for sev in ["SAFE", "LOW", "HIGH", "CRITICAL"]:
            store.add_message({
                "sender": f"{sev.lower()}@example.test",
                "recipient": "recv@example.test",
                "subject": f"{sev} message",
                "body": "Body",
                "folder": "inbox",
                "status": "delivered",
                "dlp": {"severity": sev},
            })
        snap = store.analytics_snapshot()
        counts = snap["message_severity"]
        assert counts.get("SAFE", 0) >= 1
        assert counts.get("CRITICAL", 0) >= 1

    def test_analytics_timeline_has_days(self, store):
        snap = store.analytics_snapshot()
        timeline = snap["timeline"]
        assert "days" in timeline
        assert isinstance(timeline["days"], list)
