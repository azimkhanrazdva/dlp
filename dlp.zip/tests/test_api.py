"""Integration tests for Flask API endpoints."""
import json
import os
import pytest


# ── Auth tests ────────────────────────────────────────────────────────────────

def test_login_page_loads(client):
    resp = client.get("/login")
    assert resp.status_code == 200
    assert b"Sign In" in resp.data or b"sign" in resp.data.lower()


def test_login_success_redirects(client, store):
    store.create_account({"name": "Login User", "email": "login@test.local", "password": "Pass123!", "role": "employee"})
    resp = client.post("/login", data={"email": "login@test.local", "password": "Pass123!"})
    assert resp.status_code in (200, 302)


def test_login_wrong_password(client, store):
    store.create_account({"name": "Login User2", "email": "login2@test.local", "password": "Pass123!", "role": "employee"})
    resp = client.post("/login", data={"email": "login2@test.local", "password": "WrongPass!"})
    assert resp.status_code == 401


def test_login_rate_limiting(client, store):
    store.create_account({"name": "RateLimited", "email": "rate@test.local", "password": "Pass123!", "role": "employee"})
    for _ in range(10):
        client.post("/login", data={"email": "rate@test.local", "password": "WrongPass!"})
    resp = client.post("/login", data={"email": "rate@test.local", "password": "WrongPass!"})
    assert resp.status_code == 429


def test_protected_route_redirects_unauthenticated(client):
    resp = client.get("/", follow_redirects=False)
    assert resp.status_code in (302, 401)


# ── Health & Metrics ──────────────────────────────────────────────────────────

def test_health_endpoint(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] in ("ok", "degraded")
    assert "uptime_seconds" in data
    assert "version" in data


def test_metrics_endpoint(client):
    resp = client.get("/metrics")
    assert resp.status_code == 200
    assert b"dlp_incidents_open" in resp.data
    assert b"dlp_messages_total" in resp.data
    assert b"dlp_agents_online" in resp.data


# ── Scan endpoint ─────────────────────────────────────────────────────────────

def test_scan_api_safe_text(client):
    resp = client.post(
        "/api/scan",
        data={"text": "Hello, this is a regular message about our meeting tomorrow."},
        content_type="application/x-www-form-urlencoded",
    )
    # Scan is available to logged-in users only — redirect or 200
    assert resp.status_code in (200, 302, 401, 403)


# ── Agent enrollment ──────────────────────────────────────────────────────────

def test_agent_enroll_missing_key(client):
    resp = client.post("/api/agent/enroll", json={"agent_id": "test-agent"})
    assert resp.status_code == 401


def test_agent_enroll_valid_key(client, app_instance):
    os.environ["SECUREMAIL_AGENT_ENROLLMENT_KEY"] = "test-enroll-key"
    app_instance.config["TESTING"] = True
    resp = client.post(
        "/api/agent/enroll",
        json={
            "agent_id": "test-host:testuser",
            "hostname": "test-host",
            "username": "testuser",
            "actor_email": "testuser@company.com",
            "platform": "windows",
            "version": "2.0.0",
        },
        headers={"X-Agent-Enrollment-Key": "test-enroll-key"},
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    assert "agent_key" in data


# ── Agent inspect ─────────────────────────────────────────────────────────────

def test_agent_inspect_unauthorized(client):
    resp = client.post(
        "/api/agent/inspect",
        json={"agent_id": "bad-agent", "api_key": "wrong"},
    )
    assert resp.status_code == 401


# ── MFA endpoints ─────────────────────────────────────────────────────────────

def test_mfa_status_requires_auth(client):
    resp = client.get("/api/mfa/status")
    assert resp.status_code in (302, 401, 403)


def test_mfa_status_authenticated(auth_client, store):
    resp = auth_client.get("/api/mfa/status")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "enabled" in data
    assert data["enabled"] is False


def test_mfa_setup_returns_secret(auth_client):
    resp = auth_client.post("/api/mfa/setup")
    if resp.status_code == 501:
        pytest.skip("pyotp not installed")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "secret" in data
    assert "uri" in data


def test_mfa_confirm_invalid_code(auth_client):
    auth_client.post("/api/mfa/setup")
    resp = auth_client.post("/api/mfa/confirm", json={"code": "000000"})
    if resp.status_code == 501:
        pytest.skip("pyotp not installed")
    # 000000 is almost certainly invalid
    assert resp.status_code in (200, 401)


def test_mfa_setup_then_confirm(auth_client):
    try:
        import pyotp
    except ImportError:
        pytest.skip("pyotp not installed")
    setup_resp = auth_client.post("/api/mfa/setup")
    assert setup_resp.status_code == 200
    secret = setup_resp.get_json()["secret"]
    code = pyotp.TOTP(secret).now()
    confirm_resp = auth_client.post("/api/mfa/confirm", json={"code": code})
    assert confirm_resp.status_code == 200
    data = confirm_resp.get_json()
    assert data["enabled"] is True


def test_mfa_status_after_enable(auth_client):
    try:
        import pyotp
    except ImportError:
        pytest.skip("pyotp not installed")
    setup_resp = auth_client.post("/api/mfa/setup")
    secret = setup_resp.get_json()["secret"]
    code = pyotp.TOTP(secret).now()
    auth_client.post("/api/mfa/confirm", json={"code": code})
    status_resp = auth_client.get("/api/mfa/status")
    assert status_resp.get_json()["enabled"] is True


def test_mfa_disable(auth_client):
    try:
        import pyotp
    except ImportError:
        pytest.skip("pyotp not installed")
    setup_resp = auth_client.post("/api/mfa/setup")
    secret = setup_resp.get_json()["secret"]
    totp = pyotp.TOTP(secret)
    auth_client.post("/api/mfa/confirm", json={"code": totp.now()})
    disable_resp = auth_client.post("/api/mfa/disable", json={"code": totp.now()})
    assert disable_resp.status_code == 200
    assert disable_resp.get_json()["enabled"] is False


# ── Accounts API ──────────────────────────────────────────────────────────────

def test_api_accounts_list_admin(auth_client):
    resp = auth_client.get("/api/accounts")
    assert resp.status_code == 200
    data = resp.get_json()
    assert isinstance(data, list)


def test_api_incidents_list(auth_client):
    resp = auth_client.get("/api/incidents")
    assert resp.status_code == 200
    data = resp.get_json()
    assert isinstance(data, list)


def test_api_devices_list(auth_client):
    resp = auth_client.get("/api/devices")
    assert resp.status_code == 200


# ── Register ──────────────────────────────────────────────────────────────────

def test_register_new_user(client):
    resp = client.post("/register", data={
        "name": "New User",
        "email": "newuser@test.local",
        "password": "NewPass123!",
        "department": "Engineering",
        "title": "Developer",
    })
    assert resp.status_code in (200, 302)


def test_register_short_name(client):
    resp = client.post("/register", data={
        "name": "A",
        "email": "short@test.local",
        "password": "NewPass123!",
    })
    assert resp.status_code == 400


def test_register_short_password(client):
    resp = client.post("/register", data={
        "name": "Good Name",
        "email": "short2@test.local",
        "password": "abc",
    })
    assert resp.status_code == 400
