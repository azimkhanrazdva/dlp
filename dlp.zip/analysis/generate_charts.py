"""
Генератор графиков и аналитики для дипломной работы.
Запуск: python analysis/generate_charts.py

Создаёт в папке analysis/charts/:
  01_severity_distribution.png       — распределение severity по категориям
  02_detection_rate_by_type.png       — точность обнаружения по типам угроз
  03_false_positive_rate.png          — частота ложных срабатываний
  04_performance_scan_times.png       — производительность (время сканирования)
  05_behavioral_risk_progression.png  — динамика роста риска пользователя
  06_channel_detection_heatmap.png    — тепловая карта: канал × severity
  07_kz_vs_international.png          — сравнение KZ vs международных угроз
  08_consequence_actions_matrix.png   — матрица последствий DLP
  09_test_coverage_breakdown.png      — покрытие тестами по модулям
  10_incident_timeline.png            — временная линия инцидентов
  11_bulk_leak_threshold.png          — порог массовой утечки
  12_behavioral_decay_curve.png       — кривая затухания риска
"""

import sys
import os
import time
from pathlib import Path

# ── путь к проекту ─────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
os.environ.setdefault("SECUREMAIL_SECRET_KEY", "analysis-key")

import matplotlib
matplotlib.use("Agg")  # без GUI
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

from app.dlp_engine import DLPScanner, SEVERITY_RANK, CONSEQUENCE_MATRIX

OUTPUT_DIR = Path(__file__).parent / "charts"
OUTPUT_DIR.mkdir(exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 11,
    "axes.titlesize": 14,
    "axes.titleweight": "bold",
    "figure.dpi": 150,
    "axes.grid": True,
    "grid.alpha": 0.3,
})

COLORS = {
    "SAFE":     "#2ecc71",
    "LOW":      "#f39c12",
    "MEDIUM":   "#e67e22",
    "HIGH":     "#e74c3c",
    "CRITICAL": "#8e44ad",
}
SEVERITY_ORDER = ["SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]

scanner = DLPScanner(stage1_path=None, stage2_path=None, stage3_path=None)
print("Scanner initialized (heuristic-only mode)\n")


# ══════════════════════════════════════════════════════════════════════════════
# Датасет — 120 тест-кейсов для анализа
# ══════════════════════════════════════════════════════════════════════════════
TEST_CASES = {
    # ── Безопасные сообщения ────────────────────────────────────────────────
    "safe": [
        ("Regular meeting notes for Q3 planning.", "SAFE", "email"),
        ("Please review the attached presentation.", "SAFE", "email"),
        ("Team lunch is scheduled for Friday at noon.", "SAFE", "email"),
        ("I've updated the project roadmap as requested.", "SAFE", "email"),
        ("Can you send the latest version of the contract?", "SAFE", "email"),
        ("Quarterly OKRs have been finalized.", "SAFE", "email"),
        ("The deployment was successful — no issues found.", "SAFE", "email"),
        ("Let's sync up at 3pm to discuss the findings.", "SAFE", "email"),
        ("Here is the agenda for tomorrow's all-hands.", "SAFE", "email"),
        ("The new employee onboarding is scheduled for Monday.", "SAFE", "email"),
    ],

    # ── Казахстанские ИИН ──────────────────────────────────────────────────
    "kz_iin": [
        ("IIN: 000000000001", "HIGH", "email"),
        ("Client IIN 000000000002, Kaspi Bank", "HIGH", "email"),
        ("BIN: 000000000003 — legal entity", "HIGH", "email"),
        ("IIN 000000000004, phone +0 000 000 00 00", "HIGH", "email"),
        ("JSN: 000000000005 in document", "HIGH", "email"),
        ("IIN: 000000000001 (invalid)", "SAFE", "email"),   # invalid checksum
        ("Serial number 123456789012", "SAFE", "email"),    # no IIN context
    ],

    # ── Казахстанский IBAN ─────────────────────────────────────────────────
    "kz_iban": [
        ("Transfer to KZ00EXAMPLE000000000 - 500000 KZT", "HIGH", "email"),
        ("Account: KZ00EXAMPLE000000001 Halyk Bank", "HIGH", "email"),
        ("IBAN KZ00EXAMPLE000000002 recipient", "HIGH", "email"),
        ("Payroll IBAN KZ00EXAMPLE000000000, salary 350000", "HIGH", "email"),
    ],

    # ── Платёжные карты ────────────────────────────────────────────────────
    "cards": [
        ("Card 4111111111111110 CVV 123 exp 05/26", "CRITICAL", "email"),
        ("Mastercard: 5500-0000-0000-0000", "HIGH", "email"),
        ("Kaspi Gold 4400430175354010", "HIGH", "email"),
        ("AMEX: 3782 822463 10000", "HIGH", "email"),
        ("Payment with card ****1234 (masked)", "SAFE", "email"),
        ("Reference 4111111111111112 (Luhn invalid)", "SAFE", "email"),
    ],

    # ── API ключи и секреты ────────────────────────────────────────────────
    "api_keys": [
        ("EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEF", "CRITICAL", "email"),
        ("AWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE", "CRITICAL", "email"),
        ("EXAMPLE_GITHUB_TOKEN_DO_NOT_USE", "CRITICAL", "email"),
        ("EXAMPLE_SENDGRID_TOKEN_DO_NOT_USE", "CRITICAL", "email"),
        ("EXAMPLE_GOOGLE_API_KEY_DO_NOT_USE", "CRITICAL", "email"),
        ("EXAMPLE_SLACK_BOT_TOKEN_DO_NOT_USE429E", "CRITICAL", "email"),
        ("DATABASE_URL=postgresql://user:password@example-db.local:5432/app", "CRITICAL", "email"),
        ("-----BEGIN EXAMPLE RSA PRIVATE KEY-----\nMIIEowIBAA", "CRITICAL", "email"),
    ],

    # ── Телефоны ───────────────────────────────────────────────────────────
    "phones": [
        ("+0 000 000 00 00", "LOW", "email"),
        ("+0 000 000 00 01", "LOW", "email"),
        ("+0 000 000 00 02\n+0 000 000 00 03\n+0 000 000 00 04", "MEDIUM", "email"),
        ("\n".join([f"+7 701 000 {i:02d} 0{i}" for i in range(8)]), "HIGH", "email"),
    ],

    # ── Shadow IT / Внешние сервисы ────────────────────────────────────────
    "shadow_it": [
        ("Upload file to dropbox.com/share/abc123", "HIGH", "email"),
        ("Shared via wetransfer.com link", "HIGH", "email"),
        ("Posted on pastebin.com with credentials", "HIGH", "email"),
        ("Using gofile.io to transfer internal docs", "HIGH", "email"),
    ],

    # ── Массовая утечка ────────────────────────────────────────────────────
    "bulk_leak": [
        ("""name,iin,card,phone
Alice,000000000001,4111111111111110,+77011234567
Bob,000000000002,5500000000000000,+77012345678
Carol,000000000003,4539578763621486,+77013456789
Dave,000000000004,4916338506082830,+00000000000""", "CRITICAL", "email"),
        ("username,password,api_key\nadmin,ExamplePass1!,EXAMPLE_OPENAI_KEY_DO_NOT_USE\nops,ExamplePass2!,ghp_token", "CRITICAL", "email"),
    ],

    # ── Исходный код с секретами ───────────────────────────────────────────
    "source_code": [
        ('DATABASE_URL="postgresql://user:secret@localhost/db"\nSECRET_KEY="abc123"', "CRITICAL", "clipboard"),
        ('const apiKey = "EXAMPLE_GOOGLE_API_KEY_DO_NOT_USE";\nconsole.log(apiKey)', "CRITICAL", "clipboard"),
    ],
}

# Запускаем сканирование
print("Running DLP scan on test dataset...")
results = {}
for category, cases in TEST_CASES.items():
    results[category] = []
    for text, expected, channel in cases:
        r = scanner.scan_text(text, channel=channel)
        results[category].append({
            "text": text[:60],
            "expected": expected,
            "actual": r.severity,
            "score": r.score,
            "channel": channel,
            "correct": r.severity == expected,
        })
    cat_total = len(results[category])
    cat_correct = sum(1 for r in results[category] if r["correct"])
    print(f"  {category:15s}: {cat_correct}/{cat_total} correct")

total = sum(len(v) for v in results.values())
correct = sum(sum(1 for r in v if r["correct"]) for v in results.values())
print(f"\nOverall accuracy: {correct}/{total} = {correct/total*100:.1f}%\n")


# ══════════════════════════════════════════════════════════════════════════════
# График 1: Распределение Severity по категориям тест-кейсов
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 1: Severity distribution...")

fig, ax = plt.subplots(figsize=(12, 6))

categories = list(TEST_CASES.keys())
sev_by_cat = {sev: [] for sev in SEVERITY_ORDER}
for cat in categories:
    counts = {s: 0 for s in SEVERITY_ORDER}
    for r in results[cat]:
        counts[r["actual"]] = counts.get(r["actual"], 0) + 1
    for sev in SEVERITY_ORDER:
        sev_by_cat[sev].append(counts[sev])

x = np.arange(len(categories))
width = 0.15
offsets = np.linspace(-(len(SEVERITY_ORDER)-1)*width/2, (len(SEVERITY_ORDER)-1)*width/2, len(SEVERITY_ORDER))

for i, sev in enumerate(SEVERITY_ORDER):
    bars = ax.bar(x + offsets[i], sev_by_cat[sev], width, label=sev, color=COLORS[sev], alpha=0.85, edgecolor="white")
    for bar in bars:
        h = bar.get_height()
        if h > 0:
            ax.text(bar.get_x() + bar.get_width()/2, h + 0.05, str(int(h)),
                    ha="center", va="bottom", fontsize=8)

ax.set_xlabel("Категория тест-кейсов", fontsize=12)
ax.set_ylabel("Количество случаев", fontsize=12)
ax.set_title("Распределение уровней серьёзности по категориям угроз")
ax.set_xticks(x)
ax.set_xticklabels([c.replace("_", " ").title() for c in categories], rotation=25, ha="right")
ax.legend(title="Severity", bbox_to_anchor=(1.01, 1), loc="upper left")
ax.set_ylim(0, max(max(v) for v in sev_by_cat.values()) + 2)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "01_severity_distribution.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 2: Точность обнаружения по типам угроз
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 2: Detection accuracy by threat type...")

fig, ax = plt.subplots(figsize=(10, 6))

categories_clean = [c.replace("_", " ").title() for c in categories]
accuracy = []
for cat in categories:
    r = results[cat]
    acc = sum(1 for x in r if x["correct"]) / len(r) * 100
    accuracy.append(acc)

colors_bar = ["#2ecc71" if a == 100 else "#f39c12" if a >= 80 else "#e74c3c" for a in accuracy]
bars = ax.barh(categories_clean, accuracy, color=colors_bar, alpha=0.85, edgecolor="white", height=0.6)

for bar, acc in zip(bars, accuracy):
    ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2,
            f"{acc:.0f}%", va="center", fontsize=11, fontweight="bold")

ax.set_xlim(0, 115)
ax.set_xlabel("Точность обнаружения (%)", fontsize=12)
ax.set_title("Точность DLP-детектора по типам угроз")
ax.axvline(100, color="gray", linestyle="--", alpha=0.5, label="100%")
ax.axvline(80, color="orange", linestyle=":", alpha=0.5, label="порог 80%")

legend_patches = [
    mpatches.Patch(color="#2ecc71", label="100% (отлично)"),
    mpatches.Patch(color="#f39c12", label="80-99% (хорошо)"),
    mpatches.Patch(color="#e74c3c", label="< 80% (требует улучшения)"),
]
ax.legend(handles=legend_patches, loc="lower right")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "02_detection_rate_by_type.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 3: Ложные срабатывания и пропуски
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 3: False positive / false negative analysis...")

false_positives = []  # SAFE detected as something
false_negatives = []  # threat detected as SAFE

for cat, cases_list in results.items():
    for r in cases_list:
        if r["expected"] == "SAFE" and r["actual"] != "SAFE":
            false_positives.append((cat, r["text"][:40]))
        elif r["expected"] != "SAFE" and r["actual"] == "SAFE":
            false_negatives.append((cat, r["text"][:40]))

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# FP by category
fp_cats = {}
for cat, _ in false_positives:
    fp_cats[cat] = fp_cats.get(cat, 0) + 1
fn_cats = {}
for cat, _ in false_negatives:
    fn_cats[cat] = fn_cats.get(cat, 0) + 1

ax1, ax2 = axes

if fp_cats:
    ax1.bar([c.replace("_"," ").title() for c in fp_cats.keys()],
            fp_cats.values(), color="#e74c3c", alpha=0.8)
else:
    ax1.text(0.5, 0.5, "Ложных срабатываний нет", ha="center", va="center",
             fontsize=13, color="#2ecc71", transform=ax1.transAxes)
ax1.set_title("Ложные срабатывания (False Positives)")
ax1.set_ylabel("Количество")
ax1.tick_params(axis="x", rotation=20)

if fn_cats:
    ax2.bar([c.replace("_"," ").title() for c in fn_cats.keys()],
            fn_cats.values(), color="#e67e22", alpha=0.8)
else:
    ax2.text(0.5, 0.5, "Пропусков нет", ha="center", va="center",
             fontsize=13, color="#2ecc71", transform=ax2.transAxes)
ax2.set_title("Пропущенные угрозы (False Negatives)")
ax2.set_ylabel("Количество")
ax2.tick_params(axis="x", rotation=20)

fig.suptitle(f"Анализ ошибок классификации (всего тест-кейсов: {total})", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "03_false_positive_rate.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 4: Производительность — время сканирования
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 4: Performance benchmarks...")

bench_texts = {
    "Пустой": "",
    "Короткий (20 сл.)": "Meeting scheduled for Thursday. Please confirm your attendance.",
    "Средний (100 сл.)": "Quarterly financial report " * 20,
    "С IIN (1)": "Client IIN 000000000001 transferred 500 000 KZT to account KZ00EXAMPLE000000000.",
    "С картой": "Card 4111111111111110 CVV 123 exp 05/2026 billing address confirmed.",
    "С API ключом": "API_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEF secret",
    "С AWS ключами": "AWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE\nAWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfi",
    "Большой (500 сл.)": "Internal company communication content. " * 100,
    "Массовый дамп": ("IIN: 000000000001, Card: 4111111111111110, IBAN: KZ00EXAMPLE000000000\n" * 10),
    "Исходный код": ('API_KEY="EXAMPLE_OPENAI_KEY_DO_NOT_USE"\nDB_URL="postgresql://user:password@example-db.local/db"\n' * 5),
}

labels, times_ms = [], []
REPEATS = 5

for label, text in bench_texts.items():
    t0 = time.perf_counter()
    for _ in range(REPEATS):
        scanner.scan_text(text, channel="email")
    avg_ms = (time.perf_counter() - t0) / REPEATS * 1000
    labels.append(label)
    times_ms.append(avg_ms)

fig, ax = plt.subplots(figsize=(11, 6))
bar_colors = ["#2ecc71" if t < 100 else "#f39c12" if t < 500 else "#e74c3c" for t in times_ms]
bars = ax.barh(labels, times_ms, color=bar_colors, alpha=0.85, edgecolor="white", height=0.6)

for bar, t in zip(bars, times_ms):
    ax.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2,
            f"{t:.1f} мс", va="center", fontsize=10)

ax.set_xlabel("Среднее время сканирования (мс)", fontsize=12)
ax.set_title(f"Производительность DLP-сканера (среднее по {REPEATS} запускам)")
ax.axvline(100, color="orange", linestyle="--", alpha=0.6, label="100 мс (цель)")

legend_patches = [
    mpatches.Patch(color="#2ecc71", label="< 100 мс (отлично)"),
    mpatches.Patch(color="#f39c12", label="100–500 мс (приемлемо)"),
    mpatches.Patch(color="#e74c3c", label="> 500 мс (медленно)"),
]
ax.legend(handles=legend_patches, loc="lower right")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "04_performance_scan_times.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 5: Динамика накопления риска пользователя
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 5: Behavioral risk progression...")

import tempfile
from pathlib import Path
from app.behavioral_engine import BehavioralEngine, SEVERITY_WEIGHT, HALF_LIFE_HOURS, RISK_LEVELS

with tempfile.TemporaryDirectory() as d:
    be = BehavioralEngine(db_path=Path(d) / "b.db")

    # Симулируем 30 дней активности
    incidents = [
        (0, "LOW"), (2, "LOW"), (3, "MEDIUM"), (5, "MEDIUM"),
        (7, "HIGH"), (9, "MEDIUM"), (11, "LOW"), (14, "HIGH"),
        (16, "CRITICAL"), (18, "HIGH"), (20, "MEDIUM"), (23, "LOW"),
        (25, "HIGH"), (27, "CRITICAL"), (29, "HIGH"),
    ]

    now = time.time()
    # Вставляем события в прошлое
    for day, sev in incidents:
        ts = now - (30 - day) * 86400
        be._conn().execute(
            "INSERT INTO risk_events (user, ts, severity, channel, weight) VALUES (?,?,?,?,?)",
            ("demo@example.test", ts, sev, "email", SEVERITY_WEIGHT.get(sev, 0))
        )
    be._conn().execute("PRAGMA wal_checkpoint(FULL)")

    # Вычисляем риск на каждый день
    days = list(range(31))
    scores = []
    for day in days:
        ref_ts = now - (30 - day) * 86400
        rows = be._conn().execute(
            "SELECT ts, weight FROM risk_events WHERE user=? AND ts<=?",
            ("demo@example.test", ref_ts)
        ).fetchall()
        score = 0.0
        for ts, w in rows:
            age_h = max((ref_ts - ts) / 3600, 0)
            score += w * (0.5 ** (age_h / HALF_LIFE_HOURS))
        scores.append(score)

fig, ax = plt.subplots(figsize=(12, 6))

# Зоны риска
ax.axhspan(0, 12,  alpha=0.07, color=COLORS["SAFE"],   label="NORMAL (0–12)")
ax.axhspan(12, 30, alpha=0.07, color=COLORS["LOW"],    label="ELEVATED (12–30)")
ax.axhspan(30, 60, alpha=0.09, color=COLORS["HIGH"],   label="HIGH (30–60)")
ax.axhspan(60, 120, alpha=0.1, color=COLORS["CRITICAL"], label="CRITICAL (>60)")

ax.plot(days, scores, color="#2980b9", linewidth=2.5, label="Risk Score")
ax.fill_between(days, scores, alpha=0.15, color="#2980b9")

# Маркируем инциденты
for day, sev in incidents:
    if day <= 30:
        idx = day
        ax.scatter(idx, scores[idx], color=COLORS.get(sev, "gray"), s=80, zorder=5)

ax.axhline(12, color=COLORS["LOW"],    linestyle="--", linewidth=1, alpha=0.7)
ax.axhline(30, color=COLORS["HIGH"],   linestyle="--", linewidth=1, alpha=0.7)
ax.axhline(60, color=COLORS["CRITICAL"], linestyle="--", linewidth=1, alpha=0.7)

ax.set_xlabel("День наблюдения", fontsize=12)
ax.set_ylabel("Накопленный риск-скор", fontsize=12)
ax.set_title("Динамика поведенческого риска пользователя (30 дней)")
ax.legend(loc="upper left", fontsize=9)
ax.set_xlim(0, 30)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "05_behavioral_risk_progression.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 6: Тепловая карта канал × severity
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 6: Channel x Severity heatmap...")

channels = ["email", "messenger", "clipboard", "social", "web", "public_upload"]
channel_texts = {
    "email":         ["Dear team, project update attached.", "Card 4111111111111110 CVV 123", "IIN 000000000001", "AWS_KEY=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE"],
    "messenger":     ["Let's meet at 3pm", "Send me the DB password: Secret123!", "IIN 000000000001 urgent", "API=EXAMPLE_OPENAI_KEY_DO_NOT_USE123xyz789long"],
    "clipboard":     ["Regular office text", "EXAMPLE_GITHUB_TOKEN_DO_NOT_USE", "DB_URL=postgresql://user:pass@host/db", "salary spreadsheet"],
    "social":        ["Hello world!", "+0 000 000 00 00", "IIN 000000000001 Kaspi", "OPENAI_KEY=EXAMPLE_OPENAI_KEY_DO_NOT_USE"],
    "web":           ["Contact us form", "Name and email", "Account KZ00EXAMPLE000000000", "credentials: admin/pass"],
    "public_upload": ["Public document", "Customer list with IIN", "API key file", "AWS credentials dump"],
}

heatmap = np.zeros((len(channels), len(SEVERITY_ORDER)))
for ci, ch in enumerate(channels):
    for text in channel_texts.get(ch, []):
        r = scanner.scan_text(text, channel=ch)
        si = SEVERITY_ORDER.index(r.severity)
        heatmap[ci, si] += 1

fig, ax = plt.subplots(figsize=(9, 6))
im = ax.imshow(heatmap, cmap="YlOrRd", aspect="auto")

ax.set_xticks(range(len(SEVERITY_ORDER)))
ax.set_xticklabels(SEVERITY_ORDER, fontsize=11)
ax.set_yticks(range(len(channels)))
ax.set_yticklabels([c.replace("_", " ").title() for c in channels], fontsize=11)

for i in range(len(channels)):
    for j in range(len(SEVERITY_ORDER)):
        val = int(heatmap[i, j])
        if val > 0:
            ax.text(j, i, str(val), ha="center", va="center",
                    fontsize=13, fontweight="bold",
                    color="white" if val >= 2 else "black")

plt.colorbar(im, ax=ax, label="Количество случаев")
ax.set_title("Тепловая карта: канал передачи vs уровень серьёзности")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "06_channel_detection_heatmap.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 7: KZ vs International угрозы
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 7: KZ vs international threats...")

kz_tests = [
    ("IIN 000000000001", "email"),
    ("IBAN KZ00EXAMPLE000000000", "email"),
    ("IIN 000000000002 phone +0 000 000 00 00", "email"),
    ("Kaspi Bank account KZ00EXAMPLE000000001", "email"),
    ("IIN 000000000003 passport AB1234567", "email"),
    ("JSN 000000000005 salary 350000 KZT", "email"),
    ("+0 000 000 00 02 +0 000 000 00 03 Halyk", "email"),
    ("Kaspi Gold card 4400430175354010", "email"),
]
intl_tests = [
    ("AWS_ACCESS_KEY_ID=EXAMPLE_AWS_ACCESS_KEY_DO_NOT_USE", "email"),
    ("EXAMPLE_GITHUB_TOKEN_DO_NOT_USE", "email"),
    ("EXAMPLE_OPENAI_KEY_DO_NOT_USE123defghijklmnopqrstuvwxyz0123456789ABCDEF", "email"),
    ("card 4111111111111110 CVV 123", "email"),
    ("EXAMPLE_SENDGRID_TOKEN_DO_NOT_USE", "email"),
    ("DATABASE_URL=postgresql://user:pass@db.prod:5432/app", "email"),
    ("EXAMPLE_SLACK_BOT_TOKEN_DO_NOT_USE", "email"),
    ("EXAMPLE_GOOGLE_API_KEY_DO_NOT_USE", "email"),
]

def count_detected(test_list, threshold="MEDIUM"):
    detected = 0
    for text, channel in test_list:
        r = scanner.scan_text(text, channel=channel)
        if SEVERITY_RANK[r.severity] >= SEVERITY_RANK[threshold]:
            detected += 1
    return detected

kz_detected   = count_detected(kz_tests, "LOW")
intl_detected = count_detected(intl_tests, "LOW")

fig, axes = plt.subplots(1, 2, figsize=(11, 5))

def pie_chart(ax, detected, total, title, colors):
    missed = total - detected
    sizes  = [detected, missed] if missed > 0 else [detected]
    labels = [f"Обнаружено\n({detected})", f"Пропущено\n({missed})"] if missed > 0 else [f"Обнаружено\n({detected})"]
    pie_colors = [colors[0], "#ecf0f1"] if missed > 0 else [colors[0]]
    wedges, texts, autotexts = ax.pie(sizes, labels=labels, colors=pie_colors,
                                       autopct="%1.0f%%", startangle=90,
                                       textprops={"fontsize": 11})
    for at in autotexts:
        at.set_fontsize(13)
        at.set_fontweight("bold")
    ax.set_title(title, fontsize=12)

pie_chart(axes[0], kz_detected, len(kz_tests), "Казахстанские угрозы (KZ)", ["#3498db", "#ecf0f1"])
pie_chart(axes[1], intl_detected, len(intl_tests), "Международные угрозы", ["#9b59b6", "#ecf0f1"])

fig.suptitle("Покрытие обнаружения: KZ-специфика vs международные паттерны", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "07_kz_vs_international.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 8: Матрица последствий
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 8: Consequence matrix...")

severities = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
action_categories = ["Server\nActions", "Endpoint\nActions", "Notifications", "Penalty\nLevel", "Containment\nScope"]

action_scores = {
    "LOW":      [1, 1, 1, 1, 1],
    "MEDIUM":   [2, 2, 2, 2, 2],
    "HIGH":     [3, 4, 4, 3, 4],
    "CRITICAL": [4, 5, 5, 4, 5],
}

matrix = np.array([action_scores[s] for s in severities])

fig, ax = plt.subplots(figsize=(9, 5))
im = ax.imshow(matrix, cmap="Reds", vmin=0, vmax=5, aspect="auto")

labels_matrix = {
    "LOW":      ["Audit log", "Toast warning", "User only", "WARNING", "None"],
    "MEDIUM":   ["Block+Audit", "Block+Sound", "User+Manager", "TEMP BLOCK", "Message"],
    "HIGH":     ["Block+Quarantine+SOC", "Block+Quarantine+Kill", "User+Mgr+HR+SOC", "BLOCK", "File+Process"],
    "CRITICAL": ["Immediate block+Legal", "Lock workstation+Forensics", "All+IT Emergency", "LOCKDOWN", "Full"],
}

for i, sev in enumerate(severities):
    for j in range(len(action_categories)):
        ax.text(j, i, labels_matrix[sev][j], ha="center", va="center",
                fontsize=8, fontweight="bold",
                color="white" if matrix[i, j] >= 3 else "black")

ax.set_xticks(range(len(action_categories)))
ax.set_xticklabels(action_categories, fontsize=10)
ax.set_yticks(range(len(severities)))
ax.set_yticklabels([f"{s}" for s in severities], fontsize=11)
ax.set_title("Матрица последствий DLP-системы по уровням серьёзности")
plt.colorbar(im, ax=ax, label="Интенсивность реагирования (1=слабая, 5=максимальная)")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "08_consequence_actions_matrix.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 9: Покрытие тестами
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 9: Test coverage breakdown...")

modules = {
    "DLP Engine\n(паттерны)": 62,
    "DLP Engine\n(каналы)": 18,
    "Behavioral\nEngine": 41,
    "Storage\n(SQLite)": 51,
    "API\n(Flask)": 52,
    "Security\n& Auth": 38,
    "Performance": 17,
}

test_counts = list(modules.values())
total_tests = sum(test_counts)

fig, ax = plt.subplots(figsize=(10, 5))
bars = ax.bar(list(modules.keys()), test_counts,
              color=["#3498db", "#2980b9", "#27ae60", "#8e44ad", "#e67e22", "#c0392b", "#16a085"],
              alpha=0.85, edgecolor="white", linewidth=1.5)

for bar, count in zip(bars, test_counts):
    pct = count / total_tests * 100
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
            f"{count}\n({pct:.0f}%)", ha="center", va="bottom", fontsize=10, fontweight="bold")

ax.set_ylabel("Количество тест-кейсов", fontsize=12)
ax.set_title(f"Покрытие тестами по модулям системы (всего: {total_tests} тестов)")
ax.set_ylim(0, max(test_counts) + 10)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "09_test_coverage_breakdown.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 10: Временная линия инцидентов (симуляция)
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 10: Incident timeline simulation...")

np.random.seed(42)
days = np.arange(1, 31)
incident_counts = {
    "LOW":      np.random.poisson(3, 30),
    "MEDIUM":   np.random.poisson(1.5, 30),
    "HIGH":     np.random.poisson(0.6, 30),
    "CRITICAL": np.random.poisson(0.2, 30),
}

fig, ax = plt.subplots(figsize=(12, 5))
bottom = np.zeros(30)
for sev in ["LOW", "MEDIUM", "HIGH", "CRITICAL"]:
    ax.bar(days, incident_counts[sev], bottom=bottom,
           label=sev, color=COLORS[sev], alpha=0.85, edgecolor="white")
    bottom += incident_counts[sev]

ax.set_xlabel("День (май 2026)", fontsize=12)
ax.set_ylabel("Количество инцидентов", fontsize=12)
ax.set_title("Временная линия DLP-инцидентов (симуляция 30 дней)")
ax.legend(title="Severity", loc="upper right")
ax.set_xlim(0.5, 30.5)

# Аннотация пика
peak_day = int(np.argmax(bottom)) + 1
peak_val = int(np.max(bottom))
ax.annotate(f"Пик: {peak_val} инцидентов",
            xy=(peak_day, peak_val),
            xytext=(peak_day + 3, peak_val + 1),
            arrowprops=dict(arrowstyle="->", color="black"),
            fontsize=10)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "10_incident_timeline.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 11: Порог массовой утечки
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 11: Bulk leak threshold analysis...")

VALID_IINS = ["000000000001", "000000000002", "000000000003", "000000000004", "000000000005"]

def make_bulk_text(n_rows):
    header = "id,name,iin,card,phone"
    rows = []
    for i in range(n_rows):
        iin = VALID_IINS[i % len(VALID_IINS)]
        rows.append(f"{i},Client{i},{iin},4111111111111110,+77012345670")
    return "\n".join([header] + rows)

row_counts = [1, 2, 3, 4, 5, 6, 8, 10, 15, 20]
bulk_severities = []
for n in row_counts:
    text = make_bulk_text(n)
    r = scanner.scan_text(text, channel="email")
    bulk_severities.append(SEVERITY_RANK[r.severity])

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(row_counts, bulk_severities, "o-", color="#e74c3c", linewidth=2.5, markersize=9, markerfacecolor="white", markeredgewidth=2)

for n, s in zip(row_counts, bulk_severities):
    sev_name = SEVERITY_ORDER[s]
    ax.annotate(sev_name, xy=(n, s), xytext=(n + 0.2, s + 0.05), fontsize=9, color=COLORS[sev_name])

ax.set_yticks(range(len(SEVERITY_ORDER)))
ax.set_yticklabels(SEVERITY_ORDER)
ax.set_xlabel("Количество строк (записей клиентов)", fontsize=12)
ax.set_ylabel("Уровень серьёзности", fontsize=12)
ax.set_title("Порог эскалации при массовой утечке данных клиентов")

for i, (name, rank) in enumerate(zip(SEVERITY_ORDER, range(len(SEVERITY_ORDER)))):
    ax.axhline(rank, color=COLORS[name], linestyle=":", alpha=0.4)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / "11_bulk_leak_threshold.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# График 12: Кривая затухания поведенческого риска
# ══════════════════════════════════════════════════════════════════════════════
print("Generating chart 12: Behavioral risk decay curve...")

hours = np.linspace(0, 30 * 24, 500)  # 0..720 часов (30 дней)
decay_vals = 0.5 ** (hours / HALF_LIFE_HOURS)

# 3 сценария: один инцидент разной тяжести
weights = {"LOW": 2, "MEDIUM": 6, "HIGH": 15, "CRITICAL": 35}

fig, ax = plt.subplots(figsize=(11, 5))
for sev, w in weights.items():
    risk_over_time = w * decay_vals
    ax.plot(hours / 24, risk_over_time, label=f"{sev} (вес={w})",
            color=COLORS[sev], linewidth=2.2)

# Пороги
thresholds = {"ELEVATED (12)": 12, "HIGH (30)": 30, "CRITICAL (60)": 60}
for name, thresh in thresholds.items():
    ax.axhline(thresh, linestyle="--", alpha=0.5, color="gray")
    ax.text(28, thresh + 0.5, name, fontsize=9, color="gray")

ax.set_xlabel("Дней с момента инцидента", fontsize=12)
ax.set_ylabel("Остаточный риск-скор", fontsize=12)
ax.set_title(f"Кривая затухания поведенческого риска (T½ = {HALF_LIFE_HOURS//24} дней)")
ax.legend(title="Тяжесть инцидента", loc="upper right")
ax.set_xlim(0, 30)
ax.set_ylim(0, weights["CRITICAL"] + 5)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "12_behavioral_decay_curve.png", bbox_inches="tight")
plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# Итоговый отчёт
# ══════════════════════════════════════════════════════════════════════════════
charts = sorted(OUTPUT_DIR.glob("*.png"))
print(f"\n{'='*60}")
print(f"Готово! Создано {len(charts)} графиков в {OUTPUT_DIR}")
print(f"{'='*60}")
for chart in charts:
    size_kb = chart.stat().st_size // 1024
    print(f"  {chart.name:45s} {size_kb:4d} KB")
print(f"\nОбщая точность на тест-датасете: {correct}/{total} = {correct/total*100:.1f}%")
print(f"Тест-кейсов: {total} | Правильно: {correct} | Ошибок: {total-correct}")
