$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path

Start-Process powershell -ArgumentList "-NoExit", "-ExecutionPolicy", "Bypass", "-File", (Join-Path $root "start_local_site.ps1")
Start-Sleep -Seconds 3
Start-Process powershell -ArgumentList "-NoExit", "-ExecutionPolicy", "Bypass", "-File", (Join-Path $root "start_windows_app.ps1")

Write-Host "SecureMail local stack started."
Write-Host "Site: http://127.0.0.1:5000/"
Write-Host "Admin: http://127.0.0.1:5000/admin"
