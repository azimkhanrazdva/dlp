# Architecture Site

Open [index.html](./index.html) directly in a browser to view the standalone architecture page for the diploma presentation.

For a single-slide printable scheme in A4 landscape format, open:
- [a4_landscape_architecture.html](./a4_landscape_architecture.html)

What is included:
- detailed SecureMail AI-DLP architecture layout
- component descriptions
- implementation flow
- privacy/governance explanation
- technology stack summary
- A4 landscape architecture sheet for screenshots or printing

Suggested use:
- take screenshots for the `Architecture / Implementation` slide
- use the page itself during rehearsal or live demo explanation
