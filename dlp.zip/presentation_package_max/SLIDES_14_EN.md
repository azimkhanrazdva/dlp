# SecureMail AI-DLP Presentation Structure

## Slide 1. Title
Title:
Development of AI-Based Model for Detecting Confidential Data Leakage in Electronic Communications as a Cybersecurity Measure

On-slide text:
- Student: [Your Full Name]
- Group: [Your Group]
- Supervisor: [Supervisor Name]
- Astana IT University

Visual:
- Minimal title slide with project name and logo

## Slide 2. Outline
On-slide text:
1. Problem Statement
2. Research Methods
3. Data and Experimental Design
4. Preliminary Research Results
5. Comparative Analysis
6. Research Tool
7. Project Prototype
8. Architecture
9. Privacy and Governance
10. Conclusion

Visual:
- Clean numbered outline

## Slide 3. Problem Statement
On-slide text:
- Confidential data leakage remains a critical cybersecurity problem in enterprise communications
- Sensitive data can be leaked through emails, files, screenshots, archives, USB devices, and endpoint actions
- Traditional DLP systems rely heavily on static rules and often produce excessive false positives
- Project goal: develop an AI-based DLP model and applied prototype for risk-aware leakage detection

Visual:
- Optional small examples of leak channels

## Slide 4. Research Methods
On-slide text:
- Analytical method: literature review and DLP market analysis
- Engineering method: architecture, data pipeline, web platform, endpoint integration
- Experimental method: model training, validation, runtime benchmarking
- Hybrid approach: multilingual BERT + specialist model + deterministic rules

Visual:
- assets/research_methods.svg

## Slide 5. Data and Experimental Design
On-slide text:
- Main dataset: joint_v3
- Total size: 45,764 labeled samples
- Split: 33,017 train / 6,358 validation / 6,389 test
- Sources: synthetic enterprise scenarios + ai4privacy + Isotonic
- Classes: SAFE, LOW, MEDIUM, HIGH, CRITICAL

Visual:
- assets/dataset_construction.svg

## Slide 6. Core Model and Pipeline
On-slide text:
- Base model: bert-base-multilingual-cased
- Fine-tuned for five severity classes
- Python, PyTorch, Hugging Face Transformers, scikit-learn
- OCR, file extraction, archive parsing, endpoint-aware logic
- Runtime mode: consensus DLP scanner

Visual:
- simplified pipeline icon strip or architecture thumbnail

## Slide 7. Preliminary Research Results
On-slide text:
- Test accuracy: 96.37%
- Macro F1-score: 96.57%
- Weighted F1-score: 96.35%
- Strongest class: CRITICAL
- Hardest class: MEDIUM

Visual:
- assets/results_f1.svg

## Slide 8. Misclassification Dynamics
On-slide text:
- The model shows strong diagonal clustering in the confusion matrix
- Most errors occur between adjacent severity levels
- MEDIUM is the most ambiguous class because it overlaps with both low-risk contacts and high-risk personal data
- CRITICAL is detected almost perfectly

Visual:
- assets/confusion_matrix.svg

## Slide 9. Runtime Evaluation
On-slide text:
- Mixed benchmark accuracy: 94.42%
- Runtime macro F1-score: 94.36%
- Noise false-positive rate: 1.08%
- Specialist benchmark accuracy: 100%
- Strong evidence for banking exports, OCR cases, and secret leakage detection

Visual:
- small metrics card layout

## Slide 10. Comparative Analysis
On-slide text:
- Synthetic-only training overfits artificial patterns
- Real-only training undercovers enterprise leak scenarios
- Joint training generalizes better across both synthetic and real data
- Therefore, the hybrid dataset strategy is experimentally justified

Visual:
- assets/training_comparison.svg

## Slide 11. Research Tool
On-slide text:
- Research tool: SecureMail AI-DLP platform
- Components:
  - AI classifier
  - specialist leak detector
  - web administration system
  - Windows endpoint app and agent
  - privacy-preserving access workflow

Visual:
- assets/system_architecture.svg

## Slide 12. Project Prototype
On-slide text:
- Mailbox UI and message review
- Admin panel with incidents and account governance
- Attachment, image, and archive analysis
- Windows endpoint monitoring for clipboard, files, and USB inventory
- Role-based access and unlock/request workflows

Visual:
- assets/prototype_scope.svg
- plus your real screenshots if available

## Slide 13. Privacy and Governance
On-slide text:
- Privacy-by-default model
- SAFE/LOW correspondence is not openly visible to administrators
- MEDIUM cases require controlled approval workflow
- HIGH/CRITICAL cases are handled through incident-response logic
- Full content retention is limited to critical cases

Visual:
- assets/privacy_governance.svg

## Slide 14. Conclusion
On-slide text:
- Completed:
  - trained and evaluated AI-DLP model
  - built web prototype
  - integrated endpoint agent
  - validated specialist leak scenarios
- Remaining / future work:
  - improve MEDIUM class calibration
  - stronger production hardening
  - larger real multilingual datasets
  - broader enterprise deployment

Speaker ending:
- The project demonstrates that AI-based DLP can move beyond static rules and provide practical protection against confidential data leakage in modern electronic communications.
