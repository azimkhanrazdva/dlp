# Presentation Package

This folder contains a full 14-slide presentation structure for the diploma pre-defense / defense.

Files:
- `SLIDES_14_EN.md` - full slide-by-slide text in English
- `SPEAKER_NOTES_RU.md` - speaking notes in Russian
- `assets/` - ready visual diagrams in SVG format

Suggested usage:
1. Build the slides in PowerPoint, Canva, Google Slides, or Figma
2. Use the English slide text directly
3. Use the Russian speaker notes for oral delivery
4. Add 2-3 real screenshots of your web platform and Windows app on Slide 12

Recommended maximum:
- 14 slides

Key advantage of this structure:
- matches the logic of the max-score example
- matches the pre-defense criteria
- combines research + metrics + prototype + architecture
